# Making a DayBoard plugin

A plugin is a zip file renamed to `.dayboard-plugin`. It holds a `plugin.json` manifest and the file the manifest points to. There are two kinds:

- **Colour themes** change DayBoard's colours. They're data only, with no code. Each folder here is a complete theme you can copy as a starting point: `FadedCherry/`, `Terracotta/`, `Honey/` and `Sage/` keep DayBoard's own warm base (the "Dusty Plum" look) and change the accent, and `Classic/` is DayBoard's cool grey and indigo look from before 1.5.
- **Code plugins** add features: a page in the sidebar, a panel at the top of the Day view, reminders and so on. They're .NET libraries that DayBoard 1.3 or later loads. [`plugins-src/DailyCheckIn/`](../plugins-src/DailyCheckIn) is a complete example: it's the Daily check-in and Journal. [`plugins-src/Kanban/`](../plugins-src/Kanban), [`Matrix/`](../plugins-src/Matrix) and [`WeeklyReview/`](../plugins-src/WeeklyReview) are DayBoard's former Kanban, matrix and review views, and show DayBoard's task cards and drag and drop at work. [`src/DayBoard.Focus/`](../src/DayBoard.Focus) is another: Focus is written the same way, but it comes with DayBoard.

Add a plugin under **Settings › Plugins › Add plugin…**. It then shows in the checklist there, where it can be ticked or unticked. Adding a plugin with the same `id` again replaces it, so bump `version` when you change it. DayBoard asks before adding a code plugin, and marks it "Runs code" in the list.

## plugin.json

```json
{
  "format": "dayboard-plugin",
  "formatVersion": 1,
  "id": "yourname.theme.sunset",
  "name": "Sunset",
  "version": "1.0.0",
  "author": "Your name",
  "description": "One sentence about the plugin.",
  "kind": "theme",
  "minAppVersion": "1.1.0",
  "entry": "theme.json"
}
```

| Field | Rules |
|---|---|
| `format`, `formatVersion` | Always `dayboard-plugin` and `1`. |
| `id` | Lowercase words separated by dots, such as `yourname.theme.sunset`. It must be unique: it's how DayBoard tells plugins apart, and a code plugin's saved data belongs to its id. |
| `name` | Up to 60 characters. |
| `version` | Any short version text, such as `1.0.0`. |
| `author`, `description` | Optional. Up to 60 and 300 characters. The author is shown when DayBoard asks before adding a code plugin. |
| `kind` | `theme` or `code`. (`feature` was DayBoard 1.2's kind. DayBoard 1.3 asks for the plugin's new version instead.) |
| `apiVersion` | Code plugins only, and required: the plugin API version the plugin needs. DayBoard 1.3 has version `1`, DayBoard 1.4 has version `2`, which adds the members marked *API 2* below, and DayBoard 1.6 has version `3`, which adds those marked *API 3*. Use the lowest version that has what the plugin uses. |
| `minAppVersion` | Optional. The oldest DayBoard version the plugin works with. Themes need `1.1.0` or later, code plugins `1.3.0` (`1.4.0` with API 2, `1.6.0` with API 3). |
| `entry` | The file next to `plugin.json` that holds the plugin: `theme.json` for a theme, the plugin's `.dll` for a code plugin. |

## Colour themes

Put `plugin.json` and `theme.json` in a folder, zip the two files (or the folder itself), and rename the `.zip` to `.dayboard-plugin`. `build.ps1` does this for every folder here and writes the files to `artifacts\`.

### theme.json

Every section is optional, but a theme has to set at least one colour in `light` or `dark`. Colours are `#RRGGBB`, or `#AARRGGBB` when you need transparency. Anything a theme leaves out keeps DayBoard's own colour.

```json
{
  "accent": { "light": "#AD4A50", "dark": "#E3878C" },
  "priority": { "low": "#7E97B3", "medium": "#C9A04E", "high": "#8A6B8D" },
  "swatches": ["#7E97B3", "#7F86B0", "#9A88B5", "#C98A9A", "#B5666A", "#BF8B66",
               "#C9A04E", "#9AAA6A", "#7A9A6B", "#6F9A94", "#74A0AE", "#8C8478"],
  "light": { "Accent": "#FFAD4A50", "WindowBackground": "#FFF5F1EA" },
  "dark": { "Accent": "#FFE3878C", "WindowBackground": "#FF1F1D1A" }
}
```

- **`accent`**: the accent of the standard controls, such as tick boxes and the focus line under text boxes.
- **`priority`**: suggested priority colours. They're used only while a priority colour is still DayBoard's default. If someone picks their own, theirs wins.
- **`swatches`**: exactly 12 colours that stand in for DayBoard's own category colours, in this order: blue, indigo, violet, pink, red, orange, amber, lime, green, teal, cyan, slate. Categories keep their stored colour, so unticking the theme brings back DayBoard's own (muted) versions. DayBoard's preset calendar colours follow the nearest swatch.
- **`light`** and **`dark`**: the palette for each mode, using the slot names below. Unknown names are ignored, so a theme made for a newer DayBoard still loads.

### Palette slots

| Area | Slots |
|---|---|
| Window and panels | `WindowBackground`, `PanelBackground`, `ColumnBackground`, `ColumnBackgroundToday`, `ScrimBackground` |
| Cards | `CardBackground`, `CardBackgroundHover`, `CardStroke`, `CardStrokeHover`, `ChipBackground`, `DropTarget` |
| Text | `TextPrimary`, `TextSecondary`, `TextTertiary` |
| Lines | `Divider`, `GridLine`, `GridLineSoft`, `NowLine`, `EventStripe` |
| Accent | `Accent`, `AccentSoft`, `AccentText`, `OnAccent` (text on an accent fill) |
| Navigation | `NavHover`, `NavSelected` |
| Capacity bar | `CapacityOk`, `CapacityNear`, `CapacityOver`, `CapacityTrack` |
| Completion heatmap | `Heat0` (no tasks) to `Heat4` (most tasks) |
| Status | `Danger`, `Warning`, `Success` |
| Toasts | `ToastBackground`, `ToastText` |

Check your theme in both modes, and keep text slots readable on the backgrounds behind them.

## Code plugins

A code plugin is a .NET 10 WPF class library with one public class that implements `IDayBoardPlugin`. It's built against `DayBoard.Plugins`, the plugin API in [`src/DayBoard.Plugins`](../src/DayBoard.Plugins/PluginApi.cs), and it's packed with its `plugin.json`:

```json
{
  "format": "dayboard-plugin",
  "formatVersion": 1,
  "id": "yourname.hello",
  "name": "Hello",
  "version": "1.0.0",
  "author": "Your name",
  "description": "Shows how many tasks the selected day has.",
  "kind": "code",
  "apiVersion": 1,
  "minAppVersion": "1.3.0",
  "entry": "Hello.dll"
}
```

### Start from the Daily check-in

The quickest start is a copy of `plugins-src/DailyCheckIn` next to it, say `plugins-src/Hello` (or of `plugins-src/Kanban` for a page of task cards):

1. Rename `DailyCheckIn.csproj` to `Hello.csproj`, and set `RootNamespace`, `AssemblyName` and `Version` in it.
2. Give `plugin.json` your own `id`, `name`, `version` and `entry` (`Hello.dll`).
3. Replace the code with yours.
4. Run `dotnet build -c Release`. The build writes `bin\Release\net10.0-windows\Hello.dayboard-plugin`, ready to add.

The parts of the project file that matter:

```xml
<PropertyGroup>
  <TargetFramework>net10.0-windows</TargetFramework>
  <UseWPF>true</UseWPF>
  <EnableDynamicLoading>true</EnableDynamicLoading>
</PropertyGroup>
<ItemGroup>
  <!-- DayBoard provides these at run time, so they aren't copied into the plugin. -->
  <ProjectReference Include="..\..\src\DayBoard.Plugins\DayBoard.Plugins.csproj" Private="false" />
  <PackageReference Include="WPF-UI" Version="4.3.0" ExcludeAssets="runtime" />
  <PackageReference Include="CommunityToolkit.Mvvm" Version="8.4.2" ExcludeAssets="runtime" />
</ItemGroup>
```

The `PackPlugin` target at the end of `DailyCheckIn.csproj` zips `plugin.json` and the dll after a Release build. Keep it.

### A small example

```csharp
using System.Windows;
using System.Windows.Controls;
using DayBoard.Plugins;

namespace Hello;

public sealed class HelloPlugin : IDayBoardPlugin
{
    public void Start(IDayBoardHost host) => host.AddPage(new HelloPage(host));

    public void Stop()
    {
    }
}

internal sealed class HelloPage(IDayBoardHost host) : PluginPage
{
    private TextBlock? _text;

    public override string Id => "hello";
    public override string Title => "Hello";
    public override string Icon => "HandWave24";
    public override DateNavigation Navigation => DateNavigation.Day;

    public override FrameworkElement CreateView()
    {
        _text = new TextBlock { FontSize = 16, Margin = new Thickness(6) };
        _text.SetResourceReference(TextBlock.ForegroundProperty, "DB.TextPrimary"); // follows the theme
        return _text;
    }

    public override void Show(DateOnly date) =>
        _text!.Text = $"{host.TasksOn(date).Count(t => !t.IsDone)} open tasks on {date:dddd d MMMM}.";
}
```

### What a plugin gets

DayBoard calls `Start` when the plugin is ticked (and at each start-up while it stays ticked), and `Stop` when it's unticked, updated or DayBoard closes. Both run on the UI thread. The `IDayBoardHost` passed to `Start` offers:

| Member | What it does |
|---|---|
| `AddPage(page)` | Adds a page to the sidebar, after Stats. The first six plugin pages get Ctrl+4 to Ctrl+9. Focus comes first while it's ticked, then the other plugins by name. |
| `AddDayPanel(panel)` | Adds a panel to the top of the Day view, above the timeline. |
| `Storage` | The plugin's own key/value storage, kept in DayBoard's database. See below. |
| `TasksOn(date)` | The tasks planned for a day, read-only: title, date, start time, estimate, done, priority, category, (API 2) the time logged and the checklist, and (API 3) the status (to do, doing, done), urgent, important, due date, when it was done and how often it rolled over. |
| `FindTask(id)`, `InboxTasks()`, `OverdueTasks()` | API 2. One task, the open tasks in the inbox, and the open tasks planned before today. |
| `LogTime(id, minutes)`, `SetDone(id, done)`, `ToggleSubtask(id, itemId)` | API 2. Logs time on a task (Stats count it as focus time), marks it done or not, ticks a checklist item. Each can be undone with Ctrl+Z, like any change. |
| `AddTaskAction(action)` | API 2. Adds an item to the menu you get when you right-click a task, such as Focus's *Focus on this*. Up to two per plugin. |
| `ShowPage(pageId)` | API 2. Opens one of the plugin's pages. |
| `AllTasks()` | API 3. Every task, open and done, planned or in the inbox, by date (inbox last), time and the order you put them in. |
| `SetStatus(id, status)`, `SetQuadrant(id, urgent, important)` | API 3. Moves a task to To do, Doing or Done, or to a quadrant of the Eisenhower matrix (urgent, and Medium or Low priority when its importance has to change). Both can be undone. |
| `CreateTaskCard(id, showDate)` | API 3. DayBoard's own card for a task. See *Task cards and drag and drop* below. |
| `TaskDragEnded` | API 3. Raised when a task drag ends, dropped or not. |
| `TaskHistory(from, to)`, `Completion(from, to)` | API 3. The history of rollovers, skipped repeats, overdue flags and logged focus time, and the completion rate as Stats works it out. The weekly review is built from these. |
| `Today`, `SelectedDate`, `WeekStart`, `IsDarkTheme` | Where DayBoard is, and how it looks. |
| `DateChanged`, `TasksChanged`, `ThemeChanged` | Events for when the selected date changes (and at midnight), tasks change, or the colours change. |
| `ShowDate(date, pageId)` | Opens a date in the Day view, or on one of the plugin's own pages. |
| `ShowToast(text)` | The short message at the bottom of the window. |
| `ShowNotification(title, text)` | A Windows notification from the tray icon, for reminders. |
| `AskSaveFile(title, fileName, filter)` | The Save dialog. Returns the chosen path, or null. |
| `DataFolder` | A folder for files the plugin keeps (`%LOCALAPPDATA%\DayBoard\plugin-data\<id>\`). Not in the backups. |
| `Log(message, error)` | Writes to DayBoard's log, tagged with the plugin's id. |

A `PluginPage` has an `Id`, a `Title` (one short word: it's the sidebar label and the page heading, unless the page sets a longer `Heading`, API 3), an `Icon` (a [Fluent icon](https://github.com/microsoft/fluentui-system-icons) name as WPF-UI spells it, such as `Notebook24`), a `Navigation` that makes the header's ‹ Today › buttons step by day, week or month, and a `Subtitle(date)` for the header. `CreateView` is called once, the first time the page opens. `Show(date)` is called when the page opens, when the date changes while it's open, and after tasks or the theme change. `Hide()` is called when another page opens: save anything pending there.

A `DayPanel` works the same way: `CreateView` once, `Show(date)` when the Day view shows a date, and `Hide()` when it moves to another date or closes. A panel can collapse its own view, as the check-in does for days that haven't happened yet. A plugin can add up to two pages and two panels.

### Looking like DayBoard

Use DayBoard's resources with `DynamicResource` (or `SetResourceReference` in code), so your plugin follows light and dark mode and the colour theme:

- **Brushes:** `DB.` plus any palette slot listed above, such as `DB.TextPrimary`, `DB.CardBackground` or `DB.Accent`.
- **Styles:** `DB.Panel` (the panel look used by the Day view), `DB.Card`, `DB.Title`, `DB.Subtitle`, `DB.SectionHeader`, `DB.Body`, `DB.Caption`, `DB.EmptyText`, `DB.AccentButton`, `DB.OutlineButton`, `DB.IconButton`, `DB.SmallCheck` (a small tick box), `DB.SegmentHost` with `DB.Segment` radio buttons (the Today / This week / All open switch), `DB.Chip` with `DB.ChipText` (the count beside a column title), and `DB.ListScroll` (a scroll viewer for a column of cards). The font `DB.DisplayFont` is the one the big numbers use. For a board, `DB.ColumnBackground` is the column colour and `DB.DropTarget` the highlight while a task is dragged over it.
- **Controls:** WPF and WPF-UI (`xmlns:ui="http://schemas.lepo.co/wpfui/2022/xaml"`), such as `ui:SymbolIcon` and `ui:TextBox`.

Views can be built in code, or written in XAML. Don't compile the XAML: include the `.xaml` files as embedded resources and load them with `XamlReader.Load`, as `Views/Xaml.cs` in the Daily check-in does. (Compiled XAML looks its resources up by assembly name, which isn't reliable for a library that DayBoard loads itself, and may load again after an update.) XAML loaded that way can use WPF, WPF-UI and DayBoard's resources, but not the plugin's own classes. Put those in from code, as `JournalPage.CreateView` does with the year grid.

### Task cards and drag and drop

`host.CreateTaskCard(taskId, showDate)` (API 3) makes DayBoard's own card for a task, as the inbox shows it: the tick box marks it done, a double-click edits it, right-click opens its menu (with other plugins' items, such as *Focus on this*), and it can be dragged to the Day view, the week, the inbox or a plugin's drop zone. Every change goes through DayBoard, so it can be undone. A card shows the task as it was when it was made, so make new ones in your page's `Show`, which DayBoard calls after tasks change. Cards are WPF elements: put them in an `ItemsControl` (as items, with no item template) or a `ContentControl`.

To take task drags, set `AllowDrop` on an element and handle `DragOver` and `Drop`. `TaskDragData.TryGetTask(e, out var id)` says whether the drag is a task and which one, `TaskDragData.IsOver(element, e)` tells a real `DragLeave` from moving onto a child, and the host's `TaskDragEnded` event says when to clear a highlight because the task was dropped somewhere else. Loaded XAML can't name the plugin's own event handlers, so the Kanban and matrix plugins add theirs to the page's root (`AddHandler(DragDrop.DropEvent, …)`) and find the column or quadrant from the element under the pointer: see `plugins-src/Shared/DropZones.cs`.

### Storage

`host.Storage` keeps text values under keys you choose. `GetJson` and `SetJson` store objects as JSON. The values live in DayBoard's database (`dayboard.db`), so they're in the daily backups. They're kept when the plugin is unticked or removed, and come back when it's added again with the same `id`. Keys can be up to 200 characters and values up to 1,000,000. `GetAll(prefix)` reads every key that starts with a prefix, which suits one key per day, as the check-in does (`checkin:2026-10-27`).

### Threads

Plugin code runs on the UI thread, like the rest of DayBoard. Calls to the host from another thread are passed to the UI thread. Keep slow work off the UI thread with `async`/`await` or `Task.Run`, and don't block waiting for it.

### When something goes wrong

- If the plugin throws an exception (in `Start`, a page, a panel, an event handler or its own buttons and timers), DayBoard stops it, unticks it and says so. Settings › Plugins shows the error, and the details are in DayBoard's log (`%LOCALAPPDATA%\DayBoard\logs\`). DayBoard carries on.
- If DayBoard closes while a plugin is starting, or because of an exception on one of the plugin's own threads, DayBoard turns that plugin off the next time it starts.
- `DayBoard.exe --safe-mode` starts DayBoard without running the code plugins you added. (Focus still runs: it's part of DayBoard.)

### Libraries

DayBoard provides .NET 10 with WPF, the plugin API (`DayBoard.Plugins`, API version 3), WPF-UI 4.3 and CommunityToolkit.Mvvm 8.4. A plugin always uses DayBoard's copies of these, even if it brings its own. Reference them without copying them (`Private="false"` or `ExcludeAssets="runtime"`, as above). Other libraries can come with the plugin: put their `.dll` files next to the plugin's own in the `.dayboard-plugin` file.

### Trust

A code plugin runs with the same rights as DayBoard, like any program you run: it can read your files and use the network. That's why DayBoard asks before adding one, and why only plugins from people you trust should be added.

## Limits

A plugin file can be up to 16 MB, with up to 64 files and 32 MB once unpacked. `plugin.json` and `theme.json` can be up to 512 KB each, and each `.dll` up to 8 MB. Only `plugin.json`, the entry file and, for a code plugin, the `.dll` files at the top of the zip are kept when the plugin is added. Everything else in the zip is ignored.
