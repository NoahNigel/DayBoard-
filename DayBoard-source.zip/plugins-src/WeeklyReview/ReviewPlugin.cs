using System.Globalization;
using System.Windows;
using DayBoard.Plugins;
using DayBoard.PluginShared;
using WeeklyReview.Model;
using WeeklyReview.ViewModels;

namespace WeeklyReview;

/// <summary>The weekly review: a Review page that steps through the weeks.</summary>
public sealed class ReviewPlugin : IDayBoardPlugin
{
    public void Start(IDayBoardHost host) => host.AddPage(new ReviewPage(host));

    public void Stop()
    {
    }
}

internal sealed class ReviewPage(IDayBoardHost host) : PluginPage
{
    private readonly ReviewViewModel _vm = new(host);

    public override string Id => "review";
    public override string Title => "Review";
    public override string Heading => "Weekly review";
    public override string Icon => "CalendarCheckmark24";
    public override DateNavigation Navigation => DateNavigation.Week;

    public override string? Subtitle(DateOnly date)
    {
        var c = CultureInfo.CurrentCulture;
        var ws = WeekReview.StartOfWeek(date, host.WeekStart);
        var we = ws.AddDays(6);
        var week = ISOWeek.GetWeekOfYear(ws.ToDateTime(TimeOnly.MinValue).AddDays(3));
        return $"Week {week} · {ws.ToString("d MMM", c)} – {we.ToString("d MMM yyyy", c)}";
    }

    public override FrameworkElement CreateView() => Xaml.View("ReviewPage.xaml", _vm);

    public override void Show(DateOnly date) => _vm.Load(date);
}
