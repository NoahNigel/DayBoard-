using DayBoard.Plugins;

namespace WeeklyReview.Model;

/// <summary>A day a task slipped on: rolled over, skipped (a missed repeat) or left overdue.</summary>
public sealed record SlipItem(Guid TaskId, DateOnly FromDate, PluginHistoryKind Kind);

/// <summary>What one week looks like, worked out from the tasks and their history.</summary>
public sealed class WeekReview
{
    public DateOnly WeekStart { get; init; }
    public DateOnly WeekEnd { get; init; }

    /// <summary>Tasks completed during the week, in the order they were completed.</summary>
    public List<PluginTask> Completed { get; init; } = new();

    /// <summary>Each task once per day it slipped on during the week, in day order.</summary>
    public List<SlipItem> Slipped { get; init; } = new();

    /// <summary>Up to ten tasks that rolled over most, still open or completed this week or later.</summary>
    public List<PluginTask> MostRolledOver { get; init; } = new();

    /// <summary>Tasks planned on a day of the week.</summary>
    public int PlannedCount { get; init; }

    /// <summary>Estimated minutes of the completed tasks.</summary>
    public int CompletedEstimateMinutes { get; init; }

    /// <summary>Minutes logged on the completed tasks.</summary>
    public int CompletedLoggedMinutes { get; init; }

    /// <summary>Focus time logged during the week, on any task.</summary>
    public int FocusMinutes { get; init; }

    /// <summary>Done out of planned, as Stats works it out.</summary>
    public double CompletionRate { get; init; }

    public static DateOnly StartOfWeek(DateOnly date, DayOfWeek weekStart) =>
        date.AddDays(-(((int)date.DayOfWeek - (int)weekStart + 7) % 7));

    /// <param name="tasks">Every task (the host's AllTasks).</param>
    /// <param name="history">The history around the week (the host's TaskHistory for the week).</param>
    /// <param name="completion">The week's completion rate (the host's Completion for the week).</param>
    /// <param name="weekStart">The first day of the week.</param>
    public static WeekReview Build(IReadOnlyList<PluginTask> tasks, IReadOnlyList<PluginTaskHistory> history, PluginCompletion completion, DateOnly weekStart)
    {
        var weekEnd = weekStart.AddDays(6);
        bool InWeek(DateOnly d) => d >= weekStart && d <= weekEnd;

        var completed = tasks
            .Where(t => t.IsDone && t.CompletedAt is { } c && InWeek(DateOnly.FromDateTime(c)))
            .OrderBy(t => t.CompletedAt)
            .ToList();

        var slipped = history
            .Where(h => h.Kind is PluginHistoryKind.RolledOver or PluginHistoryKind.Skipped or PluginHistoryKind.Overdue &&
                        h.FromDate is { } fd && InWeek(fd))
            .Select(h => new SlipItem(h.TaskId, h.FromDate!.Value, h.Kind))
            .GroupBy(s => (s.TaskId, s.FromDate))
            .Select(g => g.First())
            .OrderBy(s => s.FromDate)
            .ToList();

        var mostRolled = tasks
            .Where(t => t.RolloverCount > 0 && (!t.IsDone || (t.CompletedAt is { } c && DateOnly.FromDateTime(c) >= weekStart)))
            .OrderByDescending(t => t.RolloverCount)
            .ThenBy(t => t.Title, StringComparer.CurrentCulture)
            .Take(10)
            .ToList();

        return new WeekReview
        {
            WeekStart = weekStart,
            WeekEnd = weekEnd,
            Completed = completed,
            Slipped = slipped,
            MostRolledOver = mostRolled,
            PlannedCount = tasks.Count(t => t.Date is { } d && InWeek(d)),
            CompletedEstimateMinutes = completed.Sum(t => t.EstimateMinutes ?? 0),
            CompletedLoggedMinutes = completed.Sum(t => t.ActualMinutes),
            FocusMinutes = history.Where(h => h.Kind == PluginHistoryKind.Focus && InWeek(DateOnly.FromDateTime(h.At))).Sum(h => h.Minutes ?? 0),
            CompletionRate = completion.Rate,
        };
    }

    /// <summary>"1h 30m", "45m", "2h".</summary>
    public static string FormatMinutes(int minutes)
    {
        if (minutes <= 0) return "0m";
        int h = minutes / 60, m = minutes % 60;
        if (h == 0) return $"{m}m";
        return m == 0 ? $"{h}h" : $"{h}h {m}m";
    }
}
