using System.Globalization;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Plugins;
using WeeklyReview.Model;

namespace WeeklyReview.ViewModels;

/// <summary>A day's completed tasks.</summary>
public sealed record DayGroup(string Header, IReadOnlyList<FrameworkElement> Cards);

/// <summary>A task card with a line above it (why it slipped) or a count beside it (how often it rolled over).</summary>
public sealed record CardRow(string Text, FrameworkElement Card);

/// <summary>The weekly review: what got done, what slipped, and what keeps rolling over.</summary>
public sealed partial class ReviewViewModel(IDayBoardHost host) : ObservableObject
{
    [ObservableProperty] private string _completedText = "";
    [ObservableProperty] private string _plannedText = "";
    [ObservableProperty] private string _rateText = "";
    [ObservableProperty] private string _focusText = "";
    [ObservableProperty] private string _estimateText = "";
    [ObservableProperty] private IReadOnlyList<DayGroup> _completed = Array.Empty<DayGroup>();
    [ObservableProperty] private IReadOnlyList<CardRow> _slipped = Array.Empty<CardRow>();
    [ObservableProperty] private IReadOnlyList<CardRow> _mostRolled = Array.Empty<CardRow>();
    [ObservableProperty] private bool _noCompleted;
    [ObservableProperty] private bool _noSlipped;
    [ObservableProperty] private bool _noRolled;

    public DateOnly WeekStart { get; private set; }

    public void Load(DateOnly date)
    {
        WeekStart = WeekReview.StartOfWeek(date, host.WeekStart);
        var weekEnd = WeekStart.AddDays(6);
        var data = WeekReview.Build(host.AllTasks(), host.TaskHistory(WeekStart, weekEnd), host.Completion(WeekStart, weekEnd), WeekStart);
        var culture = CultureInfo.CurrentCulture;
        FrameworkElement? Card(Guid id) => host.CreateTaskCard(id, showDate: true);

        CompletedText = data.Completed.Count.ToString(culture);
        PlannedText = data.PlannedCount.ToString(culture);
        RateText = data.CompletionRate > 0 || data.Completed.Count > 0 ? $"{Math.Round(data.CompletionRate * 100)}%" : "–";
        FocusText = WeekReview.FormatMinutes(data.FocusMinutes);
        EstimateText = data.CompletedEstimateMinutes > 0
            ? $"{WeekReview.FormatMinutes(data.CompletedEstimateMinutes)} estimated · {WeekReview.FormatMinutes(data.CompletedLoggedMinutes)} logged"
            : "No estimates on completed tasks";

        Completed = data.Completed
            .GroupBy(t => DateOnly.FromDateTime(t.CompletedAt!.Value))
            .OrderBy(g => g.Key)
            .Select(g => new DayGroup(
                g.Key.ToString("dddd d MMM", culture) + $"  ·  {g.Count()}",
                g.Select(t => Card(t.Id)).OfType<FrameworkElement>().ToList()))
            .ToList();
        Slipped = data.Slipped
            .Select(x => Card(x.TaskId) is { } card ? new CardRow(SlipText(x, culture), card) : null)
            .OfType<CardRow>()
            .ToList();
        MostRolled = data.MostRolledOver
            .Select(t => Card(t.Id) is { } card ? new CardRow($"×{t.RolloverCount}", card) : null)
            .OfType<CardRow>()
            .ToList();
        NoCompleted = Completed.Count == 0;
        NoSlipped = Slipped.Count == 0;
        NoRolled = MostRolled.Count == 0;
    }

    private static string SlipText(SlipItem x, CultureInfo culture) => x.Kind switch
    {
        PluginHistoryKind.RolledOver => "Rolled over from " + x.FromDate.ToString("ddd d MMM", culture),
        PluginHistoryKind.Skipped => "Missed on " + x.FromDate.ToString("ddd d MMM", culture) + " (skipped)",
        _ => "Overdue since " + x.FromDate.ToString("ddd d MMM", culture),
    };
}
