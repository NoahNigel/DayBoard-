using DayBoard.Plugins;
using DayBoard.PluginShared;
using Kanban.Model;

namespace Kanban.ViewModels;

/// <summary>A column of the board.</summary>
public sealed class KanbanColumn(PluginTaskStatus status, string title) : DropZone
{
    public PluginTaskStatus Status { get; } = status;
    public string Title { get; } = title;
    public override string Key => Status.ToString();
}

/// <summary>The board: To do, Doing and Done. Dropping a card on a column moves the task there.</summary>
public sealed class KanbanViewModel(IDayBoardHost host) : ScopedBoard(host)
{
    public KanbanColumn ToDo { get; } = new(PluginTaskStatus.ToDo, "To do");
    public KanbanColumn Doing { get; } = new(PluginTaskStatus.Doing, "Doing");
    public KanbanColumn Done { get; } = new(PluginTaskStatus.Done, "Done");

    public override void Refresh()
    {
        var (toDo, doing, done) = KanbanColumns.Sort(Host.AllTasks(), Scope, Host.Today, Host.WeekStart);
        ToDo.Cards = Cards(toDo);
        Doing.Cards = Cards(doing);
        Done.Cards = Cards(done);
    }

    public void Drop(DropZone zone, Guid taskId)
    {
        if (zone is KanbanColumn column) Host.SetStatus(taskId, column.Status);
    }
}
