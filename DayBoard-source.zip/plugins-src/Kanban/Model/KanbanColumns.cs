using DayBoard.Plugins;
using DayBoard.PluginShared;

namespace Kanban.Model;

/// <summary>Sorts tasks into the board's three columns.</summary>
public static class KanbanColumns
{
    /// <summary>
    /// To do and Doing: open tasks in scope, in the order DayBoard gives them. Done: tasks completed today, this week, or
    /// (for "All open") in the last two weeks, newest first.
    /// </summary>
    public static (List<PluginTask> ToDo, List<PluginTask> Doing, List<PluginTask> Done) Sort(
        IEnumerable<PluginTask> tasks, BoardScope scope, DateOnly today, DayOfWeek weekStart)
    {
        var list = tasks.ToList();
        var ws = Boards.StartOfWeek(today, weekStart);

        bool DoneInScope(PluginTask t)
        {
            if (t.CompletedAt is not { } c) return false;
            var d = DateOnly.FromDateTime(c);
            return scope switch
            {
                BoardScope.Today => d == today,
                BoardScope.Week => d >= ws && d <= ws.AddDays(6),
                _ => d >= today.AddDays(-14),
            };
        }

        var open = list.Where(t => !t.IsDone && Boards.InScope(t, scope, today, weekStart)).ToList();
        return (
            open.Where(t => t.Status == PluginTaskStatus.ToDo).ToList(),
            open.Where(t => t.Status == PluginTaskStatus.Doing).ToList(),
            list.Where(t => t.IsDone && DoneInScope(t)).OrderByDescending(t => t.CompletedAt).ToList());
    }
}
