using System.Windows;
using DayBoard.Plugins;
using DayBoard.PluginShared;
using Kanban.ViewModels;

namespace Kanban;

/// <summary>The Kanban board: open tasks in To do, Doing and Done columns. Drag a card to another column to move it.</summary>
public sealed class KanbanPlugin : IDayBoardPlugin
{
    public void Start(IDayBoardHost host) => host.AddPage(new KanbanPage(host));

    public void Stop()
    {
    }
}

internal sealed class KanbanPage(IDayBoardHost host) : PluginPage
{
    private readonly KanbanViewModel _vm = new(host);

    public override string Id => "kanban";
    public override string Title => "Kanban";
    public override string Icon => "BoardSplit24";

    public override string? Subtitle(DateOnly date) => "To do · Doing · Done";

    public override FrameworkElement CreateView()
    {
        var view = Xaml.View("KanbanPage.xaml", _vm);
        _ = new ZoneDrops(host, view, _vm.Drop);
        return view;
    }

    public override void Show(DateOnly date) => _vm.Refresh();
}
