using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Media;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DailyCheckIn.Model;
using DayBoard.Plugins;
using Wpf.Ui.Controls;

namespace DailyCheckIn.ViewModels;

/// <summary>
/// Editor for one day's check-in: a face (mood 1–5), a colour of the day, tags and a note. Used by the panel at the
/// top of the Day view and by the Journal. Choices are saved right away; the note is saved shortly after typing stops.
/// </summary>
public sealed partial class CheckInViewModel : ObservableObject
{
    private const int MaxExtraTags = 4;
    private readonly IDayBoardHost _host;
    private readonly CheckInStore _store;
    private readonly bool _collapsible;
    private readonly DispatcherTimer _noteTimer = new() { Interval = TimeSpan.FromMilliseconds(600) };
    private bool _loaded;
    private bool _loading;
    private bool _notePending;
    private bool _saving;
    private bool _stale;

    public CheckInViewModel(IDayBoardHost host, CheckInStore store, bool collapsible)
    {
        _host = host;
        _store = store;
        _collapsible = collapsible;
        for (int i = 1; i <= 5; i++) Moods.Add(new MoodOption(i));
        foreach (var c in CheckInOptions.Colors) Colors.Add(new DayColorOption(c));
        _noteTimer.Tick += (_, _) => Flush();
        store.Changed += (_, date) =>
        {
            if (!_saving && date == Date) _stale = true;
        };
    }

    public DateOnly Date { get; private set; }
    public ObservableCollection<MoodOption> Moods { get; } = new();
    public ObservableCollection<DayColorOption> Colors { get; } = new();
    public ObservableCollection<TagOption> Tags { get; } = new();

    [ObservableProperty] private string _note = "";
    [ObservableProperty] private string _newTag = "";
    [ObservableProperty] [NotifyPropertyChangedFor(nameof(IsFolded))] private bool _isExpanded = true;
    [ObservableProperty] [NotifyPropertyChangedFor(nameof(IsFuture))] private bool _canEdit = true;
    [ObservableProperty] private string _prompt = "";
    [ObservableProperty] private bool _hasEntry;

    public bool IsFolded => !IsExpanded;
    public bool IsFuture => !CanEdit;

    // One-line summary shown when the Day view panel is folded away.
    [ObservableProperty] private bool _hasSummaryMood;
    [ObservableProperty] private SymbolRegular _summarySymbol = SymbolRegular.Emoji24;
    [ObservableProperty] private bool _hasSummaryColor;
    [ObservableProperty] private Brush? _summaryColor;
    [ObservableProperty] private string _summaryText = "";

    /// <summary>Shows a day. Does nothing when that day is already shown and unchanged, so typing isn't interrupted.</summary>
    public void Load(DateOnly date, bool force = false)
    {
        if (_loaded && !force && !_stale && date == Date) return;
        Flush();
        _loading = true;
        try
        {
            _loaded = true;
            Date = date;
            _stale = false;
            var today = _host.Today;
            CanEdit = date <= today;
            Prompt = PromptFor(date, today);
            var entry = _store.Get(date) ?? new CheckIn { Date = date };

            foreach (var m in Moods) m.IsSelected = m.Value == entry.Mood;
            foreach (var c in Colors) c.IsSelected = string.Equals(c.Hex, entry.Color, StringComparison.OrdinalIgnoreCase);

            // Suggested tags, a few of your own most used ones, and whatever this day already has.
            var names = new List<string>(CheckInOptions.Tags);
            foreach (var t in _store.UsedTags().Where(t => !names.Contains(t, StringComparer.CurrentCultureIgnoreCase)).Take(MaxExtraTags)) names.Add(t);
            foreach (var t in entry.Tags.Where(t => !names.Contains(t, StringComparer.CurrentCultureIgnoreCase))) names.Add(t);
            Tags.Clear();
            foreach (var n in names)
                Tags.Add(new TagOption(n) { IsSelected = entry.Tags.Contains(n, StringComparer.CurrentCultureIgnoreCase) });

            Note = entry.Note;
            NewTag = "";
            HasEntry = !entry.IsEmpty;
            IsExpanded = !_collapsible || entry.IsEmpty;
            UpdateSummary(entry);
        }
        finally
        {
            _loading = false;
        }
    }

    private static string PromptFor(DateOnly date, DateOnly today)
    {
        var c = CultureInfo.CurrentCulture;
        if (date == today) return "How's today?";
        if (date == today.AddDays(-1)) return "How was yesterday?";
        if (date < today && date > today.AddDays(-7)) return $"How was {date.ToString("dddd", c)}?";
        return $"How was {date.ToString("d MMMM", c)}?";
    }

    [RelayCommand]
    private void SetMood(MoodOption? option)
    {
        if (option is null || !CanEdit) return;
        bool select = !option.IsSelected;
        foreach (var m in Moods) m.IsSelected = select && ReferenceEquals(m, option);
        SaveNow();
    }

    [RelayCommand]
    private void SetColor(DayColorOption? option)
    {
        if (option is null || !CanEdit) return;
        bool select = !option.IsSelected;
        foreach (var c in Colors) c.IsSelected = select && ReferenceEquals(c, option);
        SaveNow();
    }

    [RelayCommand]
    private void ToggleTag(TagOption? tag)
    {
        if (tag is null || !CanEdit) return;
        tag.IsSelected = !tag.IsSelected;
        SaveNow();
    }

    [RelayCommand]
    private void AddTag()
    {
        var name = CheckIn.NormalizeTag(NewTag);
        NewTag = "";
        if (name.Length == 0 || !CanEdit) return;
        var existing = Tags.FirstOrDefault(t => string.Equals(t.Name, name, StringComparison.CurrentCultureIgnoreCase));
        if (existing is null) Tags.Add(new TagOption(name) { IsSelected = true });
        else existing.IsSelected = true;
        SaveNow();
    }

    [RelayCommand]
    private void Expand() => IsExpanded = true;

    [RelayCommand]
    private void Collapse()
    {
        Flush();
        if (_collapsible && HasEntry) IsExpanded = false;
    }

    partial void OnNoteChanged(string value)
    {
        if (_loading) return;
        _notePending = true;
        _noteTimer.Stop();
        _noteTimer.Start();
    }

    /// <summary>Saves a note that's still waiting for the typing pause (when leaving the day, the page or DayBoard).</summary>
    public void Flush()
    {
        _noteTimer.Stop();
        if (_notePending) SaveNow();
    }

    private void SaveNow()
    {
        _notePending = false;
        if (_loading || !CanEdit || !_loaded) return;
        var entry = new CheckIn
        {
            Date = Date,
            Mood = Moods.FirstOrDefault(m => m.IsSelected)?.Value,
            Color = Colors.FirstOrDefault(c => c.IsSelected)?.Hex,
            Tags = Tags.Where(t => t.IsSelected).Select(t => t.Name).ToList(),
            Note = Note,
        };
        try
        {
            _saving = true;
            _store.Save(entry, DateTime.Now);
        }
        catch (Exception ex)
        {
            _host.Log("Save check-in", ex);
            _host.ShowToast("Couldn't save your check-in: " + ex.Message);
            return;
        }
        finally
        {
            _saving = false;
        }
        var saved = _store.Get(Date) ?? new CheckIn { Date = Date };
        HasEntry = !saved.IsEmpty;
        UpdateSummary(saved);
    }

    private void UpdateSummary(CheckIn e)
    {
        HasSummaryMood = e.Mood.HasValue;
        SummarySymbol = MoodOption.SymbolFor(e.Mood);
        HasSummaryColor = e.Color is not null;
        SummaryColor = e.Color is null ? null : ViewModels.Colors.Brush(e.Color);
        var parts = new List<string>();
        if (e.Mood is int m) parts.Add(CheckIn.MoodLabel(m));
        if (CheckInOptions.ColorName(e.Color) is { } name) parts.Add(name);
        if (e.Tags.Count > 0) parts.Add(string.Join(", ", e.Tags));
        if (!string.IsNullOrWhiteSpace(e.Note)) parts.Add("“" + FirstLine(e.Note, 90) + "”");
        SummaryText = string.Join("  ·  ", parts);
    }

    public static string FirstLine(string text, int max)
    {
        var line = text.Replace("\r", "").Split('\n').FirstOrDefault(l => l.Trim().Length > 0)?.Trim() ?? "";
        return line.Length <= max ? line : line[..(max - 1)] + "…";
    }
}
