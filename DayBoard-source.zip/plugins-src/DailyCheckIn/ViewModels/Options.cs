using System.Windows;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using DailyCheckIn.Model;
using Wpf.Ui.Controls;

namespace DailyCheckIn.ViewModels;

public sealed partial class MoodOption : ObservableObject
{
    public MoodOption(int value) => Value = value;

    public int Value { get; }
    public SymbolRegular Symbol => SymbolFor(Value);
    public string Label => CheckIn.MoodLabel(Value);
    [ObservableProperty] private bool _isSelected;

    // Looked up by name in DayBoard's copy of WPF-UI, so the faces stay right whichever version DayBoard ships.
    private static readonly SymbolRegular[] Faces =
        new[] { "Emoji24", "EmojiSad24", "EmojiSadSlight24", "EmojiMeh24", "EmojiSmileSlight24", "EmojiLaugh24" }
            .Select(n => Enum.TryParse<SymbolRegular>(n, out var s) ? s : default).ToArray();

    public static SymbolRegular SymbolFor(int? mood) => mood is >= 1 and <= 5 ? Faces[mood.Value] : Faces[0];
}

public sealed partial class DayColorOption : ObservableObject
{
    public DayColorOption(DayColor color)
    {
        Hex = color.Hex;
        Name = color.Name;
        Brush = Colors.Brush(color.Hex);
    }

    public string Hex { get; }
    public string Name { get; }
    public Brush Brush { get; }
    [ObservableProperty] private bool _isSelected;
}

public sealed partial class TagOption : ObservableObject
{
    public TagOption(string name) => Name = name;

    public string Name { get; }
    [ObservableProperty] private bool _isSelected;
}

/// <summary>Brushes for colours of the day, and DayBoard's own theme brushes (the DB.* resources).</summary>
public static class Colors
{
    private static readonly Dictionary<string, SolidColorBrush> Cache = new(StringComparer.OrdinalIgnoreCase);

    public static Color? Parse(string? hex)
    {
        if (hex is not { Length: 7 } || hex[0] != '#' || !uint.TryParse(hex.AsSpan(1), System.Globalization.NumberStyles.HexNumber, null, out var v)) return null;
        return Color.FromRgb((byte)(v >> 16), (byte)(v >> 8), (byte)v);
    }

    public static SolidColorBrush Brush(string? hex, byte alpha = 0xFF)
    {
        var key = hex + "|" + alpha;
        if (Cache.TryGetValue(key, out var b)) return b;
        var c = Parse(hex) ?? Color.FromRgb(0x8A, 0x8F, 0x98);
        b = new SolidColorBrush(Color.FromArgb(alpha, c.R, c.G, c.B));
        b.Freeze();
        Cache[key] = b;
        return b;
    }

    /// <summary>A brush from DayBoard's palette, such as "DB.TextTertiary". These follow light/dark mode and colour themes.</summary>
    public static Brush Theme(string key, Brush fallback) => Application.Current?.TryFindResource(key) as Brush ?? fallback;
}
