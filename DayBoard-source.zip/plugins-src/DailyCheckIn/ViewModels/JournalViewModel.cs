using System.Collections.ObjectModel;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Media;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DailyCheckIn.Model;
using DayBoard.Plugins;
using Wpf.Ui.Controls;

namespace DailyCheckIn.ViewModels;

/// <summary>One day in the Journal's month grid.</summary>
public sealed partial class JournalDayCell : ObservableObject
{
    public required DateOnly Date { get; init; }
    public required string DayText { get; init; }
    public required bool InMonth { get; init; }
    public required bool IsToday { get; init; }
    public required bool IsFuture { get; init; }
    public required Brush Background { get; init; }
    public required bool HasMood { get; init; }
    public required SymbolRegular Symbol { get; init; }
    public required bool HasNote { get; init; }
    public required string Tooltip { get; init; }
    [ObservableProperty] private bool _isSelected;
}

/// <summary>A day with tags or a note, in the list under the month.</summary>
public sealed class JournalNoteItem
{
    public required DateOnly Date { get; init; }
    public required string DateText { get; init; }
    public required bool HasMood { get; init; }
    public required SymbolRegular Symbol { get; init; }
    public required string Facts { get; init; }
    public required bool HasColor { get; init; }
    public required Brush? ColorBrush { get; init; }
    public required string Note { get; init; }
    public required bool HasNote { get; init; }
}

/// <summary>The Journal page: a month of check-ins, the year in colour, the month's notes, and an editor for the selected day.</summary>
public sealed partial class JournalViewModel : ObservableObject
{
    private readonly IDayBoardHost _host;
    private readonly CheckInStore _store;
    private bool _refreshQueued;

    public JournalViewModel(IDayBoardHost host, CheckInStore store)
    {
        _host = host;
        _store = store;
        Editor = new CheckInViewModel(host, store, collapsible: false);
        store.Changed += (_, _) => QueueRefresh();
    }

    /// <summary>True while the page is open.</summary>
    public bool IsShown { get; set; }

    public CheckInViewModel Editor { get; }
    public ObservableCollection<JournalDayCell> Cells { get; } = new();
    public ObservableCollection<JournalNoteItem> Notes { get; } = new();

    [ObservableProperty] private DateOnly _date = DateOnly.FromDateTime(DateTime.Today);
    [ObservableProperty] private IReadOnlyList<string> _weekdayNames = Array.Empty<string>();
    [ObservableProperty] private string _monthTitle = "";
    [ObservableProperty] private string _monthSummary = "";
    [ObservableProperty] private string _selectedTitle = "";
    [ObservableProperty] private int _year;
    [ObservableProperty] private DayOfWeek _weekStart = DayOfWeek.Monday;
    [ObservableProperty] private IReadOnlyDictionary<DateOnly, Color> _yearColors = new Dictionary<DateOnly, Color>();
    [ObservableProperty] private IReadOnlyDictionary<DateOnly, string> _yearTips = new Dictionary<DateOnly, string>();
    [ObservableProperty] private string _yearTitle = "";
    [ObservableProperty] private string _notesTitle = "";
    [ObservableProperty] [NotifyPropertyChangedFor(nameof(HasNoNotes))] private bool _hasNotes;
    [ObservableProperty] private string? _exportMessage;

    public bool HasNoNotes => !HasNotes;

    private void QueueRefresh()
    {
        if (_refreshQueued) return;
        _refreshQueued = true;
        Application.Current?.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            _refreshQueued = false;
            if (IsShown) RefreshOverview();
        }));
    }

    public void Refresh()
    {
        Editor.Load(Date);
        RefreshOverview();
    }

    /// <summary>Everything except the editor, so a refresh never interrupts typing.</summary>
    private void RefreshOverview()
    {
        var c = CultureInfo.CurrentCulture;
        var today = _host.Today;
        WeekStart = _host.WeekStart;
        var first = new DateOnly(Date.Year, Date.Month, 1);
        var last = first.AddMonths(1).AddDays(-1);
        var start = Dates.StartOfWeek(first, WeekStart);
        var entries = _store.Between(start, start.AddDays(41)).ToDictionary(e => e.Date);
        var empty = ViewModels.Colors.Theme("DB.ChipBackground", Brushes.WhiteSmoke);

        WeekdayNames = Dates.WeekDays(WeekStart).Select(Dates.ShortDayName).ToList();
        MonthTitle = Date.ToString("MMMM yyyy", c);
        SelectedTitle = Date.ToString("dddd d MMMM", c);

        Cells.Clear();
        for (int i = 0; i < 42; i++)
        {
            var d = start.AddDays(i);
            if (i == 35 && d > last) break; // five weeks are enough for this month
            entries.TryGetValue(d, out var e);
            bool inMonth = d.Month == first.Month;
            Brush bg = e?.Color is { } hex ? ViewModels.Colors.Brush(hex, inMonth ? (byte)0x8C : (byte)0x40) : inMonth ? empty : Brushes.Transparent;
            Cells.Add(new JournalDayCell
            {
                Date = d,
                DayText = d.Day.ToString(c),
                InMonth = inMonth,
                IsToday = d == today,
                IsFuture = d > today,
                Background = bg,
                HasMood = e?.Mood is not null,
                Symbol = MoodOption.SymbolFor(e?.Mood),
                HasNote = !string.IsNullOrWhiteSpace(e?.Note),
                Tooltip = Describe(d, e, today),
                IsSelected = d == Date,
            });
        }

        var month = _store.Between(first, last);
        var moods = month.Where(e => e.Mood.HasValue).GroupBy(e => e.Mood!.Value).OrderByDescending(g => g.Count()).ThenByDescending(g => g.Key).ToList();
        MonthSummary = month.Count == 0
            ? "No check-ins this month yet"
            : $"{month.Count} check-in{(month.Count == 1 ? "" : "s")}" + (moods.Count > 0 ? $" · most often {CheckIn.MoodLabel(moods[0].Key).ToLower(c)}" : "");

        Notes.Clear();
        foreach (var e in month.Where(e => !string.IsNullOrWhiteSpace(e.Note) || e.Tags.Count > 0).OrderByDescending(e => e.Date))
        {
            var facts = new List<string>();
            if (e.Mood is int m) facts.Add(CheckIn.MoodLabel(m));
            if (CheckInOptions.ColorName(e.Color) is { } name) facts.Add(name);
            if (e.Tags.Count > 0) facts.Add(string.Join(", ", e.Tags));
            Notes.Add(new JournalNoteItem
            {
                Date = e.Date,
                DateText = e.Date.ToString("ddd d MMM", c),
                HasMood = e.Mood.HasValue,
                Symbol = MoodOption.SymbolFor(e.Mood),
                Facts = string.Join("  ·  ", facts),
                HasColor = e.Color is not null,
                ColorBrush = e.Color is null ? null : ViewModels.Colors.Brush(e.Color),
                Note = e.Note,
                HasNote = !string.IsNullOrWhiteSpace(e.Note),
            });
        }
        HasNotes = Notes.Count > 0;
        NotesTitle = $"Notes in {Date.ToString("MMMM", c)}";

        Year = Date.Year;
        var yearEntries = _store.Between(new DateOnly(Year, 1, 1), new DateOnly(Year, 12, 31));
        var neutral = ViewModels.Colors.Theme("DB.TextTertiary", Brushes.Gray) is SolidColorBrush nb ? nb.Color : System.Windows.Media.Colors.Gray;
        YearColors = yearEntries.ToDictionary(e => e.Date, e =>
            e.Color is { } hex && ViewModels.Colors.Parse(hex) is { } col ? col : Color.FromArgb(0x70, neutral.R, neutral.G, neutral.B));
        YearTips = yearEntries.ToDictionary(e => e.Date, e => Describe(e.Date, e, today));
        YearTitle = $"{Year} in colour";
    }

    private static string Describe(DateOnly d, CheckIn? e, DateOnly today)
    {
        var text = d.ToString("dddd d MMMM yyyy", CultureInfo.CurrentCulture);
        if (e is null) return text + (d > today ? "" : "\nNo check-in");
        var facts = new List<string>();
        if (e.Mood is int m) facts.Add(CheckIn.MoodLabel(m));
        if (CheckInOptions.ColorName(e.Color) is { } name) facts.Add(name);
        if (e.Tags.Count > 0) facts.Add(string.Join(", ", e.Tags));
        if (facts.Count > 0) text += "\n" + string.Join(" · ", facts);
        if (!string.IsNullOrWhiteSpace(e.Note)) text += "\n“" + CheckInViewModel.FirstLine(e.Note, 80) + "”";
        return text;
    }

    [RelayCommand]
    private void SelectDay(object? arg)
    {
        DateOnly? d = arg switch
        {
            DateOnly x => x,
            JournalDayCell cell => cell.Date,
            JournalNoteItem note => note.Date,
            _ => null,
        };
        if (d is { } date) _host.ShowDate(date, JournalPage.PageId);
    }

    [RelayCommand]
    private void Export()
    {
        Editor.Flush();
        var path = _host.AskSaveFile("Export your journal", $"DayBoard-journal-{DateTime.Now:yyyy-MM-dd}.md",
            "Markdown files (*.md)|*.md|Text files (*.txt)|*.txt");
        if (path is not null) ExportTo(path);
    }

    /// <summary>Writes the whole journal as Markdown. Returns the number of days written.</summary>
    public int ExportTo(string path)
    {
        var all = _store.All();
        try
        {
            File.WriteAllText(path, JournalExporter.ToMarkdown(all, CheckInOptions.ColorName), new UTF8Encoding(false));
            ExportMessage = $"Saved {all.Count} day{(all.Count == 1 ? "" : "s")} to {path}";
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            ExportMessage = "Couldn't save the journal: " + ex.Message;
        }
        return all.Count;
    }
}

internal static class Dates
{
    public static DateOnly StartOfWeek(DateOnly date, DayOfWeek weekStart) => date.AddDays(-(((int)date.DayOfWeek - (int)weekStart + 7) % 7));

    public static IReadOnlyList<DayOfWeek> WeekDays(DayOfWeek weekStart) =>
        Enumerable.Range(0, 7).Select(i => (DayOfWeek)(((int)weekStart + i) % 7)).ToList();

    public static string ShortDayName(DayOfWeek d) => CultureInfo.InvariantCulture.DateTimeFormat.GetAbbreviatedDayName(d);
}
