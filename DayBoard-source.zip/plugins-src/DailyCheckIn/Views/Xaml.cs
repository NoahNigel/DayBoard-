using System.Windows;
using System.Windows.Markup;

namespace DailyCheckIn.Views;

/// <summary>
/// Loads the views, which are embedded as XAML text and parsed at run time. Compiled XAML finds its resources by
/// assembly name, which isn't reliable for a plugin that DayBoard loads (and may reload after an update).
/// </summary>
internal static class Xaml
{
    public static T Load<T>(string file) where T : class
    {
        var name = "DailyCheckIn.Views." + file;
        using var stream = typeof(Xaml).Assembly.GetManifestResourceStream(name)
                           ?? throw new InvalidOperationException($"The view {name} is missing from the plugin.");
        return XamlReader.Load(stream) as T ?? throw new InvalidOperationException($"The view {name} isn't a {typeof(T).Name}.");
    }

    /// <summary>Loads a view with the check-in styles available to it.</summary>
    public static FrameworkElement View(string file, object dataContext)
    {
        var view = Load<FrameworkElement>(file);
        view.Resources.MergedDictionaries.Add(Load<ResourceDictionary>("Styles.xaml"));
        view.DataContext = dataContext;
        return view;
    }
}
