using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DailyCheckIn.ViewModels;

namespace DailyCheckIn.Views;

/// <summary>A year of days in week columns, each square filled with that day's colour. Clicking a day runs <see cref="SelectCommand"/>.</summary>
public sealed class DayColorGrid : FrameworkElement
{
    public static readonly DependencyProperty ColorsProperty = DependencyProperty.Register(nameof(Colors), typeof(IReadOnlyDictionary<DateOnly, Color>), typeof(DayColorGrid),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty TipsProperty = DependencyProperty.Register(nameof(Tips), typeof(IReadOnlyDictionary<DateOnly, string>), typeof(DayColorGrid),
        new FrameworkPropertyMetadata(null));

    public static readonly DependencyProperty YearProperty = DependencyProperty.Register(nameof(Year), typeof(int), typeof(DayColorGrid),
        new FrameworkPropertyMetadata(DateTime.Today.Year, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty WeekStartProperty = DependencyProperty.Register(nameof(WeekStart), typeof(DayOfWeek), typeof(DayColorGrid),
        new FrameworkPropertyMetadata(DayOfWeek.Monday, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty SelectedDateProperty = DependencyProperty.Register(nameof(SelectedDate), typeof(DateOnly), typeof(DayColorGrid),
        new FrameworkPropertyMetadata(default(DateOnly), FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SelectCommandProperty = DependencyProperty.Register(nameof(SelectCommand), typeof(ICommand), typeof(DayColorGrid));

    private const double Cell = 12, Gap = 3, LeftLabels = 30, TopLabels = 18;
    private readonly ToolTip _tip = new() { Placement = System.Windows.Controls.Primitives.PlacementMode.Mouse };
    private readonly List<(Rect Rect, DateOnly Date)> _cells = new();
    private DateOnly? _hover;

    public DayColorGrid()
    {
        _tip.PlacementTarget = this;
        Cursor = Cursors.Hand;
    }

    public IReadOnlyDictionary<DateOnly, Color>? Colors { get => (IReadOnlyDictionary<DateOnly, Color>?)GetValue(ColorsProperty); set => SetValue(ColorsProperty, value); }
    public IReadOnlyDictionary<DateOnly, string>? Tips { get => (IReadOnlyDictionary<DateOnly, string>?)GetValue(TipsProperty); set => SetValue(TipsProperty, value); }
    public int Year { get => (int)GetValue(YearProperty); set => SetValue(YearProperty, value); }
    public DayOfWeek WeekStart { get => (DayOfWeek)GetValue(WeekStartProperty); set => SetValue(WeekStartProperty, value); }
    public DateOnly SelectedDate { get => (DateOnly)GetValue(SelectedDateProperty); set => SetValue(SelectedDateProperty, value); }
    public ICommand? SelectCommand { get => (ICommand?)GetValue(SelectCommandProperty); set => SetValue(SelectCommandProperty, value); }

    private int Columns()
    {
        var first = Dates.StartOfWeek(new DateOnly(Year, 1, 1), WeekStart);
        return (new DateOnly(Year, 12, 31).DayNumber - first.DayNumber) / 7 + 1;
    }

    protected override Size MeasureOverride(Size availableSize) =>
        new(LeftLabels + Columns() * (Cell + Gap), TopLabels + 7 * (Cell + Gap));

    protected override void OnRender(DrawingContext dc)
    {
        _cells.Clear();
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(RenderSize));
        var text = ViewModels.Colors.Theme("DB.TextTertiary", Brushes.Gray);
        var empty = ViewModels.Colors.Theme("DB.Heat0", Brushes.WhiteSmoke);
        var accent = ViewModels.Colors.Theme("DB.Accent", Brushes.SlateBlue);
        var strong = ViewModels.Colors.Theme("DB.TextPrimary", Brushes.Black);
        var typeface = new Typeface(new FontFamily("Segoe UI Variable Text, Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        FormattedText Text(string s) => new(s, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, typeface, 10, text, dpi);
        var colors = Colors ?? new Dictionary<DateOnly, Color>();
        var today = DateOnly.FromDateTime(DateTime.Today);
        var days = Dates.WeekDays(WeekStart);
        var start = Dates.StartOfWeek(new DateOnly(Year, 1, 1), WeekStart);
        int cols = Columns();

        for (int r = 0; r < 7; r += 2) dc.DrawText(Text(Dates.ShortDayName(days[r])), new Point(0, TopLabels + r * (Cell + Gap) - 1));
        int lastMonth = 0;
        for (int c = 0; c < cols; c++)
        {
            var colStart = start.AddDays(c * 7);
            var firstOfMonth = Enumerable.Range(0, 7).Select(i => colStart.AddDays(i)).FirstOrDefault(d => d.Year == Year && (d.Day == 1 || c == 0));
            if (firstOfMonth.Year == Year && firstOfMonth.Month != lastMonth)
            {
                lastMonth = firstOfMonth.Month;
                dc.DrawText(Text(CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(lastMonth)), new Point(LeftLabels + c * (Cell + Gap), 0));
            }
            for (int r = 0; r < 7; r++)
            {
                var date = colStart.AddDays(r);
                if (date.Year != Year) continue;
                var rect = new Rect(LeftLabels + c * (Cell + Gap), TopLabels + r * (Cell + Gap), Cell, Cell);
                Brush fill = colors.TryGetValue(date, out var col) ? new SolidColorBrush(col) : empty;
                Pen? pen = date == SelectedDate ? new Pen(strong, 1.5) : date == today ? new Pen(accent, 1.5) : null;
                dc.DrawRoundedRectangle(fill, pen, rect, 2.5, 2.5);
                _cells.Add((rect, date));
            }
        }
    }

    private DateOnly? HitTest(Point p)
    {
        foreach (var (rect, date) in _cells)
        {
            var hit = rect;
            hit.Inflate(Gap / 2, Gap / 2);
            if (hit.Contains(p)) return date;
        }
        return null;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        var date = HitTest(e.GetPosition(this));
        if (date is null)
        {
            _hover = null;
            _tip.IsOpen = false;
            return;
        }
        if (_hover == date) return;
        _hover = date;
        _tip.Content = Tips?.GetValueOrDefault(date.Value) ?? date.Value.ToString("dddd d MMMM yyyy", CultureInfo.CurrentCulture);
        _tip.IsOpen = false;
        _tip.IsOpen = true;
    }

    protected override void OnMouseLeave(MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        _hover = null;
        _tip.IsOpen = false;
    }

    protected override void OnMouseLeftButtonUp(MouseButtonEventArgs e)
    {
        base.OnMouseLeftButtonUp(e);
        if (HitTest(e.GetPosition(this)) is { } date && SelectCommand?.CanExecute(date) == true)
        {
            _tip.IsOpen = false;
            SelectCommand.Execute(date);
        }
    }
}
