using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using DailyCheckIn.Model;
using DailyCheckIn.ViewModels;
using DailyCheckIn.Views;
using DayBoard.Plugins;

namespace DailyCheckIn;

/// <summary>
/// The Daily check-in: a panel at the top of the Day view to log how a day felt, and a Journal page to look back.
/// Check-ins are kept in the plugin's storage, so they're in DayBoard's database and its daily backups.
/// </summary>
public sealed class CheckInPlugin : IDayBoardPlugin
{
    private CheckInPanel? _panel;
    private JournalPage? _page;

    public void Start(IDayBoardHost host)
    {
        var store = new CheckInStore(host.Storage);
        _panel = new CheckInPanel(host, store);
        _page = new JournalPage(host, store);
        host.AddDayPanel(_panel);
        host.AddPage(_page);
        host.Log($"Started with {store.Count} check-in{(store.Count == 1 ? "" : "s")}.");
    }

    public void Stop()
    {
        // Save a note that's still waiting for the typing pause.
        _panel?.Flush();
        _page?.Flush();
    }
}

/// <summary>The check-in at the top of the Day view, for today and earlier days.</summary>
internal sealed class CheckInPanel(IDayBoardHost host, CheckInStore store) : DayPanel
{
    private readonly CheckInViewModel _vm = new(host, store, collapsible: true);
    private FrameworkElement? _view;

    public override FrameworkElement CreateView() => _view = Xaml.View("DayPanel.xaml", _vm);

    public override void Show(DateOnly date)
    {
        bool canCheckIn = date <= host.Today;
        if (_view is not null) _view.Visibility = canCheckIn ? Visibility.Visible : Visibility.Collapsed;
        if (canCheckIn) _vm.Load(date);
    }

    public override void Hide() => _vm.Flush();

    public void Flush() => _vm.Flush();
}

/// <summary>The Journal in the sidebar: a month of check-ins, the year in colour, notes, and the selected day.</summary>
internal sealed class JournalPage(IDayBoardHost host, CheckInStore store) : PluginPage
{
    public const string PageId = "journal";
    private readonly JournalViewModel _vm = new(host, store);

    public override string Id => PageId;
    public override string Title => "Journal";
    public override string Icon => "Notebook24";
    public override DateNavigation Navigation => DateNavigation.Month;

    public override string? Subtitle(DateOnly date) => "How you felt and what you wrote · " + date.ToString("MMMM yyyy", CultureInfo.CurrentCulture);

    public override FrameworkElement CreateView()
    {
        var view = Xaml.View("JournalPage.xaml", _vm);
        if (view.FindName("YearGridHost") is ContentControl slot)
        {
            var grid = new DayColorGrid();
            grid.SetBinding(DayColorGrid.YearProperty, new Binding(nameof(JournalViewModel.Year)));
            grid.SetBinding(DayColorGrid.WeekStartProperty, new Binding(nameof(JournalViewModel.WeekStart)));
            grid.SetBinding(DayColorGrid.ColorsProperty, new Binding(nameof(JournalViewModel.YearColors)));
            grid.SetBinding(DayColorGrid.TipsProperty, new Binding(nameof(JournalViewModel.YearTips)));
            grid.SetBinding(DayColorGrid.SelectedDateProperty, new Binding(nameof(JournalViewModel.Date)));
            grid.SetBinding(DayColorGrid.SelectCommandProperty, new Binding(nameof(JournalViewModel.SelectDayCommand)));
            slot.Content = grid;
        }
        return view;
    }

    public override void Show(DateOnly date)
    {
        _vm.IsShown = true;
        _vm.Date = date;
        _vm.Refresh();
    }

    public override void Hide()
    {
        _vm.IsShown = false;
        _vm.Editor.Flush();
    }

    public void Flush() => _vm.Editor.Flush();
}
