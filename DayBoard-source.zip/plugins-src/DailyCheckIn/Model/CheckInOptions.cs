namespace DailyCheckIn.Model;

/// <summary>A colour you can give a day, with the name shown in tooltips, the Journal and the export.</summary>
public sealed record DayColor(string Name, string Hex);

/// <summary>The colours and suggested tags the check-in offers.</summary>
public static class CheckInOptions
{
    public static readonly IReadOnlyList<DayColor> Colors = new[]
    {
        new DayColor("Dusty blue", "#7E97B3"), new DayColor("Sage", "#7A9A6B"), new DayColor("Honey", "#C9A04E"),
        new DayColor("Terracotta", "#C47552"), new DayColor("Rose", "#C98A9A"), new DayColor("Lavender", "#9A88B5"),
        new DayColor("Teal", "#6F9A94"), new DayColor("Stone", "#8C8478"),
    };

    public static readonly IReadOnlyList<string> Tags = new[]
    {
        "calm", "focused", "tired", "stressed", "social", "active", "grateful", "anxious",
    };

    /// <summary>The name of a colour of the day, or null for a colour that isn't offered (any more).</summary>
    public static string? ColorName(string? hex) =>
        hex is null ? null : Colors.FirstOrDefault(c => string.Equals(c.Hex, hex, StringComparison.OrdinalIgnoreCase))?.Name;
}
