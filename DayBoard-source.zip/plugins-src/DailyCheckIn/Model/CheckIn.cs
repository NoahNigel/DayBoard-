using System.Globalization;
using System.Text;

namespace DailyCheckIn.Model;

/// <summary>One day's check-in: how you felt (1–5), a colour for the day, a few tags and an optional journal note.</summary>
public sealed class CheckIn
{
    public const int MaxTags = 12;
    public const int MaxTagLength = 30;
    public const int MaxNoteLength = 20_000;

    public DateOnly Date { get; set; }

    /// <summary>1 (very low) to 5 (great), or null when not logged.</summary>
    public int? Mood { get; set; }

    /// <summary>The colour of the day as #RRGGBB, or null.</summary>
    public string? Color { get; set; }

    public List<string> Tags { get; set; } = new();
    public string Note { get; set; } = "";
    public DateTime UpdatedAt { get; set; }

    public bool IsEmpty => Mood is null && string.IsNullOrEmpty(Color) && Tags.Count == 0 && string.IsNullOrWhiteSpace(Note);

    public CheckIn Clone()
    {
        var c = (CheckIn)MemberwiseClone();
        c.Tags = new List<string>(Tags);
        return c;
    }

    /// <summary>Trims and limits the values so whatever is typed can be stored safely.</summary>
    public void Normalize()
    {
        if (Mood is < 1 or > 5) Mood = null;
        Color = string.IsNullOrWhiteSpace(Color) ? null : Color.Trim().ToUpperInvariant();
        Tags = Tags.Select(t => NormalizeTag(t)).Where(t => t.Length > 0)
            .Distinct(StringComparer.CurrentCultureIgnoreCase).Take(MaxTags).ToList();
        Note = (Note ?? "").TrimEnd();
        if (Note.Length > MaxNoteLength) Note = Note[..MaxNoteLength];
    }

    public static string NormalizeTag(string? tag)
    {
        var t = string.Join(' ', (tag ?? "").Split((char[]?)null, StringSplitOptions.RemoveEmptyEntries)).Trim().TrimStart('#');
        return t.Length > MaxTagLength ? t[..MaxTagLength] : t;
    }

    public static string MoodLabel(int? mood) => mood switch
    {
        1 => "Very low",
        2 => "Low",
        3 => "Okay",
        4 => "Good",
        5 => "Great",
        _ => "",
    };
}

/// <summary>Writes the journal as Markdown, oldest day first.</summary>
public static class JournalExporter
{
    public static string ToMarkdown(IEnumerable<CheckIn> entries, Func<string?, string?> colorName, CultureInfo? culture = null)
    {
        culture ??= CultureInfo.CurrentCulture;
        var sb = new StringBuilder();
        sb.Append("# DayBoard journal\n");
        foreach (var e in entries.Where(e => !e.IsEmpty).OrderBy(e => e.Date))
        {
            sb.Append("\n## ").Append(e.Date.ToString("dddd d MMMM yyyy", culture)).Append('\n');
            var facts = new List<string>();
            if (e.Mood is { } m) facts.Add($"Feeling: {CheckIn.MoodLabel(m)} ({m}/5)");
            if (!string.IsNullOrEmpty(e.Color)) facts.Add("Colour: " + (colorName(e.Color) ?? e.Color));
            if (e.Tags.Count > 0) facts.Add("Tags: " + string.Join(", ", e.Tags));
            if (facts.Count > 0) sb.Append('\n').Append(string.Join(" · ", facts)).Append('\n');
            if (!string.IsNullOrWhiteSpace(e.Note))
            {
                sb.Append('\n');
                // Keep the note's own lines. A line starting with '#' would become a heading, so escape it.
                foreach (var line in e.Note.Replace("\r\n", "\n").Split('\n'))
                    sb.Append(line.StartsWith('#') ? "\\" + line : line).Append('\n');
            }
        }
        return sb.ToString();
    }
}
