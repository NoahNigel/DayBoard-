using System.Globalization;
using System.Text.Json;
using DayBoard.Plugins;

namespace DailyCheckIn.Model;

/// <summary>
/// The check-ins, kept in the plugin's storage as one entry per day ("checkin:2026-10-27"), and in memory while the
/// plugin runs. DayBoard 1.3 copied the check-ins made with DayBoard 1.2 into the same keys.
/// </summary>
public sealed class CheckInStore
{
    public const string KeyPrefix = "checkin:";
    private const string DateFmt = "yyyy-MM-dd";
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    private readonly IPluginStorage _storage;
    private readonly Dictionary<DateOnly, CheckIn> _items = new();

    public CheckInStore(IPluginStorage storage)
    {
        _storage = storage;
        foreach (var (key, value) in storage.GetAll(KeyPrefix))
        {
            if (!DateOnly.TryParseExact(key[KeyPrefix.Length..], DateFmt, CultureInfo.InvariantCulture, DateTimeStyles.None, out var date)) continue;
            if (Parse(value) is not { } s) continue;
            var c = new CheckIn
            {
                Date = date,
                Mood = s.Mood,
                Color = s.Color,
                Tags = s.Tags ?? new(),
                Note = s.Note ?? "",
                UpdatedAt = s.UpdatedAt,
            };
            c.Normalize();
            if (!c.IsEmpty) _items[date] = c;
        }
    }

    private static Stored? Parse(string json)
    {
        try
        {
            return JsonSerializer.Deserialize<Stored>(json, Json);
        }
        catch (JsonException)
        {
            return null; // a damaged entry is skipped, never fatal
        }
    }

    /// <summary>How a day is stored: camelCase JSON, such as {"mood":4,"color":"#7A9A6B","tags":["calm"],"note":"…"}.</summary>
    private sealed record Stored(int? Mood, string? Color, List<string>? Tags, string? Note, DateTime UpdatedAt);

    public static string KeyFor(DateOnly date) => KeyPrefix + date.ToString(DateFmt, CultureInfo.InvariantCulture);

    /// <summary>Raised after an entry was saved or removed.</summary>
    public event EventHandler<DateOnly>? Changed;

    public int Count => _items.Count;

    /// <summary>A copy of the entry for a day, or null when nothing was logged.</summary>
    public CheckIn? Get(DateOnly date) => _items.TryGetValue(date, out var c) ? c.Clone() : null;

    public IReadOnlyList<CheckIn> Between(DateOnly from, DateOnly to) =>
        _items.Values.Where(c => c.Date >= from && c.Date <= to).OrderBy(c => c.Date).Select(c => c.Clone()).ToList();

    public IReadOnlyList<CheckIn> All() => _items.Values.OrderBy(c => c.Date).Select(c => c.Clone()).ToList();

    /// <summary>Tags used before, most used first (ties A to Z).</summary>
    public IReadOnlyList<string> UsedTags() => _items.Values.SelectMany(c => c.Tags)
        .GroupBy(t => t, StringComparer.CurrentCultureIgnoreCase)
        .OrderByDescending(g => g.Count()).ThenBy(g => g.Key, StringComparer.CurrentCultureIgnoreCase)
        .Select(g => g.First()).ToList();

    /// <summary>Saves a day's entry. An entry with nothing in it removes the day.</summary>
    public void Save(CheckIn entry, DateTime now)
    {
        var c = entry.Clone();
        c.Normalize();
        c.UpdatedAt = now;
        if (c.IsEmpty)
        {
            if (!_items.Remove(c.Date)) return;
            _storage.Set(KeyFor(c.Date), null);
        }
        else
        {
            _storage.SetJson(KeyFor(c.Date), new Stored(c.Mood, c.Color, c.Tags, c.Note, c.UpdatedAt));
            _items[c.Date] = c;
        }
        Changed?.Invoke(this, c.Date);
    }
}
