using System.Windows;
using DayBoard.Plugins;
using DayBoard.PluginShared;
using Matrix.ViewModels;

namespace Matrix;

/// <summary>
/// The Eisenhower matrix: open tasks by urgency and importance. Drag a card to another quadrant to change the task's
/// urgency and priority.
/// </summary>
public sealed class MatrixPlugin : IDayBoardPlugin
{
    public void Start(IDayBoardHost host) => host.AddPage(new MatrixPage(host));

    public void Stop()
    {
    }
}

internal sealed class MatrixPage(IDayBoardHost host) : PluginPage
{
    private readonly MatrixViewModel _vm = new(host);

    public override string Id => "matrix";
    public override string Title => "Matrix";
    public override string Heading => "Eisenhower matrix";
    public override string Icon => "Grid24";

    public override string? Subtitle(DateOnly date) => "Urgency × importance (Medium and High priority count as important)";

    public override FrameworkElement CreateView()
    {
        var view = Xaml.View("MatrixPage.xaml", _vm);
        _ = new ZoneDrops(host, view, _vm.Drop);
        return view;
    }

    public override void Show(DateOnly date) => _vm.Refresh();
}
