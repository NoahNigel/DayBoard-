using DayBoard.Plugins;
using DayBoard.PluginShared;
using Matrix.Model;

namespace Matrix.ViewModels;

/// <summary>A quadrant of the matrix.</summary>
public sealed class Quadrant(string key, string title, string hint, bool urgent, bool important) : DropZone
{
    public override string Key { get; } = key;
    public string Title { get; } = title;
    public string Hint { get; } = hint;
    public bool Urgent { get; } = urgent;
    public bool Important { get; } = important;
}

/// <summary>The four quadrants. Dropping a card on one sets the task's urgency and, if needed, its priority.</summary>
public sealed class MatrixViewModel(IDayBoardHost host) : ScopedBoard(host)
{
    public Quadrant DoFirst { get; } = new("DoFirst", "Do first", "Urgent and important", true, true);
    public Quadrant Schedule { get; } = new("Schedule", "Schedule", "Important, not urgent", false, true);
    public Quadrant Delegate { get; } = new("Delegate", "Delegate", "Urgent, not important", true, false);
    public Quadrant Eliminate { get; } = new("Eliminate", "Eliminate", "Neither urgent nor important", false, false);

    public override void Refresh()
    {
        var tasks = Host.AllTasks();
        foreach (var q in new[] { DoFirst, Schedule, Delegate, Eliminate })
            q.Cards = Cards(Quadrants.In(tasks, q.Urgent, q.Important, Scope, Host.Today, Host.WeekStart));
    }

    public void Drop(DropZone zone, Guid taskId)
    {
        if (zone is Quadrant q) Host.SetQuadrant(taskId, q.Urgent, q.Important);
    }
}
