using DayBoard.Plugins;
using DayBoard.PluginShared;

namespace Matrix.Model;

/// <summary>Sorts open tasks into the Eisenhower matrix: urgent or not, important (Medium or High priority) or not.</summary>
public static class Quadrants
{
    public static List<PluginTask> In(IEnumerable<PluginTask> tasks, bool urgent, bool important, BoardScope scope, DateOnly today, DayOfWeek weekStart) =>
        tasks.Where(t => !t.IsDone && t.IsUrgent == urgent && t.IsImportant == important && Boards.InScope(t, scope, today, weekStart)).ToList();
}
