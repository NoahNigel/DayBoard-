using DayBoard.Plugins;

namespace DayBoard.PluginShared;

/// <summary>Which tasks a board shows: today's, this week's or every open one.</summary>
public enum BoardScope
{
    Today,
    Week,
    All,
}

/// <summary>Board helpers shared by the Kanban and matrix plugins (the file is compiled into each).</summary>
public static class Boards
{
    public static DateOnly StartOfWeek(DateOnly date, DayOfWeek weekStart)
    {
        int diff = ((int)date.DayOfWeek - (int)weekStart + 7) % 7;
        return date.AddDays(-diff);
    }

    /// <summary>Whether an open task belongs on a board with this scope. Overdue work always shows.</summary>
    public static bool InScope(PluginTask t, BoardScope scope, DateOnly today, DayOfWeek weekStart)
    {
        if (scope == BoardScope.All) return true;
        if (t.Date is not { } d) return false;
        if (!t.IsDone && d < today) return true;
        if (scope == BoardScope.Today) return d == today;
        var ws = StartOfWeek(today, weekStart);
        return d >= ws && d <= ws.AddDays(6);
    }

    public static BoardScope ParseScope(string? text) =>
        Enum.TryParse<BoardScope>(text, ignoreCase: true, out var s) && Enum.IsDefined(s) ? s : BoardScope.Week;
}
