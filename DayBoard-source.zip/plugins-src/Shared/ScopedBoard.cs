using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Plugins;

namespace DayBoard.PluginShared;

/// <summary>A board with the Today / This week / All open switch. The choice is kept in the plugin's storage.</summary>
public abstract partial class ScopedBoard : ObservableObject
{
    private const string ScopeKey = "scope";

    protected ScopedBoard(IDayBoardHost host)
    {
        Host = host;
        _scope = Boards.ParseScope(host.Storage.Get(ScopeKey));
    }

    protected IDayBoardHost Host { get; }

    [ObservableProperty] private BoardScope _scope;

    public bool IsToday
    {
        get => Scope == BoardScope.Today;
        set
        {
            if (value) Scope = BoardScope.Today;
        }
    }

    public bool IsWeek
    {
        get => Scope == BoardScope.Week;
        set
        {
            if (value) Scope = BoardScope.Week;
        }
    }

    public bool IsAll
    {
        get => Scope == BoardScope.All;
        set
        {
            if (value) Scope = BoardScope.All;
        }
    }

    partial void OnScopeChanged(BoardScope value)
    {
        Host.Storage.Set(ScopeKey, value.ToString());
        OnPropertyChanged(nameof(IsToday));
        OnPropertyChanged(nameof(IsWeek));
        OnPropertyChanged(nameof(IsAll));
        Refresh();
    }

    /// <summary>Rebuilds the board from the host's tasks.</summary>
    public abstract void Refresh();

    /// <summary>DayBoard's cards for these tasks, with their dates shown.</summary>
    protected IReadOnlyList<System.Windows.FrameworkElement> Cards(IEnumerable<PluginTask> tasks) =>
        tasks.Select(t => Host.CreateTaskCard(t.Id, showDate: true)).OfType<System.Windows.FrameworkElement>().ToList();
}
