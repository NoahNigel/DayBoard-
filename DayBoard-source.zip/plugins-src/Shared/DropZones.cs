using System.Windows;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Plugins;

namespace DayBoard.PluginShared;

/// <summary>A place on a board that takes dropped tasks: a Kanban column or a matrix quadrant.</summary>
public abstract partial class DropZone : ObservableObject
{
    /// <summary>Names the zone, such as "Doing" or "DoFirst".</summary>
    public abstract string Key { get; }

    /// <summary>True while a task is dragged over the zone, for the highlight.</summary>
    [ObservableProperty] private bool _isDropTarget;

    /// <summary>DayBoard's task cards, made by the host.</summary>
    [ObservableProperty] private IReadOnlyList<FrameworkElement> _cards = Array.Empty<FrameworkElement>();

    public int Count => Cards.Count;

    public bool IsEmpty => Cards.Count == 0;

    partial void OnCardsChanged(IReadOnlyList<FrameworkElement> value)
    {
        OnPropertyChanged(nameof(Count));
        OnPropertyChanged(nameof(IsEmpty));
    }
}

/// <summary>
/// Takes DayBoard's task drags on a view: any element with AllowDrop whose DataContext is a <see cref="DropZone"/> is a
/// target. The handlers sit on the view itself, because loaded XAML can't name the plugin's own methods.
/// </summary>
public sealed class ZoneDrops
{
    private readonly FrameworkElement _root;
    private readonly Action<DropZone, Guid> _drop;
    private DropZone? _target;

    public ZoneDrops(IDayBoardHost host, FrameworkElement root, Action<DropZone, Guid> drop)
    {
        _root = root;
        _drop = drop;
        root.AddHandler(DragDrop.DragOverEvent, new DragEventHandler(OnDragOver));
        root.AddHandler(DragDrop.DragLeaveEvent, new DragEventHandler(OnDragLeave));
        root.AddHandler(DragDrop.DropEvent, new DragEventHandler(OnDrop));
        host.TaskDragEnded += (_, _) => Highlight(null);
    }

    private void OnDragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        var zone = ZoneAt(e.OriginalSource);
        e.Effects = zone is not null && TaskDragData.TryGetTask(e, out _) ? DragDropEffects.Move : DragDropEffects.None;
        Highlight(e.Effects == DragDropEffects.None ? null : zone);
    }

    private void OnDragLeave(object sender, DragEventArgs e)
    {
        if (!TaskDragData.IsOver(_root, e)) Highlight(null);
    }

    private void OnDrop(object sender, DragEventArgs e)
    {
        e.Handled = true;
        Highlight(null);
        if (ZoneAt(e.OriginalSource) is { } zone && TaskDragData.TryGetTask(e, out var id)) _drop(zone, id);
    }

    private void Highlight(DropZone? zone)
    {
        if (ReferenceEquals(zone, _target)) return;
        if (_target is not null) _target.IsDropTarget = false;
        _target = zone;
        if (zone is not null) zone.IsDropTarget = true;
    }

    /// <summary>The zone under the pointer: the nearest element up the tree that takes drops for a zone.</summary>
    private static DropZone? ZoneAt(object? source)
    {
        for (var d = source as DependencyObject; d is not null; d = Parent(d))
        {
            if (d is FrameworkElement { AllowDrop: true, DataContext: DropZone zone }) return zone;
        }
        return null;
    }

    private static DependencyObject? Parent(DependencyObject d) =>
        (d is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : null) ?? LogicalTreeHelper.GetParent(d);
}
