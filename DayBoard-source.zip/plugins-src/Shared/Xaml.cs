using System.Windows;
using System.Windows.Markup;

namespace DayBoard.PluginShared;

/// <summary>
/// Loads the plugin's views, which are embedded as XAML text and parsed at run time. Compiled XAML finds its resources
/// by assembly name, which isn't reliable for a plugin that DayBoard loads (and may load again after an update).
/// </summary>
public static class Xaml
{
    /// <summary>Loads Views/<paramref name="file"/> from this plugin and sets its DataContext.</summary>
    public static FrameworkElement View(string file, object dataContext)
    {
        var assembly = typeof(Xaml).Assembly;
        var name = assembly.GetName().Name + ".Views." + file;
        using var stream = assembly.GetManifestResourceStream(name)
                           ?? throw new InvalidOperationException($"The view {name} is missing from the plugin.");
        var view = XamlReader.Load(stream) as FrameworkElement
                   ?? throw new InvalidOperationException($"The view {name} isn't a FrameworkElement.");
        view.DataContext = dataContext;
        return view;
    }
}
