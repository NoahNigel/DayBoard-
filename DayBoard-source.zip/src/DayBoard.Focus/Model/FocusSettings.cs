namespace DayBoard.Focus.Model;

/// <summary>The timer's lengths, kept in the plugin's storage under <see cref="Key"/>.</summary>
public sealed record FocusSettings
{
    public const string Key = "settings";

    public int WorkMinutes { get; init; } = 25;
    public int BreakMinutes { get; init; } = 5;
    public int LongBreakMinutes { get; init; } = 15;

    /// <summary>A long break comes after this many focus sessions.</summary>
    public int LongBreakEvery { get; init; } = 4;

    public bool AutoStartBreak { get; init; } = true;

    /// <summary>The same settings, kept within sensible limits.</summary>
    public FocusSettings Normalized() => this with
    {
        WorkMinutes = Math.Clamp(WorkMinutes, 1, 180),
        BreakMinutes = Math.Clamp(BreakMinutes, 1, 60),
        LongBreakMinutes = Math.Clamp(LongBreakMinutes, 1, 120),
        LongBreakEvery = Math.Clamp(LongBreakEvery, 2, 12),
    };

    /// <summary>Formats minutes the way DayBoard does: "45m", "2h", "1h 30m".</summary>
    public static string FormatMinutes(int minutes)
    {
        if (minutes <= 0) return "0m";
        int h = minutes / 60, m = minutes % 60;
        if (h == 0) return $"{m}m";
        return m == 0 ? $"{h}h" : $"{h}h {m}m";
    }
}
