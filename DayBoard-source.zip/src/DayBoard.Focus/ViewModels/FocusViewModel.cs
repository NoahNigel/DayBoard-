using System.Globalization;
using System.Media;
using System.Windows;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Focus.Model;
using DayBoard.Plugins;

namespace DayBoard.Focus.ViewModels;

public sealed record FocusTaskOption(Guid Id, string Title, string Detail);

public enum FocusPhase
{
    Work,
    ShortBreak,
    LongBreak,
}

/// <summary>
/// The focus timer, bound to a task. Work time is logged to the task when a session ends, when you reset or skip, when
/// you switch tasks, and when Focus stops (unticked, or DayBoard closing).
/// </summary>
public sealed partial class FocusViewModel : ObservableObject
{
    private readonly IDayBoardHost _host;
    private readonly DispatcherTimer _timer = new() { Interval = TimeSpan.FromMilliseconds(250) };
    private FocusSettings _settings;
    private DateTime _phaseEndsAt;
    private DateTime? _workStartedAt;
    private double _workSecondsUnlogged;
    private int _workStreak;
    private bool _loadingSettings;

    [ObservableProperty] private List<FocusTaskOption> _tasks = new();
    [ObservableProperty] private FocusTaskOption? _selected;
    [ObservableProperty] private FocusPhase _phase = FocusPhase.Work;
    [ObservableProperty] private bool _isRunning;
    [ObservableProperty] private TimeSpan _remaining;
    [ObservableProperty] private double _progress;
    [ObservableProperty] private int _completedSessions;
    [ObservableProperty] private string _estimateText = "–";
    [ObservableProperty] private string _actualText = "0m";
    [ObservableProperty] private GridLength _actualPart = new(0, GridUnitType.Star);
    [ObservableProperty] private GridLength _restPart = new(1, GridUnitType.Star);
    [ObservableProperty] private bool _isOverEstimate;
    [ObservableProperty] private List<PluginSubtask> _subtasks = new();
    [ObservableProperty] private bool _hasSubtasks;
    [ObservableProperty] private string _taskTitle = "Pick a task to focus on";
    [ObservableProperty] private string _taskMeta = "";

    // Timer settings, as typed.
    [ObservableProperty] private string _workMinutes = "";
    [ObservableProperty] private string _breakMinutes = "";
    [ObservableProperty] private string _longBreakMinutes = "";
    [ObservableProperty] private string _longBreakEvery = "";
    [ObservableProperty] private bool _autoStartBreak;

    public FocusViewModel(IDayBoardHost host)
    {
        _host = host;
        _settings = (host.Storage.GetJson<FocusSettings>(FocusSettings.Key) ?? new FocusSettings()).Normalized();
        _timer.Tick += (_, _) => Tick();
        Remaining = PhaseLength;
        ShowSettings();
    }

    public string RemainingText => $"{(int)Remaining.TotalMinutes:00}:{Remaining.Seconds:00}";
    public string PhaseText => Phase switch
    {
        FocusPhase.ShortBreak => "Short break",
        FocusPhase.LongBreak => "Long break",
        _ => "Focus",
    };
    public string StartPauseText => IsRunning ? "Pause" : Remaining < PhaseLength ? "Resume" : "Start";
    public bool HasTask => Selected is not null;
    public string SessionsText => CompletedSessions == 1 ? "1 session today" : $"{CompletedSessions} sessions today";

    private TimeSpan PhaseLength => TimeSpan.FromMinutes(Phase switch
    {
        FocusPhase.ShortBreak => _settings.BreakMinutes,
        FocusPhase.LongBreak => _settings.LongBreakMinutes,
        _ => _settings.WorkMinutes,
    });

    private static string SessionsKey(DateOnly day) => "sessions:" + day.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

    partial void OnRemainingChanged(TimeSpan value)
    {
        OnPropertyChanged(nameof(RemainingText));
        OnPropertyChanged(nameof(StartPauseText));
    }

    partial void OnIsRunningChanged(bool value) => OnPropertyChanged(nameof(StartPauseText));
    partial void OnPhaseChanged(FocusPhase value) => OnPropertyChanged(nameof(PhaseText));
    partial void OnCompletedSessionsChanged(int value) => OnPropertyChanged(nameof(SessionsText));

    partial void OnSelectedChanged(FocusTaskOption? oldValue, FocusTaskOption? newValue)
    {
        if (oldValue is not null && oldValue.Id != newValue?.Id) LogWork(oldValue.Id);
        OnPropertyChanged(nameof(HasTask));
        UpdateTaskInfo();
    }

    /// <summary>"Focus on this" from a task's menu.</summary>
    public void Select(Guid taskId)
    {
        Refresh();
        var opt = Tasks.FirstOrDefault(t => t.Id == taskId);
        if (opt is null)
        {
            if (_host.FindTask(taskId) is not { } task) return;
            opt = new FocusTaskOption(task.Id, task.Title, task.Date?.ToString("ddd d MMM", CultureInfo.CurrentCulture) ?? "Inbox");
            Tasks = Tasks.Prepend(opt).ToList();
        }
        Selected = opt;
    }

    public void Refresh()
    {
        var today = _host.Today;
        var todays = _host.TasksOn(today);
        var options = _host.OverdueTasks().Concat(todays.Where(t => !t.IsDone)).Concat(_host.InboxTasks())
            .DistinctBy(t => t.Id)
            .Select(t => new FocusTaskOption(t.Id, t.Title,
                t.Date is null ? "Inbox" : t.Date < today ? "Overdue" : t.StartTime is { } st ? st.ToString("HH\\:mm", CultureInfo.InvariantCulture) : "Today"))
            .ToList();
        if (Selected is not null && options.All(o => o.Id != Selected.Id) && _host.FindTask(Selected.Id) is { } sel)
            options.Insert(0, new FocusTaskOption(sel.Id, sel.Title, sel.IsDone ? "Done" : "Selected"));
        var keep = Selected?.Id;
        Tasks = options;
        if (keep.HasValue)
        {
            Selected = Tasks.FirstOrDefault(o => o.Id == keep.Value);
        }
        else if (!IsRunning)
        {
            // Suggest the task that's on now (or next), else the first open task of the day.
            var now = TimeOnly.FromDateTime(DateTime.Now);
            var timed = todays.Where(t => !t.IsDone && t.StartTime is { } st && st.AddMinutes(t.EstimateMinutes ?? 30) > now)
                .OrderBy(t => t.StartTime).FirstOrDefault();
            Selected = (timed is null ? null : Tasks.FirstOrDefault(o => o.Id == timed.Id)) ?? Tasks.FirstOrDefault();
        }
        CompletedSessions = int.TryParse(_host.Storage.Get(SessionsKey(today)), out var n) ? n : 0;
        if (!IsRunning && Remaining == TimeSpan.Zero) Remaining = PhaseLength;
        UpdateTaskInfo();
    }

    private void UpdateTaskInfo()
    {
        var t = Selected is null ? null : _host.FindTask(Selected.Id);
        if (t is null)
        {
            TaskTitle = "Pick a task to focus on";
            TaskMeta = "";
            EstimateText = "–";
            ActualText = "0m";
            SetActualBar(0);
            IsOverEstimate = false;
            Subtasks = new();
            HasSubtasks = false;
            return;
        }
        TaskTitle = t.Title;
        TaskMeta = t.Date?.ToString("dddd d MMMM", CultureInfo.CurrentCulture) ?? "Inbox";
        EstimateText = t.EstimateMinutes is > 0 ? FocusSettings.FormatMinutes(t.EstimateMinutes.Value) : "No estimate";
        Subtasks = t.Subtasks.ToList();
        HasSubtasks = Subtasks.Count > 0;
        UpdateActual(t);
    }

    /// <summary>Logged time plus the running session that isn't logged yet.</summary>
    private void UpdateActual(PluginTask t)
    {
        double running = _workSecondsUnlogged + (IsRunning && Phase == FocusPhase.Work && _workStartedAt is { } ws ? (DateTime.Now - ws).TotalSeconds : 0);
        int actual = t.ActualMinutes + (int)Math.Floor(running / 60);
        ActualText = FocusSettings.FormatMinutes(actual);
        SetActualBar(t.EstimateMinutes is > 0 ? Math.Min(1.0, actual / (double)t.EstimateMinutes.Value) : 0);
        IsOverEstimate = t.EstimateMinutes is > 0 && actual > t.EstimateMinutes;
    }

    private void SetActualBar(double ratio)
    {
        ActualPart = new GridLength(ratio, GridUnitType.Star);
        RestPart = new GridLength(1 - ratio, GridUnitType.Star);
    }

    [RelayCommand]
    private void StartPause()
    {
        if (IsRunning)
        {
            Remaining = _phaseEndsAt - DateTime.Now is { } left && left > TimeSpan.Zero ? TimeSpan.FromSeconds(Math.Ceiling(left.TotalSeconds)) : TimeSpan.Zero;
            AccumulateWork();
            IsRunning = false;
            _timer.Stop();
            return;
        }
        var remaining = Remaining <= TimeSpan.Zero ? PhaseLength : Remaining;
        _phaseEndsAt = DateTime.Now + remaining;
        if (Phase == FocusPhase.Work) _workStartedAt = DateTime.Now;
        IsRunning = true;
        _timer.Start();
    }

    [RelayCommand]
    private void Reset()
    {
        if (IsRunning) StartPause();
        if (Phase == FocusPhase.Work && Selected is not null) LogWork(Selected.Id);
        Remaining = PhaseLength;
        Progress = 0;
    }

    [RelayCommand]
    private void Skip()
    {
        if (IsRunning) StartPause();
        if (Phase == FocusPhase.Work && Selected is not null) LogWork(Selected.Id);
        AdvancePhase(completedWork: false);
    }

    /// <summary>Logs the focus time so far to the task.</summary>
    [RelayCommand]
    private void LogNow()
    {
        if (Selected is null) return;
        if (IsRunning) AccumulateWork();
        LogWork(Selected.Id);
    }

    [RelayCommand]
    private void MarkDone()
    {
        if (Selected is null) return;
        LogNow();
        _host.SetDone(Selected.Id, true);
    }

    [RelayCommand]
    private void ToggleSubtask(PluginSubtask? sub)
    {
        if (Selected is null || sub is null) return;
        _host.ToggleSubtask(Selected.Id, sub.Id);
        UpdateTaskInfo();
    }

    private void Tick()
    {
        var left = _phaseEndsAt - DateTime.Now;
        if (left <= TimeSpan.Zero)
        {
            _timer.Stop();
            IsRunning = false;
            AccumulateWork();
            var finished = Phase;
            if (finished == FocusPhase.Work)
            {
                if (Selected is not null) LogWork(Selected.Id);
                var key = SessionsKey(_host.Today);
                CompletedSessions = (int.TryParse(_host.Storage.Get(key), out var n) ? n : 0) + 1;
                _host.Storage.Set(key, CompletedSessions.ToString(CultureInfo.InvariantCulture));
            }
            try
            {
                SystemSounds.Asterisk.Play();
            }
            catch (Exception)
            {
                // No sound is fine.
            }
            _host.ShowNotification(finished == FocusPhase.Work ? "Focus session done" : "Break over",
                finished == FocusPhase.Work ? "Time for a break." : "Ready for the next focus session?");
            AdvancePhase(completedWork: finished == FocusPhase.Work);
            if (_settings.AutoStartBreak && finished == FocusPhase.Work) StartPause();
            return;
        }
        Remaining = TimeSpan.FromSeconds(Math.Ceiling(left.TotalSeconds));
        Progress = 1 - left.TotalSeconds / PhaseLength.TotalSeconds;
        if (Phase == FocusPhase.Work && Selected is not null && _host.FindTask(Selected.Id) is { } task) UpdateActual(task);
    }

    private void AdvancePhase(bool completedWork)
    {
        if (Phase == FocusPhase.Work)
        {
            if (completedWork) _workStreak++;
            if (_workStreak >= _settings.LongBreakEvery)
            {
                Phase = FocusPhase.LongBreak;
                _workStreak = 0;
            }
            else
            {
                Phase = FocusPhase.ShortBreak;
            }
        }
        else
        {
            Phase = FocusPhase.Work;
        }
        Remaining = PhaseLength;
        Progress = 0;
    }

    private void AccumulateWork()
    {
        if (Phase != FocusPhase.Work || _workStartedAt is null) return;
        _workSecondsUnlogged += (DateTime.Now - _workStartedAt.Value).TotalSeconds;
        _workStartedAt = IsRunning ? DateTime.Now : null;
    }

    private void LogWork(Guid taskId)
    {
        if (IsRunning && Phase == FocusPhase.Work) AccumulateWork();
        int minutes = (int)Math.Round(_workSecondsUnlogged / 60);
        _workSecondsUnlogged = 0;
        if (minutes >= 1 && _host.FindTask(taskId) is not null) _host.LogTime(taskId, minutes);
    }

    /// <summary>Focus is stopping: logs running focus time and stops the timer.</summary>
    public void Stop()
    {
        if (Selected is not null)
        {
            if (IsRunning) AccumulateWork();
            LogWork(Selected.Id);
        }
        _timer.Stop();
        IsRunning = false;
    }

    // ---------------------------------------------------------------- timer settings

    private void ShowSettings()
    {
        _loadingSettings = true;
        var c = CultureInfo.CurrentCulture;
        WorkMinutes = _settings.WorkMinutes.ToString(c);
        BreakMinutes = _settings.BreakMinutes.ToString(c);
        LongBreakMinutes = _settings.LongBreakMinutes.ToString(c);
        LongBreakEvery = _settings.LongBreakEvery.ToString(c);
        AutoStartBreak = _settings.AutoStartBreak;
        _loadingSettings = false;
    }

    partial void OnWorkMinutesChanged(string value) => SaveSettings(s => s with { WorkMinutes = Int(value, s.WorkMinutes) });
    partial void OnBreakMinutesChanged(string value) => SaveSettings(s => s with { BreakMinutes = Int(value, s.BreakMinutes) });
    partial void OnLongBreakMinutesChanged(string value) => SaveSettings(s => s with { LongBreakMinutes = Int(value, s.LongBreakMinutes) });
    partial void OnLongBreakEveryChanged(string value) => SaveSettings(s => s with { LongBreakEvery = Int(value, s.LongBreakEvery) });
    partial void OnAutoStartBreakChanged(bool value) => SaveSettings(s => s with { AutoStartBreak = value });

    private static int Int(string text, int current) => int.TryParse(text, NumberStyles.Integer, CultureInfo.CurrentCulture, out var n) ? n : current;

    private void SaveSettings(Func<FocusSettings, FocusSettings> change)
    {
        if (_loadingSettings) return;
        var before = PhaseLength;
        var updated = change(_settings).Normalized();
        if (updated == _settings) return;
        _settings = updated;
        _host.Storage.SetJson(FocusSettings.Key, _settings);
        // A timer that hasn't started yet takes the new length straight away.
        if (!IsRunning && Remaining == before) Remaining = PhaseLength;
    }
}
