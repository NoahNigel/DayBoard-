using System.Windows;
using System.Windows.Markup;

namespace DayBoard.Focus.Views;

/// <summary>Loads the embedded XAML views at run time, as plugins do (see the plugin guide).</summary>
internal static class Xaml
{
    public static FrameworkElement View(string file, object dataContext)
    {
        var name = "DayBoard.Focus.Views." + file;
        using var stream = typeof(Xaml).Assembly.GetManifestResourceStream(name)
                           ?? throw new InvalidOperationException($"The view {name} is missing.");
        var view = XamlReader.Load(stream) as FrameworkElement ?? throw new InvalidOperationException($"The view {name} isn't an element.");
        view.DataContext = dataContext;
        return view;
    }
}
