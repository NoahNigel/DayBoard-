using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using DayBoard.Focus.ViewModels;
using DayBoard.Focus.Views;
using DayBoard.Plugins;

namespace DayBoard.Focus;

/// <summary>
/// Focus: a timer for one task at a time, with short and long breaks. It adds the Focus page and "Focus on this" to the
/// task menu, and logs work time to the task. It comes with DayBoard, and can be unticked under Settings › Plugins.
/// </summary>
public sealed class FocusPlugin : IDayBoardPlugin
{
    private FocusPage? _page;

    public void Start(IDayBoardHost host)
    {
        _page = new FocusPage(new FocusViewModel(host));
        host.AddPage(_page);
        host.AddTaskAction(new FocusOnTask(host, _page));
    }

    public void Stop() => _page?.ViewModel.Stop();
}

internal sealed class FocusPage(FocusViewModel vm) : PluginPage
{
    public const string PageId = "focus";

    public FocusViewModel ViewModel { get; } = vm;

    public override string Id => PageId;
    public override string Title => "Focus";
    public override string Icon => "Timer24";

    public override string? Subtitle(DateOnly date) => "Pomodoro timer with time logging";

    public override FrameworkElement CreateView()
    {
        var view = Xaml.View("FocusPage.xaml", ViewModel);
        if (view.FindName("RingHost") is ContentControl slot)
        {
            var ring = new RingProgress { Thickness = 12 };
            ring.SetBinding(RingProgress.ProgressProperty, new Binding(nameof(FocusViewModel.Progress)));
            ring.SetResourceReference(RingProgress.FillProperty, "DB.Accent");
            ring.SetResourceReference(RingProgress.TrackProperty, "DB.CapacityTrack");
            slot.Content = ring;
        }
        return view;
    }

    public override void Show(DateOnly date) => ViewModel.Refresh();
}

/// <summary>"Focus on this" in a task's menu: opens Focus with that task.</summary>
internal sealed class FocusOnTask(IDayBoardHost host, FocusPage page) : TaskAction
{
    public override string Title => "Focus on this";
    public override string Icon => "Timer24";

    public override void Invoke(Guid taskId)
    {
        page.ViewModel.Select(taskId);
        host.ShowPage(FocusPage.PageId);
    }
}
