using System.Windows.Markup;
using Wpf.Ui.Controls;

namespace DayBoard.Infrastructure;

/// <summary>Resolves Fluent icon names at runtime with a fallback, so a bad name can never break a view.</summary>
public static class Symbols
{
    public static SymbolRegular Parse(string? name, SymbolRegular fallback = SymbolRegular.Tag24) =>
        !string.IsNullOrWhiteSpace(name) && Enum.TryParse<SymbolRegular>(name, ignoreCase: true, out var s) ? s : fallback;

    /// <summary>Icons offered for categories (filtered to names that exist in this WPF-UI version).</summary>
    public static IReadOnlyList<string> CategoryIcons { get; } = new[]
    {
        "Tag24", "Briefcase24", "Person24", "People24", "Home24", "Heart24", "HeartPulse24", "Book24", "HatGraduation24", "Code24",
        "Cart24", "Money24", "Wallet24", "Airplane24", "VehicleCar24", "Food24", "DrinkCoffee24", "Sport24", "Dumbbell24", "Run24",
        "Leaf24", "Lightbulb24", "Star24", "Flag24", "Mail24", "Call24", "Chat24", "Building24", "Globe24", "Wrench24",
        "PaintBrush24", "MusicNote224", "Games24", "Gift24", "Camera24", "Video24", "Bug24", "Rocket24", "Target24", "Trophy24",
        "Shield24", "Clock24", "Calendar24", "Pin24", "Folder24", "Document24", "Bed24", "Beach24", "Pets24", "Baby24",
    }.Where(n => Enum.TryParse<SymbolRegular>(n, out _)).ToList();
}

/// <summary>XAML: <c>Symbol="{infra:Sym CalendarLtr24}"</c>. Unknown names fall back instead of failing to load.</summary>
[MarkupExtensionReturnType(typeof(SymbolRegular))]
public sealed class SymExtension : MarkupExtension
{
    public SymExtension() { }

    public SymExtension(string name) => Name = name;

    [ConstructorArgument("name")]
    public string Name { get; set; } = "";

    public override object ProvideValue(IServiceProvider serviceProvider) => Symbols.Parse(Name, SymbolRegular.Circle24);
}
