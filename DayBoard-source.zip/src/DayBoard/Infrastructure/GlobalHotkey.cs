using System.Runtime.InteropServices;
using System.Windows.Input;
using System.Windows.Interop;

namespace DayBoard.Infrastructure;

/// <summary>System-wide shortcut via RegisterHotKey on a message-only window.</summary>
public sealed class GlobalHotkey : IDisposable
{
    private const int HotkeyId = 0xDB01;
    private HwndSource? _source;
    private bool _registered;

    public event EventHandler? Pressed;

    public bool IsRegistered => _registered;
    public string? LastError { get; private set; }
    public string Display { get; private set; } = "";

    public bool Register(ModifierKeys modifiers, Key key)
    {
        Unregister();
        Display = Format(modifiers, key);
        if (key == Key.None || modifiers == ModifierKeys.None)
        {
            LastError = "Choose a key together with Ctrl, Alt, Shift or Win.";
            return false;
        }

        EnsureSource();
        uint fs = NativeMethods.MOD_NOREPEAT;
        if (modifiers.HasFlag(ModifierKeys.Alt)) fs |= NativeMethods.MOD_ALT;
        if (modifiers.HasFlag(ModifierKeys.Control)) fs |= NativeMethods.MOD_CONTROL;
        if (modifiers.HasFlag(ModifierKeys.Shift)) fs |= NativeMethods.MOD_SHIFT;
        if (modifiers.HasFlag(ModifierKeys.Windows)) fs |= NativeMethods.MOD_WIN;
        uint vk = (uint)KeyInterop.VirtualKeyFromKey(key);

        if (!NativeMethods.RegisterHotKey(_source!.Handle, HotkeyId, fs, vk))
        {
            int err = Marshal.GetLastWin32Error();
            LastError = err == NativeMethods.ERROR_HOTKEY_ALREADY_REGISTERED
                ? $"{Display} is already used by another app."
                : $"Windows refused {Display} (error {err}).";
            return false;
        }

        LastError = null;
        _registered = true;
        return true;
    }

    public void Unregister()
    {
        if (_registered && _source is not null) NativeMethods.UnregisterHotKey(_source.Handle, HotkeyId);
        _registered = false;
    }

    private void EnsureSource()
    {
        if (_source is not null) return;
        var p = new HwndSourceParameters("DayBoardHotkeySink")
        {
            Width = 0,
            Height = 0,
            WindowStyle = 0,
            ParentWindow = new IntPtr(-3), // HWND_MESSAGE: message-only window
        };
        _source = new HwndSource(p);
        _source.AddHook(WndProc);
    }

    private IntPtr WndProc(IntPtr hwnd, int msg, IntPtr wParam, IntPtr lParam, ref bool handled)
    {
        if (msg == NativeMethods.WM_HOTKEY && wParam.ToInt32() == HotkeyId)
        {
            handled = true;
            Pressed?.Invoke(this, EventArgs.Empty);
        }
        return IntPtr.Zero;
    }

    public static bool TryParse(string modifiers, string key, out ModifierKeys mods, out Key k)
    {
        bool okM = Enum.TryParse(modifiers, ignoreCase: true, out mods);
        bool okK = Enum.TryParse(key, ignoreCase: true, out k);
        return okM && okK && k != Key.None;
    }

    public static string Format(ModifierKeys mods, Key key)
    {
        var parts = new List<string>();
        if (mods.HasFlag(ModifierKeys.Control)) parts.Add("Ctrl");
        if (mods.HasFlag(ModifierKeys.Alt)) parts.Add("Alt");
        if (mods.HasFlag(ModifierKeys.Shift)) parts.Add("Shift");
        if (mods.HasFlag(ModifierKeys.Windows)) parts.Add("Win");
        if (key != Key.None) parts.Add(KeyName(key));
        return string.Join("+", parts);
    }

    private static string KeyName(Key key) => key switch
    {
        >= Key.D0 and <= Key.D9 => ((int)key - (int)Key.D0).ToString(System.Globalization.CultureInfo.InvariantCulture),
        Key.OemPlus => "+",
        Key.OemMinus => "-",
        Key.OemComma => ",",
        Key.OemPeriod => ".",
        Key.Oem2 => "/",
        Key.Oem1 => ";",
        _ => key.ToString(),
    };

    public void Dispose()
    {
        Unregister();
        _source?.RemoveHook(WndProc);
        _source?.Dispose();
        _source = null;
    }
}
