using System.Windows;
using System.Windows.Controls;
using DayBoard.Data;
using H.NotifyIcon;
using H.NotifyIcon.Core;

namespace DayBoard.Infrastructure;

/// <summary>Notification-area icon with today's remaining count in the badge and tooltip.</summary>
public sealed class TrayService : IDisposable
{
    private readonly TaskbarIcon _icon;
    private System.Drawing.Icon? _current;
    private int _shownCount = -1;

    public TrayService(Action open, Action quickAdd, Action toggleMini, Action exit)
    {
        var menu = new ContextMenu();
        menu.Items.Add(Item("Open DayBoard", open, bold: true));
        menu.Items.Add(Item("Quick add…", quickAdd));
        menu.Items.Add(Item("Mini view", toggleMini));
        menu.Items.Add(new Separator());
        menu.Items.Add(Item("Exit", exit));

        _icon = new TaskbarIcon
        {
            ToolTipText = "DayBoard",
            ContextMenu = menu,
            NoLeftClickDelay = true,
            MenuActivation = PopupActivationMode.RightClick,
        };
        _icon.TrayLeftMouseUp += (_, _) => open();
        Update(0);
        _icon.ForceCreate(enablesEfficiencyMode: false);
    }

    private static MenuItem Item(string header, Action action, bool bold = false)
    {
        var item = new MenuItem { Header = header };
        if (bold) item.FontWeight = FontWeights.SemiBold;
        item.Click += (_, _) => action();
        return item;
    }

    public void Update(int remainingToday)
    {
        _icon.ToolTipText = remainingToday switch
        {
            0 => "DayBoard: nothing left for today",
            1 => "DayBoard: 1 task left today",
            _ => $"DayBoard: {remainingToday} tasks left today",
        };
        if (remainingToday == _shownCount) return;
        _shownCount = remainingToday;
        try
        {
            var next = IconFactory.TrayIcon(remainingToday);
            _icon.Icon = next;
            _current?.Dispose();
            _current = next;
        }
        catch (Exception ex)
        {
            Log.Error("Update tray icon", ex);
        }
    }

    public void Notify(string title, string message)
    {
        try
        {
            _icon.ShowNotification(title, message, NotificationIcon.Info);
        }
        catch (Exception ex)
        {
            Log.Error("Tray notification", ex);
        }
    }

    public void Dispose()
    {
        _icon.Dispose();
        _current?.Dispose();
    }
}
