using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;

namespace DayBoard.Infrastructure;

/// <summary>Task drag-and-drop plumbing shared by every view.</summary>
public static class TaskDrag
{
    public const string Format = DayBoard.Plugins.TaskDragData.Format;

    /// <summary>The task being dragged (null when no drag is in progress).</summary>
    public static Guid? Current { get; private set; }

    /// <summary>Estimated minutes of the dragged task (for the timeline drop ghost).</summary>
    public static int CurrentMinutes { get; private set; }

    public static event EventHandler? Ended;

    public static void Begin(DependencyObject source, Guid taskId, int minutes)
    {
        if (Current.HasValue) return;
        Current = taskId;
        CurrentMinutes = minutes;
        try
        {
            var data = new DataObject(Format, taskId.ToString());
            DragDrop.DoDragDrop(source, data, DragDropEffects.Move);
        }
        finally
        {
            Current = null;
            Ended?.Invoke(null, EventArgs.Empty);
        }
    }

    /// <summary>True when the drag position is still inside <paramref name="el"/> (DragLeave also fires when moving onto a child).</summary>
    public static bool IsInside(FrameworkElement el, DragEventArgs e)
    {
        var p = e.GetPosition(el);
        return p.X >= 0 && p.Y >= 0 && p.X < el.ActualWidth && p.Y < el.ActualHeight;
    }

    /// <summary>Self-test hook: pretends a drag of <paramref name="taskId"/> is in progress.</summary>
    internal static void Simulate(Guid taskId, int minutes)
    {
        Current = taskId;
        CurrentMinutes = minutes;
    }

    internal static void EndSimulation()
    {
        Current = null;
        Ended?.Invoke(null, EventArgs.Empty);
    }

    public static bool TryGet(DragEventArgs e, out Guid taskId)
    {
        taskId = default;
        return e.Data.GetDataPresent(Format) && Guid.TryParse(e.Data.GetData(Format) as string, out taskId);
    }
}

/// <summary>Starts a drag after the mouse moved a few pixels with the button held.</summary>
public sealed class DragStarter
{
    private Point? _start;

    public void MouseDown(MouseButtonEventArgs e, IInputElement relativeTo)
    {
        _start = e.ChangedButton == MouseButton.Left ? e.GetPosition(relativeTo) : null;
    }

    public bool ShouldStart(MouseEventArgs e, IInputElement relativeTo)
    {
        if (_start is null || e.LeftButton != MouseButtonState.Pressed)
        {
            _start = null;
            return false;
        }
        var p = e.GetPosition(relativeTo);
        if (Math.Abs(p.X - _start.Value.X) < SystemParameters.MinimumHorizontalDragDistance &&
            Math.Abs(p.Y - _start.Value.Y) < SystemParameters.MinimumVerticalDragDistance)
            return false;
        _start = null;
        return true;
    }

    public void Reset() => _start = null;
}

/// <summary>Horizontal insertion line drawn over a list while dragging.</summary>
public sealed class InsertionAdorner : Adorner
{
    private double _y;
    private readonly Pen _pen;
    private readonly Brush _brush;

    public InsertionAdorner(UIElement adorned) : base(adorned)
    {
        IsHitTestVisible = false;
        _brush = ThemeService.Resource("DB.Accent", Brushes.SlateBlue);
        _pen = new Pen(_brush, 2.5) { StartLineCap = PenLineCap.Round, EndLineCap = PenLineCap.Round };
        _pen.Freeze();
    }

    public double Y
    {
        get => _y;
        set
        {
            if (Math.Abs(_y - value) < 0.5) return;
            _y = value;
            InvalidateVisual();
        }
    }

    protected override void OnRender(DrawingContext dc)
    {
        double w = AdornedElement.RenderSize.Width;
        dc.DrawLine(_pen, new Point(6, _y), new Point(w - 6, _y));
        dc.DrawEllipse(_brush, null, new Point(5, _y), 3.5, 3.5);
        dc.DrawEllipse(_brush, null, new Point(w - 5, _y), 3.5, 3.5);
    }
}

/// <summary>Computes the insertion index in an ItemsControl and shows the insertion line.</summary>
public sealed class ListDropIndicator
{
    private InsertionAdorner? _adorner;
    private ItemsControl? _list;

    /// <summary>Returns the visual insertion index (0..Items.Count) for the mouse position and shows the indicator.</summary>
    public int Update(ItemsControl list, DragEventArgs e)
    {
        if (!ReferenceEquals(_list, list)) Clear();
        _list = list;
        var (index, y) = Compute(list, e.GetPosition(list));
        if (_adorner is null)
        {
            var layer = AdornerLayer.GetAdornerLayer(list);
            if (layer is not null)
            {
                _adorner = new InsertionAdorner(list);
                layer.Add(_adorner);
            }
        }
        if (_adorner is not null) _adorner.Y = y;
        return index;
    }

    public static int IndexAt(ItemsControl list, DragEventArgs e) => Compute(list, e.GetPosition(list)).Index;

    private static (int Index, double Y) Compute(ItemsControl list, Point pos)
    {
        int count = list.Items.Count;
        double lastBottom = 2;
        for (int i = 0; i < count; i++)
        {
            if (list.ItemContainerGenerator.ContainerFromIndex(i) is not FrameworkElement c || !c.IsVisible) continue;
            Rect bounds;
            try
            {
                bounds = c.TransformToAncestor(list).TransformBounds(new Rect(c.RenderSize));
            }
            catch (InvalidOperationException)
            {
                continue;
            }
            if (pos.Y < bounds.Top + bounds.Height / 2) return (i, Math.Max(1.5, bounds.Top - 1.5));
            lastBottom = bounds.Bottom;
        }
        return (count, lastBottom + 1);
    }

    public void Clear()
    {
        if (_adorner is not null && _list is not null)
        {
            AdornerLayer.GetAdornerLayer(_list)?.Remove(_adorner);
        }
        _adorner = null;
        _list = null;
    }
}

/// <summary>Scrolls a ScrollViewer when dragging near its top or bottom edge.</summary>
public static class DragAutoScroll
{
    public static void Handle(ScrollViewer? sv, DragEventArgs e)
    {
        if (sv is null) return;
        var p = e.GetPosition(sv);
        const double zone = 36;
        if (p.Y < zone) sv.ScrollToVerticalOffset(sv.VerticalOffset - Math.Max(4, (zone - p.Y) / 2));
        else if (p.Y > sv.ActualHeight - zone) sv.ScrollToVerticalOffset(sv.VerticalOffset + Math.Max(4, (p.Y - (sv.ActualHeight - zone)) / 2));
    }

    public static T? FindAncestor<T>(DependencyObject? d) where T : DependencyObject
    {
        while (d is not null)
        {
            if (d is T t) return t;
            d = d is Visual or System.Windows.Media.Media3D.Visual3D ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d);
        }
        return null;
    }
}
