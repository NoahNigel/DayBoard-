using System.Globalization;
using System.Runtime.InteropServices;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using DayBoard.Data;
using Drawing = System.Drawing;

namespace DayBoard.Infrastructure;

/// <summary>Builds the tray icon with a count badge and the taskbar overlay badge.</summary>
public static class IconFactory
{
    private static readonly Uri IconUri = new("pack://application:,,,/Assets/DayBoard.ico", UriKind.Absolute);

    /// <summary>The notification area's icon size in pixels: 16 at 100 % scaling, 20 at 125 %, 24 at 150 %, 32 at 200 %.</summary>
    public static int TrayIconSize
    {
        get
        {
            try
            {
                int size = NativeMethods.GetSystemMetrics(NativeMethods.SM_CXSMICON);
                return size is >= 16 and <= 64 ? size : 32;
            }
            catch (Exception)
            {
                return 32;
            }
        }
    }

    private static IReadOnlyList<BitmapFrame>? _frames;

    /// <summary>The frames of DayBoard.ico (16 to 256 px; 16-32 px are the variant drawn for small sizes).</summary>
    private static IReadOnlyList<BitmapFrame> Frames
    {
        get
        {
            if (_frames is not null) return _frames;
            using var stream = Application.GetResourceStream(IconUri)!.Stream;
            var decoder = new IconBitmapDecoder(stream, BitmapCreateOptions.PreservePixelFormat, BitmapCacheOption.OnLoad);
            return _frames = decoder.Frames.ToList();
        }
    }

    /// <summary>
    /// The tray icon at <paramref name="size"/> pixels (the tray's own size when null). With nothing left today it's the
    /// logo, from the icon frame made for that size. Otherwise the arc opens up around the number of tasks left today.
    /// </summary>
    public static Drawing.Icon TrayIcon(int count, int? size = null)
    {
        int px = size ?? TrayIconSize;
        var frame = Frames.OrderBy(f => Math.Abs(f.PixelWidth - px)).ThenByDescending(f => f.PixelWidth).First();
        var visual = new DrawingVisual();
        using (var dc = visual.RenderOpen())
        {
            if (count > 0) DrawCount(dc, px, count > 9 ? "9+" : count.ToString(CultureInfo.InvariantCulture));
            else dc.DrawImage(frame, new Rect(0, 0, px, px));
        }
        var rtb = new RenderTargetBitmap(px, px, 96, 96, PixelFormats.Pbgra32);
        rtb.Render(visual);

        // Hand the pixels to GDI+ (premultiplied BGRA either way) to make the HICON the tray needs.
        var pixels = new byte[px * px * 4];
        rtb.CopyPixels(pixels, px * 4, 0);
        using var bmp = new Drawing.Bitmap(px, px, Drawing.Imaging.PixelFormat.Format32bppPArgb);
        var data = bmp.LockBits(new Drawing.Rectangle(0, 0, px, px), Drawing.Imaging.ImageLockMode.WriteOnly, Drawing.Imaging.PixelFormat.Format32bppPArgb);
        try
        {
            for (int y = 0; y < px; y++) Marshal.Copy(pixels, y * px * 4, data.Scan0 + y * data.Stride, px * 4);
        }
        finally
        {
            bmp.UnlockBits(data);
        }

        var hIcon = bmp.GetHicon();
        try
        {
            using var temp = Drawing.Icon.FromHandle(hIcon);
            return (Drawing.Icon)temp.Clone();
        }
        finally
        {
            NativeMethods.DestroyIcon(hIcon);
        }
    }

    // The high priority colour of DayBoard's own look: a muted brick red.
    private static readonly Brush BadgeFill = Frozen(new SolidColorBrush(Color.FromRgb(0xB5, 0x58, 0x5A)));
    private static readonly Brush LogoViolet = Frozen(new SolidColorBrush(Color.FromRgb(0x7B, 0x63, 0xA8)));
    private static readonly Geometry CountArc = Arc(radius: 56, startWidth: 8, endWidth: 20);

    private static Brush Frozen(Brush b)
    {
        b.Freeze();
        return b;
    }

    /// <summary>
    /// The logo's arc on its 160 grid: from the top, clockwise for 270°, swelling from <paramref name="startWidth"/> to
    /// <paramref name="endWidth"/>, with round ends. The same shape as branding/make_logo.py draws.
    /// </summary>
    private static Geometry Arc(double radius, double startWidth, double endWidth)
    {
        const int steps = 120;
        double Width(double t) => startWidth + (endWidth - startWidth) * Math.Pow(t, 0.9);
        Point At(double t, double r)
        {
            double a = (-90 + 270 * t) * Math.PI / 180;
            return new Point(80 + r * Math.Cos(a), 80 + r * Math.Sin(a));
        }
        var outline = new StreamGeometry();
        using (var ctx = outline.Open())
        {
            ctx.BeginFigure(At(0, radius + Width(0) / 2), true, true);
            for (int k = 1; k <= steps; k++) ctx.LineTo(At(k / (double)steps, radius + Width(k / (double)steps) / 2), false, false);
            for (int k = steps; k >= 0; k--) ctx.LineTo(At(k / (double)steps, radius - Width(k / (double)steps) / 2), false, false);
        }
        var arc = new GeometryGroup { FillRule = FillRule.Nonzero };
        arc.Children.Add(outline);
        arc.Children.Add(new EllipseGeometry(At(0, radius), Width(0) / 2, Width(0) / 2));
        arc.Children.Add(new EllipseGeometry(At(1, radius), Width(1) / 2, Width(1) / 2));
        arc.Freeze();
        return arc;
    }

    // The violet square, the arc drawn wider and finer, and the number inside it.
    private static void DrawCount(DrawingContext dc, int px, string text)
    {
        dc.PushTransform(new ScaleTransform(px / 160.0, px / 160.0));
        dc.DrawRoundedRectangle(LogoViolet, null, new Rect(0, 0, 160, 160), 32, 32);
        dc.DrawGeometry(Brushes.White, null, CountArc);
        var ft = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
            new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal), 100, Brushes.White, 1.0);
        var glyphs = ft.BuildGeometry(new Point(0, 0));
        if (glyphs.IsFrozen) glyphs = glyphs.Clone();
        var b = glyphs.Bounds;
        if (!b.IsEmpty && b.Width > 0 && b.Height > 0)
        {
            // Sized by the glyphs themselves, and centred a touch right of and below the middle, where the ring looks centred.
            double k = text.Length > 1 ? Math.Min(44 / b.Height, 78 / b.Width) : Math.Min(56 / b.Height, 60 / b.Width);
            var place = new TransformGroup();
            place.Children.Add(new TranslateTransform(-(b.X + b.Width / 2), -(b.Y + b.Height / 2)));
            place.Children.Add(new ScaleTransform(k, k));
            place.Children.Add(new TranslateTransform(82, 82));
            glyphs.Transform = place;
            dc.DrawGeometry(Brushes.White, null, glyphs);
        }
        dc.Pop();
    }

    /// <summary>Small round badge for <c>TaskbarItemInfo.Overlay</c>.</summary>
    public static ImageSource? OverlayBadge(int count)
    {
        if (count <= 0) return null;
        try
        {
            var text = count > 99 ? "99+" : count.ToString(CultureInfo.InvariantCulture);
            var visual = new DrawingVisual();
            using (var dc = visual.RenderOpen())
            {
                // Windows puts it over the bottom right of the taskbar icon; the violet edge keeps it apart from the arc.
                dc.DrawEllipse(BadgeFill, new Pen(LogoViolet, 2), new Point(16, 16), 15, 15);
                var ft = new FormattedText(text, CultureInfo.InvariantCulture, FlowDirection.LeftToRight,
                    new Typeface(new FontFamily("Segoe UI"), FontStyles.Normal, FontWeights.Bold, FontStretches.Normal),
                    text.Length > 2 ? 11 : text.Length > 1 ? 14 : 18, Brushes.White, 1.0);
                dc.DrawText(ft, new Point(16 - ft.Width / 2, 16 - ft.Height / 2));
            }
            var rtb = new RenderTargetBitmap(32, 32, 96, 96, PixelFormats.Pbgra32);
            rtb.Render(visual);
            rtb.Freeze();
            return rtb;
        }
        catch (Exception ex)
        {
            Log.Error("Overlay badge", ex);
            return null;
        }
    }
}
