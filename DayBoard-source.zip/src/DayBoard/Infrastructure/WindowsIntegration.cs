using System.Windows;
using System.Windows.Shell;
using DayBoard.Data;
using Microsoft.Win32;

namespace DayBoard.Infrastructure;

/// <summary>"Start with Windows" via the HKCU Run key.</summary>
public static class StartupRegistration
{
    private const string RunKey = @"Software\Microsoft\Windows\CurrentVersion\Run";
    private const string ValueName = "DayBoard";

    public static bool IsEnabled()
    {
        using var key = Registry.CurrentUser.OpenSubKey(RunKey, writable: false);
        return key?.GetValue(ValueName) is string s && s.Contains(AppPaths.ExecutablePath, StringComparison.OrdinalIgnoreCase);
    }

    public static void Set(bool enabled)
    {
        try
        {
            using var key = Registry.CurrentUser.CreateSubKey(RunKey, writable: true);
            if (enabled) key.SetValue(ValueName, $"\"{AppPaths.ExecutablePath}\" --minimized");
            else key.DeleteValue(ValueName, throwOnMissingValue: false);
        }
        catch (Exception ex)
        {
            Log.Error("Update startup registration", ex);
        }
    }
}

/// <summary>Taskbar jump list with "New task" and "Today".</summary>
public static class JumpLists
{
    public const string QuickAddArg = "--quick-add";
    public const string TodayArg = "--today";

    public static void Apply(Application app)
    {
        try
        {
            var exe = AppPaths.ExecutablePath;
            var list = new JumpList { ShowFrequentCategory = false, ShowRecentCategory = false };
            list.JumpItems.Add(new JumpTask
            {
                Title = "New task",
                Description = "Quick-add a task",
                ApplicationPath = exe,
                Arguments = QuickAddArg,
                IconResourcePath = exe,
                IconResourceIndex = 0,
            });
            list.JumpItems.Add(new JumpTask
            {
                Title = "Today",
                Description = "Open today's plan",
                ApplicationPath = exe,
                Arguments = TodayArg,
                IconResourcePath = exe,
                IconResourceIndex = 0,
            });
            JumpList.SetJumpList(app, list);
            list.Apply();
        }
        catch (Exception ex)
        {
            Log.Error("Apply jump list", ex);
        }
    }
}

/// <summary>
/// A per-user Start menu shortcut, so Windows search and the Start menu find DayBoard.
/// DayBoard has no installer, so it creates (and, if the exe moved, updates) the shortcut itself.
/// </summary>
public static class StartMenuShortcut
{
    public static string DefaultPath =>
        System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Programs), "DayBoard.lnk");

    /// <summary>Creates or updates the shortcut to point at the running exe. Skipped when the exe runs from a temporary folder.</summary>
    public static void Ensure()
    {
        try
        {
            var exe = AppPaths.ExecutablePath;
            if (IsTemporary(exe)) return;
            if (ReadTarget(DefaultPath) is { } current && string.Equals(current, exe, StringComparison.OrdinalIgnoreCase)) return;
            Write(DefaultPath, exe);
        }
        catch (Exception ex)
        {
            Log.Error("Create Start menu shortcut", ex);
        }
    }

    public static void Remove()
    {
        try
        {
            if (System.IO.File.Exists(DefaultPath)) System.IO.File.Delete(DefaultPath);
        }
        catch (Exception ex)
        {
            Log.Error("Remove Start menu shortcut", ex);
        }
    }

    /// <summary>
    /// True when DayBoard was started from inside the zip: Explorer copies the exe to a temporary folder that Windows
    /// deletes later, so no shortcut is made for it.
    /// </summary>
    public static bool RunningFromTemporaryFolder => IsTemporary(AppPaths.ExecutablePath);

    private static bool IsTemporary(string exe) =>
        exe.StartsWith(System.IO.Path.GetTempPath(), StringComparison.OrdinalIgnoreCase);

    public static void Write(string shortcutPath, string exe)
    {
        System.IO.Directory.CreateDirectory(System.IO.Path.GetDirectoryName(shortcutPath)!);
        var link = (IShellLinkW)new CShellLink();
        try
        {
            link.SetPath(exe);
            link.SetWorkingDirectory(System.IO.Path.GetDirectoryName(exe) ?? "");
            link.SetDescription("Visual daily and weekly task planner");
            link.SetIconLocation(exe, 0);
            ((System.Runtime.InteropServices.ComTypes.IPersistFile)link).Save(shortcutPath, true);
        }
        finally
        {
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(link);
        }
    }

    /// <summary>The exe a shortcut points at, or null when there's no readable shortcut.</summary>
    public static string? ReadTarget(string shortcutPath)
    {
        if (!System.IO.File.Exists(shortcutPath)) return null;
        var link = (IShellLinkW)new CShellLink();
        try
        {
            ((System.Runtime.InteropServices.ComTypes.IPersistFile)link).Load(shortcutPath, 0);
            var sb = new System.Text.StringBuilder(1024);
            link.GetPath(sb, sb.Capacity, IntPtr.Zero, 0x4 /* SLGP_RAWPATH */);
            return sb.Length > 0 ? sb.ToString() : null;
        }
        catch (Exception)
        {
            return null;
        }
        finally
        {
            System.Runtime.InteropServices.Marshal.FinalReleaseComObject(link);
        }
    }

    [System.Runtime.InteropServices.ComImport]
    [System.Runtime.InteropServices.Guid("00021401-0000-0000-C000-000000000046")]
    private class CShellLink
    {
    }

    [System.Runtime.InteropServices.ComImport]
    [System.Runtime.InteropServices.InterfaceType(System.Runtime.InteropServices.ComInterfaceType.InterfaceIsIUnknown)]
    [System.Runtime.InteropServices.Guid("000214F9-0000-0000-C000-000000000046")]
    private interface IShellLinkW
    {
        void GetPath([System.Runtime.InteropServices.Out, System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pszFile, int cch, IntPtr pfd, uint fFlags);
        void GetIDList(out IntPtr ppidl);
        void SetIDList(IntPtr pidl);
        void GetDescription([System.Runtime.InteropServices.Out, System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pszName, int cch);
        void SetDescription([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszName);
        void GetWorkingDirectory([System.Runtime.InteropServices.Out, System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pszDir, int cch);
        void SetWorkingDirectory([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszDir);
        void GetArguments([System.Runtime.InteropServices.Out, System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pszArgs, int cch);
        void SetArguments([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszArgs);
        void GetHotkey(out short wHotkey);
        void SetHotkey(short wHotkey);
        void GetShowCmd(out int iShowCmd);
        void SetShowCmd(int iShowCmd);
        void GetIconLocation([System.Runtime.InteropServices.Out, System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] System.Text.StringBuilder pszIconPath, int cch, out int iIcon);
        void SetIconLocation([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszIconPath, int iIcon);
        void SetRelativePath([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszPathRel, uint dwReserved);
        void Resolve(IntPtr hwnd, uint fFlags);
        void SetPath([System.Runtime.InteropServices.MarshalAs(System.Runtime.InteropServices.UnmanagedType.LPWStr)] string pszFile);
    }
}
