using System.IO;
using System.IO.Pipes;
using System.Security.Cryptography;
using System.Text;
using DayBoard.Data;

namespace DayBoard.Infrastructure;

/// <summary>
/// One DayBoard per user session. Later launches (including jump list tasks) forward their command-line
/// arguments to the running instance over a named pipe that only the current user can open, then exit.
/// </summary>
public sealed class SingleInstance : IDisposable
{
    private readonly Mutex _mutex;
    private readonly CancellationTokenSource _cts = new();

    public SingleInstance(string appId)
    {
        var user = Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(Environment.UserDomainName + "\\" + Environment.UserName)))[..16];
        var name = $"{appId}-{user}";
        PipeName = name + "-args";
        _mutex = new Mutex(initiallyOwned: true, @"Local\" + name, out bool created);
        IsFirstInstance = created;
    }

    public bool IsFirstInstance { get; private set; }
    public string PipeName { get; }

    /// <summary>Raised on a background thread with the arguments of a later launch.</summary>
    public event Action<string[]>? ArgumentsReceived;

    public void StartListening() => _ = Task.Run(ListenLoop);

    private async Task ListenLoop()
    {
        while (!_cts.IsCancellationRequested)
        {
            try
            {
                await using var server = new NamedPipeServerStream(PipeName, PipeDirection.In, 1, PipeTransmissionMode.Byte,
                    PipeOptions.Asynchronous | PipeOptions.CurrentUserOnly);
                await server.WaitForConnectionAsync(_cts.Token).ConfigureAwait(false);
                using var reader = new StreamReader(server, Encoding.UTF8);
                var text = await reader.ReadToEndAsync(_cts.Token).ConfigureAwait(false);
                var args = text.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                ArgumentsReceived?.Invoke(args);
            }
            catch (OperationCanceledException)
            {
                return;
            }
            catch (Exception ex)
            {
                Log.Error("Single-instance pipe", ex);
                await Task.Delay(500).ConfigureAwait(false);
            }
        }
    }

    /// <summary>After a restart, waits for the previous instance to exit and takes over.</summary>
    public bool TryTakeOver(TimeSpan timeout)
    {
        if (IsFirstInstance) return true;
        try
        {
            IsFirstInstance = _mutex.WaitOne(timeout);
        }
        catch (AbandonedMutexException)
        {
            IsFirstInstance = true;
        }
        return IsFirstInstance;
    }

    /// <summary>Sends arguments to the first instance. Returns false if it couldn't be reached.</summary>
    public bool ForwardToFirstInstance(string[] args)
    {
        try
        {
            NativeMethods.AllowSetForegroundWindow(NativeMethods.ASFW_ANY);
            using var client = new NamedPipeClientStream(".", PipeName, PipeDirection.Out, PipeOptions.CurrentUserOnly);
            client.Connect(3000);
            var payload = args.Length == 0 ? "--activate" : string.Join('\n', args);
            var bytes = Encoding.UTF8.GetBytes(payload);
            client.Write(bytes, 0, bytes.Length);
            client.Flush();
            return true;
        }
        catch (Exception ex)
        {
            Log.Error("Forward to running instance", ex);
            return false;
        }
    }

    public void Dispose()
    {
        _cts.Cancel();
        try
        {
            if (IsFirstInstance) _mutex.ReleaseMutex();
        }
        catch (ApplicationException)
        {
        }
        _mutex.Dispose();
    }
}
