using System.IO;
using System.Reflection;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using DayBoard.Core.Models;
using DayBoard.Core.Recurrence;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Services;
using DayBoard.ViewModels;
using DayBoard.Views.Windows;
using ThemeMode = DayBoard.Core.Models.ThemeMode;

namespace DayBoard.Infrastructure;

/// <summary>
/// <c>DayBoard.exe --selftest &lt;folder&gt;</c>: boots the real app on throwaway sample data, opens every view and
/// window in light and dark themes, saves a PNG of each, and writes selftest.log. Exit code 0 = no failures.
/// Used to check the UI on a build machine without clicking through it.
/// </summary>
public static class SelfTest
{
    public const string Arg = "--selftest";
    public const string PluginArg = "--plugin";

    /// <summary>
    /// Plugins to test (<c>--plugin &lt;file&gt;</c>, repeatable): the first theme and the first code plugin are used.
    /// A small built-in theme stands in when none is passed; the code plugin checks need the Daily check-in plugin.
    /// </summary>
    private static readonly List<string> _pluginFiles = new();

    private static readonly StringBuilder LogText = new();
    private static int _failures;
    private static string _out = "";

    public static bool IsRequested(string[] args, out string outDir)
    {
        int i = Array.FindIndex(args, a => a.Equals(Arg, StringComparison.OrdinalIgnoreCase));
        outDir = i >= 0 && i + 1 < args.Length ? args[i + 1] : Path.Combine(Path.GetTempPath(), "DayBoard-selftest-out");
        _pluginFiles.Clear();
        for (int a = 0; a < args.Length - 1; a++)
        {
            if (args[a].Equals(PluginArg, StringComparison.OrdinalIgnoreCase)) _pluginFiles.Add(args[a + 1]);
        }
        return i >= 0;
    }

    public static void Prepare(string outDir)
    {
        _out = outDir;
        Directory.CreateDirectory(outDir);
        AppPaths.DataDir = Path.Combine(Path.GetTempPath(), "DayBoard-selftest-" + Guid.NewGuid().ToString("N")[..8]);
        Line($"Data folder: {AppPaths.DataDir}");
    }

    public static void RecordException(string where, Exception ex)
    {
        _failures++;
        Line($"FAIL (unhandled in {where}): {ex}");
    }

    private static void Line(string s)
    {
        LogText.AppendLine($"{DateTime.Now:HH:mm:ss.fff} {s}");
        try
        {
            if (_out.Length > 0) File.WriteAllText(Path.Combine(_out, "selftest.log"), LogText.ToString());
        }
        catch (IOException)
        {
        }
    }

    private static async Task Idle(int extraMs = 120)
    {
        await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
        await Task.Delay(extraMs);
        await Dispatcher.Yield(DispatcherPriority.ApplicationIdle);
    }

    private static async Task Step(string name, Func<Task> action)
    {
        try
        {
            await action();
            Line("PASS " + name);
        }
        catch (Exception ex)
        {
            _failures++;
            Line($"FAIL {name}: {ex}");
        }
    }

    private static Task Step(string name, Action action) => Step(name, () =>
    {
        action();
        return Task.CompletedTask;
    });

    public static async Task<int> RunAsync()
    {
        var s = AppServices.Current;
        var main = (Views.MainWindow)Application.Current.MainWindow;
        Line($"DayBoard self-test on {Environment.OSVersion.VersionString}, .NET {Environment.Version}");
        Line(s.Tray is null ? "WARN tray icon could not be created (see log)" : "PASS tray icon created");

        await Step("seed sample data", () => Seed(s));
        await Step("show main window", async () =>
        {
            main.WindowState = WindowState.Normal;
            main.Width = 1440;
            main.Height = 900;
            main.Left = 20;
            main.Top = 20;
            main.Show();
            await Idle(400);
        });

        foreach (var theme in new[] { ThemeMode.Light, ThemeMode.Dark })
        {
            await Step($"apply {theme} theme", async () =>
            {
                s.Settings.Current.Theme = theme;
                ThemeService.Apply(s.Settings.Current, main);
                await Idle(300);
                if (ThemeService.IsDark != (theme == ThemeMode.Dark)) throw new InvalidOperationException("Palette did not switch.");
            });

            foreach (var view in PageKeys.Order.Concat(s.Main.PluginNav.Select(n => n.Key)).ToList())
            {
                await Step($"{theme} {ViewName(view)} view", async () =>
                {
                    s.Main.SelectedDate = s.Planner.Today;
                    s.Main.CurrentView = view;
                    await Idle(250);
                    if (view == PageKeys.Stats) s.Main.Stats.Period = "90";
                    await Idle(150);
                    var prefix = $"{theme.ToString().ToLowerInvariant()}-{ViewName(view).ToLowerInvariant()}";
                    Snap(main, prefix + ".png");
                    if (view is PageKeys.Settings or PageKeys.Stats && FindPageScroll(main) is { } sv)
                    {
                        for (int page = 1; page <= 3 && sv.VerticalOffset < sv.ScrollableHeight; page++)
                        {
                            sv.ScrollToVerticalOffset(sv.VerticalOffset + sv.ViewportHeight - 40);
                            await Idle(150);
                            Snap(main, $"{prefix}-{page + 1}.png");
                        }
                        sv.ScrollToTop();
                    }
                });
            }
        }

        await Step("visiting settings keeps category icons", () =>
        {
            var defaults = Category.Defaults().ToDictionary(c => c.Name, c => c.Icon);
            foreach (var c in s.Planner.Store.Categories)
            {
                if (defaults.TryGetValue(c.Name, out var icon) && icon != c.Icon)
                    throw new InvalidOperationException($"Category {c.Name} icon changed to {c.Icon}");
            }
        });

        await DragDropChecks(s, main);
        await FocusChecks(s, main);
        await PluginChecks(s, main);
        await CodePluginChecks(s, main);
        await BoardPluginChecks(s, main);

        await Step("compact density (week)", async () =>
        {
            s.Settings.Current.Density = Density.Compact;
            ThemeService.Apply(s.Settings.Current, main);
            s.Main.CurrentView = PageKeys.Week;
            await Idle(250);
            Snap(main, "dark-week-compact.png");
            s.Settings.Current.Density = Density.Comfortable;
            s.Settings.Current.Theme = ThemeMode.Light;
            ThemeService.Apply(s.Settings.Current, main);
            await Idle(200);
        });

        await Step("navigation next/previous/today", async () =>
        {
            s.Main.CurrentView = PageKeys.Day;
            var today = s.Planner.Today;
            s.Main.NextCommand.Execute(null);
            if (s.Main.SelectedDate != today.AddDays(1)) throw new InvalidOperationException("Next did not advance a day.");
            s.Main.CurrentView = PageKeys.Week;
            s.Main.PreviousCommand.Execute(null);
            if (s.Main.SelectedDate != today.AddDays(-6)) throw new InvalidOperationException("Previous did not go back a week.");
            s.Main.GoTodayCommand.Execute(null);
            if (s.Main.SelectedDate != today) throw new InvalidOperationException("Today failed.");
            await Idle();
        });

        await Step("undo and redo through the UI commands", async () =>
        {
            var before = s.Planner.Store.Tasks.Count;
            s.Planner.AddTask(new TaskItem { Title = "Undo me", ScheduledDate = s.Planner.Today });
            await Idle();
            s.Main.UndoCommand.Execute(null);
            if (s.Planner.Store.Tasks.Count != before) throw new InvalidOperationException("Undo did not remove the task.");
            s.Main.RedoCommand.Execute(null);
            if (s.Planner.Store.Tasks.Count != before + 1) throw new InvalidOperationException("Redo did not restore the task.");
            s.Main.UndoCommand.Execute(null);
            await Idle();
        });

        await Step("task editor (recurring task)", async () =>
        {
            var task = s.Planner.TasksOn(s.Planner.Today).First(t => t.SeriesId.HasValue);
            var w = new TaskEditorWindow(new TaskEditorViewModel(task)) { Owner = main };
            w.Show();
            await Idle(400);
            Snap(w, "editor-recurring.png");
            w.Close();
        });

        await Step("task editor (new, weekly repeat)", async () =>
        {
            var vm = new TaskEditorViewModel(null, s.Planner.Today, new TimeOnly(15, 0)) { Title = "Draft" };
            vm.RepeatChoice = vm.RepeatKinds.First(k => k.Value == RepeatKind.Weekly);
            var w = new TaskEditorWindow(vm) { Owner = main };
            w.Show();
            await Idle(400);
            Snap(w, "editor-new.png");
            w.Close();
        });

        await Step("quick add window", async () =>
        {
            var w = new QuickAddWindow(new QuickAddViewModel(s.Planner.Today));
            w.Show();
            await Idle(300);
            Snap(w, "quick-add.png");
            w.Close();
            await Idle();
        });

        await Step("mini view", async () =>
        {
            s.Windows.ShowMini();
            await Idle(400);
            var w = Application.Current.Windows.OfType<MiniWindow>().First();
            Snap(w, "mini-view.png");
            s.Windows.ToggleMini();
            await Idle();
        });

        await Step("choice dialog", async () =>
        {
            var d = new ChoiceDialog("Recurring task", "This is a recurring task. Delete only this occurrence, or this and all future occurrences?",
                new[] { "This occurrence", "Whole series", "Cancel" }) { Owner = main };
            d.Show();
            await Idle(300);
            Snap(d, "choice-dialog.png");
            d.Close();
        });

        await Step("Microsoft To Do import window", async () =>
        {
            var w = new MsTodoImportWindow { Owner = main };
            w.Show();
            await Idle(300);
            Snap(w, "mstodo-import.png");
            w.Close();
        });

        await Step("Start menu shortcut can be written and read back", () =>
        {
            var lnk = Path.Combine(_out, "shortcut-test", "DayBoard.lnk");
            StartMenuShortcut.Write(lnk, AppPaths.ExecutablePath);
            var target = StartMenuShortcut.ReadTarget(lnk);
            Line($"     shortcut target: {target}");
            if (!string.Equals(target, AppPaths.ExecutablePath, StringComparison.OrdinalIgnoreCase))
                throw new InvalidOperationException($"Shortcut points at {target}, expected {AppPaths.ExecutablePath}.");
            Directory.Delete(Path.GetDirectoryName(lnk)!, recursive: true);
        });

        await Step("global hotkey registers and unregisters", () =>
        {
            using var hk = new GlobalHotkey();
            bool ok = hk.Register(System.Windows.Input.ModifierKeys.Control | System.Windows.Input.ModifierKeys.Alt | System.Windows.Input.ModifierKeys.Shift,
                System.Windows.Input.Key.F12);
            Line($"  hotkey Ctrl+Alt+Shift+F12 registered: {ok} {hk.LastError}");
            hk.Unregister();
        });

        await Step("tray icon with badge, at each tray size", () =>
        {
            Line($"     tray icon size here: {IconFactory.TrayIconSize} px");
            foreach (var size in new[] { 16, 20, 24, 32 })
            {
                foreach (var count in new[] { 0, 3, 12 })
                {
                    using var icon = IconFactory.TrayIcon(count, size);
                    if (icon.Width != size || icon.Height != size) throw new InvalidOperationException($"Asked for {size} px, got {icon.Width} px.");
                    using var bmp = icon.ToBitmap();
                    bmp.Save(Path.Combine(_out, $"tray-icon-{size}-{count}.png"), System.Drawing.Imaging.ImageFormat.Png);
                }
            }
            if (IconFactory.OverlayBadge(5) is not BitmapSource overlay) throw new InvalidOperationException("No taskbar badge.");
            var png = new PngBitmapEncoder();
            png.Frames.Add(BitmapFrame.Create(overlay));
            using var f = File.Create(Path.Combine(_out, "taskbar-badge-5.png"));
            png.Save(f);
        });

        await Step("export round trip", () =>
        {
            var json = Core.Export.JsonPorter.Export(s.Planner.Store.Snapshot(), DateTime.Now);
            var data = Core.Export.JsonPorter.Import(json);
            if (data.Tasks.Count != s.Planner.Store.Tasks.Count) throw new InvalidOperationException("Export lost tasks.");
            File.WriteAllText(Path.Combine(_out, "sample-export.json"), json);
            File.WriteAllText(Path.Combine(_out, "sample-export.csv"), Core.Export.CsvExporter.Export(s.Planner.Store.Snapshot()), new UTF8Encoding(true));
            File.WriteAllText(Path.Combine(_out, "sample-export.ics"),
                Core.Calendar.IcsWriter.WriteTasks(s.Planner.Store.Tasks.Where(t => t.ScheduledDate >= s.Planner.Today.AddDays(-7)), s.Planner.Store.FindCategory, DateTime.UtcNow));
        });

        if (Environment.GetEnvironmentVariable("DAYBOARD_TEST_ICS_URL") is { Length: > 0 } icsUrl)
        {
            await Step("subscribe to an iCal URL over HTTP", async () =>
            {
                var sub = new CalendarSubscription { Name = "Calendar", Url = icsUrl, Color = "#22C55E" };
                s.Settings.Current.Calendars.Add(sub);
                var ok = await s.Calendars.RefreshAsync(sub);
                if (!ok) throw new InvalidOperationException("Refresh failed: " + sub.LastError);
                var events = s.Calendars.EventsBetween(s.Planner.Today, s.Planner.Today.AddDays(30)).Count(e => e.SubscriptionId == sub.Id);
                Line($"  fetched '{sub.Name}', {events} event instance(s) in the next 30 days");
                if (events == 0) throw new InvalidOperationException("No events parsed from the feed.");
                s.Main.CurrentView = PageKeys.Week;
                await Idle(300);
                Snap(main, "week-with-subscription.png");
            });
        }

        await Step("backup", () =>
        {
            var path = BackupService.BackupNow(s.Repository);
            if (!File.Exists(path)) throw new InvalidOperationException("No backup file.");
        });

        Line(_failures == 0 ? "RESULT: all checks passed" : $"RESULT: {_failures} failure(s)");
        return _failures == 0 ? 0 : 1;
    }

    private static ScrollViewer? FindPageScroll(Window main)
    {
        var host = AllDescendants<ContentControl>((DependencyObject)main.Content).FirstOrDefault(c => c.Content is IPage);
        return host is null ? null : Views.Controls.VisualTreeExt.FindDescendant<ScrollViewer>(host);
    }

    private static DragEventArgs MakeDragArgs(RoutedEvent ev, UIElement target, Point point, Guid taskId)
    {
        var data = new DataObject(TaskDrag.Format, taskId.ToString());
        var ctor = typeof(DragEventArgs).GetConstructors(BindingFlags.NonPublic | BindingFlags.Instance)
            .First(c => c.GetParameters().Length == 5);
        var args = (DragEventArgs)ctor.Invoke(new object[] { data, DragDropKeyStates.LeftMouseButton, DragDropEffects.Move, target, point });
        args.RoutedEvent = ev;
        args.Source = target;
        return args;
    }

    /// <summary>Raises DragOver (and snapshots the indicator) then Drop on <paramref name="target"/> at <paramref name="point"/>.</summary>
    private static async Task SimulateDrop(Window main, UIElement target, Point point, TaskItem task, string? snap)
    {
        TaskDrag.Simulate(task.Id, task.EstimateMinutes ?? 30);
        try
        {
            target.RaiseEvent(MakeDragArgs(DragDrop.DragEnterEvent, target, point, task.Id));
            target.RaiseEvent(MakeDragArgs(DragDrop.DragOverEvent, target, point, task.Id));
            await Idle(150);
            if (snap is not null) Snap(main, snap);
            target.RaiseEvent(MakeDragArgs(DragDrop.DropEvent, target, point, task.Id));
        }
        finally
        {
            TaskDrag.EndSimulation();
        }
        await Idle(200);
    }

    private static T Named<T>(DependencyObject root, string name) where T : FrameworkElement =>
        Views.Controls.VisualTreeExt.FindDescendant<T>(root, name) ?? throw new InvalidOperationException($"Element {name} not found.");

    private static async Task DragDropChecks(AppServices s, Window main)
    {
        var p = s.Planner;
        var today = p.Today;
        TaskItem Find(string title) => p.Store.Tasks.First(t => t.Title == title && !t.IsSkipped);

        await Step("drag: inbox task onto the day timeline at 15:00", async () =>
        {
            s.Main.SelectedDate = today;
            s.Main.CurrentView = PageKeys.Day;
            await Idle(300);
            var day = s.Main.Day;
            var area = Named<Grid>((DependencyObject)main.Content, "DropArea");
            var task = Find("Plan weekend trip");
            double y = day.OffsetOf(new TimeOnly(15, 0)) + 4;
            await SimulateDrop(main, area, new Point(80, y), task, "drag-day-timeline.png");
            var t = p.Store.FindTask(task.Id)!;
            if (t.ScheduledDate != today || t.StartTime != new TimeOnly(15, 0)) throw new InvalidOperationException($"Got {t.ScheduledDate} {t.StartTime}");
        });

        await Step("drag: time block onto the unscheduled list (top)", async () =>
        {
            var zone = Named<Border>((DependencyObject)main.Content, "UnscheduledZone");
            var task = Find("Plan weekend trip");
            await SimulateDrop(main, zone, new Point(60, 70), task, "drag-day-unscheduled.png");
            var t = p.Store.FindTask(task.Id)!;
            if (t.StartTime is not null || t.ScheduledDate != today) throw new InvalidOperationException($"Got {t.ScheduledDate} {t.StartTime}");
            var first = p.TasksOn(today).First(x => x.StartTime is null);
            if (first.Id != task.Id) throw new InvalidOperationException($"Expected it first, first is {first.Title}");
        });

        await Step("drag: card onto tomorrow's week column", async () =>
        {
            s.Main.CurrentView = PageKeys.Week;
            await Idle(300);
            var tomorrow = today.AddDays(1);
            if (Core.Time.DateUtil.StartOfWeek(tomorrow, s.Settings.Current.WeekStart) != s.Main.Week.WeekStart)
            {
                Line("  (tomorrow is in next week; using today's column)");
                tomorrow = today;
            }
            var column = FindColumn(main, tomorrow);
            var task = Find("Book dentist");
            var list = Named<ItemsControl>(column, "List");
            var listTop = list.TranslatePoint(new Point(0, 0), column).Y;
            await SimulateDrop(main, column, new Point(40, listTop + 4), task, "drag-week-column.png");
            var t = p.Store.FindTask(task.Id)!;
            if (t.ScheduledDate != tomorrow) throw new InvalidOperationException($"Got {t.ScheduledDate}");
            var firstUntimed = p.TasksOn(tomorrow).First(x => x.StartTime is null);
            if (firstUntimed.Id != task.Id) throw new InvalidOperationException($"Expected top of untimed list, got {firstUntimed.Title}");
        });

        await Step("drag: card onto the inbox", async () =>
        {
            var inbox = Views.Controls.VisualTreeExt.FindDescendant<Views.InboxPanel>((DependencyObject)main.Content)!;
            var zone = Named<Border>(inbox, "Zone");
            var task = Find("Book dentist");
            await SimulateDrop(main, zone, new Point(60, 120), task, "drag-inbox.png");
            if (p.Store.FindTask(task.Id)!.ScheduledDate is not null) throw new InvalidOperationException("Still scheduled.");
        });

        await Step("undo restores the dragged task", async () =>
        {
            for (int i = 0; i < 4; i++) s.Main.UndoCommand.Execute(null);
            await Idle();
            var t = Find("Book dentist");
            if (t.ScheduledDate != today || t.Status != TaskState.ToDo || !t.IsUrgent) throw new InvalidOperationException($"Got {t.ScheduledDate} {t.Status} urgent={t.IsUrgent}");
            if (Find("Plan weekend trip").ScheduledDate is not null) throw new InvalidOperationException("Inbox task not restored.");
        });
    }

    private static Border FindColumn(Window main, DateOnly date)
    {
        foreach (var b in AllDescendants<Border>((DependencyObject)main.Content))
        {
            if (b.Name == "Column" && b.DataContext is WeekDayViewModel d && d.Date == date) return b;
        }
        throw new InvalidOperationException($"No week column for {date}.");
    }

    /// <summary>A plugin's drop zone: an element taking drops whose DataContext has this Key (a column or quadrant).</summary>
    private static Border FindPluginZone(Window main, string key)
    {
        foreach (var b in AllDescendants<Border>((DependencyObject)main.Content))
        {
            if (b.AllowDrop && b.IsVisible && Prop(b.DataContext, "Key") as string == key) return b;
        }
        throw new InvalidOperationException($"No drop zone called {key}.");
    }

    /// <summary>A public property of a plugin's object, which the self-test can't name the type of.</summary>
    private static object? Prop(object? o, string name) => o?.GetType().GetProperty(name)?.GetValue(o);

    private static IEnumerable<T> AllDescendants<T>(DependencyObject root) where T : DependencyObject
    {
        int n = VisualTreeHelper.GetChildrenCount(root);
        for (int i = 0; i < n; i++)
        {
            var c = VisualTreeHelper.GetChild(root, i);
            if (c is T t) yield return t;
            foreach (var d in AllDescendants<T>(c)) yield return d;
        }
    }

    // ------------------------------------------------------------------ plugins

    private static async Task PluginChecks(AppServices s, Views.MainWindow main)
    {
        var vm = s.Main.SettingsPage;
        InstalledPlugin? plugin = null;
        string package = PluginOfKind(PluginKind.Theme) ?? MakeTestPlugin("dayboard.selftest.mint", "Self-test mint", "selftest-theme.dayboard-plugin");
        Line("Plugin under test: " + package);

        await Step("plugins: none added, so an empty checklist", () =>
        {
            vm.Refresh();
            if (s.Plugins.All.Count(p => !p.IsBuiltIn) != 0 || vm.Plugins.Count(p => !p.IsBuiltIn) != 0) throw new InvalidOperationException("Expected no added plugins.");
            if (ThemeService.ActiveTheme is not null) throw new InvalidOperationException("A theme is active without plugins.");
        });

        await Step("plugins: a file that isn't a plugin is refused", () =>
        {
            var bad = Path.Combine(_out, "not-a-plugin.dayboard-plugin");
            File.WriteAllText(bad, "hello");
            try
            {
                if (vm.InstallPluginFrom(bad) || !vm.PluginMessageIsError) throw new InvalidOperationException("Bad file was accepted.");
                Line("     message: " + vm.PluginMessage);
            }
            finally
            {
                File.Delete(bad);
            }
        });

        await Step("plugins: add a theme", async () =>
        {
            SetMode(s, main, ThemeMode.Light);
            if (!vm.InstallPluginFrom(package)) throw new InvalidOperationException(vm.PluginMessage);
            Line("     message: " + vm.PluginMessage);
            plugin = s.Plugins.All.Single(p => !p.IsBuiltIn);
            if (plugin.Theme is null) throw new InvalidOperationException("Not a theme plugin.");
            if (s.Settings.Current.ThemePluginId != plugin.Id || ThemeService.ActiveTheme?.Id != plugin.Id)
                throw new InvalidOperationException("A newly installed theme should become the active theme.");
            if (vm.Plugins.Where(p => !p.IsBuiltIn).ToList() is not [{ IsOn: true }]) throw new InvalidOperationException("The added theme isn't ticked in the checklist.");
            await Idle(200);
            ExpectSlot(plugin.Theme, "Accent", dark: false);
        });
        if (plugin?.Theme is not { } theme) return;

        foreach (var mode in new[] { ThemeMode.Light, ThemeMode.Dark })
        {
            await Step($"plugins: {plugin.Name}, {mode}", async () =>
            {
                SetMode(s, main, mode);
                await Idle(250);
                bool dark = mode == ThemeMode.Dark;
                foreach (var slot in new[] { "Accent", "WindowBackground", "CardBackground", "TextPrimary" }) ExpectSlot(theme, slot, dark);
                var prefix = $"{mode.ToString().ToLowerInvariant()}-plugin";
                foreach (var view in new[] { PageKeys.Day, PageKeys.Week, PageKeys.Stats, FocusKey, PageKeys.Settings })
                {
                    s.Main.SelectedDate = s.Planner.Today;
                    s.Main.CurrentView = view;
                    await Idle(250);
                    Snap(main, $"{prefix}-{ViewName(view).ToLowerInvariant()}.png");
                }
                if (FindPageScroll(main) is { } sv)
                {
                    sv.ScrollToEnd();
                    await Idle(200);
                    Snap(main, $"{prefix}-settings-plugins.png");
                    sv.ScrollToTop();
                }
            });
        }

        await Step("plugins: category and priority colours follow the theme", () =>
        {
            if (theme.Swatches is { } sw)
            {
                if (ColorUtil.Display(ColorUtil.Swatches[0]) != PluginFormat.ToHex(sw[0])) throw new InvalidOperationException("Swatch colours aren't remapped.");
                if (ColorUtil.Display("#0EA5E9") != PluginFormat.ToHex(sw[10])) throw new InvalidOperationException("Calendar colours aren't remapped.");
            }
            if (theme.PriorityHigh is { } high)
            {
                var actual = ((SolidColorBrush)Application.Current.FindResource("DB.PriorityHighBrush")).Color;
                if (Argb(actual) != high) throw new InvalidOperationException($"High priority is {actual}, expected {PluginFormat.ToHex(high)}.");
                if (!vm.ThemeSetsPriority) throw new InvalidOperationException("Settings doesn't say the theme picks priority colours.");
            }
        });

        await Step("plugins: unticking a theme restores DayBoard's colours", async () =>
        {
            vm.Plugins.Single(p => !p.IsBuiltIn).IsOn = false;
            await Idle(200);
            if (ThemeService.ActiveTheme is not null || s.Settings.Current.ThemePluginId is not null) throw new InvalidOperationException("Theme still active after unticking it.");
            ExpectStock("Accent", ThemeService.IsDark);
            if (ColorUtil.Display(ColorUtil.Swatches[0]) != PluginFormat.ToHex(StockLook.Swatches[0])) throw new InvalidOperationException("Swatches don't show DayBoard's own colours.");
            if (((SolidColorBrush)Application.Current.FindResource("DB.PriorityHighBrush")).Color != (Color)ColorConverter.ConvertFromString(PluginFormat.ToHex(StockLook.PriorityHigh)))
                throw new InvalidOperationException("High priority isn't DayBoard's own colour.");
            if (vm.Plugins.Single(p => !p.IsBuiltIn).IsOn) throw new InvalidOperationException("Checklist still ticked.");
            vm.Plugins.Single(p => !p.IsBuiltIn).IsOn = true;
            await Idle(200);
            if (ThemeService.ActiveTheme?.Id != plugin.Id) throw new InvalidOperationException("Ticking the theme again didn't apply it.");
        });

        await Step("plugins: only one colour theme is ticked at a time", async () =>
        {
            var second = MakeTestPlugin("dayboard.selftest.second", "Self-test second theme", "selftest-second.dayboard-plugin");
            if (!vm.InstallPluginFrom(second)) throw new InvalidOperationException(vm.PluginMessage);
            await Idle(200);
            var on = vm.Plugins.Where(p => p.IsOn && !p.IsBuiltIn).Select(p => p.Id).ToList();
            if (vm.Plugins.Count(p => !p.IsBuiltIn) != 2 || on.Count != 1 || on[0] != "dayboard.selftest.second") throw new InvalidOperationException("Adding a second theme should tick only that one.");
            SetMode(s, main, ThemeMode.Light);
            s.Main.CurrentView = PageKeys.Settings;
            await Idle(250);
            if (FindPageScroll(main) is { } sv)
            {
                sv.ScrollToEnd();
                await Idle(200);
                Snap(main, "light-plugin-checklist.png");
                sv.ScrollToTop();
            }
            vm.Plugins.Single(p => p.Id == plugin.Id).IsOn = true;
            await Idle(200);
            on = vm.Plugins.Where(p => p.IsOn && !p.IsBuiltIn).Select(p => p.Id).ToList();
            if (on.Count != 1 || on[0] != plugin.Id || ThemeService.ActiveTheme?.Id != plugin.Id) throw new InvalidOperationException("Ticking the first theme should untick the second.");
            s.Plugins.Remove("dayboard.selftest.second");
            vm.Refresh();
        });

        await Step("plugins: adding the same plugin again is an update", () =>
        {
            if (!vm.InstallPluginFrom(package) || vm.PluginMessage?.StartsWith("Updated", StringComparison.Ordinal) != true)
                throw new InvalidOperationException("Reinstall: " + vm.PluginMessage);
            if (s.Plugins.All.Count(p => !p.IsBuiltIn) != 1 || ThemeService.ActiveTheme?.Id != plugin.Id) throw new InvalidOperationException("Update changed the plugin list or theme.");
        });

        await Step("plugins: removing the theme restores DayBoard's colours", async () =>
        {
            s.Plugins.Remove(plugin.Id); // clean up, so the rest of the self-test runs on the stock look
            ThemeService.Apply(s.Settings.Current, main);
            vm.Refresh();
            await Idle(200);
            if (ThemeService.ActiveTheme is not null || s.Settings.Current.ThemePluginId is not null || s.Plugins.All.Count(p => !p.IsBuiltIn) != 0 || vm.Plugins.Count(p => !p.IsBuiltIn) != 0)
                throw new InvalidOperationException("Plugin or theme left behind after removal.");
            if (Directory.Exists(Path.Combine(AppPaths.PluginDir, plugin.Id))) throw new InvalidOperationException("Plugin folder left behind.");
            ExpectStock("Accent", ThemeService.IsDark);
        });

        SetMode(s, main, ThemeMode.Dark);
        await Idle(150);
    }

    private static string? PluginWithId(string id)
    {
        foreach (var f in _pluginFiles)
        {
            try
            {
                if (PluginFormat.ReadPackage(f, PluginService.AppVersion).Manifest.Id == id) return f;
            }
            catch (PluginException)
            {
                // PluginOfKind reports it.
            }
        }
        return null;
    }

    private static string? PluginOfKind(PluginKind kind)
    {
        foreach (var f in _pluginFiles)
        {
            try
            {
                if (PluginFormat.ReadPackage(f, PluginService.AppVersion).Manifest.Kind == kind) return f;
            }
            catch (PluginException ex)
            {
                Line($"WARN {f} isn't a usable plugin: {ex.Message}");
            }
        }
        return null;
    }

    // ------------------------------------------------------------------ Focus (a plugin that comes with DayBoard)

    private static string FocusKey => Hosting.PluginRunner.PageKey(LegacySettings.FocusPluginId, "focus");

    /// <summary>A view's name for the log and the screenshots: "Day", or a plugin page's title, such as "Focus".</summary>
    private static string ViewName(string view) =>
        AppServices.Current.Main.PluginNav.FirstOrDefault(n => n.Key == view)?.Title ?? view;

    private static async Task FocusChecks(AppServices s, Views.MainWindow main)
    {
        var settingsVm = s.Main.SettingsPage;
        var focusId = LegacySettings.FocusPluginId;
        var today = s.Planner.Today;
        FrameworkElement Page() => s.Runner.FindPage(FocusKey)?.Host.Child as FrameworkElement ?? throw new InvalidOperationException("No Focus page.");
        bool HasButton(string name) => AllDescendants<Button>(Page()).Any(b => AutomationName(b) == name && b.IsVisible);
        MenuItem? FocusMenuItem(TaskItem t)
        {
            var menu = new ContextMenu();
            Views.Controls.TaskInteractions.Populate(menu, new TaskCardViewModel(t, CardContext.Create()));
            return menu.Items.OfType<MenuItem>().FirstOrDefault(m => m.Header as string == "Focus on this");
        }
        var task = s.Planner.TasksOn(today).First(t => !t.IsDone && t.Subtasks.Count > 0);
        SetMode(s, main, ThemeMode.Light);

        await Step("focus: comes with DayBoard, ticked, first among plugin pages (Ctrl+4)", async () =>
        {
            settingsVm.Refresh();
            var item = settingsVm.Plugins.First();
            if (item is not { IsBuiltIn: true, IsOn: true, IsCode: false, HasMessage: false } || item.Id != focusId)
                throw new InvalidOperationException($"First in the list: {item.Name} (built in {item.IsBuiltIn}, on {item.IsOn}).");
            if (!s.Runner.IsRunning(focusId)) throw new InvalidOperationException("Not running: " + s.Runner.ErrorFor(focusId));
            if (s.Runner.Data.Get(focusId, "settings") is not { } stored || !stored.Contains("\"workMinutes\":25", StringComparison.Ordinal))
                throw new InvalidOperationException("The timer settings weren't carried over.");
            s.Main.NavigateCommand.Execute("#1");
            await Idle(300);
            if (s.Main.CurrentView != FocusKey || s.Main.HeaderTitle != "Focus" || s.Main.ShowDateNav) throw new InvalidOperationException("Ctrl+4 didn't open Focus.");
        });

        await Step("focus: \"Focus on this\" in a task's menu", async () =>
        {
            s.Main.ShowDate(today, PageKeys.Day);
            await Idle(200);
            var item = FocusMenuItem(task) ?? throw new InvalidOperationException("No \"Focus on this\" in the task menu.");
            item.RaiseEvent(new RoutedEventArgs(MenuItem.ClickEvent));
            await Idle(300);
            if (s.Main.CurrentView != FocusKey || !HasText(Page(), task.Title)) throw new InvalidOperationException("Focus didn't open on the task.");
            if (!HasText(Page(), "25:00") || !HasButton("Start")) throw new InvalidOperationException("The timer isn't ready.");
            Snap(main, "light-focus-task.png");
        });

        await Step("focus: start, pause and reset the timer", async () =>
        {
            Click(Page(), "Start");
            await Idle(1400);
            if (!HasButton("Pause") || HasText(Page(), "25:00")) throw new InvalidOperationException("The timer isn't running.");
            Click(Page(), "Pause");
            await Idle(150);
            if (!HasButton("Resume")) throw new InvalidOperationException("No Resume after pausing.");
            Click(Page(), "Reset");
            await Idle(150);
            if (!HasButton("Start") || !HasText(Page(), "25:00")) throw new InvalidOperationException("Reset didn't go back to the start.");
        });

        await Step("focus: tick the checklist and mark the task done (both undoable)", async () =>
        {
            var sub = task.Subtasks.First(x => !x.IsDone);
            var box = AllDescendants<CheckBox>(Page()).First(c => AutomationName(c) == sub.Title);
            typeof(System.Windows.Controls.Primitives.ButtonBase).GetMethod("OnClick", BindingFlags.NonPublic | BindingFlags.Instance)!.Invoke(box, null);
            await Idle(200);
            if (s.Planner.Store.FindTask(task.Id)!.Subtasks.Single(x => x.Id == sub.Id).IsDone != true) throw new InvalidOperationException("The checklist item wasn't ticked.");
            Click(Page(), "Mark done");
            await Idle(200);
            if (!s.Planner.Store.FindTask(task.Id)!.IsDone) throw new InvalidOperationException("The task isn't done.");
            s.Main.UndoCommand.Execute(null);
            s.Main.UndoCommand.Execute(null);
            await Idle(200);
            var back = s.Planner.Store.FindTask(task.Id)!;
            if (back.IsDone || back.Subtasks.Single(x => x.Id == sub.Id).IsDone) throw new InvalidOperationException("Undo didn't bring the task back.");
        });

        await Step("focus: a whole session logs its time to the task", async () =>
        {
            Find<TextBox>(Page(), "Focus minutes").Text = "1";
            await Idle(700);
            if (s.Runner.Data.Get(focusId, "settings")?.Contains("\"workMinutes\":1,", StringComparison.Ordinal) != true || !HasText(Page(), "01:00"))
                throw new InvalidOperationException("The new focus length wasn't used.");
            int before = s.Planner.Store.FindTask(task.Id)!.ActualMinutes;
            Click(Page(), "Start");
            var until = DateTime.Now.AddSeconds(75);
            while (!HasText(Page(), "Short break") && DateTime.Now < until) await Task.Delay(500);
            await Idle(300);
            int after = s.Planner.Store.FindTask(task.Id)!.ActualMinutes;
            Line($"     logged {after - before} min; {s.Main.UndoTooltip}");
            if (after != before + 1) throw new InvalidOperationException($"Logged {after - before} minutes instead of 1.");
            if (!HasText(Page(), "1 session today") || !HasButton("Pause")) throw new InvalidOperationException("The break didn't start, or the session wasn't counted.");
            Snap(main, "light-focus-break.png");
            SetMode(s, main, ThemeMode.Dark);
            await Idle(250);
            Snap(main, "dark-focus-break.png");
            SetMode(s, main, ThemeMode.Light);
            Click(Page(), "Skip");
            await Idle(150);
            s.Main.UndoCommand.Execute(null);
            await Idle(150);
            if (s.Planner.Store.FindTask(task.Id)!.ActualMinutes != before) throw new InvalidOperationException("Undo didn't take the logged time back.");
            Find<TextBox>(Page(), "Focus minutes").Text = "25";
            await Idle(700);
            if (!HasText(Page(), "25:00")) throw new InvalidOperationException("Focus length wasn't set back.");
        });

        await Step("focus: unticking removes its page and menu item", async () =>
        {
            settingsVm.Refresh();
            settingsVm.Plugins.Single(p => p.Id == focusId).IsOn = false;
            await Idle(300);
            if (s.Runner.IsRunning(focusId) || s.Main.PluginNav.Any(n => n.Key == FocusKey) || FocusMenuItem(task) is not null)
                throw new InvalidOperationException("Focus is still there.");
            if (!s.Settings.Current.DisabledBuiltInPlugins.Contains(focusId) || s.Main.CurrentView == FocusKey) throw new InvalidOperationException("Not unticked properly.");
            s.Main.NavigateCommand.Execute("#1");
            if (s.Main.CurrentView == FocusKey) throw new InvalidOperationException("Ctrl+4 still opens Focus.");
            settingsVm.Plugins.Single(p => p.Id == focusId).IsOn = true;
            await Idle(300);
            if (!s.Runner.IsRunning(focusId) || FocusMenuItem(task) is null || s.Settings.Current.DisabledBuiltInPlugins.Count != 0)
                throw new InvalidOperationException("Ticking it again didn't bring it back.");
        });

        await Step("focus: can't be replaced by a plugin file", () =>
        {
            var file = MakeTestPlugin(focusId, "Not Focus", "selftest-not-focus.dayboard-plugin");
            if (settingsVm.InstallPluginFrom(file) || !settingsVm.PluginMessage!.Contains("comes with DayBoard", StringComparison.Ordinal))
                throw new InvalidOperationException("Message: " + settingsVm.PluginMessage);
            Line("     message: " + settingsVm.PluginMessage);
            if (s.Plugins.All.Count(p => p.Id == focusId) != 1 || Directory.Exists(Path.Combine(AppPaths.PluginDir, focusId)))
                throw new InvalidOperationException("The file was installed.");
        });

        s.Main.ShowDate(today, PageKeys.Day);
        SetMode(s, main, ThemeMode.Dark);
        await Idle(200);
    }

    // ------------------------------------------------------------------ code plugins (the Daily check-in)

    private static async Task CodePluginChecks(AppServices s, Views.MainWindow main)
    {
        var settingsVm = s.Main.SettingsPage;
        var day = s.Main.Day;
        var today = s.Planner.Today;
        var package = PluginWithId(PluginDataStore.CheckInPluginId);
        if (package is null)
        {
            Line("WARN the Daily check-in wasn't passed with --plugin, so the code plugin checks were skipped");
            return;
        }
        var manifest = PluginService.Peek(package);
        var id = manifest.Id;
        Line($"Code plugin under test: {package} ({manifest.Name} {manifest.Version})");
        string Stored(DateOnly d) => s.Runner.Data.Get(id, "checkin:" + d.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture)) ?? "";
        FrameworkElement Panel() => s.Runner.Panels.SingleOrDefault()?.Host.Child as FrameworkElement ?? throw new InvalidOperationException("No Day view panel.");
        FrameworkElement Page() => s.Runner.Pages.SingleOrDefault(p => p.PluginId == id)?.Host.Child as FrameworkElement ?? throw new InvalidOperationException("No plugin page view.");
        string NavTitles() => string.Join(", ", s.Main.PluginNav.Select(n => n.Title));

        await Step("code plugin: nothing extra until it's added", async () =>
        {
            SetMode(s, main, ThemeMode.Light);
            s.Main.ShowDate(today, PageKeys.Day);
            await Idle(200);
            if (s.Runner.Panels.Count != 0 || NavTitles() != "Focus") throw new InvalidOperationException("Plugin UI without the plugin: " + NavTitles());
            s.Main.NavigateCommand.Execute("#2");
            if (s.Main.CurrentView != PageKeys.Day) throw new InvalidOperationException("Ctrl+5 opened something without a plugin.");
        });

        await Step("code plugin: check-ins from DayBoard 1.2 are waiting in its storage", () => SeedCheckIns(s, id, today));

        await Step("code plugin: DayBoard 1.2's check-in plugin asks for its new version", () =>
        {
            // As left behind by DayBoard 1.2: a settings-only "feature" plugin with the same id.
            var folder = Path.Combine(AppPaths.PluginDir, id);
            Directory.CreateDirectory(folder);
            File.WriteAllText(Path.Combine(folder, "plugin.json"), """
                { "format": "dayboard-plugin", "formatVersion": 1, "id": "ID", "name": "Daily check-in", "version": "1.0.0",
                  "kind": "feature", "minAppVersion": "1.2.0", "entry": "feature.json" }
                """.Replace("ID", id));
            File.WriteAllText(Path.Combine(folder, "feature.json"), """{ "feature": "daily-checkin" }""");
            s.Plugins.Reload();
            settingsVm.Refresh();
            var item = settingsVm.Plugins.Single(p => p.Id == id);
            if (item.IsUsable || item.IsOn || item.Name != "Daily check-in" || item.Message?.Contains("new version", StringComparison.Ordinal) != true)
                throw new InvalidOperationException($"Listed as {item.Name}: {item.Message}");
            Line("     " + item.Message);
        });

        await Step("code plugin: adding asks first, and Cancel adds nothing", async () =>
        {
            var answered = AnswerChoiceDialog("Cancel", "code-plugin-confirm.png");
            if (settingsVm.InstallPluginFrom(package)) throw new InvalidOperationException("Added although Cancel was pressed.");
            var title = await answered;
            if (!title.Contains("runs code", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Dialog: " + title);
            if (s.Plugins.All.Any(p => p.Id == id && p.IsUsable) || s.Runner.IsRunning(id)) throw new InvalidOperationException("The plugin was installed.");
            Line("     message: " + settingsVm.PluginMessage);
        });

        await Step("code plugin: add it", async () =>
        {
            var answered = AnswerChoiceDialog("Add plugin", null);
            if (!settingsVm.InstallPluginFrom(package)) throw new InvalidOperationException(settingsVm.PluginMessage);
            await answered;
            Line("     message: " + settingsVm.PluginMessage);
            if (!s.Runner.IsRunning(id)) throw new InvalidOperationException("Not running: " + s.Runner.ErrorFor(id));
            if (NavTitles() != "Focus, Journal") throw new InvalidOperationException("Sidebar: " + NavTitles());
            if (settingsVm.Plugins.Single(p => p.Id == id) is not { IsOn: true, IsCode: true, HasMessage: false })
                throw new InvalidOperationException("The checklist doesn't show it ticked, marked as code.");
            if (!settingsVm.PluginMessage!.Contains("Journal", StringComparison.Ordinal)) throw new InvalidOperationException("Message doesn't say where it is.");
            s.Main.CurrentView = PageKeys.Settings;
            await Idle(250);
            if (FindPageScroll(main) is { } sv)
            {
                sv.ScrollToBottom();
                await Idle(200);
                Snap(main, "light-settings-code-plugin.png");
                sv.ScrollToTop();
            }
        });
        if (!s.Runner.IsRunning(id)) return;

        await Step("code plugin: log today from its Day view panel", async () =>
        {
            s.Main.ShowDate(today, PageKeys.Day);
            await Idle(300);
            var panel = Panel();
            if (panel.Visibility != Visibility.Visible || !HasText(panel, "How's today?")) throw new InvalidOperationException("The check-in isn't open on today.");
            Snap(main, "light-checkin-empty.png");
            Click(panel, "Good");
            Click(panel, "Sage");
            Click(panel, "calm");
            var newTag = Find<TextBox>(panel, "New tag");
            newTag.Text = "  long walk ";
            newTag.InputBindings.OfType<System.Windows.Input.KeyBinding>().Single().Command.Execute(null);
            Find<TextBox>(panel, "Journal note").Text = "Long walk along the canal after lunch.\nFinished the planning doc.";
            await Idle(900); // the note saves after a short pause in typing
            var saved = Stored(today);
            foreach (var part in new[] { "\"mood\":4", "\"color\":\"#7A9A6B\"", "\"tags\":[\"calm\",\"long walk\"]", "Long walk along the canal" })
            {
                if (!saved.Contains(part, StringComparison.Ordinal)) throw new InvalidOperationException("Saved: " + saved);
            }
            Snap(main, "light-checkin-day.png");
            Click(panel, "Good"); // clicking the chosen face again clears it
            await Idle(100);
            if (Stored(today).Contains("\"mood\":4", StringComparison.Ordinal)) throw new InvalidOperationException("Face didn't clear.");
            Click(panel, "Good");
        });

        await Step("code plugin: fold the panel away and open it again", async () =>
        {
            Click(Panel(), "Fold away the check-in");
            await Idle(200);
            if (!HasText(Panel(), t => t.StartsWith("Good", StringComparison.Ordinal) && t.Contains("Sage", StringComparison.Ordinal)))
                throw new InvalidOperationException("No summary after folding.");
            Snap(main, "light-checkin-folded.png");
            SetMode(s, main, ThemeMode.Dark);
            await Idle(250);
            Snap(main, "dark-checkin-folded.png");
            Click(Panel(), "Edit");
            await Idle(200);
            Snap(main, "dark-checkin-day.png");
        });

        await Step("code plugin: a note is saved when you move to another day", async () =>
        {
            var note = Find<TextBox>(Panel(), "Journal note");
            note.Text += "\nGood evening too.";
            s.Main.NextCommand.Execute(null); // straight away, before the typing pause
            await Idle(150);
            if (!Stored(today).Contains("Good evening too.", StringComparison.Ordinal)) throw new InvalidOperationException("Note lost when leaving the day.");
            if (Panel().Visibility == Visibility.Visible) throw new InvalidOperationException("Check-in shown on a future day.");
            s.Main.PreviousCommand.Execute(null);
            s.Main.PreviousCommand.Execute(null);
            await Idle(200);
            if (Panel().Visibility != Visibility.Visible || !HasText(Panel(), "How was yesterday?")) throw new InvalidOperationException("Yesterday isn't shown.");
        });

        await Step("code plugin: its Journal page (Ctrl+5, after Focus)", async () =>
        {
            s.Main.SelectedDate = today;
            s.Main.NavigateCommand.Execute("#2");
            await Idle(400);
            if (!PluginRunnerKey(s.Main.CurrentView) || s.Main.HeaderTitle != "Journal" || !s.Main.ShowDateNav)
                throw new InvalidOperationException($"View {s.Main.CurrentView}, header {s.Main.HeaderTitle}.");
            if (!s.Main.PluginNav[1].IsSelected) throw new InvalidOperationException("Its sidebar button isn't selected.");
            var page = Page();
            var dayNames = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.DayNames;
            int cells = AllDescendants<Button>(page).Count(b => dayNames.Any(n => AutomationName(b).StartsWith(n + " ", StringComparison.Ordinal)));
            var grid = AllDescendants<FrameworkElement>(page).FirstOrDefault(e => e.GetType().Name == "DayColorGrid");
            if (cells < 35 || grid is null || grid.ActualWidth < 500 || !HasText(page, "Long walk along the canal after lunch.\nFinished the planning doc.\nGood evening too."))
                throw new InvalidOperationException($"Journal: {cells} day cells, year grid {grid?.ActualWidth ?? 0} wide.");
            Snap(main, "dark-journal.png");
            SetMode(s, main, ThemeMode.Light);
            await Idle(300);
            Snap(main, "light-journal.png");
            s.Main.NextCommand.Execute(null);
            await Idle(200);
            if (s.Main.SelectedDate.Month != today.AddMonths(1).Month || !s.Main.HeaderSubtitle.Contains(today.AddMonths(1).ToString("MMMM"), StringComparison.Ordinal))
                throw new InvalidOperationException("Next didn't move a month: " + s.Main.HeaderSubtitle);
            s.Main.GoTodayCommand.Execute(null);
            await Idle(200);
        });

        await Step("code plugin: edit a past day in the Journal", async () =>
        {
            var past = today.AddDays(-9);
            var cell = AllDescendants<Button>(Page()).First(b => AutomationName(b).StartsWith(past.ToString("dddd d MMMM yyyy"), StringComparison.Ordinal));
            Invoke(cell);
            await Idle(300);
            if (s.Main.SelectedDate != past) throw new InvalidOperationException("Clicking the day didn't select it.");
            Click(Page(), "Very low");
            await Idle(250);
            if (!Stored(past).Contains("\"mood\":1", StringComparison.Ordinal)) throw new InvalidOperationException("Past day wasn't saved: " + Stored(past));
            s.Main.ShowDate(past, PageKeys.Day);
            await Idle(300);
            if (!HasText(Panel(), t => t.StartsWith("Very low", StringComparison.Ordinal))) throw new InvalidOperationException("The Day view doesn't show the change.");
        });

        await Step("code plugin: future days can't be filled in", async () =>
        {
            s.Main.ShowDate(today.AddDays(3), s.Main.PluginNav[1].Key);
            await Idle(300);
            if (!HasText(Page(), t => t.StartsWith("This day hasn't happened yet", StringComparison.Ordinal))) throw new InvalidOperationException("A future day is editable.");
        });

        await Step("code plugin: export the journal (save dialog from the host)", async () =>
        {
            var file = Path.Combine(_out, "journal.md");
            Hosting.PluginHostContext.SelfTestSavePath = file;
            try
            {
                var export = AllDescendants<Button>(Page()).First(b => HasText(b, "Export journal…"));
                Invoke(export);
                await Idle(200);
            }
            finally
            {
                Hosting.PluginHostContext.SelfTestSavePath = null;
            }
            var md = File.ReadAllText(file);
            Line($"     exported {md.Length} characters");
            if (!md.StartsWith("# DayBoard journal", StringComparison.Ordinal) || !md.Contains("Long walk along the canal", StringComparison.Ordinal) ||
                !md.Contains("Feeling: Good (4/5)", StringComparison.Ordinal) || !md.Contains("Colour: Sage", StringComparison.Ordinal))
                throw new InvalidOperationException("Markdown is missing today's entry.");
        });

        await Step("code plugin: unticking removes it and keeps its data", async () =>
        {
            int before = s.Runner.Data.Count(id);
            settingsVm.Refresh();
            settingsVm.Plugins.Single(p => p.Id == id).IsOn = false;
            await Idle(300);
            if (s.Runner.IsRunning(id) || NavTitles() != "Focus" || s.Runner.Panels.Count != 0) throw new InvalidOperationException("Still running.");
            if (s.Main.CurrentView != PageKeys.Day) throw new InvalidOperationException("The Journal page stayed open.");
            if (s.Runner.Data.Count(id) != before) throw new InvalidOperationException("Data was removed.");
            settingsVm.Plugins.Single(p => p.Id == id).IsOn = true;
            await Idle(300);
            if (!s.Runner.IsRunning(id) || NavTitles() != "Focus, Journal") throw new InvalidOperationException("Ticking it again didn't bring it back.");
            s.Main.ShowDate(today, PageKeys.Day);
            await Idle(250);
            if (!HasText(Panel(), t => t.StartsWith("Good", StringComparison.Ordinal))) throw new InvalidOperationException("Today's entry is gone.");
        });

        await Step("code plugin: updating it while it runs", async () =>
        {
            settingsVm.ConfirmCodePlugin = _ => true;
            try
            {
                if (!settingsVm.InstallPluginFrom(package)) throw new InvalidOperationException(settingsVm.PluginMessage);
            }
            finally
            {
                settingsVm.ConfirmCodePlugin = _ => false;
            }
            Line("     message: " + settingsVm.PluginMessage);
            await Idle(300);
            if (!s.Runner.IsRunning(id) || NavTitles() != "Focus, Journal" || s.Runner.Panels.Count != 1) throw new InvalidOperationException("Not running after the update.");
            if (!HasText(Panel(), t => t.StartsWith("Good", StringComparison.Ordinal))) throw new InvalidOperationException("The updated plugin lost today's entry.");
        });

        await Step("code plugin: one that throws is turned off, and DayBoard carries on", async () =>
        {
            // Make the plugin's own code throw: its check-in store doesn't accept a missing entry.
            var vm = Panel().DataContext;
            var store = vm.GetType().GetField("_store", BindingFlags.NonPublic | BindingFlags.Instance)!.GetValue(vm)!;
            Exception? thrown = null;
            try
            {
                store.GetType().GetMethod("Save")!.Invoke(store, new object?[] { null, DateTime.Now });
            }
            catch (TargetInvocationException ex)
            {
                thrown = ex.InnerException;
            }
            if (thrown is null) throw new InvalidOperationException("The plugin didn't throw.");
            if (!s.Runner.TryHandle(thrown)) throw new InvalidOperationException("The exception wasn't traced to the plugin.");
            await Idle(250);
            if (s.Runner.IsRunning(id) || s.Settings.Current.EnabledPlugins.Contains(id)) throw new InvalidOperationException("Still on.");
            settingsVm.Refresh();
            var item = settingsVm.Plugins.Single(p => p.Id == id);
            if (item.IsOn || item.Message?.StartsWith("Turned off after an error", StringComparison.Ordinal) != true) throw new InvalidOperationException("Settings: " + item.Message);
            Line("     " + s.Main.ToastText);
            Line("     " + item.Message);
        });

        // The rest of the self-test runs without the plugin.
        s.Plugins.Remove(id);
        s.Runner.Sync();
        settingsVm.Refresh();
        s.Main.ShowDate(today, PageKeys.Day);
        SetMode(s, main, ThemeMode.Dark);
        await Idle(200);
    }

    // ------------------------------------------------------------------ Kanban, matrix and review (views until 1.5)

    private static async Task BoardPluginChecks(AppServices s, Views.MainWindow main)
    {
        var settingsVm = s.Main.SettingsPage;
        var today = s.Planner.Today;
        var views = LegacySettings.MovedViews;
        var files = views.Select(v => PluginWithId(v.PluginId)).ToList();
        if (files.Any(f => f is null))
        {
            Line("WARN the Kanban, matrix and review plugins weren't all passed with --plugin, so their checks were skipped");
            return;
        }
        MovedView matrix = views.Single(v => v.View == "Matrix"), kanban = views.Single(v => v.View == "Kanban"), review = views.Single(v => v.View == "Review");
        string Key(MovedView v) => Hosting.PluginRunner.PageKey(v.PluginId, v.PageId);
        FrameworkElement Page(MovedView v) => s.Runner.FindPage(Key(v))?.Host.Child as FrameworkElement ?? throw new InvalidOperationException($"No {v.View} page.");
        string NavTitles() => string.Join(", ", s.Main.PluginNav.Select(n => n.Title));
        TaskItem Find(string title) => s.Planner.Store.Tasks.First(t => t.Title == title && !t.IsSkipped);
        bool HasCard(DependencyObject root, Guid id) => AllDescendants<Views.Controls.TaskCard>(root).Any(c => (c.DataContext as TaskCardViewModel)?.Id == id);
        async Task Open(MovedView v)
        {
            s.Main.SelectedDate = today;
            s.Main.CurrentView = Key(v);
            await Idle(300);
        }
        async Task AllOpen(MovedView v)
        {
            var all = AllDescendants<RadioButton>(Page(v)).First(r => r.Content as string == "All open");
            all.IsChecked = true;
            await Idle(250);
        }
        SetMode(s, main, ThemeMode.Light);

        await Step("boards: Day, Week and Stats are DayBoard's own; Ctrl+3 is Stats and Ctrl+4 to Ctrl+9 open plugin pages", () =>
        {
            if (string.Join(",", PageKeys.Order) != "Day,Week,Stats,Settings") throw new InvalidOperationException("Stock views: " + string.Join(",", PageKeys.Order));
            var keys = main.InputBindings.OfType<System.Windows.Input.KeyBinding>()
                .Where(k => k.Modifiers == System.Windows.Input.ModifierKeys.Control && k.Key is >= System.Windows.Input.Key.D1 and <= System.Windows.Input.Key.D9)
                .OrderBy(k => k.Key).Select(k => k.CommandParameter as string).ToList();
            if (string.Join(",", keys) != "Day,Week,Stats,#1,#2,#3,#4,#5,#6") throw new InvalidOperationException("Ctrl+1 to 9: " + string.Join(",", keys));
            if (NavTitles() != "Focus") throw new InvalidOperationException("Sidebar: " + NavTitles());
            if (AllDescendants<TextBlock>(main).Any(t => t.IsVisible && t.Text is "Kanban" or "Matrix" or "Review")) throw new InvalidOperationException("A removed view is still in the sidebar.");
        });

        await Step("boards: a view left open in DayBoard 1.5 opens the Day view until its plugin is added", async () =>
        {
            s.Main.CurrentView = PageKeys.Day;
            s.Settings.Current.LastView = "Kanban";
            s.Main.OpenLastView();
            await Idle(150);
            if (s.Main.CurrentView != PageKeys.Day) throw new InvalidOperationException("Opened " + s.Main.CurrentView);
        });

        await Step("boards: add the Kanban, matrix and review plugins", async () =>
        {
            settingsVm.ConfirmCodePlugin = _ => true;
            try
            {
                foreach (var f in files)
                {
                    if (!settingsVm.InstallPluginFrom(f!)) throw new InvalidOperationException(settingsVm.PluginMessage);
                    Line("     message: " + settingsVm.PluginMessage);
                }
            }
            finally
            {
                settingsVm.ConfirmCodePlugin = _ => false;
            }
            await Idle(300);
            foreach (var v in views)
            {
                if (!s.Runner.IsRunning(v.PluginId)) throw new InvalidOperationException($"{v.PluginName} isn't running: {s.Runner.ErrorFor(v.PluginId)}");
            }
            // Built-in plugins first, then by plugin name: Eisenhower matrix, Kanban board, Weekly review.
            if (NavTitles() != "Focus, Matrix, Kanban, Review") throw new InvalidOperationException("Sidebar: " + NavTitles());
            var tips = string.Join(" | ", s.Main.PluginNav.Select(n => n.Tooltip));
            if (tips != "Focus (Ctrl+4) | Matrix (Ctrl+5) | Kanban (Ctrl+6) | Review (Ctrl+7)") throw new InvalidOperationException("Tooltips: " + tips);
            s.Main.NavigateCommand.Execute("#2");
            await Idle(300);
            if (s.Main.CurrentView != Key(matrix) || s.Main.HeaderTitle != "Eisenhower matrix" || s.Main.ShowDateNav)
                throw new InvalidOperationException($"Ctrl+5 opened {s.Main.CurrentView}: {s.Main.HeaderTitle}");
        });
        if (!views.All(v => s.Runner.IsRunning(v.PluginId))) return;

        await Step("boards: the view left open in DayBoard 1.5 now opens its plugin's page", async () =>
        {
            s.Main.CurrentView = PageKeys.Day;
            s.Settings.Current.LastView = "Kanban";
            s.Main.OpenLastView();
            await Idle(250);
            if (s.Main.CurrentView != Key(kanban) || s.Main.HeaderTitle != "Kanban") throw new InvalidOperationException("Opened " + s.Main.CurrentView);
        });

        foreach (var mode in new[] { ThemeMode.Light, ThemeMode.Dark })
        {
            await Step($"boards: {mode} pages", async () =>
            {
                SetMode(s, main, mode);
                foreach (var v in views)
                {
                    await Open(v);
                    Snap(main, $"{mode.ToString().ToLowerInvariant()}-{v.PageId}.png");
                }
            });
        }
        SetMode(s, main, ThemeMode.Light);

        await Step("boards: drag a card between Eisenhower quadrants", async () =>
        {
            await Open(matrix);
            await AllOpen(matrix);
            if (s.Runner.Data.Get(matrix.PluginId, "scope") != "All") throw new InvalidOperationException("The scope wasn't kept.");
            var task = Find("Book dentist");
            if (!task.IsUrgent) throw new InvalidOperationException("The sample task should start urgent.");
            if (!HasCard(FindPluginZone(main, task.Priority.IsImportant() ? "DoFirst" : "Delegate"), task.Id)) throw new InvalidOperationException("Not in its quadrant.");
            await SimulateDrop(main, FindPluginZone(main, "Eliminate"), new Point(60, 60), task, "drag-matrix.png");
            var t = s.Planner.Store.FindTask(task.Id)!;
            if (t.IsUrgent || t.Priority.IsImportant()) throw new InvalidOperationException($"Got urgent={t.IsUrgent} priority={t.Priority}");
            await Idle(200);
            if (!HasCard(FindPluginZone(main, "Eliminate"), task.Id)) throw new InvalidOperationException("The card didn't move.");
            if (Prop(FindPluginZone(main, "Eliminate").DataContext, "IsDropTarget") is not false) throw new InvalidOperationException("The drop highlight stayed on.");
        });

        await Step("boards: drag a card to the Doing column", async () =>
        {
            await Open(kanban);
            await AllOpen(kanban);
            var task = Find("Book dentist");
            await SimulateDrop(main, FindPluginZone(main, "Doing"), new Point(60, 60), task, "drag-kanban.png");
            if (s.Planner.Store.FindTask(task.Id)!.Status != TaskState.Doing) throw new InvalidOperationException("Status unchanged.");
            await Idle(200);
            if (!HasCard(FindPluginZone(main, "Doing"), task.Id)) throw new InvalidOperationException("The card didn't move.");
            Snap(main, "light-kanban-doing.png");
        });

        await Step("boards: a card on a plugin page is DayBoard's own (tick it done, undo)", async () =>
        {
            var task = Find("Book dentist");
            var card = AllDescendants<Views.Controls.TaskCard>(FindPluginZone(main, "Doing")).First(c => (c.DataContext as TaskCardViewModel)?.Id == task.Id);
            var tick = AllDescendants<CheckBox>(card).First(c => AutomationName(c) == "Done");
            tick.RaiseEvent(new RoutedEventArgs(System.Windows.Controls.Primitives.ButtonBase.ClickEvent, tick));
            await Idle(250);
            if (!s.Planner.Store.FindTask(task.Id)!.IsDone || !HasCard(FindPluginZone(main, "Done"), task.Id)) throw new InvalidOperationException("Not done, or not in Done.");
            s.Main.UndoCommand.Execute(null);
            await Idle(250);
            if (s.Planner.Store.FindTask(task.Id)!.Status != TaskState.Doing) throw new InvalidOperationException("Undo didn't put it back in Doing.");
        });

        await Step("boards: the weekly review steps through the weeks", async () =>
        {
            await Open(review);
            var ws = Core.Time.DateUtil.StartOfWeek(today, s.Settings.Current.WeekStart);
            int done = s.Planner.Store.Tasks.Count(t => t.IsDone && !t.IsSkipped && t.CompletedAt is { } c && DateOnly.FromDateTime(c) >= ws && DateOnly.FromDateTime(c) <= ws.AddDays(6));
            var vm = Page(review).DataContext;
            if (s.Main.HeaderTitle != "Weekly review" || !s.Main.HeaderSubtitle.StartsWith("Week ", StringComparison.Ordinal) || !s.Main.ShowDateNav)
                throw new InvalidOperationException($"Header: {s.Main.HeaderTitle} / {s.Main.HeaderSubtitle}");
            if (Prop(vm, "CompletedText") as string != done.ToString(System.Globalization.CultureInfo.CurrentCulture)) throw new InvalidOperationException($"Completed {Prop(vm, "CompletedText")}, expected {done}.");
            Line($"     this week: {done} completed, rate {Prop(vm, "RateText")}, focus {Prop(vm, "FocusText")}");
            var subtitle = s.Main.HeaderSubtitle;
            s.Main.PreviousCommand.Execute(null);
            await Idle(300);
            if ((DateOnly)Prop(vm, "WeekStart")! != ws.AddDays(-7) || s.Main.HeaderSubtitle == subtitle) throw new InvalidOperationException("Previous didn't show last week.");
            Snap(main, "light-review-last-week.png");
            s.Main.GoTodayCommand.Execute(null);
            await Idle(300);
            if ((DateOnly)Prop(vm, "WeekStart")! != ws || s.Main.CurrentView != Key(review)) throw new InvalidOperationException("Today didn't come back to this week.");
        });

        await Step("boards: undo the drags", async () =>
        {
            s.Main.UndoCommand.Execute(null);
            s.Main.UndoCommand.Execute(null);
            await Idle();
            var t = Find("Book dentist");
            if (t.Status != TaskState.ToDo || !t.IsUrgent) throw new InvalidOperationException($"Got {t.Status} urgent={t.IsUrgent}");
        });

        await Step("boards: unticking Kanban removes its page and leaves the others", async () =>
        {
            await Open(kanban);
            settingsVm.Refresh();
            settingsVm.Plugins.Single(p => p.Id == kanban.PluginId).IsOn = false;
            await Idle(300);
            if (NavTitles() != "Focus, Matrix, Review" || s.Main.CurrentView != PageKeys.Day) throw new InvalidOperationException($"Sidebar {NavTitles()}, showing {s.Main.CurrentView}");
        });

        // The rest of the self-test runs without them.
        foreach (var v in views) s.Plugins.Remove(v.PluginId);
        s.Runner.Sync();
        settingsVm.Refresh();
        s.Main.ShowDate(today, PageKeys.Day);
        SetMode(s, main, ThemeMode.Dark);
        await Idle(200);
    }

    private static bool PluginRunnerKey(string view) => Hosting.PluginRunner.IsPageKey(view);

    /// <summary>Seeds check-ins in the plugin's storage, as DayBoard 1.3 copies them over from 1.2.</summary>
    private static void SeedCheckIns(AppServices s, string pluginId, DateOnly today)
    {
        string[] colors = { "#7E97B3", "#7A9A6B", "#C9A04E", "#C47552", "#C98A9A", "#9A88B5", "#6F9A94", "#8C8478" };
        string[] tags = { "calm", "focused", "tired", "social", "active", "stressed", "grateful" };
        string[] notes =
        {
            "Slow morning, good coffee. Got through the inbox before lunch.",
            "Too many meetings. Went for a run in the evening and felt better.",
            "Dinner with Sam and Alex. Laughed a lot.",
            "Tired all day. Early night.",
            "Finally fixed the squeaky door!",
            "Spanish lesson went well: I followed most of the conversation.",
        };
        var rng = new Random(42);
        int n = 0;
        for (int i = 1; i <= 80; i++)
        {
            if (rng.NextDouble() < 0.18) continue; // some days without a check-in
            var d = today.AddDays(-i);
            int mood = Math.Clamp(3 + (int)Math.Round(Math.Sin(i / 5.0) * 1.3 + (rng.NextDouble() - 0.5)), 1, 5);
            var json = System.Text.Json.JsonSerializer.Serialize(new
            {
                mood,
                color = rng.NextDouble() < 0.85 ? colors[(mood * 2 + rng.Next(3)) % colors.Length] : null,
                tags = tags.OrderBy(_ => rng.Next()).Take(rng.Next(0, 3)).ToList(),
                note = rng.NextDouble() < 0.35 ? notes[rng.Next(notes.Length)] : "",
                updatedAt = DateTime.Now,
            });
            s.Runner.Data.Set(pluginId, "checkin:" + d.ToString("yyyy-MM-dd", System.Globalization.CultureInfo.InvariantCulture), json, DateTime.Now);
            n++;
        }
        Line($"     {n} check-ins seeded");
    }

    /// <summary>Waits for the next themed dialog, snaps it, and presses one of its buttons. Returns the dialog's title.</summary>
    private static Task<string> AnswerChoiceDialog(string button, string? snap)
    {
        var done = new TaskCompletionSource<string>();
        var started = DateTime.Now;
        var timer = new DispatcherTimer(DispatcherPriority.ApplicationIdle) { Interval = TimeSpan.FromMilliseconds(150) };
        timer.Tick += (_, _) =>
        {
            var dlg = Application.Current.Windows.OfType<ChoiceDialog>().FirstOrDefault(w => w.IsLoaded);
            if (dlg is null)
            {
                if (DateTime.Now - started < TimeSpan.FromSeconds(10)) return;
                timer.Stop();
                done.TrySetException(new InvalidOperationException("No dialog was shown."));
                return;
            }
            timer.Stop();
            try
            {
                if (snap is not null) Snap(dlg, snap);
                var b = AllDescendants<Button>(dlg).First(x => x.Content as string == button);
                var title = dlg.Title;
                Invoke(b);
                done.TrySetResult(title);
            }
            catch (Exception ex)
            {
                dlg.Close();
                done.TrySetException(ex);
            }
        };
        timer.Start();
        return done.Task;
    }

    private static string AutomationName(DependencyObject d) => System.Windows.Automation.AutomationProperties.GetName(d) ?? "";

    private static T Find<T>(DependencyObject root, string automationName) where T : FrameworkElement =>
        AllDescendants<T>(root).FirstOrDefault(e => AutomationName(e) == automationName)
        ?? throw new InvalidOperationException($"No {typeof(T).Name} called \"{automationName}\".");

    /// <summary>Clicks a button found by its accessible name, or by its text.</summary>
    private static void Click(DependencyObject root, string name)
    {
        var b = AllDescendants<Button>(root).FirstOrDefault(x => AutomationName(x) == name && x.IsVisible)
                ?? AllDescendants<Button>(root).FirstOrDefault(x => x.Content as string == name && x.IsVisible)
                ?? throw new InvalidOperationException($"No visible button called \"{name}\".");
        Invoke(b);
    }

    /// <summary>Presses a button the way assistive technology would.</summary>
    private static void Invoke(Button b)
    {
        if (!b.IsEnabled) throw new InvalidOperationException($"The button \"{AutomationName(b)}\" is disabled.");
        var peer = new System.Windows.Automation.Peers.ButtonAutomationPeer(b);
        ((System.Windows.Automation.Provider.IInvokeProvider)peer.GetPattern(System.Windows.Automation.Peers.PatternInterface.Invoke)!).Invoke();
    }

    private static bool HasText(DependencyObject root, string text) => HasText(root, t => t == text);

    private static bool HasText(DependencyObject root, Func<string, bool> match) =>
        AllDescendants<TextBlock>(root).Any(t => t.IsVisible && match(t.Text)) ||
        AllDescendants<TextBox>(root).Any(t => t.IsVisible && match(t.Text));

    private static void SetMode(AppServices s, Window main, ThemeMode mode)
    {
        s.Settings.Current.Theme = mode;
        ThemeService.Apply(s.Settings.Current, main);
    }

    private static uint Argb(Color c) => ((uint)c.A << 24) | ((uint)c.R << 16) | ((uint)c.G << 8) | c.B;

    private static void ExpectSlot(ThemeDefinition theme, string slot, bool dark)
    {
        if (!(dark ? theme.Dark : theme.Light).TryGetValue(slot, out var expected)) return;
        var actual = ((SolidColorBrush)Application.Current.FindResource("DB." + slot)).Color;
        if (Argb(actual) != expected) throw new InvalidOperationException($"DB.{slot} is {actual}, expected {PluginFormat.ToHex(expected)}.");
    }

    private static void ExpectStock(string slot, bool dark)
    {
        var stock = new ResourceDictionary { Source = new Uri($"pack://application:,,,/DayBoard;component/Themes/Palette.{(dark ? "Dark" : "Light")}.xaml", UriKind.Absolute) };
        var expected = ((SolidColorBrush)stock["DB." + slot]).Color;
        var actual = ((SolidColorBrush)Application.Current.FindResource("DB." + slot)).Color;
        if (actual != expected) throw new InvalidOperationException($"DB.{slot} is {actual}, expected DayBoard's {expected}.");
    }

    /// <summary>A small theme, used when no plugin file is passed with --plugin and as a second theme.</summary>
    private static string MakeTestPlugin(string id, string name, string fileName)
    {
        var path = Path.Combine(_out, fileName);
        if (File.Exists(path)) File.Delete(path);
        using var zip = System.IO.Compression.ZipFile.Open(path, System.IO.Compression.ZipArchiveMode.Create);
        void Add(string name, string text)
        {
            using var w = new StreamWriter(zip.CreateEntry(name).Open(), new UTF8Encoding(false));
            w.Write(text);
        }
        Add("plugin.json", """
            { "format": "dayboard-plugin", "formatVersion": 1, "id": "ID", "name": "NAME",
              "version": "1.0.0", "author": "DayBoard", "kind": "theme", "entry": "theme.json" }
            """.Replace("ID", id).Replace("NAME", name));
        Add("theme.json", """
            { "accent": { "light": "#2E8B57", "dark": "#80CFA0" },
              "priority": { "high": "#6A5ACD" },
              "swatches": ["#5B8DB8","#6B74B8","#8A79B8","#C27BA0","#C0605F","#C98A5A","#C9A04E","#93A85A","#4F9A6F","#4F9A94","#5A9EB0","#7A8490"],
              "light": { "Accent": "#FF2E8B57", "WindowBackground": "#FFF1F7F3", "AccentSoft": "#FFDDEFE4" },
              "dark": { "Accent": "#FF80CFA0", "WindowBackground": "#FF18201B" } }
            """);
        return path;
    }

    private static void Snap(Window w, string file)
    {
        if (w.Content is not FrameworkElement root) return;
        w.UpdateLayout();
        var dpi = VisualTreeHelper.GetDpi(root);
        double wDip = Math.Max(root.ActualWidth + root.Margin.Left + root.Margin.Right, 1);
        double hDip = Math.Max(root.ActualHeight + root.Margin.Top + root.Margin.Bottom, 1);
        int width = (int)Math.Ceiling(wDip * dpi.DpiScaleX);
        int height = (int)Math.Ceiling(hDip * dpi.DpiScaleY);
        if (root.ActualWidth <= 0 || root.ActualHeight <= 0) throw new InvalidOperationException($"{file}: nothing to render.");
        var rtb = new RenderTargetBitmap(width, height, dpi.PixelsPerInchX, dpi.PixelsPerInchY, PixelFormats.Pbgra32);
        if (!w.AllowsTransparency)
        {
            var bg = new DrawingVisual();
            using (var dc = bg.RenderOpen()) dc.DrawRectangle(ThemeService.Resource("DB.WindowBackground", Brushes.White), null, new Rect(0, 0, wDip, hDip));
            rtb.Render(bg);
        }
        rtb.Render(root);
        var enc = new PngBitmapEncoder();
        enc.Frames.Add(BitmapFrame.Create(rtb));
        using var fs = File.Create(Path.Combine(_out, file));
        enc.Save(fs);
    }

    private static void Seed(AppServices s)
    {
        var p = s.Planner;
        var today = p.Today;
        var cats = p.Store.Categories.ToDictionary(c => c.Name);
        Guid Cat(string n) => cats[n].Id;
        var ws = Core.Time.DateUtil.StartOfWeek(today, s.Settings.Current.WeekStart);

        // History for the heatmap and stats: completed tasks over the past ~4 months.
        var rnd = new Random(42);
        var names = new[] { "Reply to emails", "Groceries", "Review PR", "Call mum", "Gym", "Read 20 pages", "Plan sprint", "Pay rent" };
        var catNames = cats.Keys.ToArray();
        for (int d = 120; d >= 1; d--)
        {
            int n = rnd.Next(0, 6);
            for (int i = 0; i < n; i++)
            {
                var day = today.AddDays(-d);
                var t = p.AddTask(new TaskItem
                {
                    Title = names[rnd.Next(names.Length)], ScheduledDate = day, Priority = (Priority)rnd.Next(0, 4),
                    CategoryId = Cat(catNames[rnd.Next(catNames.Length)]), EstimateMinutes = 15 * rnd.Next(1, 5),
                });
                {
                    var c = p.Store.FindTask(t.Id)!.Clone();
                    c.Status = TaskState.Done;
                    c.CompletedAt = day.ToDateTime(new TimeOnly(9 + rnd.Next(0, 9), rnd.Next(0, 60)));
                    p.Execute(new Core.Store.ChangeSet("seed").Task(p.Store.FindTask(t.Id), c));
                }
            }
        }
        // Leftovers from the past roll over into today.
        p.AddTask(new TaskItem { Title = "Renew passport", ScheduledDate = today.AddDays(-2), Priority = Priority.High, CategoryId = Cat("Errands"), EstimateMinutes = 30 });
        p.AddTask(new TaskItem { Title = "Draft blog post", ScheduledDate = today.AddDays(-1), Priority = Priority.Low, CategoryId = Cat("Learning"), EstimateMinutes = 45 });
        p.RunDailyMaintenance();

        // Today
        var deep = p.AddTask(new TaskItem
        {
            Title = "Write Q4 planning doc", ScheduledDate = today, StartTime = new TimeOnly(9, 0), EstimateMinutes = 90, Priority = Priority.High,
            CategoryId = Cat("Work"), Notes = "Outline goals, risks and staffing.",
            Subtasks = { new Subtask { Title = "Goals", IsDone = true }, new Subtask { Title = "Risks" }, new Subtask { Title = "Staffing" } },
        });
        p.AddTask(new TaskItem { Title = "1:1 prep", ScheduledDate = today, StartTime = new TimeOnly(9, 30), EstimateMinutes = 30, Priority = Priority.Medium, CategoryId = Cat("Work") });
        p.AddTask(new TaskItem { Title = "Spanish lesson", ScheduledDate = today, StartTime = new TimeOnly(13, 0), EstimateMinutes = 45, Priority = Priority.Low, CategoryId = Cat("Learning") },
            new RepeatPattern { Kind = RepeatKind.Weekdays });
        p.AddTask(new TaskItem { Title = "Run 5k", ScheduledDate = today, StartTime = new TimeOnly(18, 0), EstimateMinutes = 40, CategoryId = Cat("Health") },
            new RepeatPattern { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Monday, DayOfWeek.Wednesday, DayOfWeek.Friday, today.DayOfWeek } });
        p.AddTask(new TaskItem { Title = "Book dentist", ScheduledDate = today, Priority = Priority.High, IsUrgent = true, CategoryId = Cat("Health"), EstimateMinutes = 10 });
        p.AddTask(new TaskItem { Title = "Order birthday gift for Sam", ScheduledDate = today, Priority = Priority.Medium, CategoryId = Cat("Personal"), DueDate = today.AddDays(1), EstimateMinutes = 20 });
        var done = p.AddTask(new TaskItem { Title = "Water the plants", ScheduledDate = today, CategoryId = Cat("Personal"), EstimateMinutes = 5 });
        p.SetDone(done.Id, true);
        p.LogFocusTime(deep.Id, 25);

        // The rest of the week, including one overbooked day.
        for (int i = 0; i < 7; i++)
        {
            var d = ws.AddDays(i);
            if (d == today) continue;
            var added = new List<TaskItem>
            {
                p.AddTask(new TaskItem { Title = "Inbox zero", ScheduledDate = d, EstimateMinutes = 30, CategoryId = Cat("Work") }),
            };
            if (i % 2 == 0) added.Add(p.AddTask(new TaskItem { Title = "Deep work block", ScheduledDate = d, StartTime = new TimeOnly(10, 0), EstimateMinutes = 120, Priority = Priority.High, CategoryId = Cat("Work") }));
            if (d == today.AddDays(1) || d == today.AddDays(-1))
            {
                added.Add(p.AddTask(new TaskItem { Title = "Workshop prep", ScheduledDate = d, EstimateMinutes = 240, Priority = Priority.Medium, CategoryId = Cat("Work"), IsUrgent = true }));
                added.Add(p.AddTask(new TaskItem { Title = "Expense report", ScheduledDate = d, EstimateMinutes = 60, CategoryId = Cat("Errands") }));
            }
            if (d < today)
            {
                foreach (var t in added) p.SetDone(t.Id, true);
            }
        }

        // Inbox
        p.AddTask(new TaskItem { Title = "Research standing desks", CategoryId = Cat("Personal") });
        p.AddTask(new TaskItem { Title = "Fix squeaky door", CategoryId = Cat("Errands"), Priority = Priority.Low });
        p.AddTask(new TaskItem { Title = "Learn WPF drag and drop", CategoryId = Cat("Learning"), Priority = Priority.Medium, IsUrgent = true });
        p.AddTask(new TaskItem { Title = "Plan weekend trip", Notes = "Somewhere with mountains" });

        // A read-only calendar feed.
        var sub = new CalendarSubscription { Name = "Work calendar", Url = "https://example.invalid/cal.ics", Color = "#0EA5E9" };
        s.Settings.Current.Calendars.Add(sub);
        var t0 = today.ToDateTime(new TimeOnly(11, 0));
        string Fmt(DateTime d) => d.ToString("yyyyMMdd'T'HHmmss");
        var ics = "BEGIN:VCALENDAR\r\nVERSION:2.0\r\n" +
                  $"BEGIN:VEVENT\r\nUID:sync@test\r\nDTSTART:{Fmt(t0)}\r\nDTEND:{Fmt(t0.AddHours(1))}\r\nRRULE:FREQ=WEEKLY\r\nSUMMARY:Team sync\r\nLOCATION:Room 4\r\nEND:VEVENT\r\n" +
                  $"BEGIN:VEVENT\r\nUID:lunch@test\r\nDTSTART:{Fmt(today.ToDateTime(new TimeOnly(12, 30)))}\r\nDTEND:{Fmt(today.ToDateTime(new TimeOnly(13, 15)))}\r\nSUMMARY:Lunch with Alex\r\nEND:VEVENT\r\n" +
                  $"BEGIN:VEVENT\r\nUID:conf@test\r\nDTSTART;VALUE=DATE:{today.AddDays(1):yyyyMMdd}\r\nDTEND;VALUE=DATE:{today.AddDays(3):yyyyMMdd}\r\nSUMMARY:Design conference\r\nEND:VEVENT\r\n" +
                  "END:VCALENDAR\r\n";
        s.Calendars.LoadForTest(sub, ics);
        s.Main.RefreshNow();
    }
}
