using System.Globalization;
using System.Windows;
using System.Windows.Data;

namespace DayBoard.Infrastructure;

public sealed class BoolToVisibilityConverter : IValueConverter
{
    public bool Invert { get; set; }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        bool b = value switch
        {
            bool x => x,
            int i => i != 0,
            string s => !string.IsNullOrWhiteSpace(s),
            null => false,
            _ => true,
        };
        if (Invert) b = !b;
        return b ? Visibility.Visible : Visibility.Collapsed;
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) =>
        value is Visibility v && (v == Visibility.Visible) != Invert;
}

public sealed class InverseBoolConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) => value is not true;
    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => value is not true;
}

/// <summary>True when the bound value equals the converter parameter (string compare). Used for radio-button groups bound to a string or enum.</summary>
public sealed class EqualsConverter : IValueConverter
{
    public object Convert(object value, Type targetType, object parameter, CultureInfo culture) =>
        string.Equals(value?.ToString(), parameter?.ToString(), StringComparison.OrdinalIgnoreCase);

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
    {
        if (value is not true) return Binding.DoNothing;
        if (targetType.IsEnum && parameter is string s) return Enum.Parse(targetType, s);
        if (targetType == typeof(int) && parameter is string si && int.TryParse(si, out var n)) return n;
        return parameter;
    }
}

/// <summary>A double (0..1) to a star GridLength, for simple proportional bars.</summary>
public sealed class StarConverter : IValueConverter
{
    public bool Remainder { get; set; }

    public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
    {
        double v = value is double d ? d : 0;
        v = Math.Clamp(double.IsFinite(v) ? v : 1, 0, 1);
        if (Remainder) v = 1 - v;
        return new GridLength(Math.Max(v, 0.0001), GridUnitType.Star);
    }

    public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture) => Binding.DoNothing;
}
