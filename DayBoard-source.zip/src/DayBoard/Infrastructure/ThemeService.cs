using System.Windows;
using System.Windows.Media;
using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Services;
using Wpf.Ui.Appearance;
using ThemeMode = DayBoard.Core.Models.ThemeMode;
using Wpf.Ui.Controls;

namespace DayBoard.Infrastructure;

/// <summary>
/// Light / dark / follow-system theme, density, and priority colours. A theme plugin, when one is picked, is layered
/// over DayBoard's own palette: slots it doesn't set keep their stock colours.
/// </summary>
public static class ThemeService
{
    private const string PaletteMarker = "/Themes/Palette.";
    private static Window? _watched;
    private static bool _hooked;
    private static string? _appliedPalette;
    private static AppSettings? _settings;

    public static event EventHandler? Changed;

    public static bool IsDark { get; private set; }

    /// <summary>The theme plugin in use, or null for DayBoard's own colours.</summary>
    public static InstalledPlugin? ActiveTheme { get; private set; }

    public static void Apply(AppSettings settings, Window? mainWindow)
    {
        _settings = settings;
        ActiveTheme = AppServices.Current?.Plugins?.ActiveTheme(settings);
        ColorUtil.SetSwatchMap(ActiveTheme?.Theme?.Swatches ?? StockLook.Swatches);

        if (!_hooked)
        {
            _hooked = true;
            ApplicationThemeManager.Changed += (_, _) => Application.Current?.Dispatcher.BeginInvoke(SyncPalette);
        }

        if (_watched is not null)
        {
            SystemThemeWatcher.UnWatch(_watched);
            _watched = null;
        }

        switch (settings.Theme)
        {
            case ThemeMode.Light:
                ApplicationThemeManager.Apply(ApplicationTheme.Light, WindowBackdropType.Mica, updateAccent: false);
                break;
            case ThemeMode.Dark:
                ApplicationThemeManager.Apply(ApplicationTheme.Dark, WindowBackdropType.Mica, updateAccent: false);
                break;
            default:
                ApplicationThemeManager.ApplySystemTheme(updateAccent: false);
                if (mainWindow is not null)
                {
                    SystemThemeWatcher.Watch(mainWindow, WindowBackdropType.Mica, updateAccents: false);
                    _watched = mainWindow;
                }
                break;
        }

        SyncPalette();
        ApplyDensity(settings.Density);
        ApplyPriorityColors(settings);
    }

    private static void SyncPalette()
    {
        var app = Application.Current;
        if (app is null) return;
        var theme = ApplicationThemeManager.GetAppTheme();
        bool dark = theme == ApplicationTheme.Dark ||
                    (theme == ApplicationTheme.HighContrast && ApplicationThemeManager.GetSystemTheme() is SystemTheme.HCBlack or SystemTheme.HC1 or SystemTheme.HC2);
        IsDark = dark;
        var custom = ActiveTheme?.Theme;

        try
        {
            var accent = ToColor((dark ? custom?.AccentDark : custom?.AccentLight) ?? (dark ? StockLook.AccentDark : StockLook.AccentLight));
            ApplicationAccentColorManager.Apply(accent, dark ? ApplicationTheme.Dark : ApplicationTheme.Light);
        }
        catch (Exception ex)
        {
            Log.Error("Apply accent", ex);
        }

        var key = $"{ActiveTheme?.Id ?? "stock"}@{ActiveTheme?.Manifest?.Version}|{(dark ? "dark" : "light")}";
        var merged = app.Resources.MergedDictionaries;
        int index = -1;
        for (int i = 0; i < merged.Count; i++)
        {
            if (merged[i].Source?.OriginalString.Contains(PaletteMarker, StringComparison.OrdinalIgnoreCase) == true)
            {
                index = i;
                break;
            }
        }
        if (index >= 0 && _appliedPalette == key) return;

        var stock = new Uri($"pack://application:,,,/DayBoard;component/Themes/Palette.{(dark ? "Dark" : "Light")}.xaml", UriKind.Absolute);
        var dict = new ResourceDictionary { Source = stock };
        if (custom is not null)
        {
            foreach (var (slot, argb) in dark ? custom.Dark : custom.Light)
            {
                var c = ToColor(argb);
                var brush = new SolidColorBrush(c);
                brush.Freeze();
                dict[$"DB.{slot}Color"] = c;
                dict[$"DB.{slot}"] = brush;
            }
        }
        if (index >= 0) merged[index] = dict;
        else merged.Add(dict);
        _appliedPalette = key;
        Changed?.Invoke(null, EventArgs.Empty);
    }

    private static Color ToColor(uint argb) =>
        Color.FromArgb((byte)(argb >> 24), (byte)(argb >> 16), (byte)(argb >> 8), (byte)argb);

    public static void ApplyDensity(Density density)
    {
        var r = Application.Current.Resources;
        bool compact = density == Density.Compact;
        r["DB.CardPadding"] = compact ? new Thickness(8, 4, 8, 4) : new Thickness(10, 8, 10, 8);
        r["DB.CardMargin"] = compact ? new Thickness(0, 0, 0, 3) : new Thickness(0, 0, 0, 6);
        r["DB.CardTitleSize"] = compact ? 12.5 : 13.5;
        r["DB.CardMetaSize"] = compact ? 11.0 : 11.5;
        r["DB.NotesVisibility"] = compact ? Visibility.Collapsed : Visibility.Visible;
        Changed?.Invoke(null, EventArgs.Empty);
    }

    public static void ApplyPriorityColors(AppSettings s)
    {
        var r = Application.Current.Resources;
        foreach (var p in new[] { Priority.Low, Priority.Medium, Priority.High })
        {
            var c = ColorUtil.Parse(PriorityHex(p, s)) ?? Color.FromRgb(0x8A, 0x8F, 0x98);
            var brush = new SolidColorBrush(c);
            brush.Freeze();
            var tint = new SolidColorBrush(Color.FromArgb(0x26, c.R, c.G, c.B));
            tint.Freeze();
            r[$"DB.Priority{p}Brush"] = brush;
            r[$"DB.Priority{p}Tint"] = tint;
        }
    }

    /// <summary>True when the active theme suggests priority colours and the user hasn't picked their own.</summary>
    public static bool ThemeSetsPriorityColors(AppSettings s) =>
        ActiveTheme?.Theme is { HasPriorityColors: true } && new[] { Priority.Low, Priority.Medium, Priority.High }.Any(p => UsesThemePriority(p, s));

    private static bool UsesThemePriority(Priority p, AppSettings s)
    {
        var theme = ActiveTheme?.Theme;
        if (theme is null) return false;
        var suggested = p switch { Priority.Low => theme.PriorityLow, Priority.Medium => theme.PriorityMedium, Priority.High => theme.PriorityHigh, _ => null };
        return suggested.HasValue && string.Equals(s.PriorityColor(p), Defaults.PriorityColor(p), StringComparison.OrdinalIgnoreCase);
    }

    private static readonly AppSettings Defaults = new();

    /// <summary>
    /// The colour a priority is shown in: the user's own choice; or, while it's still DayBoard's default, the active
    /// theme's suggestion (DayBoard's own when no theme is ticked). Colours picked from the swatches follow the shown
    /// version of that swatch.
    /// </summary>
    public static string PriorityHex(Priority p, AppSettings? s = null)
    {
        s ??= _settings ?? Defaults;
        if (p == Priority.None) return s.PriorityColor(p);
        if (UsesThemePriority(p, s))
        {
            var theme = ActiveTheme!.Theme!;
            var v = p switch { Priority.Low => theme.PriorityLow, Priority.Medium => theme.PriorityMedium, _ => theme.PriorityHigh };
            return PluginFormat.ToHex(v!.Value);
        }
        if (ActiveTheme is null && string.Equals(s.PriorityColor(p), Defaults.PriorityColor(p), StringComparison.OrdinalIgnoreCase))
            return PluginFormat.ToHex(p switch { Priority.Low => StockLook.PriorityLow, Priority.Medium => StockLook.PriorityMedium, _ => StockLook.PriorityHigh });
        return ColorUtil.Display(s.PriorityColor(p));
    }

    public static Brush Resource(string key, Brush fallback) =>
        Application.Current?.TryFindResource(key) as Brush ?? fallback;
}

public static class ColorUtil
{
    public static Color? Parse(string? hex)
    {
        if (string.IsNullOrWhiteSpace(hex)) return null;
        try
        {
            var s = hex.Trim();
            if (!s.StartsWith('#')) s = "#" + s;
            return (Color)ColorConverter.ConvertFromString(s);
        }
        catch (FormatException)
        {
            return null;
        }
    }

    private static readonly Dictionary<string, SolidColorBrush> Cache = new(StringComparer.OrdinalIgnoreCase);
    private static Dictionary<string, string>? _swatchMap;

    /// <summary>
    /// Brush for a stored colour (category, priority, calendar). Colours that are one of the stock swatches are shown in
    /// the active theme's version of that swatch; the stored value itself never changes.
    /// </summary>
    public static SolidColorBrush Brush(string? hex, byte? alpha = null)
    {
        var shown = Display(hex);
        var key = shown + "|" + alpha;
        if (Cache.TryGetValue(key, out var b)) return b;
        var c = Parse(shown) ?? Color.FromRgb(0x8A, 0x8F, 0x98);
        if (alpha.HasValue) c = Color.FromArgb(alpha.Value, c.R, c.G, c.B);
        b = new SolidColorBrush(c);
        b.Freeze();
        Cache[key] = b;
        return b;
    }

    /// <summary>The colour actually shown for a stored colour under the active theme.</summary>
    public static string Display(string? hex)
    {
        var s = (hex ?? "").Trim();
        return _swatchMap is not null && _swatchMap.TryGetValue(s, out var mapped) ? mapped : s;
    }

    /// <summary>Called by <see cref="ThemeService"/> with the swatches to show: the active theme's, or DayBoard's own.</summary>
    public static void SetSwatchMap(IReadOnlyList<uint>? swatches)
    {
        Dictionary<string, string>? map = null;
        if (swatches is { Count: > 0 })
        {
            map = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (int i = 0; i < Math.Min(swatches.Count, Swatches.Count); i++) map[Swatches[i]] = PluginFormat.ToHex(swatches[i]);
            foreach (var (hex, slot) in CalendarColorSlots)
            {
                if (slot < swatches.Count) map[hex] = PluginFormat.ToHex(swatches[slot]);
            }
        }
        bool same = (map is null && _swatchMap is null) ||
                    (map is not null && _swatchMap is not null && map.Count == _swatchMap.Count && map.All(kv => _swatchMap.TryGetValue(kv.Key, out var v) && v == kv.Value));
        if (same) return;
        _swatchMap = map;
        Cache.Clear();
    }

    public static string ToHex(Color c) => $"#{c.R:X2}{c.G:X2}{c.B:X2}";

    /// <summary>DayBoard's 12 category colours, as stored. They're shown muted (see <see cref="StockLook"/>), or as a theme restyles them.</summary>
    public static readonly IReadOnlyList<string> Swatches = PluginFormat.StockSwatches;

    /// <summary>Colours given to new calendar subscriptions, in turn.</summary>
    public static readonly IReadOnlyList<string> CalendarColors = new[] { "#7C8DB5", "#0EA5E9", "#22C55E", "#A855F7", "#F97316", "#EF4444" };

    /// <summary>
    /// Calendar colours that aren't swatches follow the shown version of the nearest swatch
    /// (sky → cyan, green → green, purple → violet, red → red). #7C8DB5 is already muted and #F97316 is a swatch.
    /// The neutral grey for "no category" and "no priority" follows slate.
    /// </summary>
    private static readonly (string Hex, int Slot)[] CalendarColorSlots = { ("#0EA5E9", 10), ("#22C55E", 8), ("#A855F7", 2), ("#EF4444", 4), ("#8A8F98", 11) };
}
