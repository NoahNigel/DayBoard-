using System.Windows;
using System.Windows.Threading;
using DayBoard.Core.Models;
using DayBoard.Core.Planning;
using DayBoard.Core.Store;
using DayBoard.Core.Time;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Hosting;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;
using DayBoard.Views;
using Microsoft.Win32;

namespace DayBoard;

public partial class App : Application
{
    private SingleInstance? _single;
    private DispatcherTimer? _clockTimer;
    private DateOnly _lastDay;
    private bool _crashShown;

    public bool IsExiting { get; private set; }

    /// <summary>True while running <c>--selftest</c> (temporary data, no system integration side effects).</summary>
    public bool IsSelfTest { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);
        if (SelfTest.IsRequested(e.Args, out var selfTestDir))
        {
            IsSelfTest = true;
            SelfTest.Prepare(selfTestDir);
            if (Environment.GetEnvironmentVariable("DAYBOARD_SOFTWARE_RENDER") == "1")
                System.Windows.Media.RenderOptions.ProcessRenderMode = System.Windows.Interop.RenderMode.SoftwareOnly;
        }
        _single = new SingleInstance(IsSelfTest ? "DayBoard-SelfTest" : "DayBoard");
        if (!_single.IsFirstInstance && e.Args.Contains("--after-restart"))
            _single.TryTakeOver(TimeSpan.FromSeconds(15));
        if (!_single.IsFirstInstance)
        {
            // Another DayBoard is running: hand over our arguments (e.g. from the jump list) and quit.
            _single.ForwardToFirstInstance(e.Args);
            _single.Dispose();
            _single = null;
            Shutdown();
            return;
        }

        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += (_, args) =>
        {
            var ex = (Exception)args.ExceptionObject;
            Log.Error("Unhandled", ex);
            // DayBoard is about to close. If a plugin caused it, the next start turns that plugin off.
            if ((AppServices.Current?.Runner?.FindPlugin(ex) ?? PluginLoadContext.PluginIn(ex)) is { } pluginId) StartMarker.WriteCrash(pluginId);
        };
        TaskScheduler.UnobservedTaskException += (_, args) =>
        {
            Log.Error("Unobserved task", args.Exception);
            args.SetObserved();
        };

        try
        {
            Boot(e.Args);
            if (IsSelfTest)
            {
                Dispatcher.BeginInvoke(async () =>
                {
                    int code = await SelfTest.RunAsync();
                    IsExiting = true;
                    Shutdown(code);
                }, DispatcherPriority.ApplicationIdle);
            }
        }
        catch (Exception ex)
        {
            if (IsSelfTest)
            {
                SelfTest.RecordException("startup", ex);
                Shutdown(2);
                return;
            }
            Log.Error("Startup", ex);
            MessageBox.Show($"DayBoard couldn't start:\n\n{ex.Message}\n\nDetails were written to {AppPaths.LogDir}.",
                "DayBoard", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown(1);
        }
    }

    private void Boot(string[] args)
    {
        AppPaths.EnsureCreated();
        if (BackupService.ApplyPendingRestore()) Log.Info("Restored database from backup.");

        var repo = new SqliteRepository(AppPaths.Database);
        var settings = new SettingsService(new SettingsStore(repo));
        var planner = new Planner(repo, SystemClock.Instance, () => settings.Current);
        var services = new AppServices
        {
            Repository = repo,
            Planner = planner,
            Settings = settings,
            Plugins = new PluginService(new PluginStore(AppPaths.PluginDir, PluginService.AppVersion), settings, BuiltInPlugins.All(PluginService.AppVersion)),
            Runner = new PluginRunner(new PluginDataStore(repo), safeMode: args.Contains("--safe-mode")),
            Calendars = new CalendarService(settings),
            Windows = new WindowService(),
            Hotkey = new GlobalHotkey(),
        };
        AppServices.Current = services;

        bool usedBefore = settings.Current.SeededDefaults;
        if (!settings.Current.SeededDefaults)
        {
            if (planner.Store.Categories.Count == 0)
            {
                var batch = new StoreBatch();
                foreach (var c in Category.Defaults()) batch.PutCategory(c);
                planner.Store.Commit(batch);
            }
            settings.Current.SeededDefaults = true;
            settings.Save(notify: false);
        }

        var rollover = planner.RunDailyMaintenance();
        try
        {
            BackupService.RunDailyIfNeeded(repo, planner.Today);
        }
        catch (Exception ex)
        {
            Log.Error("Daily backup", ex);
        }

        services.Main = new MainViewModel();
        var main = new MainWindow(services.Main);
        MainWindow = main;
        ThemeService.Apply(settings.Current, main);

        try
        {
            services.Tray = new TrayService(
                open: () => services.Windows.ShowMain(),
                quickAdd: () => services.Windows.ShowQuickAdd(planner.Today),
                toggleMini: () => services.Windows.ToggleMini(),
                exit: ExitApp);
        }
        catch (Exception ex)
        {
            // No notification area (e.g. Explorer not running): carry on without a tray icon.
            Log.Error("Create tray icon", ex);
            services.Tray = null;
        }
        services.Hotkey.Pressed += (_, _) => services.Windows.ShowQuickAdd(planner.Today);
        if (!IsSelfTest)
        {
            services.Main.ApplyHotkey(showErrors: true);
            JumpLists.Apply(this);
            if (settings.Current.StartWithWindows != StartupRegistration.IsEnabled())
                StartupRegistration.Set(settings.Current.StartWithWindows);
            if (settings.Current.StartMenuShortcut) StartMenuShortcut.Ensure();
        }

        var pluginNote = StartPlugins(services, usedBefore);

        bool startHidden = args.Contains("--minimized") && settings.Current.StartMinimized;
        if (!startHidden) main.Show();
        services.Main.RefreshNow();
        if (!IsSelfTest) services.Calendars.Start();
        if (settings.Current.MiniWindowOpen) services.Windows.ShowMini();

        _single!.ArgumentsReceived += a => Dispatcher.BeginInvoke(() => services.Main.HandleArguments(a));
        _single.StartListening();
        services.Main.HandleArguments(args);

        _lastDay = planner.Today;
        _clockTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(30) };
        _clockTimer.Tick += (_, _) => OnClockTick();
        _clockTimer.Start();
        SystemEvents.PowerModeChanged += OnPowerModeChanged;
        SystemEvents.TimeChanged += OnSystemTimeChanged;

        if (!IsSelfTest && StartMenuShortcut.RunningFromTemporaryFolder)
            services.Main.ShowToast("DayBoard is running from inside the zip. Unzip it to a folder you keep, so it stays in the Start menu and Windows search.");
        else if (pluginNote is not null)
            services.Main.ShowToast(pluginNote);
        else if (rollover.Moved > 0)
            services.Main.ShowToast($"{rollover.Moved} unfinished task{(rollover.Moved == 1 ? "" : "s")} rolled over to today");
    }

    /// <summary>Starts the ticked code plugins. Returns a note for the user when one had to be turned off.</summary>
    private static string? StartPlugins(AppServices s, bool usedBefore)
    {
        string? note = null;
        var enabled = s.Settings.Current.EnabledPlugins;
        string NameOf(string id) => s.Plugins.All.FirstOrDefault(p => p.Id == id)?.Name ?? id;

        // Focus became a plugin in 1.4: it takes its timer settings along.
        try
        {
            LegacySettings.CarryOverFocusTimer(s.Runner.Data, s.Settings.Current, DateTime.Now);
        }
        catch (Exception ex)
        {
            Log.Error("Carry over focus timer settings", ex);
        }

        // A plugin that DayBoard closed on (while starting, or by crashing) is turned off rather than tried again.
        if (StartMarker.TakeLast() is { } last && s.Plugins.All.FirstOrDefault(p => p.Id == last.PluginId) is { } culprit &&
            s.Plugins.IsOn(culprit, s.Settings.Current))
        {
            s.Settings.Update(x => s.Plugins.SetOn(x, last.PluginId, false));
            Log.Info($"Turned off plugin {last.PluginId}: DayBoard closed while it was {(last.Crashed ? "running" : "starting")}.");
            note = $"{NameOf(last.PluginId)} was turned off because DayBoard closed unexpectedly while it was {(last.Crashed ? "running" : "starting")}. " +
                   "You can turn it back on in Settings › Plugins.";
        }

        // Plugins made for DayBoard 1.2 need their new version. Say so once.
        foreach (var old in s.Plugins.All.Where(p => p.IsOutdated && enabled.Contains(p.Id)).ToList())
        {
            s.Settings.Update(x => PluginService.SetEnabled(x, old.Id, false));
            note ??= $"{old.Name} needs its new version for this DayBoard. Add it again in Settings › Plugins. Everything it saved is kept.";
        }

        // Matrix, Kanban and Review became plugins in 1.6. Say so once to someone who had them.
        var installed = s.Plugins.All.Where(p => p.IsUsable).Select(p => p.Id).ToList();
        string? moved = null;
        s.Settings.Update(x => moved = LegacySettings.TakeViewsMovedNote(x, usedBefore, installed), notify: false);
        note ??= moved;

        s.Runner.Changed += (_, _) => s.Main.OnPluginsChanged();
        s.Planner.Store.Changed += (_, _) => s.Runner.OnTasksChanged();
        ThemeService.Changed += (_, _) => s.Runner.OnThemeChanged();
        TaskDrag.Ended += (_, _) => s.Runner.OnTaskDragEnded();
        s.Runner.Sync();
        s.Main.OpenLastView();
        if (s.Runner.SafeMode) note = "Safe mode: code plugins you added won't run until DayBoard is restarted.";
        return note;
    }

    private void OnPowerModeChanged(object? sender, PowerModeChangedEventArgs e)
    {
        if (e.Mode == PowerModes.Resume) Dispatcher.BeginInvoke(OnClockTick);
    }

    private void OnSystemTimeChanged(object? sender, EventArgs e) => Dispatcher.BeginInvoke(OnClockTick);

    /// <summary>Detects midnight (also after sleep or clock changes) and moves the now-line.</summary>
    private void OnClockTick()
    {
        var s = AppServices.Current;
        if (s is null) return;
        var today = s.Planner.Today;
        if (today != _lastDay)
        {
            var previous = _lastDay;
            _lastDay = today;
            s.Main.OnNewDay(previous);
        }
        s.Main.Day.UpdateNow();
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        e.Handled = true;
        // A plugin's own code threw (in a click handler, a timer, ...): that plugin is turned off and DayBoard carries on.
        if (AppServices.Current?.Runner?.TryHandle(e.Exception) == true) return;
        Log.Error("UI", e.Exception);
        if (IsSelfTest)
        {
            SelfTest.RecordException("dispatcher", e.Exception);
            return;
        }
        if (_crashShown) return;
        _crashShown = true;
        MessageBox.Show($"Something went wrong: {e.Exception.Message}\n\nDayBoard will keep running. Details are in {AppPaths.LogDir}.",
            "DayBoard", MessageBoxButton.OK, MessageBoxImage.Warning);
        _crashShown = false;
    }

    /// <summary>Really quits (the main window's close button may only hide to the tray).</summary>
    public void ExitApp()
    {
        if (IsExiting) return;
        IsExiting = true;
        try
        {
            AppServices.Current?.Runner?.StopAll();
            if (MainWindow is MainWindow mw) mw.SaveBounds();
            foreach (var w in Windows.Cast<Window>().ToList()) w.Close();
        }
        catch (Exception ex)
        {
            Log.Error("Exit", ex);
        }
        Shutdown();
    }

    protected override void OnExit(ExitEventArgs e)
    {
        _clockTimer?.Stop();
        SystemEvents.PowerModeChanged -= OnPowerModeChanged;
        SystemEvents.TimeChanged -= OnSystemTimeChanged;
        var s = AppServices.Current;
        if (s is not null)
        {
            s.Tray?.Dispose();
            s.Hotkey.Dispose();
            s.Calendars.Dispose();
            s.Repository.Dispose();
        }
        _single?.Dispose();
        base.OnExit(e);
    }
}
