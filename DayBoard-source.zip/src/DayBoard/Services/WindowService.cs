using System.Windows;
using System.Windows.Interop;
using DayBoard.Core.Models;
using DayBoard.Infrastructure;
using DayBoard.ViewModels;
using DayBoard.Views;
using DayBoard.Views.Windows;

namespace DayBoard.Services;

/// <summary>Opens and activates the app's windows and dialogs.</summary>
public sealed class WindowService
{
    private QuickAddWindow? _quickAdd;
    private MiniWindow? _mini;

    private static Window? Main => Application.Current.MainWindow;

    public void ShowMain()
    {
        if (Main is not { } w) return;
        if (!w.IsVisible) w.Show();
        if (w.WindowState == WindowState.Minimized) w.WindowState = WindowState.Normal;
        Activate(w);
    }

    public static void Activate(Window w)
    {
        w.Activate();
        // Topmost toggle brings the window forward even when another app owns the foreground.
        w.Topmost = true;
        w.Topmost = false;
        w.Focus();
        var hwnd = new WindowInteropHelper(w).Handle;
        if (hwnd != IntPtr.Zero) NativeMethods.SetForegroundWindow(hwnd);
    }

    private static Window? Owner => Main is { IsVisible: true } m ? m : null;

    public void ShowQuickAdd(DateOnly? date)
    {
        if (_quickAdd is { IsLoaded: true })
        {
            Activate(_quickAdd);
            return;
        }
        _quickAdd = new QuickAddWindow(new QuickAddViewModel(date));
        _quickAdd.Closed += (_, _) => _quickAdd = null;
        _quickAdd.Show();
        Activate(_quickAdd);
    }

    public void ToggleMini()
    {
        if (_mini is { IsLoaded: true })
        {
            _mini.Close();
            return;
        }
        ShowMini();
    }

    public void ShowMini()
    {
        if (_mini is { IsLoaded: true })
        {
            Activate(_mini);
            return;
        }
        _mini = new MiniWindow(AppServices.Current.Main.Mini);
        _mini.Closed += (_, _) =>
        {
            _mini = null;
            if (!((App)Application.Current).IsExiting) AppServices.Current.Settings.Update(s => s.MiniWindowOpen = false, notify: false);
        };
        _mini.Show();
        AppServices.Current.Settings.Update(s => s.MiniWindowOpen = true, notify: false);
        AppServices.Current.Main.Mini.Refresh();
    }

    public bool IsMiniOpen => _mini is { IsLoaded: true };

    public void NewTask(DateOnly? date, TimeOnly? time)
    {
        var vm = new TaskEditorViewModel(null, date, time);
        var w = new TaskEditorWindow(vm) { Owner = Owner };
        if (Owner is null) w.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        w.ShowDialog();
    }

    public void EditTask(Guid id)
    {
        var task = AppServices.Current.Planner.Store.FindTask(id);
        if (task is null) return;
        var vm = new TaskEditorViewModel(task);
        var owner = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive) ?? Owner;
        var w = new TaskEditorWindow(vm) { Owner = owner };
        if (owner is null) w.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        w.ShowDialog();
    }

    /// <summary>Asks whether an edit/delete of a recurring task applies to this occurrence or the whole series. Null = cancelled.</summary>
    public EditScope? AskScope(string action, bool allowThisOccurrence = true)
    {
        var buttons = allowThisOccurrence
            ? new[] { "This occurrence", "Whole series", "Cancel" }
            : new[] { "Whole series", "Cancel" };
        var message = allowThisOccurrence
            ? $"This is a recurring task. {action} only this occurrence, or this and all future occurrences?"
            : $"Changing how a task repeats applies to this and all future occurrences.";
        int choice = Ask("Recurring task", message, buttons);
        if (allowThisOccurrence)
            return choice switch { 0 => EditScope.ThisOccurrence, 1 => EditScope.WholeSeries, _ => null };
        return choice == 0 ? EditScope.WholeSeries : null;
    }

    /// <summary>Shows a small themed dialog; returns the index of the button pressed (or -1 when closed).</summary>
    public int Ask(string title, string message, params string[] buttons)
    {
        var owner = Application.Current.Windows.OfType<Window>().FirstOrDefault(x => x.IsActive) ?? Owner;
        var dlg = new ChoiceDialog(title, message, buttons) { Owner = owner };
        if (owner is null) dlg.WindowStartupLocation = WindowStartupLocation.CenterScreen;
        dlg.ShowDialog();
        return dlg.Choice;
    }

    public void ShowMsTodoImport()
    {
        var w = new MsTodoImportWindow { Owner = Owner };
        w.ShowDialog();
    }

    /// <summary>Deletes a task, asking about the scope for recurring tasks.</summary>
    public void DeleteTask(Guid id)
    {
        var s = AppServices.Current;
        var t = s.Planner.Store.FindTask(id);
        if (t is null) return;
        var scope = EditScope.ThisOccurrence;
        if (t.SeriesId is not null && s.Planner.Store.FindSeries(t.SeriesId) is not null)
        {
            if (AskScope("Delete") is not { } chosen) return;
            scope = chosen;
        }
        s.Planner.DeleteTask(id, scope);
        s.Main.ShowToast($"Deleted \"{(t.Title.Length > 40 ? t.Title[..39] + "…" : t.Title)}\"", undo: true);
    }
}
