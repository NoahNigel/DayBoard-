using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;

namespace DayBoard.Services;

/// <summary>
/// Keeps the list of plugins: the ones that come with DayBoard, then the installed colour themes (data only) and code
/// plugins (run by <see cref="Hosting.PluginRunner"/>).
/// </summary>
public sealed class PluginService
{
    private readonly PluginStore _store;
    private readonly SettingsService _settings;
    private readonly IReadOnlyList<InstalledPlugin> _builtIn;

    public PluginService(PluginStore store, SettingsService settings, IReadOnlyList<InstalledPlugin>? builtIn = null)
    {
        _store = store;
        _settings = settings;
        _builtIn = builtIn ?? Array.Empty<InstalledPlugin>();
        try
        {
            _store.CleanUp();
        }
        catch (Exception ex)
        {
            Log.Error("Clean up plugins folder", ex);
        }
        Reload();
    }

    public static Version AppVersion => typeof(PluginService).Assembly.GetName().Version ?? new Version(1, 1, 0);

    public string Folder => _store.Root;

    public IReadOnlyList<InstalledPlugin> All { get; private set; } = Array.Empty<InstalledPlugin>();

    public event EventHandler? Changed;

    /// <summary>Theme plugins that can be picked under Appearance.</summary>
    public IReadOnlyList<InstalledPlugin> Themes => All.Where(p => p.IsUsable && p.Theme is not null).ToList();

    public bool IsOn(InstalledPlugin p, AppSettings settings) =>
        p.IsBuiltIn ? !settings.DisabledBuiltInPlugins.Contains(p.Id, StringComparer.Ordinal)
        : p.Theme is not null ? ActiveTheme(settings)?.Id == p.Id
        : p.IsCode && settings.EnabledPlugins.Contains(p.Id, StringComparer.Ordinal);

    public bool IsBuiltIn(string id) => _builtIn.Any(p => p.Id == id);

    /// <summary>Ticks or unticks a code plugin (built in or added from a file).</summary>
    public void SetOn(AppSettings s, string id, bool on)
    {
        if (IsBuiltIn(id))
        {
            s.DisabledBuiltInPlugins.RemoveAll(x => x == id);
            if (!on) s.DisabledBuiltInPlugins.Add(id);
        }
        else
        {
            SetEnabled(s, id, on);
        }
    }

    /// <summary>The theme in use, or null for DayBoard's own colours.</summary>
    public InstalledPlugin? ActiveTheme(AppSettings settings) =>
        settings.ThemePluginId is { } id ? Themes.FirstOrDefault(p => p.Id == id) : null;

    public void Reload()
    {
        IReadOnlyList<InstalledPlugin> installed;
        try
        {
            installed = _store.LoadAll();
        }
        catch (Exception ex)
        {
            Log.Error("Load plugins", ex);
            installed = Array.Empty<InstalledPlugin>();
        }
        All = _builtIn.Concat(installed.Where(p => !IsBuiltIn(p.Id))).ToList();
        foreach (var broken in All.Where(p => !p.IsUsable)) Log.Info($"Plugin {broken.Id} can't be used: {broken.Error}");
        Changed?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>
    /// Installs or updates a plugin file. A new theme becomes the active theme and a new code plugin is turned on.
    /// An update keeps the plugin ticked or unticked as it was. Throws <see cref="PluginException"/>.
    /// </summary>
    public (InstalledPlugin Plugin, bool Updated) Install(string path)
    {
        var id = Peek(path).Id;
        CheckNotBuiltIn(id);
        // Replacing a plugin made for DayBoard 1.2 counts as adding it: it was unusable until now.
        bool updated = All.Any(p => p.Id == id && !p.IsOutdated);
        var plugin = _store.Install(path);
        if (!updated)
        {
            if (plugin.Theme is not null) _settings.Update(s => s.ThemePluginId = plugin.Id);
            if (plugin.IsCode) _settings.Update(s => SetEnabled(s, plugin.Id, true));
        }
        Reload();
        return (plugin, updated);
    }

    /// <summary>A file can't stand in for a plugin that comes with DayBoard.</summary>
    public void CheckNotBuiltIn(string id)
    {
        if (_builtIn.FirstOrDefault(p => p.Id == id) is { } b)
            throw new PluginException($"{b.Name} comes with DayBoard, so it can't be added from a file. Tick it in the list to use it.");
    }

    /// <summary>Reads a plugin file's manifest without installing it. Throws <see cref="PluginException"/>.</summary>
    public static PluginManifest Peek(string path) => PluginFormat.ReadPackage(path, AppVersion).Manifest;

    /// <summary>Deletes an installed plugin. Not offered in Settings; used by the self-test to clean up.</summary>
    public void Remove(string id)
    {
        if (IsBuiltIn(id)) throw new ArgumentException("Plugins that come with DayBoard can't be removed.", nameof(id));
        _store.Remove(id);
        _settings.Update(s =>
        {
            if (s.ThemePluginId == id) s.ThemePluginId = null;
            SetEnabled(s, id, false);
        });
        Reload();
    }

    /// <summary>Ticks or unticks a code plugin.</summary>
    public static void SetEnabled(AppSettings s, string id, bool on)
    {
        s.EnabledPlugins.RemoveAll(x => x == id);
        if (on) s.EnabledPlugins.Add(id);
    }
}
