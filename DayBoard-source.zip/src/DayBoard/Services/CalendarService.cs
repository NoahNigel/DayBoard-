using System.IO;
using System.Net;
using System.Net.Http;
using System.Windows.Threading;
using DayBoard.Core.Calendar;
using DayBoard.Core.Models;
using DayBoard.Data;

namespace DayBoard.Services;

public sealed record CalendarEventView(Guid SubscriptionId, string CalendarName, string Color, CalendarOccurrence Occurrence);

/// <summary>
/// Read-only iCal subscriptions (e.g. Google/Outlook secret addresses). Feeds are cached on disk so they
/// show offline, and refreshed on a timer. URLs are never logged.
/// </summary>
public sealed class CalendarService : IDisposable
{
    private readonly SettingsService _settings;
    private readonly HttpClient _http;
    private readonly DispatcherTimer _timer;
    private readonly Dictionary<Guid, IcsCalendar> _parsed = new();
    private readonly Dictionary<(DateOnly, DateOnly), List<CalendarEventView>> _cache = new();
    private bool _refreshing;

    public CalendarService(SettingsService settings)
    {
        _settings = settings;
        _http = new HttpClient(new SocketsHttpHandler
        {
            AutomaticDecompression = DecompressionMethods.All,
            PooledConnectionLifetime = TimeSpan.FromMinutes(10),
        })
        {
            Timeout = TimeSpan.FromSeconds(30),
        };
        _http.DefaultRequestHeaders.UserAgent.ParseAdd("DayBoard/1.0");
        _timer = new DispatcherTimer();
        _timer.Tick += async (_, _) => await RefreshAllAsync();
    }

    public event EventHandler? Changed;

    public bool IsRefreshing => _refreshing;

    public void Start()
    {
        foreach (var sub in _settings.Current.Calendars) LoadCache(sub);
        ResetTimer();
        _ = RefreshAllAsync();
    }

    public void ResetTimer()
    {
        _timer.Stop();
        _timer.Interval = TimeSpan.FromMinutes(Math.Clamp(_settings.Current.CalendarRefreshMinutes, 5, 24 * 60));
        _timer.Start();
    }

    private static string CachePath(CalendarSubscription sub) => Path.Combine(AppPaths.CalendarCacheDir, sub.Id.ToString("N") + ".ics");

    private void LoadCache(CalendarSubscription sub)
    {
        try
        {
            var path = CachePath(sub);
            if (File.Exists(path)) _parsed[sub.Id] = IcsCalendar.Parse(File.ReadAllText(path));
        }
        catch (Exception ex)
        {
            Log.Error($"Load cached calendar '{sub.Name}'", ex);
        }
    }

    public async Task RefreshAllAsync()
    {
        if (_refreshing) return;
        _refreshing = true;
        try
        {
            foreach (var sub in _settings.Current.Calendars.Where(c => c.Enabled).ToList())
                await RefreshOneAsync(sub, notify: false);
        }
        finally
        {
            _refreshing = false;
            _settings.Save(notify: false);
            Invalidate();
        }
    }

    public async Task<bool> RefreshAsync(CalendarSubscription sub)
    {
        var ok = await RefreshOneAsync(sub, notify: true);
        _settings.Save(notify: false);
        return ok;
    }

    private async Task<bool> RefreshOneAsync(CalendarSubscription sub, bool notify)
    {
        var url = NormalizeUrl(sub.Url);
        if (url is null)
        {
            sub.LastError = "Enter an https:// or webcal:// address.";
            return false;
        }
        try
        {
            var text = await _http.GetStringAsync(url);
            if (!text.Contains("BEGIN:VCALENDAR", StringComparison.OrdinalIgnoreCase))
                throw new InvalidDataException("The address didn't return an iCal (.ics) calendar.");
            var cal = IcsCalendar.Parse(text);
            _parsed[sub.Id] = cal;
            Directory.CreateDirectory(AppPaths.CalendarCacheDir);
            await File.WriteAllTextAsync(CachePath(sub), text);
            if (sub.Name is "" or "Calendar" && !string.IsNullOrWhiteSpace(cal.Name)) sub.Name = cal.Name!;
            sub.LastRefreshed = DateTime.Now;
            sub.LastError = null;
            if (notify) Invalidate();
            return true;
        }
        catch (Exception ex) when (ex is HttpRequestException or TaskCanceledException or InvalidDataException or IOException or UriFormatException)
        {
            sub.LastError = ex is TaskCanceledException ? "Timed out." : ex.Message;
            Log.Info($"Calendar '{sub.Name}' refresh failed: {ex.GetType().Name}");
            if (notify) Invalidate();
            return false;
        }
    }

    public static Uri? NormalizeUrl(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;
        var s = raw.Trim();
        if (s.StartsWith("webcal://", StringComparison.OrdinalIgnoreCase)) s = "https://" + s[9..];
        if (s.StartsWith("webcals://", StringComparison.OrdinalIgnoreCase)) s = "https://" + s[10..];
        return Uri.TryCreate(s, UriKind.Absolute, out var u) && (u.Scheme == Uri.UriSchemeHttps || u.Scheme == Uri.UriSchemeHttp) ? u : null;
    }

    public void Remove(CalendarSubscription sub)
    {
        _parsed.Remove(sub.Id);
        try
        {
            File.Delete(CachePath(sub));
        }
        catch (IOException)
        {
        }
        Invalidate();
    }

    /// <summary>Loads a feed from text without fetching it (self-test).</summary>
    public void LoadForTest(CalendarSubscription sub, string icsText)
    {
        _parsed[sub.Id] = IcsCalendar.Parse(icsText);
        sub.LastRefreshed = DateTime.Now;
        Invalidate();
    }

    public void Invalidate()
    {
        _cache.Clear();
        Changed?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>Event instances from enabled calendars that overlap the given dates.</summary>
    public IReadOnlyList<CalendarEventView> EventsBetween(DateOnly from, DateOnly toInclusive)
    {
        if (_cache.TryGetValue((from, toInclusive), out var cached)) return cached;
        var list = new List<CalendarEventView>();
        var start = from.ToDateTime(TimeOnly.MinValue);
        var end = toInclusive.AddDays(1).ToDateTime(TimeOnly.MinValue);
        foreach (var sub in _settings.Current.Calendars.Where(c => c.Enabled))
        {
            if (!_parsed.TryGetValue(sub.Id, out var cal)) continue;
            try
            {
                foreach (var o in CalendarExpander.Expand(cal, start, end))
                    list.Add(new CalendarEventView(sub.Id, sub.Name, sub.Color, o));
            }
            catch (Exception ex)
            {
                Log.Error($"Expand calendar '{sub.Name}'", ex);
            }
        }
        list.Sort((a, b) => a.Occurrence.Start.CompareTo(b.Occurrence.Start));
        if (_cache.Count > 64) _cache.Clear();
        _cache[(from, toInclusive)] = list;
        return list;
    }

    public void Dispose()
    {
        _timer.Stop();
        _http.Dispose();
    }
}
