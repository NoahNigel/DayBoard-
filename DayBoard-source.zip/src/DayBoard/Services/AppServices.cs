using DayBoard.Core.Planning;
using DayBoard.Data;
using DayBoard.Infrastructure;

namespace DayBoard.Services;

/// <summary>Application-wide services, created once at startup.</summary>
public sealed class AppServices
{
    public static AppServices Current { get; set; } = null!;

    public required SqliteRepository Repository { get; init; }
    public required Planner Planner { get; init; }
    public required SettingsService Settings { get; init; }
    public required PluginService Plugins { get; init; }
    public required CalendarService Calendars { get; init; }
    public required WindowService Windows { get; init; }
    public required GlobalHotkey Hotkey { get; init; }
    public TrayService? Tray { get; set; }

    /// <summary>Runs the ticked code plugins. Created once the main view model exists.</summary>
    public Hosting.PluginRunner Runner { get; set; } = null!;
    public ViewModels.MainViewModel Main { get; set; } = null!;
}
