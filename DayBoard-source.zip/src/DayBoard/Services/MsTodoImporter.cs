using System.Globalization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text.Json;
using System.Text.RegularExpressions;
using DayBoard.Core.Models;
using DayBoard.Core.Store;
using Microsoft.Identity.Client;

namespace DayBoard.Services;

public sealed record TodoListInfo(string Id, string Name, int OpenCount);

public sealed class TodoImportOptions
{
    public bool IncludeCompleted { get; set; }
    public bool ScheduleOnDueDate { get; set; }
}

/// <summary>
/// Imports Microsoft To Do lists through Microsoft Graph. The user supplies their own Azure app registration
/// (public client, "Mobile and desktop" platform with redirect URI http://localhost, delegated Tasks.Read permission).
/// Sign-in uses the system browser via MSAL; no embedded web view.
/// </summary>
public sealed partial class MsTodoImporter : IDisposable
{
    private static readonly string[] Scopes = { "Tasks.Read" };
    private const string Graph = "https://graph.microsoft.com/v1.0";
    private readonly HttpClient _http = new() { Timeout = TimeSpan.FromSeconds(60) };
    private IPublicClientApplication? _app;
    private string? _token;

    public string? AccountName { get; private set; }

    public async Task SignInAsync(string clientId, string tenant, IntPtr ownerWindow, CancellationToken ct)
    {
        if (!Guid.TryParse(clientId.Trim(), out _))
            throw new InvalidOperationException("The client ID must be the Application (client) ID GUID from your Azure app registration.");
        tenant = string.IsNullOrWhiteSpace(tenant) ? "common" : tenant.Trim();

        _app = PublicClientApplicationBuilder.Create(clientId.Trim())
            .WithAuthority(AzureCloudInstance.AzurePublic, tenant)
            .WithRedirectUri("http://localhost")
            .Build();

        AuthenticationResult result;
        var accounts = await _app.GetAccountsAsync();
        try
        {
            result = await _app.AcquireTokenSilent(Scopes, accounts.FirstOrDefault()).ExecuteAsync(ct);
        }
        catch (MsalUiRequiredException)
        {
            result = await _app.AcquireTokenInteractive(Scopes)
                .WithUseEmbeddedWebView(false)
                .WithParentActivityOrWindow(ownerWindow)
                .WithPrompt(Prompt.SelectAccount)
                .ExecuteAsync(ct);
        }
        _token = result.AccessToken;
        AccountName = result.Account?.Username;
    }

    public async Task<List<TodoListInfo>> GetListsAsync(CancellationToken ct)
    {
        var lists = new List<TodoListInfo>();
        await foreach (var item in Pages($"{Graph}/me/todo/lists", ct))
        {
            var id = item.GetProperty("id").GetString()!;
            var name = item.TryGetProperty("displayName", out var dn) ? dn.GetString() ?? "List" : "List";
            int open = 0;
            await foreach (var t in Pages($"{Graph}/me/todo/lists/{Uri.EscapeDataString(id)}/tasks?$top=100&$select=status&$filter=status ne 'completed'", ct))
                open++;
            lists.Add(new TodoListInfo(id, name, open));
        }
        return lists;
    }

    /// <summary>Builds the data to import. Tasks already imported earlier (same To Do id) are skipped.</summary>
    public async Task<PlannerData> BuildImportAsync(IEnumerable<TodoListInfo> lists, TodoImportOptions options,
        IReadOnlyCollection<TaskItem> existing, IReadOnlyList<Category> categories, CancellationToken ct)
    {
        var seen = existing.Where(t => t.ExternalId is not null).Select(t => t.ExternalId!).ToHashSet(StringComparer.Ordinal);
        var data = new PlannerData();
        var palette = new[] { "#3B82F6", "#10B981", "#8B5CF6", "#F59E0B", "#EC4899", "#14B8A6", "#64748B" };
        int colorIndex = 0;

        foreach (var list in lists)
        {
            var cat = categories.FirstOrDefault(c => string.Equals(c.Name, list.Name, StringComparison.OrdinalIgnoreCase))?.Clone()
                      ?? new Category { Name = list.Name, Color = palette[colorIndex++ % palette.Length], Icon = "TaskListLtr24" };
            bool catUsed = false;

            await foreach (var item in Pages($"{Graph}/me/todo/lists/{Uri.EscapeDataString(list.Id)}/tasks?$top=100&$expand=checklistItems", ct))
            {
                var id = item.GetProperty("id").GetString()!;
                var externalId = "mstodo:" + id;
                if (seen.Contains(externalId)) continue;

                var status = Str(item, "status");
                bool completed = status == "completed";
                if (completed && !options.IncludeCompleted) continue;

                var task = new TaskItem
                {
                    Title = Str(item, "title") ?? "(untitled)",
                    ExternalId = externalId,
                    CategoryId = cat.Id,
                    Priority = Str(item, "importance") switch { "high" => Priority.High, "low" => Priority.Low, _ => Priority.None },
                    Status = completed ? TaskState.Done : status == "inProgress" ? TaskState.Doing : TaskState.ToDo,
                    CreatedAt = ParseGraphDate(item, "createdDateTime") ?? DateTime.Now,
                    UpdatedAt = DateTime.Now,
                };
                if (item.TryGetProperty("body", out var body) && body.ValueKind == JsonValueKind.Object)
                {
                    var content = Str(body, "content") ?? "";
                    if (string.Equals(Str(body, "contentType"), "html", StringComparison.OrdinalIgnoreCase)) content = StripHtml(content);
                    task.Notes = content.Trim();
                }
                if (ParseGraphDate(item, "dueDateTime") is { } due)
                {
                    task.DueDate = DateOnly.FromDateTime(due);
                    if (options.ScheduleOnDueDate) task.ScheduledDate = task.DueDate;
                }
                if (completed) task.CompletedAt = ParseGraphDate(item, "completedDateTime") ?? DateTime.Now;
                if (item.TryGetProperty("checklistItems", out var checklist) && checklist.ValueKind == JsonValueKind.Array)
                {
                    foreach (var c in checklist.EnumerateArray())
                    {
                        task.Subtasks.Add(new Subtask
                        {
                            Title = Str(c, "displayName") ?? "",
                            IsDone = c.TryGetProperty("isChecked", out var ic) && ic.ValueKind == JsonValueKind.True,
                        });
                    }
                }
                data.Tasks.Add(task);
                catUsed = true;
            }

            if (catUsed) data.Categories.Add(cat);
        }

        // Keep the To Do order: newest first in To Do, so reverse into ascending sort order.
        double order = 1024;
        foreach (var t in data.Tasks.OrderBy(t => t.CreatedAt)) t.SortOrder = order += 1024;
        return data;
    }

    private async IAsyncEnumerable<JsonElement> Pages(string url, [System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct)
    {
        if (_token is null) throw new InvalidOperationException("Sign in first.");
        string? next = url;
        while (next is not null)
        {
            using var req = new HttpRequestMessage(HttpMethod.Get, next);
            req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", _token);
            using var resp = await _http.SendAsync(req, ct);
            var json = await resp.Content.ReadAsStringAsync(ct);
            if (!resp.IsSuccessStatusCode)
                throw new HttpRequestException($"Microsoft Graph returned {(int)resp.StatusCode}: {GraphError(json)}");
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("value", out var value))
            {
                foreach (var item in value.EnumerateArray()) yield return item.Clone();
            }
            next = doc.RootElement.TryGetProperty("@odata.nextLink", out var nl) ? nl.GetString() : null;
        }
    }

    private static string GraphError(string json)
    {
        try
        {
            using var doc = JsonDocument.Parse(json);
            if (doc.RootElement.TryGetProperty("error", out var e) && e.TryGetProperty("message", out var m)) return m.GetString() ?? json;
        }
        catch (JsonException)
        {
        }
        return json.Length > 200 ? json[..200] : json;
    }

    private static string? Str(JsonElement e, string name) =>
        e.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String ? v.GetString() : null;

    private static DateTime? ParseGraphDate(JsonElement e, string name)
    {
        if (!e.TryGetProperty(name, out var v)) return null;
        string? s = v.ValueKind switch
        {
            JsonValueKind.String => v.GetString(),
            JsonValueKind.Object => Str(v, "dateTime"),
            _ => null,
        };
        if (s is null) return null;
        return DateTime.TryParse(s, CultureInfo.InvariantCulture, DateTimeStyles.AdjustToUniversal | DateTimeStyles.AssumeUniversal, out var d)
            ? (v.ValueKind == JsonValueKind.Object ? d : d.ToLocalTime())
            : null;
    }

    [GeneratedRegex("<[^>]+>")]
    private static partial Regex TagRegex();

    private static string StripHtml(string html)
    {
        var text = html.Replace("<br>", "\n", StringComparison.OrdinalIgnoreCase).Replace("</p>", "\n", StringComparison.OrdinalIgnoreCase);
        text = TagRegex().Replace(text, "");
        return System.Net.WebUtility.HtmlDecode(text);
    }

    public void Dispose() => _http.Dispose();
}
