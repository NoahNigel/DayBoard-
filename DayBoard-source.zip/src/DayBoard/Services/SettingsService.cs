using DayBoard.Core.Models;
using DayBoard.Data;

namespace DayBoard.Services;

public sealed class SettingsService
{
    private readonly SettingsStore _store;

    public SettingsService(SettingsStore store)
    {
        _store = store;
        Current = store.Load();
    }

    public AppSettings Current { get; }

    public event EventHandler? Changed;

    public void Save(bool notify = true)
    {
        try
        {
            _store.Save(Current);
        }
        catch (Exception ex)
        {
            Log.Error("Save settings", ex);
        }
        if (notify) Changed?.Invoke(this, EventArgs.Empty);
    }

    public void Update(Action<AppSettings> change, bool notify = true)
    {
        change(Current);
        Save(notify);
    }
}
