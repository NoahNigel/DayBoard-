using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Input;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Calendar;
using DayBoard.Core.Export;
using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Infrastructure;
using DayBoard.Services;
using Microsoft.Win32;
using Wpf.Ui.Controls;
using ThemeMode = DayBoard.Core.Models.ThemeMode;

namespace DayBoard.ViewModels;

public sealed partial class CategoryEditItem : ObservableObject
{
    private readonly SettingsViewModel _owner;
    private bool _loading = true;
    private string _savedName;

    public CategoryEditItem(Category c, SettingsViewModel owner)
    {
        _owner = owner;
        Id = c.Id;
        SortOrder = c.SortOrder;
        _name = c.Name;
        _savedName = c.Name;
        _color = c.Color;
        _icon = c.Icon;
        _loading = false;
    }

    /// <summary>Updates from the store (e.g. after undo) without overwriting a name that is being typed.</summary>
    public void Sync(Category c)
    {
        _loading = true;
        if (Name == _savedName) Name = c.Name;
        _savedName = c.Name;
        Color = c.Color;
        Icon = c.Icon;
        _loading = false;
    }

    public Guid Id { get; }
    public int SortOrder { get; }
    [ObservableProperty] private string _name;
    [ObservableProperty] private string _color;
    [ObservableProperty] private string _icon;

    public System.Windows.Media.Brush Brush => ColorUtil.Brush(Color);
    public SymbolRegular Symbol => Symbols.Parse(Icon);

    /// <summary>The theme changed, so the same stored colour may now be shown differently.</summary>
    public void RefreshBrush() => OnPropertyChanged(nameof(Brush));

    partial void OnColorChanged(string value)
    {
        OnPropertyChanged(nameof(Brush));
        Commit();
    }

    partial void OnIconChanged(string value)
    {
        OnPropertyChanged(nameof(Symbol));
        // A combo box can briefly push null while its list loads; never save that.
        if (!string.IsNullOrWhiteSpace(value)) Commit();
    }

    /// <summary>Saves the category (name is committed when the text box loses focus).</summary>
    public void Commit()
    {
        if (_loading || string.IsNullOrWhiteSpace(Name) || string.IsNullOrWhiteSpace(Icon) || string.IsNullOrWhiteSpace(Color)) return;
        _savedName = Name;
        _owner.SaveCategory(this);
    }

    public Category ToCategory() => new() { Id = Id, Name = Name.Trim(), Color = Color, Icon = Icon, SortOrder = SortOrder };
}

public sealed partial class CalendarSubItem : ObservableObject
{
    public CalendarSubItem(CalendarSubscription sub) => Sub = sub;

    public CalendarSubscription Sub { get; }
    public string Name => Sub.Name;
    public string Color => Sub.Color;
    public System.Windows.Media.Brush Brush => ColorUtil.Brush(Sub.Color);
    public string MaskedUrl
    {
        get
        {
            var u = CalendarService.NormalizeUrl(Sub.Url);
            return u is null ? Sub.Url : $"{u.Scheme}://{u.Host}/…";
        }
    }

    public bool Enabled
    {
        get => Sub.Enabled;
        set
        {
            if (Sub.Enabled == value) return;
            Sub.Enabled = value;
            OnPropertyChanged();
            AppServices.Current.Settings.Save();
            AppServices.Current.Calendars.Invalidate();
        }
    }

    public string Status => Sub.LastError is { } e ? "Couldn't refresh: " + e
        : Sub.LastRefreshed is { } r ? "Updated " + r.ToString("g", CultureInfo.CurrentCulture) : "Not refreshed yet";

    public bool HasError => Sub.LastError is not null;

    public void Notify()
    {
        OnPropertyChanged(nameof(Status));
        OnPropertyChanged(nameof(HasError));
        OnPropertyChanged(nameof(Name));
    }
}

/// <summary>One row of the plugin checklist in Settings. Ticked means the plugin is in use.</summary>
public sealed partial class PluginItem : ObservableObject
{
    private readonly SettingsViewModel _owner;
    private bool _isOn;

    public PluginItem(InstalledPlugin plugin, bool isOn, SettingsViewModel owner)
    {
        _owner = owner;
        Plugin = plugin;
        _isOn = isOn;
    }

    public InstalledPlugin Plugin { get; }
    public string Id => Plugin.Id;
    public string Name => Plugin.Name;
    public string VersionText => Plugin.IsBuiltIn ? "" : Plugin.Manifest?.Version is { } v ? "v" + v : "";
    public bool IsUsable => Plugin.IsUsable;

    /// <summary>Code plugins added from a file are marked, as they run their own code.</summary>
    public bool IsCode => Plugin.IsCode && !Plugin.IsBuiltIn;

    /// <summary>Comes with DayBoard.</summary>
    public bool IsBuiltIn => Plugin.IsBuiltIn;

    /// <summary>Why the plugin can't be used or isn't running, or null when all is well.</summary>
    public string? Message
    {
        get
        {
            if (Plugin.Error is { } e) return Plugin.IsOutdated ? e : "Can't be used: " + e;
            if (!Plugin.IsCode) return null;
            var runner = AppServices.Current.Runner;
            if (runner.ErrorFor(Id) is { } error) return error;
            return IsOn && runner.SafeMode && !Plugin.IsBuiltIn ? "Not running: DayBoard was started in safe mode." : null;
        }
    }

    public bool HasMessage => Message is not null;

    public bool IsOn
    {
        get => _isOn;
        set
        {
            if (_isOn == value) return;
            _isOn = value;
            OnPropertyChanged();
            _owner.SetPluginOn(this, value);
        }
    }

    /// <summary>Updates the tick without acting on it (another theme was turned on, or the list was refreshed).</summary>
    public void Sync(bool isOn)
    {
        OnPropertyChanged(nameof(Message));
        OnPropertyChanged(nameof(HasMessage));
        if (_isOn == isOn) return;
        _isOn = isOn;
        OnPropertyChanged(nameof(IsOn));
    }
}

public sealed partial class SettingsViewModel : ObservableObject, IPage
{
    private bool _loading;

    public SettingsViewModel()
    {
        Load();
        ThemeService.Changed += (_, _) =>
        {
            foreach (var c in Categories) c.RefreshBrush();
            UpdatePriorityNote();
        };
    }

    private static AppServices S => AppServices.Current;
    private static AppSettings Cur => S.Settings.Current;

    public IReadOnlyList<ChoiceOption<DayOfWeek>> WeekStarts { get; } =
        DateUtilDays().Select(d => new ChoiceOption<DayOfWeek>(d, CultureInfo.CurrentCulture.DateTimeFormat.GetDayName(d))).ToList();

    public IReadOnlyList<int> Hours { get; } = Enumerable.Range(0, 25).ToList();
    public IReadOnlyList<string> Swatches => ColorUtil.Swatches;
    public IReadOnlyList<string> IconChoices => Symbols.CategoryIcons;
    public ObservableCollection<CategoryEditItem> Categories { get; } = new();
    public ObservableCollection<CalendarSubItem> Calendars { get; } = new();
    public ObservableCollection<FileInfo> Backups { get; } = new();
    public ObservableCollection<PluginItem> Plugins { get; } = new();

    private static IEnumerable<DayOfWeek> DateUtilDays() => new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday, DayOfWeek.Saturday, DayOfWeek.Sunday };

    // Appearance
    [ObservableProperty] private string _theme = "System";
    [ObservableProperty] private string _density = "Comfortable";
    [ObservableProperty] private string _priorityLowColor = "";
    [ObservableProperty] private string _priorityMediumColor = "";
    [ObservableProperty] private string _priorityHighColor = "";
    [ObservableProperty] private bool _showCompleted;
    [ObservableProperty] private bool _themeSetsPriority;
    [ObservableProperty] private string _themePriorityNote = "";

    // Plugins
    [ObservableProperty] private string? _pluginMessage;
    [ObservableProperty] private bool _pluginMessageIsError;

    // Planning
    [ObservableProperty] private ChoiceOption<DayOfWeek>? _weekStart;
    [ObservableProperty] private int _dayStartHour;
    [ObservableProperty] private int _dayEndHour;
    [ObservableProperty] private string _capacityHours = "";
    [ObservableProperty] private string _defaultEstimate = "";
    [ObservableProperty] private string _rolloverMode = "MoveToToday";

    // Windows
    [ObservableProperty] private bool _hotkeyEnabled;
    [ObservableProperty] private string _hotkeyText = "";
    [ObservableProperty] private string _hotkeyStatus = "";
    [ObservableProperty] private bool _hotkeyOk;
    [ObservableProperty] private bool _closeToTray;
    [ObservableProperty] private bool _startWithWindows;
    [ObservableProperty] private bool _startMenuShortcut;
    [ObservableProperty] private bool _startMinimized;


    // Calendars
    [ObservableProperty] private string _newCalendarName = "";
    [ObservableProperty] private string _newCalendarUrl = "";
    [ObservableProperty] private string _calendarRefreshMinutes = "";
    [ObservableProperty] private string? _calendarMessage;

    // Data
    [ObservableProperty] private DateTime? _icsFrom;
    [ObservableProperty] private DateTime? _icsTo;
    [ObservableProperty] private FileInfo? _selectedBackup;
    [ObservableProperty] private string? _dataMessage;

    // Microsoft To Do
    [ObservableProperty] private string _msTodoClientId = "";
    [ObservableProperty] private string _msTodoTenant = "";

    public string DataFolder => AppPaths.DataDir;
    public bool RunningFromZip => Infrastructure.StartMenuShortcut.RunningFromTemporaryFolder;
    public string VersionText => "DayBoard " + (typeof(SettingsViewModel).Assembly.GetName().Version?.ToString(3) ?? "1.0.0");

    public void Refresh()
    {
        LoadPlugins();
        LoadCategories();
        SyncCalendars();
        LoadBackups();
        UpdateHotkeyStatus();
    }

    private void SyncCalendars()
    {
        var subs = Cur.Calendars;
        for (int i = Calendars.Count - 1; i >= 0; i--)
        {
            if (!subs.Contains(Calendars[i].Sub)) Calendars.RemoveAt(i);
        }
        foreach (var sub in subs)
        {
            if (Calendars.All(c => !ReferenceEquals(c.Sub, sub))) Calendars.Add(new CalendarSubItem(sub));
        }
        foreach (var c in Calendars) c.Notify();
    }

    private void Load()
    {
        _loading = true;
        var c = Cur;
        Theme = c.Theme.ToString();
        Density = c.Density.ToString();
        PriorityLowColor = c.PriorityLowColor;
        PriorityMediumColor = c.PriorityMediumColor;
        PriorityHighColor = c.PriorityHighColor;
        ShowCompleted = c.ShowCompletedTasks;
        WeekStart = WeekStarts.First(w => w.Value == c.WeekStart);
        DayStartHour = c.DayStartHour;
        DayEndHour = c.DayEndHour;
        CapacityHours = c.CapacityHours.ToString("0.##", CultureInfo.CurrentCulture);
        DefaultEstimate = c.DefaultEstimateMinutes.ToString(CultureInfo.CurrentCulture);
        RolloverMode = c.RolloverMode.ToString();
        HotkeyEnabled = c.HotkeyEnabled;
        HotkeyText = GlobalHotkey.TryParse(c.HotkeyModifiers, c.HotkeyKey, out var m, out var k) ? GlobalHotkey.Format(m, k) : "Ctrl+Alt+Space";
        CloseToTray = c.CloseToTray;
        StartWithWindows = c.StartWithWindows;
        StartMenuShortcut = c.StartMenuShortcut;
        StartMinimized = c.StartMinimized;
        CalendarRefreshMinutes = c.CalendarRefreshMinutes.ToString(CultureInfo.CurrentCulture);
        MsTodoClientId = c.MsTodoClientId;
        MsTodoTenant = c.MsTodoTenant;
        var today = DateTime.Today;
        IcsFrom = today.AddDays(-7);
        IcsTo = today.AddDays(60);
        Calendars.Clear();
        foreach (var sub in c.Calendars) Calendars.Add(new CalendarSubItem(sub));
        _loading = false;
        LoadPlugins();
        LoadCategories();
        LoadBackups();
        UpdateHotkeyStatus();
    }

    private void Save(Action<AppSettings> change, bool reapplyTheme = false)
    {
        if (_loading) return;
        S.Settings.Update(change);
        if (reapplyTheme) ThemeService.Apply(Cur, Application.Current.MainWindow);
    }

    private static int Int(string s, int fallback, int min, int max) =>
        int.TryParse(s, NumberStyles.Integer, CultureInfo.CurrentCulture, out var v) ? Math.Clamp(v, min, max) : fallback;

    partial void OnThemeChanged(string value) => Save(s => s.Theme = Enum.Parse<ThemeMode>(value), reapplyTheme: true);
    partial void OnDensityChanged(string value) => Save(s => s.Density = Enum.Parse<Core.Models.Density>(value), reapplyTheme: true);
    partial void OnPriorityLowColorChanged(string value) { if (ColorUtil.Parse(value) is not null) Save(s => s.PriorityLowColor = value.Trim(), true); }
    partial void OnPriorityMediumColorChanged(string value) { if (ColorUtil.Parse(value) is not null) Save(s => s.PriorityMediumColor = value.Trim(), true); }
    partial void OnPriorityHighColorChanged(string value) { if (ColorUtil.Parse(value) is not null) Save(s => s.PriorityHighColor = value.Trim(), true); }
    partial void OnShowCompletedChanged(bool value) => Save(s => s.ShowCompletedTasks = value);
    partial void OnWeekStartChanged(ChoiceOption<DayOfWeek>? value) { if (value is not null) Save(s => s.WeekStart = value.Value); }
    partial void OnDayStartHourChanged(int value) => Save(s => { s.DayStartHour = Math.Clamp(value, 0, 23); if (s.DayEndHour <= s.DayStartHour) s.DayEndHour = Math.Min(24, s.DayStartHour + 1); });
    partial void OnDayEndHourChanged(int value) => Save(s => { s.DayEndHour = Math.Clamp(value, 1, 24); if (s.DayStartHour >= s.DayEndHour) s.DayStartHour = Math.Max(0, s.DayEndHour - 1); });
    partial void OnCapacityHoursChanged(string value)
    {
        if (double.TryParse(value, NumberStyles.Float, CultureInfo.CurrentCulture, out var h) && h >= 0 && h <= 24) Save(s => s.CapacityHours = h);
    }
    partial void OnDefaultEstimateChanged(string value) => Save(s => s.DefaultEstimateMinutes = Int(value, s.DefaultEstimateMinutes, 5, 480));
    partial void OnRolloverModeChanged(string value) => Save(s => s.RolloverMode = Enum.Parse<Core.Models.RolloverMode>(value));
    partial void OnCloseToTrayChanged(bool value) => Save(s => s.CloseToTray = value);
    partial void OnStartWithWindowsChanged(bool value)
    {
        if (_loading) return;
        StartupRegistration.Set(value);
        Save(s => s.StartWithWindows = value);
    }
    partial void OnStartMinimizedChanged(bool value) => Save(s => s.StartMinimized = value);
    partial void OnStartMenuShortcutChanged(bool value)
    {
        if (_loading) return;
        Save(s => s.StartMenuShortcut = value);
        if (value) Infrastructure.StartMenuShortcut.Ensure();
        else Infrastructure.StartMenuShortcut.Remove();
    }
    partial void OnHotkeyEnabledChanged(bool value)
    {
        Save(s => s.HotkeyEnabled = value);
        if (!_loading) S.Main.ApplyHotkey(showErrors: false);
        UpdateHotkeyStatus();
    }
    partial void OnCalendarRefreshMinutesChanged(string value)
    {
        Save(s => s.CalendarRefreshMinutes = Int(value, s.CalendarRefreshMinutes, 5, 1440));
        if (!_loading) S.Calendars.ResetTimer();
    }
    partial void OnMsTodoClientIdChanged(string value) => Save(s => s.MsTodoClientId = value.Trim());
    partial void OnMsTodoTenantChanged(string value) => Save(s => s.MsTodoTenant = string.IsNullOrWhiteSpace(value) ? "common" : value.Trim());

    [RelayCommand]
    private void SetPriorityColor(string? arg)
    {
        // arg: "High|#E5484D"
        var parts = (arg ?? "").Split('|');
        if (parts.Length != 2) return;
        switch (parts[0])
        {
            case "Low": PriorityLowColor = parts[1]; break;
            case "Medium": PriorityMediumColor = parts[1]; break;
            case "High": PriorityHighColor = parts[1]; break;
        }
    }

    [RelayCommand]
    private void ResetPriorityColors()
    {
        var d = new AppSettings();
        PriorityLowColor = d.PriorityLowColor;
        PriorityMediumColor = d.PriorityMediumColor;
        PriorityHighColor = d.PriorityHighColor;
    }

    // ---------------------------------------------------------------- hotkey

    /// <summary>Called by the hotkey box with the keys the user pressed.</summary>
    public void CaptureHotkey(ModifierKeys mods, Key key)
    {
        if (key is Key.LeftCtrl or Key.RightCtrl or Key.LeftAlt or Key.RightAlt or Key.LeftShift or Key.RightShift or Key.LWin or Key.RWin or Key.System)
            return;
        HotkeyText = GlobalHotkey.Format(mods, key);
        if (mods == ModifierKeys.None)
        {
            HotkeyStatus = "Add Ctrl, Alt, Shift or Win to the key.";
            HotkeyOk = false;
            return;
        }
        Save(s =>
        {
            s.HotkeyModifiers = mods.ToString();
            s.HotkeyKey = key.ToString();
            s.HotkeyEnabled = true;
        });
        _loading = true;
        HotkeyEnabled = true;
        _loading = false;
        S.Main.ApplyHotkey(showErrors: false);
        UpdateHotkeyStatus();
    }

    [RelayCommand]
    private void ResetHotkey() => CaptureHotkey(ModifierKeys.Control | ModifierKeys.Alt, Key.Space);

    private void UpdateHotkeyStatus()
    {
        var hk = S.Hotkey;
        if (!Cur.HotkeyEnabled)
        {
            HotkeyStatus = "Global shortcut is off.";
            HotkeyOk = false;
        }
        else if (hk.IsRegistered)
        {
            HotkeyStatus = $"{hk.Display} opens quick add from anywhere.";
            HotkeyOk = true;
        }
        else
        {
            HotkeyStatus = (hk.LastError ?? "Shortcut not registered.") + " Click the box and press a different combination.";
            HotkeyOk = false;
        }
    }

    // ---------------------------------------------------------------- plugins

    private void LoadPlugins()
    {
        var all = S.Plugins.All;
        if (!Plugins.Select(p => p.Plugin).SequenceEqual(all))
        {
            Plugins.Clear();
            foreach (var p in all) Plugins.Add(new PluginItem(p, S.Plugins.IsOn(p, Cur), this));
        }
        else
        {
            foreach (var item in Plugins) item.Sync(S.Plugins.IsOn(item.Plugin, Cur));
        }
        UpdatePriorityNote();
    }

    /// <summary>Ticking a theme makes it the colour theme (only one can be on); unticking goes back to DayBoard's own colours.</summary>
    public void SetPluginOn(PluginItem item, bool on)
    {
        if (item.Plugin.IsCode)
        {
            S.Settings.Update(s => S.Plugins.SetOn(s, item.Id, on));
            S.Runner.Sync();
            LoadPlugins();
            if (!on) ShowPluginMessage($"Turned off {item.Name}. Anything it saved is kept for when you tick it again.");
            else ShowStartedMessage(item.Plugin, "Turned on");
            return;
        }
        if (item.Plugin.Theme is null) return;
        S.Settings.Update(s =>
        {
            if (on) s.ThemePluginId = item.Id;
            else if (s.ThemePluginId == item.Id) s.ThemePluginId = null;
        });
        AfterPluginChange();
        ShowPluginMessage(on ? $"Using {item.Name}." : $"Turned off {item.Name}. You're back to DayBoard's own colours.");
    }

    private void UpdatePriorityNote()
    {
        ThemeSetsPriority = ThemeService.ThemeSetsPriorityColors(Cur);
        ThemePriorityNote = ThemeSetsPriority && ThemeService.ActiveTheme is { } t
            ? $"{t.Name} picks these colours until you choose your own."
            : "";
    }

    private void AfterPluginChange()
    {
        ThemeService.Apply(Cur, Application.Current.MainWindow);
        LoadPlugins();
    }

    /// <summary>Says where a code plugin that was just turned on shows up, or why it isn't running.</summary>
    private void ShowStartedMessage(InstalledPlugin plugin, string verb)
    {
        var runner = S.Runner;
        if (runner.SafeMode && !plugin.IsBuiltIn)
        {
            ShowPluginMessage($"Ticked {plugin.Name}. It starts once DayBoard is restarted without safe mode.");
            return;
        }
        if (!runner.IsRunning(plugin.Id))
        {
            ShowPluginMessage($"{plugin.Name} couldn't start. {runner.ErrorFor(plugin.Id)}", error: true);
            return;
        }
        var (pages, panels, first) = runner.Contributions(plugin.Id);
        var where = pages > 0 && panels > 0 ? $" It added {first} to the sidebar and a panel to the top of the Day view."
            : pages > 0 ? $" It added {first} to the sidebar."
            : panels > 0 ? " It added a panel to the top of the Day view."
            : "";
        ShowPluginMessage(verb == "Added" ? $"Added {plugin.Name} and turned it on.{where}" : $"Turned on {plugin.Name}.{where}");
    }

    private void ShowPluginMessage(string text, bool error = false)
    {
        PluginMessage = text;
        PluginMessageIsError = error;
    }

    [RelayCommand]
    private void AddPlugin()
    {
        var dlg = new OpenFileDialog
        {
            Title = "Add DayBoard plugins",
            Filter = $"DayBoard plugins (*{PluginFormat.FileExtension})|*{PluginFormat.FileExtension}|All files (*.*)|*.*",
            Multiselect = true,
        };
        // The download has a Plugins folder next to DayBoard.exe, with the plugins that come with DayBoard.
        if (AppPaths.BundledPluginDir is { } bundled) dlg.InitialDirectory = bundled;
        if (dlg.ShowDialog(Application.Current.MainWindow) != true) return;
        foreach (var file in dlg.FileNames)
        {
            if (!InstallPluginFrom(file) && dlg.FileNames.Length > 1) break; // keep the error in view
        }
    }

    /// <summary>Asks before adding a code plugin. The self-test replaces it to answer the dialog itself.</summary>
    public Func<PluginManifest, bool> ConfirmCodePlugin { get; set; } = manifest =>
    {
        var by = string.IsNullOrWhiteSpace(manifest.Author) ? "" : " by " + manifest.Author;
        return S.Windows.Ask("Add a plugin that runs code?",
            $"{manifest.Name} {manifest.Version}{by} runs its own code inside DayBoard. Like any program you run, it can reach your files " +
            "and everything in DayBoard, so only add plugins from people you trust.",
            "Add plugin", "Cancel") == 0;
    };

    /// <summary>Adds a plugin file and reports the result in the Plugins section.</summary>
    public bool InstallPluginFrom(string path)
    {
        try
        {
            var manifest = PluginService.Peek(path);
            S.Plugins.CheckNotBuiltIn(manifest.Id);
            if (manifest.Kind == PluginKind.Code && !ConfirmCodePlugin(manifest))
            {
                ShowPluginMessage($"Didn't add {manifest.Name}.");
                return false;
            }
            var (plugin, updated) = S.Plugins.Install(path);
            S.Runner.Sync();
            AfterPluginChange();
            var version = plugin.Manifest?.Version ?? "";
            if (updated) ShowPluginMessage($"Updated {plugin.Name} to {version}.");
            else if (plugin.Theme is not null) ShowPluginMessage($"Added {plugin.Name} and turned it on. Untick it to go back to DayBoard's own colours.");
            else if (plugin.IsCode) ShowStartedMessage(plugin, "Added");
            else ShowPluginMessage($"Added {plugin.Name}.");
            return true;
        }
        catch (PluginException ex)
        {
            ShowPluginMessage("Couldn't add that plugin. " + ex.Message, error: true);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            Log.Error("Add plugin", ex);
            ShowPluginMessage("Couldn't add that plugin: " + ex.Message, error: true);
        }
        return false;
    }

    // ---------------------------------------------------------------- categories

    private void LoadCategories()
    {
        var cats = S.Planner.Store.Categories;
        if (Categories.Select(c => c.Id).SequenceEqual(cats.Select(c => c.Id)))
        {
            for (int i = 0; i < cats.Count; i++) Categories[i].Sync(cats[i]);
            return;
        }
        Categories.Clear();
        foreach (var c in cats) Categories.Add(new CategoryEditItem(c, this));
    }

    public void SaveCategory(CategoryEditItem item) => S.Planner.SaveCategory(item.ToCategory());

    [RelayCommand]
    private void AddCategory()
    {
        var used = S.Planner.Store.Categories.Select(c => c.Color).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var color = ColorUtil.Swatches.FirstOrDefault(c => !used.Contains(c)) ?? ColorUtil.Swatches[0];
        S.Planner.SaveCategory(new Category { Name = "New category", Color = color, Icon = "Tag24" });
        LoadCategories();
    }

    [RelayCommand]
    private void DeleteCategory(CategoryEditItem? item)
    {
        if (item is null) return;
        S.Planner.DeleteCategory(item.Id);
        LoadCategories();
        S.Main.ShowToast($"Deleted category \"{item.Name}\"", undo: true);
    }

    [RelayCommand]
    private void SetCategoryColor(object? arg)
    {
        if (arg is object[] { Length: 2 } pair && pair[0] is CategoryEditItem item && pair[1] is string color) item.Color = color;
    }

    // ---------------------------------------------------------------- calendars

    [RelayCommand]
    private async Task AddCalendar()
    {
        var url = CalendarService.NormalizeUrl(NewCalendarUrl);
        if (url is null)
        {
            CalendarMessage = "Paste the calendar's secret iCal address (https://… or webcal://…).";
            return;
        }
        var colors = ColorUtil.CalendarColors;
        var sub = new CalendarSubscription
        {
            Name = string.IsNullOrWhiteSpace(NewCalendarName) ? "Calendar" : NewCalendarName.Trim(),
            Url = NewCalendarUrl.Trim(),
            Color = colors[Cur.Calendars.Count % colors.Count],
        };
        Cur.Calendars.Add(sub);
        S.Settings.Save();
        var item = new CalendarSubItem(sub);
        Calendars.Add(item);
        NewCalendarName = "";
        NewCalendarUrl = "";
        CalendarMessage = "Fetching…";
        var ok = await S.Calendars.RefreshAsync(sub);
        item.Notify();
        CalendarMessage = ok ? $"Added \"{sub.Name}\"." : $"Added, but it couldn't be fetched: {sub.LastError}";
    }

    [RelayCommand]
    private void RemoveCalendar(CalendarSubItem? item)
    {
        if (item is null) return;
        Cur.Calendars.Remove(item.Sub);
        S.Settings.Save();
        S.Calendars.Remove(item.Sub);
        Calendars.Remove(item);
        CalendarMessage = $"Removed \"{item.Name}\".";
    }

    [RelayCommand]
    private async Task RefreshCalendars()
    {
        CalendarMessage = "Refreshing…";
        await S.Calendars.RefreshAllAsync();
        foreach (var c in Calendars) c.Notify();
        CalendarMessage = Calendars.Any(c => c.HasError) ? "Some calendars couldn't be refreshed." : "Calendars are up to date.";
    }

    // ---------------------------------------------------------------- data

    private void LoadBackups()
    {
        var selected = SelectedBackup?.FullName;
        var files = BackupService.List();
        if (Backups.Select(b => b.FullName).SequenceEqual(files.Select(f => f.FullName))) return;
        Backups.Clear();
        foreach (var b in files) Backups.Add(b);
        SelectedBackup = Backups.FirstOrDefault(b => b.FullName == selected) ?? Backups.FirstOrDefault();
    }

    private static string? AskSavePath(string title, string fileName, string filter)
    {
        var dlg = new SaveFileDialog { Title = title, FileName = fileName, Filter = filter, AddExtension = true, OverwritePrompt = true };
        return dlg.ShowDialog(Application.Current.MainWindow) == true ? dlg.FileName : null;
    }

    [RelayCommand]
    private void ExportJson()
    {
        var path = AskSavePath("Export to JSON", $"DayBoard-{DateTime.Now:yyyy-MM-dd}.json", "JSON files (*.json)|*.json");
        if (path is null) return;
        File.WriteAllText(path, JsonPorter.Export(S.Planner.Store.Snapshot(), DateTime.Now), new UTF8Encoding(false));
        DataMessage = "Exported to " + path;
    }

    [RelayCommand]
    private void ExportCsv()
    {
        var path = AskSavePath("Export to CSV", $"DayBoard-{DateTime.Now:yyyy-MM-dd}.csv", "CSV files (*.csv)|*.csv");
        if (path is null) return;
        File.WriteAllText(path, CsvExporter.Export(S.Planner.Store.Snapshot()), new UTF8Encoding(true));
        DataMessage = "Exported to " + path;
    }

    [RelayCommand]
    private void ExportIcs()
    {
        var from = DateOnly.FromDateTime(IcsFrom ?? DateTime.Today.AddDays(-7));
        var to = DateOnly.FromDateTime(IcsTo ?? DateTime.Today.AddDays(60));
        if (to < from) (from, to) = (to, from);
        var path = AskSavePath("Export to calendar (.ics)", $"DayBoard-{from:yyyy-MM-dd}-to-{to:yyyy-MM-dd}.ics", "iCalendar files (*.ics)|*.ics");
        if (path is null) return;
        S.Planner.EnsureOccurrencesThrough(to);
        var store = S.Planner.Store;
        var tasks = store.Tasks.Where(t => t.ScheduledDate is { } d && d >= from && d <= to);
        var ics = IcsWriter.WriteTasks(tasks, store.FindCategory, DateTime.UtcNow, Cur.DefaultEstimateMinutes);
        File.WriteAllText(path, ics, new UTF8Encoding(false));
        DataMessage = $"Exported {tasks.Count()} tasks to " + path;
    }

    [RelayCommand]
    private void ImportJson()
    {
        var dlg = new OpenFileDialog { Title = "Import DayBoard JSON", Filter = "JSON files (*.json)|*.json|All files (*.*)|*.*" };
        if (dlg.ShowDialog(Application.Current.MainWindow) != true) return;
        try
        {
            var data = JsonPorter.Import(File.ReadAllText(dlg.FileName));
            int n = S.Planner.Import(data);
            DataMessage = $"Imported {n} task{(n == 1 ? "" : "s")}. Undo (Ctrl+Z) reverts the import.";
            S.Main.ShowToast($"Imported {n} tasks", undo: true);
        }
        catch (Exception ex) when (ex is FormatException or IOException)
        {
            DataMessage = ex.Message;
        }
    }

    [RelayCommand]
    private void OpenDataFolder() => Process.Start(new ProcessStartInfo { FileName = AppPaths.DataDir, UseShellExecute = true });

    [RelayCommand]
    private void BackupNow()
    {
        try
        {
            var path = BackupService.BackupNow(S.Repository, Path.Combine(AppPaths.BackupDir, $"dayboard-{DateTime.Now:yyyy-MM-dd}.db"));
            LoadBackups();
            DataMessage = "Backup saved: " + Path.GetFileName(path);
        }
        catch (Exception ex)
        {
            DataMessage = "Backup failed: " + ex.Message;
        }
    }

    [RelayCommand]
    private void RestoreBackup()
    {
        if (SelectedBackup is null) return;
        var choice = S.Windows.Ask("Restore backup?",
            $"DayBoard will restart and replace your current data with the backup from {SelectedBackup.Name}. A copy of the current data is kept in the backups folder.",
            "Restore and restart", "Cancel");
        if (choice != 0) return;
        BackupService.ScheduleRestore(SelectedBackup.FullName);
        S.Main.Restart();
    }

    [RelayCommand]
    private void ImportMsTodo() => S.Windows.ShowMsTodoImport();
}
