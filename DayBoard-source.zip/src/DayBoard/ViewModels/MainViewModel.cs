using System.Diagnostics;
using System.Globalization;
using System.Windows;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Time;
using DayBoard.Data;
using DayBoard.Hosting;
using DayBoard.Infrastructure;
using DayBoard.Plugins;
using DayBoard.Services;

namespace DayBoard.ViewModels;

public static class PageKeys
{
    public const string Day = "Day";
    public const string Week = "Week";
    public const string Stats = "Stats";
    public const string Settings = "Settings";

    /// <summary>The views that are always there, in sidebar order. Plugin pages (such as Focus) come after Stats.</summary>
    public static readonly string[] Order = { Day, Week, Stats, Settings };

    public static readonly string[] All = Order;
}

public sealed partial class MainViewModel : ObservableObject
{
    private readonly DispatcherTimer _toastTimer = new() { Interval = TimeSpan.FromSeconds(6) };
    private bool _refreshQueued;

    public MainViewModel()
    {
        var s = AppServices.Current;
        _selectedDate = s.Planner.Today;
        Day = new DayViewModel { Date = _selectedDate };
        Week = new WeekViewModel { WeekStart = DateUtil.StartOfWeek(_selectedDate, s.Settings.Current.WeekStart) };
        _isInboxVisible = s.Settings.Current.InboxVisible;
        // A plugin page that was open last time is reopened once the plugin has started (see OpenLastView).
        _currentView = PageKeys.All.Contains(s.Settings.Current.LastView) ? s.Settings.Current.LastView : PageKeys.Day;
        _currentPage = PageFor(_currentView);

        s.Planner.Store.Changed += (_, _) => QueueRefresh();
        s.Planner.Undo.StateChanged += (_, _) =>
        {
            UndoCommand.NotifyCanExecuteChanged();
            RedoCommand.NotifyCanExecuteChanged();
            OnPropertyChanged(nameof(UndoTooltip));
            OnPropertyChanged(nameof(RedoTooltip));
        };
        s.Calendars.Changed += (_, _) => QueueRefresh();
        s.Settings.Changed += (_, _) => QueueRefresh();
        ThemeService.Changed += (_, _) => QueueRefresh();
        _toastTimer.Tick += (_, _) => HideToast();
        UpdateHeader();
    }

    public DayViewModel Day { get; }
    public WeekViewModel Week { get; }
    public InboxViewModel Inbox { get; } = new();
    public StatsViewModel Stats { get; } = new();
    public SettingsViewModel SettingsPage { get; } = new();
    public MiniViewModel Mini { get; } = new();

    /// <summary>Plugin pages with a shortcut: Ctrl+4 to Ctrl+9.</summary>
    public const int MaxPageShortcuts = 6;

    /// <summary>Sidebar buttons for pages that code plugins added.</summary>
    public System.Collections.ObjectModel.ObservableCollection<PluginNavItem> PluginNav { get; } = new();

    [ObservableProperty] private string _currentView;
    [ObservableProperty] private object _currentPage;
    [ObservableProperty] private DateOnly _selectedDate;
    [ObservableProperty] private string _headerTitle = "";
    [ObservableProperty] private string _headerSubtitle = "";
    [ObservableProperty] private bool _isInboxVisible;
    [ObservableProperty] private string? _toastText;
    [ObservableProperty] private bool _toastCanUndo;
    [ObservableProperty] private bool _isToastVisible;

    public bool ShowInboxPanel => IsInboxVisible && CurrentView is PageKeys.Day or PageKeys.Week;
    public bool ShowDateNav => CurrentView is PageKeys.Day or PageKeys.Week || PluginNavigation != DateNavigation.None;

    /// <summary>How the date buttons move while a plugin page is open (None for DayBoard's own pages).</summary>
    private DateNavigation PluginNavigation => CurrentPluginPage?.Navigation ?? DateNavigation.None;

    private PluginPageEntry? CurrentPluginPage => PluginRunner.IsPageKey(CurrentView) ? AppServices.Current.Runner?.FindPage(CurrentView) : null;

    public bool IsTodaySelected
    {
        get
        {
            var today = AppServices.Current.Planner.Today;
            bool sameWeek = DateUtil.StartOfWeek(SelectedDate, WeekStart) == DateUtil.StartOfWeek(today, WeekStart);
            bool sameMonth = SelectedDate.Year == today.Year && SelectedDate.Month == today.Month;
            return CurrentView switch
            {
                PageKeys.Day => SelectedDate == today,
                PageKeys.Week => sameWeek,
                _ => PluginNavigation switch
                {
                    DateNavigation.Day => SelectedDate == today,
                    DateNavigation.Week => sameWeek,
                    DateNavigation.Month => sameMonth,
                    _ => true,
                },
            };
        }
    }
    public string UndoTooltip => AppServices.Current.Planner.Undo.UndoDescription is { } d ? $"Undo {d} (Ctrl+Z)" : "Nothing to undo";
    public string RedoTooltip => AppServices.Current.Planner.Undo.RedoDescription is { } d ? $"Redo {d} (Ctrl+Y)" : "Nothing to redo";
    private static DayOfWeek WeekStart => AppServices.Current.Settings.Current.WeekStart;

    private object PageFor(string view) => view switch
    {
        PageKeys.Week => Week,
        PageKeys.Stats => Stats,
        PageKeys.Settings => SettingsPage,
        _ when PluginRunner.IsPageKey(view) && AppServices.Current.Runner?.FindPage(view) is { } p => p.Host,
        _ => Day,
    };

    partial void OnCurrentViewChanging(string value)
    {
        // Let the page that's closing save what it has pending.
        if (CurrentPluginPage is { } page && page.Key != value) page.Host.HidePage();
        if (CurrentView == PageKeys.Day && value != PageKeys.Day) AppServices.Current.Runner?.HidePanels();
    }

    partial void OnCurrentViewChanged(string value)
    {
        CurrentPage = PageFor(value);
        foreach (var item in PluginNav) item.IsSelected = item.Key == value;
        AppServices.Current.Settings.Update(s => s.LastView = value, notify: false);
        OnPropertyChanged(nameof(ShowInboxPanel));
        OnPropertyChanged(nameof(ShowDateNav));
        UpdateHeader();
        RefreshNow();
    }

    partial void OnIsInboxVisibleChanged(bool value)
    {
        AppServices.Current.Settings.Update(s => s.InboxVisible = value, notify: false);
        OnPropertyChanged(nameof(ShowInboxPanel));
        if (value) Inbox.Refresh();
    }

    partial void OnSelectedDateChanged(DateOnly value)
    {
        Day.Date = value;
        Week.WeekStart = DateUtil.StartOfWeek(value, WeekStart);
        UpdateHeader();
        RefreshNow();
        AppServices.Current.Runner?.OnDateChanged();
    }

    /// <summary>Plugins added or removed pages: rebuilds the sidebar buttons.</summary>
    public void OnPluginsChanged()
    {
        var pages = AppServices.Current.Runner.Pages;
        PluginNav.Clear();
        for (int i = 0; i < pages.Count; i++)
        {
            var p = pages[i];
            PluginNav.Add(new PluginNavItem
            {
                Key = p.Key,
                Title = p.Title,
                Symbol = p.Symbol,
                Tooltip = i < MaxPageShortcuts ? $"{p.Title} (Ctrl+{4 + i})" : p.Title,
                IsSelected = p.Key == CurrentView,
            });
        }
        if (PluginRunner.IsPageKey(CurrentView) && CurrentPluginPage is null)
        {
            CurrentView = PageKeys.Day; // its plugin was unticked or removed
            return;
        }
        OnPropertyChanged(nameof(ShowDateNav));
        UpdateHeader();
        QueueRefresh();
    }

    /// <summary>Reopens the plugin page that was open when DayBoard last closed, once plugins have started.</summary>
    public void OpenLastView()
    {
        var last = AppServices.Current.Settings.Current.LastView;
        if (last == "Focus") last = PluginRunner.PageKey(Data.Plugins.LegacySettings.FocusPluginId, "focus"); // a page of DayBoard 1.3's
        if (Data.Plugins.LegacySettings.MovedViews.FirstOrDefault(v => v.View == last) is { } moved) last = PluginRunner.PageKey(moved.PluginId, moved.PageId); // 1.5's
        if (PluginRunner.IsPageKey(last) && AppServices.Current.Runner.FindPage(last) is not null) CurrentView = last;
    }

    private void UpdateHeader()
    {
        var c = CultureInfo.CurrentCulture;
        var today = AppServices.Current.Planner.Today;
        switch (CurrentView)
        {
            case PageKeys.Day:
                HeaderTitle = SelectedDate == today ? "Today" : SelectedDate == today.AddDays(1) ? "Tomorrow" : SelectedDate == today.AddDays(-1) ? "Yesterday" : SelectedDate.ToString("dddd", c);
                HeaderSubtitle = SelectedDate.ToString("dddd d MMMM yyyy", c);
                break;
            case PageKeys.Week:
            {
                var ws = DateUtil.StartOfWeek(SelectedDate, WeekStart);
                var we = ws.AddDays(6);
                HeaderTitle = ws.Month == we.Month ? $"{ws.Day}–{we.Day} {we.ToString("MMMM", c)}" : $"{ws.ToString("d MMM", c)} – {we.ToString("d MMM", c)}";
                var week = ISOWeek.GetWeekOfYear(ws.ToDateTime(TimeOnly.MinValue).AddDays(3));
                HeaderSubtitle = $"Week {week} · {we.Year}";
                break;
            }
            case PageKeys.Stats:
                HeaderTitle = "Stats";
                HeaderSubtitle = "Completion rates and history";
                break;
            case PageKeys.Settings:
                HeaderTitle = "Settings";
                HeaderSubtitle = "Data is stored in " + AppPaths.DataDir;
                break;
            default:
                if (CurrentPluginPage is { } page)
                {
                    HeaderTitle = page.Heading;
                    HeaderSubtitle = page.Host.Subtitle(SelectedDate);
                }
                break;
        }
        OnPropertyChanged(nameof(IsTodaySelected));
    }

    // ---------------------------------------------------------------- refresh

    public void QueueRefresh()
    {
        if (_refreshQueued) return;
        _refreshQueued = true;
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(RefreshNow));
    }

    public void RefreshNow()
    {
        _refreshQueued = false;
        try
        {
            if (PluginRunner.IsPageKey(CurrentView) && CurrentPluginPage is null)
            {
                CurrentView = PageKeys.Day; // the plugin was unticked or removed
                return;
            }
            if (CurrentPage is IPage page) page.Refresh();
            if (CurrentPluginPage is not null) UpdateHeader(); // the subtitle may follow what the page shows
            if (ShowInboxPanel) Inbox.Refresh();
            Mini.Refresh();
            UpdateBadges();
        }
        catch (Exception ex)
        {
            Log.Error("Refresh", ex);
        }
    }

    public void UpdateBadges()
    {
        var planner = AppServices.Current.Planner;
        var today = planner.Today;
        int remaining = planner.TasksOn(today).Count(t => !t.IsDone) + planner.OverdueBefore(today).Count;
        AppServices.Current.Tray?.Update(remaining);
        if (Application.Current.MainWindow is DayBoard.Views.MainWindow mw) mw.SetBadge(remaining);
    }

    /// <summary>Called on date change (midnight / resume): maintenance, backup and a refresh.</summary>
    public void OnNewDay(DateOnly previousToday)
    {
        var s = AppServices.Current;
        var result = s.Planner.RunDailyMaintenance();
        try
        {
            BackupService.RunDailyIfNeeded(s.Repository, s.Planner.Today);
        }
        catch (Exception ex)
        {
            Log.Error("Daily backup", ex);
        }
        if (SelectedDate == previousToday) SelectedDate = s.Planner.Today;
        UpdateHeader();
        RefreshNow();
        s.Runner?.OnDateChanged();
        if (result.Moved > 0) ShowToast($"{result.Moved} unfinished task{(result.Moved == 1 ? "" : "s")} rolled over to today");
    }

    // ---------------------------------------------------------------- commands

    [RelayCommand]
    private void Navigate(string view)
    {
        // "#1" to "#6": the first six plugin pages (Ctrl+4 to Ctrl+9).
        if (view.StartsWith('#'))
        {
            if (!int.TryParse(view[1..], out var n) || n < 1 || n > PluginNav.Count) return;
            view = PluginNav[n - 1].Key;
        }
        if (PluginRunner.IsPageKey(view) && AppServices.Current.Runner.FindPage(view) is null) return;
        CurrentView = view;
    }

    [RelayCommand]
    private void Previous() => Step(-1);

    [RelayCommand]
    private void Next() => Step(1);

    private void Step(int direction)
    {
        switch (CurrentView)
        {
            case PageKeys.Day:
                SelectedDate = SelectedDate.AddDays(direction);
                break;
            case PageKeys.Week:
                SelectedDate = SelectedDate.AddDays(7 * direction);
                break;
            default:
                SelectedDate = PluginNavigation switch
                {
                    DateNavigation.Day => SelectedDate.AddDays(direction),
                    DateNavigation.Week => SelectedDate.AddDays(7 * direction),
                    DateNavigation.Month => SelectedDate.AddMonths(direction),
                    _ => SelectedDate,
                };
                break;
        }
    }

    [RelayCommand]
    private void GoToday()
    {
        SelectedDate = AppServices.Current.Planner.Today;
        if (!ShowDateNav) CurrentView = PageKeys.Day;
    }

    public void ShowDate(DateOnly date, string view = PageKeys.Day)
    {
        SelectedDate = date;
        CurrentView = view;
    }

    private bool CanUndo() => AppServices.Current.Planner.Undo.CanUndo;
    private bool CanRedo() => AppServices.Current.Planner.Undo.CanRedo;

    [RelayCommand(CanExecute = nameof(CanUndo))]
    private void Undo()
    {
        var desc = AppServices.Current.Planner.Undo.UndoDescription;
        if (AppServices.Current.Planner.Undo.Undo()) ShowToast("Undid " + Lower(desc));
    }

    [RelayCommand(CanExecute = nameof(CanRedo))]
    private void Redo()
    {
        var desc = AppServices.Current.Planner.Undo.RedoDescription;
        if (AppServices.Current.Planner.Undo.Redo()) ShowToast("Redid " + Lower(desc));
    }

    private static string Lower(string? s) => string.IsNullOrEmpty(s) ? "" : char.ToLower(s[0], CultureInfo.CurrentCulture) + s[1..];

    [RelayCommand]
    private void NewTask()
    {
        DateOnly? date = CurrentView switch
        {
            PageKeys.Day => SelectedDate,
            PageKeys.Week => SelectedDate,
            _ => AppServices.Current.Planner.Today,
        };
        AppServices.Current.Windows.NewTask(date, null);
    }

    [RelayCommand]
    private void QuickAdd() => AppServices.Current.Windows.ShowQuickAdd(CurrentView == PageKeys.Day ? SelectedDate : AppServices.Current.Planner.Today);

    [RelayCommand]
    private void ToggleInbox() => IsInboxVisible = !IsInboxVisible;

    [RelayCommand]
    private void ToggleMini() => AppServices.Current.Windows.ToggleMini();

    [RelayCommand]
    private async Task RefreshCalendars() => await AppServices.Current.Calendars.RefreshAllAsync();

    // ---------------------------------------------------------------- toast

    public void ShowToast(string text, bool undo = false)
    {
        ToastText = text;
        ToastCanUndo = undo && AppServices.Current.Planner.Undo.CanUndo;
        IsToastVisible = true;
        _toastTimer.Stop();
        _toastTimer.Start();
    }

    [RelayCommand]
    private void HideToast()
    {
        _toastTimer.Stop();
        IsToastVisible = false;
    }

    [RelayCommand]
    private void ToastUndo()
    {
        HideToast();
        AppServices.Current.Planner.Undo.Undo();
    }

    // ---------------------------------------------------------------- integration

    /// <summary>Registers the global quick-add shortcut from settings. Conflicts are reported, never fatal.</summary>
    public void ApplyHotkey(bool showErrors)
    {
        var s = AppServices.Current;
        var cfg = s.Settings.Current;
        s.Hotkey.Unregister();
        if (!cfg.HotkeyEnabled) return;
        if (!GlobalHotkey.TryParse(cfg.HotkeyModifiers, cfg.HotkeyKey, out var mods, out var key))
        {
            mods = System.Windows.Input.ModifierKeys.Control | System.Windows.Input.ModifierKeys.Alt;
            key = System.Windows.Input.Key.Space;
        }
        if (!s.Hotkey.Register(mods, key) && showErrors)
        {
            s.Tray?.Notify("Quick-add shortcut unavailable", (s.Hotkey.LastError ?? "") + " Pick another one in Settings › Windows integration.");
            ShowToast((s.Hotkey.LastError ?? "Shortcut unavailable.") + " Choose another in Settings.");
        }
    }

    public void Restart()
    {
        try
        {
            Process.Start(new ProcessStartInfo { FileName = AppPaths.ExecutablePath, Arguments = "--after-restart", UseShellExecute = false });
        }
        catch (Exception ex)
        {
            Log.Error("Restart", ex);
        }
        ((App)Application.Current).ExitApp();
    }

    /// <summary>Handles command-line arguments from startup, the jump list or a second launch.</summary>
    public void HandleArguments(IEnumerable<string> args)
    {
        var list = args.ToList();
        if (list.Count > 0) Log.Info("Arguments: " + string.Join(" ", list));
        foreach (var a in list)
        {
            switch (a.ToLowerInvariant())
            {
                case JumpLists.QuickAddArg:
                    AppServices.Current.Windows.ShowQuickAdd(AppServices.Current.Planner.Today);
                    return;
                case JumpLists.TodayArg:
                    AppServices.Current.Windows.ShowMain();
                    ShowDate(AppServices.Current.Planner.Today);
                    return;
                case "--minimized":
                case "--after-restart":
                case "--safe-mode":
                    break;
                default:
                    AppServices.Current.Windows.ShowMain();
                    return;
            }
        }
    }
}
