using System.Collections.ObjectModel;
using System.Globalization;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Core.Time;
using DayBoard.Services;

namespace DayBoard.ViewModels;

public sealed partial class WeekDayViewModel : DropZoneViewModel
{
    public WeekDayViewModel(DateOnly date, DateOnly today)
    {
        Date = date;
        IsToday = date == today;
        IsPast = date < today;
        IsWeekend = date.DayOfWeek is DayOfWeek.Saturday or DayOfWeek.Sunday;
        DayName = date.ToString("ddd", CultureInfo.CurrentCulture);
        DayNumber = date.Day.ToString(CultureInfo.CurrentCulture);
        MonthText = date.Day == 1 || IsToday ? date.ToString("MMM", CultureInfo.CurrentCulture) : "";
    }

    public DateOnly Date { get; }
    public bool IsToday { get; }
    public bool IsPast { get; }
    public bool IsWeekend { get; }
    public string DayName { get; }
    public string DayNumber { get; }
    public string MonthText { get; }
    public List<TaskCardViewModel> Cards { get; set; } = new();
    public List<EventChipViewModel> Events { get; set; } = new();
    public CapacityViewModel? Capacity { get; set; }
    public bool HasEvents => Events.Count > 0;
    public bool IsEmpty => Cards.Count == 0;
}

public sealed partial class WeekViewModel : ObservableObject, IPage
{
    [ObservableProperty] private DateOnly _weekStart;
    [ObservableProperty] private string _summary = "";

    public ObservableCollection<WeekDayViewModel> Days { get; } = new();

    public void Refresh()
    {
        var s = AppServices.Current;
        var planner = s.Planner;
        var today = planner.Today;
        var weekEnd = WeekStart.AddDays(6);
        planner.EnsureOccurrencesThrough(weekEnd);
        var ctx = CardContext.Create();
        var events = s.Calendars.EventsBetween(WeekStart, weekEnd);
        bool showDone = s.Settings.Current.ShowCompletedTasks;

        var days = new List<WeekDayViewModel>();
        int planned = 0, capacity = 0;
        for (int i = 0; i < 7; i++)
        {
            var date = WeekStart.AddDays(i);
            var tasks = planner.TasksOn(date);
            if (!showDone) tasks = tasks.Where(t => !t.IsDone).ToList();
            var cap = planner.CapacityFor(date);
            planned += cap.PlannedMinutes;
            capacity += cap.CapacityMinutes;
            days.Add(new WeekDayViewModel(date, today)
            {
                Cards = ctx.Cards(tasks),
                Events = events.Where(e => e.Occurrence.CoversDate(date)).Select(e => new EventChipViewModel(e, date)).ToList(),
                Capacity = new CapacityViewModel(cap),
            });
        }
        DayViewModel.Replace(Days, days);
        Summary = $"{DateUtil.FormatMinutes(planned)} planned of {DateUtil.FormatMinutes(capacity)} available";
    }
}
