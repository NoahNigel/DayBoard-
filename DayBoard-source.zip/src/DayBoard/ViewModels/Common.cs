using System.Globalization;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Core.Planning;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;
using DayBoard.Services;

namespace DayBoard.ViewModels;

public interface IPage
{
    void Refresh();
}

public sealed class CapacityViewModel
{
    public CapacityViewModel(CapacityInfo info)
    {
        Info = info;
        Ratio = double.IsFinite(info.Ratio) ? Math.Clamp(info.Ratio, 0, 1) : 1;
        Level = info.Level.ToString();
        Text = $"{DateUtil.FormatMinutes(info.PlannedMinutes)} / {DateUtil.FormatMinutes(info.CapacityMinutes)}";
        var pct = double.IsFinite(info.Ratio) ? (int)Math.Round(info.Ratio * 100) : 100;
        Tooltip = info.Level switch
        {
            CapacityLevel.Over => $"Over capacity: {DateUtil.FormatMinutes(info.PlannedMinutes - info.CapacityMinutes)} more than the {DateUtil.FormatMinutes(info.CapacityMinutes)} available ({pct}%)",
            CapacityLevel.Near => $"Near capacity: {pct}% of {DateUtil.FormatMinutes(info.CapacityMinutes)}",
            _ => $"{pct}% of {DateUtil.FormatMinutes(info.CapacityMinutes)} planned",
        };
        if (info.UnestimatedCount > 0)
            Tooltip += $"\n{info.UnestimatedCount} task{(info.UnestimatedCount == 1 ? " has" : "s have")} no estimate";
    }

    public CapacityInfo Info { get; }
    public double Ratio { get; }
    public string Level { get; }
    public string Text { get; }
    public string Tooltip { get; }
    public bool HasUnestimated => Info.UnestimatedCount > 0;
    public string UnestimatedText => $"+{Info.UnestimatedCount} unestimated";
}

public sealed class EventChipViewModel
{
    public EventChipViewModel(CalendarEventView ev, DateOnly onDate)
    {
        Event = ev;
        var o = ev.Occurrence;
        Title = o.Title;
        Brush = ColorUtil.Brush(ev.Color);
        Tint = ColorUtil.Brush(ev.Color, 0x33);
        IsAllDay = o.IsAllDay;
        var day = onDate.ToDateTime(TimeOnly.MinValue);
        var startsBefore = o.Start < day;
        TimeText = o.IsAllDay ? "All day" : startsBefore ? "…" + o.End.ToString("HH:mm", CultureInfo.InvariantCulture) : o.Start.ToString("HH:mm", CultureInfo.InvariantCulture);
        var range = o.IsAllDay
            ? (o.End - o.Start).TotalDays > 1 ? $"{o.Start:ddd d MMM} – {o.End.AddDays(-1):ddd d MMM}" : "All day"
            : $"{o.Start:ddd d MMM HH:mm} – {(o.End.Date == o.Start.Date ? o.End.ToString("HH:mm", CultureInfo.InvariantCulture) : o.End.ToString("ddd HH:mm", CultureInfo.CurrentCulture))}";
        Tooltip = $"{o.Title}\n{range}" + (string.IsNullOrWhiteSpace(o.Location) ? "" : $"\n{o.Location}") + $"\n{ev.CalendarName} (read-only)";
    }

    public CalendarEventView Event { get; }
    public string Title { get; }
    public string TimeText { get; }
    public Brush Brush { get; }
    public Brush Tint { get; }
    public bool IsAllDay { get; }
    public string Tooltip { get; }
}

/// <summary>Items with a drop-highlight flag for columns and panels.</summary>
public abstract partial class DropZoneViewModel : ObservableObject
{
    [ObservableProperty] private bool _isDropTarget;
}
