using System.Globalization;
using System.Windows.Media;
using DayBoard.Core.Models;
using DayBoard.Core.Planning;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;
using DayBoard.Services;
using Wpf.Ui.Controls;

namespace DayBoard.ViewModels;

/// <summary>Shared lookups for building cards during one refresh.</summary>
public sealed class CardContext
{
    private CardContext(Planner planner, bool showDate)
    {
        Planner = planner;
        Today = planner.Today;
        ShowDate = showDate;
        Categories = planner.Store.Categories.ToDictionary(c => c.Id);
    }

    public Planner Planner { get; }
    public DateOnly Today { get; }
    public bool ShowDate { get; }
    public Dictionary<Guid, Category> Categories { get; }

    public static CardContext Create(bool showDate = false) => new(AppServices.Current.Planner, showDate);

    public TaskCardViewModel Card(TaskItem t) => new(t, this);

    public List<TaskCardViewModel> Cards(IEnumerable<TaskItem> tasks) => tasks.Select(Card).ToList();
}

/// <summary>Read-only presentation of one task. Cards are rebuilt on every change, so they hold no editable state.</summary>
public sealed class TaskCardViewModel
{
    private static readonly CultureInfo Culture = CultureInfo.CurrentCulture;

    public TaskCardViewModel(TaskItem task, CardContext ctx)
    {
        Task = task;
        var today = ctx.Today;
        Category? cat = task.CategoryId is { } cid && ctx.Categories.TryGetValue(cid, out var c) ? c : null;

        HasCategory = cat is not null;
        CategoryName = cat?.Name ?? "";
        CategoryBrush = cat is null ? Brushes.Transparent : ColorUtil.Brush(cat.Color);
        CategoryTint = cat is null ? Brushes.Transparent : ColorUtil.Brush(cat.Color, 0x2E);
        CategoryIcon = Symbols.Parse(cat?.Icon);

        if (task.StartTime is { } st)
        {
            HasTime = true;
            TimeShort = st.ToString("HH\\:mm", CultureInfo.InvariantCulture);
            TimeText = task.EstimateMinutes is int m and > 0 ? $"{st:HH\\:mm}–{st.AddMinutes(m):HH\\:mm}" : st.ToString("HH\\:mm", CultureInfo.InvariantCulture);
        }
        if (task.EstimateMinutes is int est and > 0)
        {
            HasEstimate = true;
            EstimateText = DateUtil.FormatMinutes(est);
        }
        if (task.ActualMinutes > 0)
        {
            HasActual = true;
            ActualText = DateUtil.FormatMinutes(task.ActualMinutes);
        }
        if (task.Subtasks.Count > 0)
        {
            HasSubtasks = true;
            SubtaskText = $"{task.SubtasksDone}/{task.Subtasks.Count}";
            SubtaskProgress = (double)task.SubtasksDone / task.Subtasks.Count;
        }

        IsRecurring = task.SeriesId.HasValue;
        if (IsRecurring) RecurrenceText = ctx.Planner.RepeatOf(task).Describe();

        HasRollover = task.RolloverCount > 0;
        RolloverText = task.RolloverCount.ToString(Culture);

        if (task.DueDate is { } due && !task.IsDone)
        {
            HasDue = true;
            int days = due.DayNumber - today.DayNumber;
            IsDueOverdue = days < 0;
            DueText = days switch
            {
                < 0 => $"Due {-days}d ago",
                0 => "Due today",
                1 => "Due tomorrow",
                < 7 => "Due " + due.ToString("ddd", Culture),
                _ => "Due " + due.ToString("d MMM", Culture),
            };
        }

        IsOverdue = !task.IsDone && task.ScheduledDate is { } sd && sd < today;
        if (IsOverdue) OverdueText = "Overdue since " + task.ScheduledDate!.Value.ToString("ddd d MMM", Culture);

        ShowDate = ctx.ShowDate;
        DateText = task.ScheduledDate is { } d
            ? d == today ? "Today" : d == today.AddDays(1) ? "Tomorrow" : d == today.AddDays(-1) ? "Yesterday" : d.ToString("ddd d MMM", Culture)
            : "Inbox";

        var firstLine = (task.Notes ?? "").Split('\n', 2)[0].Trim();
        NotesPreview = firstLine.Length > 110 ? firstLine[..109] + "…" : firstLine;

        var parts = new List<string> { task.Title };
        if (task.Priority != Priority.None) parts.Add($"{task.Priority.Label()} priority");
        if (task.IsUrgent) parts.Add("urgent");
        if (HasCategory) parts.Add(CategoryName);
        if (HasTime) parts.Add(TimeText!);
        if (task.IsDone) parts.Add("done");
        AutomationName = string.Join(", ", parts);
    }

    public TaskItem Task { get; }
    public Guid Id => Task.Id;
    public string Title => Task.Title;
    public bool IsDone => Task.IsDone;
    public bool IsDoing => Task.Status == TaskState.Doing;
    public string PriorityKey => Task.Priority.ToString();
    public string PriorityGlyph => Task.Priority.Glyph();
    public bool HasPriority => Task.Priority != Priority.None;
    public string PriorityTooltip => $"{Task.Priority.Label()} priority";
    public bool IsUrgent => Task.IsUrgent;

    public bool HasCategory { get; }
    public string CategoryName { get; }
    public Brush CategoryBrush { get; }
    public Brush CategoryTint { get; }
    public SymbolRegular CategoryIcon { get; }

    public bool HasTime { get; }
    public string? TimeText { get; }
    public string? TimeShort { get; }
    public bool HasEstimate { get; }
    public string? EstimateText { get; }
    public bool HasActual { get; }
    public string? ActualText { get; }
    public bool HasSubtasks { get; }
    public string? SubtaskText { get; }
    public double SubtaskProgress { get; }
    public bool IsRecurring { get; }
    public string? RecurrenceText { get; }
    public bool HasRollover { get; }
    public string RolloverText { get; }
    public string RolloverTooltip => Task.RolloverCount == 1 ? "Rolled over once" : $"Rolled over {Task.RolloverCount} times";
    public bool HasDue { get; }
    public string? DueText { get; }
    public bool IsDueOverdue { get; }
    public bool IsOverdue { get; }
    public string? OverdueText { get; }
    public bool ShowDate { get; }
    public string DateText { get; }
    public string NotesPreview { get; }
    public bool HasNotes => NotesPreview.Length > 0;
    public bool HasMeta => ShowDate || HasTime || HasEstimate || HasActual || HasCategory || HasSubtasks || IsRecurring || HasRollover || HasDue || IsOverdue;

    /// <summary>Narrow cards (week columns) show priority and urgency in the chip row instead of beside the title.</summary>
    public bool HasMetaNarrow => HasMeta || HasPriority || IsUrgent;
    public string AutomationName { get; }

    /// <summary>Minutes used for timeline block height and drag ghosts.</summary>
    public int BlockMinutes => Task.EstimateMinutes is int m and > 0 ? m : AppServices.Current.Settings.Current.DefaultEstimateMinutes;
}
