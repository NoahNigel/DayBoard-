using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Models;
using DayBoard.Core.Recurrence;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;
using DayBoard.Services;
using Wpf.Ui.Controls;

namespace DayBoard.ViewModels;

public sealed record PriorityOption(Priority Value, string Label, string Glyph)
{
    public static IReadOnlyList<PriorityOption> All { get; } = new[]
    {
        new PriorityOption(Priority.None, "None", ""),
        new PriorityOption(Priority.Low, "Low", "!"),
        new PriorityOption(Priority.Medium, "Medium", "!!"),
        new PriorityOption(Priority.High, "High", "!!!"),
    };
}

public sealed record CategoryOption(Guid? Id, string Name, Brush Brush, SymbolRegular Icon)
{
    public static List<CategoryOption> FromStore()
    {
        var list = new List<CategoryOption> { new(null, "No category", ColorUtil.Brush("#8A8F98", 0x60), SymbolRegular.Circle24) };
        list.AddRange(AppServices.Current.Planner.Store.Categories.Select(c => new CategoryOption(c.Id, c.Name, ColorUtil.Brush(c.Color), Symbols.Parse(c.Icon))));
        return list;
    }
}

public sealed record StateOption(TaskState Value, string Label);

public sealed record ChoiceOption<T>(T Value, string Label);

public sealed partial class WeekdayToggle : ObservableObject
{
    public WeekdayToggle(DayOfWeek day, bool isOn)
    {
        Day = day;
        Label = CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedDayName(day)[..2];
        _isOn = isOn;
    }

    public DayOfWeek Day { get; }
    public string Label { get; }
    [ObservableProperty] private bool _isOn;
}

public sealed partial class SubtaskEditItem : ObservableObject
{
    public Guid Id { get; init; } = Guid.NewGuid();
    [ObservableProperty] private string _title = "";
    [ObservableProperty] private bool _isDone;
}

public sealed partial class TaskEditorViewModel : ObservableObject
{
    private readonly RepeatPattern _originalRepeat;

    public TaskEditorViewModel(TaskItem? existing, DateOnly? defaultDate = null, TimeOnly? defaultTime = null)
    {
        var s = AppServices.Current;
        IsNew = existing is null;
        Original = existing?.Clone() ?? new TaskItem
        {
            ScheduledDate = defaultDate,
            StartTime = defaultTime,
            EstimateMinutes = defaultTime.HasValue ? s.Settings.Current.DefaultEstimateMinutes : null,
        };
        var t = Original;
        Categories = CategoryOption.FromStore();
        _title = t.Title;
        _notes = t.Notes;
        _priority = PriorityOption.All.First(p => p.Value == t.Priority);
        _isUrgent = t.IsUrgent;
        _category = Categories.FirstOrDefault(c => c.Id == t.CategoryId) ?? Categories[0];
        _status = States.First(x => x.Value == t.Status);
        _hasDate = t.ScheduledDate.HasValue;
        _date = (t.ScheduledDate ?? s.Planner.Today).ToDateTime(TimeOnly.MinValue);
        _startTimeText = t.StartTime?.ToString("HH\\:mm", CultureInfo.InvariantCulture) ?? "";
        _estimateText = t.EstimateMinutes?.ToString(CultureInfo.InvariantCulture) ?? "";
        _dueDate = t.DueDate?.ToDateTime(TimeOnly.MinValue);
        _actualText = t.ActualMinutes > 0 ? t.ActualMinutes.ToString(CultureInfo.InvariantCulture) : "";
        foreach (var st in t.Subtasks) Subtasks.Add(new SubtaskEditItem { Id = st.Id, Title = st.Title, IsDone = st.IsDone });

        _originalRepeat = existing is null ? RepeatPattern.None : s.Planner.RepeatOf(existing);
        IsRecurringExisting = existing?.SeriesId is not null && _originalRepeat.IsRepeating;
        var anchor = t.ScheduledDate ?? s.Planner.Today;
        var p = _originalRepeat.IsRepeating ? _originalRepeat : RepeatPattern.None;
        _repeatChoice = RepeatKinds.FirstOrDefault(k => k.Value == p.Kind) ?? RepeatKinds[0];
        _intervalText = Math.Max(1, p.Interval).ToString(CultureInfo.InvariantCulture);
        _dayOfMonthText = (p.Kind == RepeatKind.MonthlyDay ? p.DayOfMonth : anchor.Day).ToString(CultureInfo.InvariantCulture);
        var defaults = RepeatPattern.DefaultFor(RepeatKind.MonthlyWeekday, anchor);
        _ordinal = Ordinals.First(o => o.Value == (p.Kind == RepeatKind.MonthlyWeekday ? p.WeekOrdinal : defaults.WeekOrdinal));
        _weekday = Weekdays.First(o => o.Value == (p.Kind == RepeatKind.MonthlyWeekday ? p.Weekday : anchor.DayOfWeek));
        _hasUntil = p.Until.HasValue;
        _until = (p.Until ?? anchor.AddMonths(3)).ToDateTime(TimeOnly.MinValue);
        var days = p.Kind == RepeatKind.Weekly ? p.Days : new List<DayOfWeek> { anchor.DayOfWeek };
        foreach (var d in DateUtil.WeekDays(s.Settings.Current.WeekStart))
        {
            var toggle = new WeekdayToggle(d, days.Contains(d));
            toggle.PropertyChanged += (_, _) => OnPropertyChanged(nameof(RepeatSummary));
            WeekdayToggles.Add(toggle);
        }
        CustomRule = p.Kind == RepeatKind.Custom ? p.CustomRule : null;
    }

    public bool IsNew { get; }
    public TaskItem Original { get; }
    public string WindowTitle => IsNew ? "New task" : "Edit task";
    public bool IsRecurringExisting { get; }
    public string? CustomRule { get; }

    public IReadOnlyList<PriorityOption> Priorities => PriorityOption.All;
    public List<CategoryOption> Categories { get; }

    public IReadOnlyList<StateOption> States { get; } = new[]
    {
        new StateOption(TaskState.ToDo, "To do"),
        new StateOption(TaskState.Doing, "Doing"),
        new StateOption(TaskState.Done, "Done"),
    };

    public IReadOnlyList<string> TimeOptions { get; } =
        new[] { "" }.Concat(Enumerable.Range(0, 48).Select(i => new TimeOnly(i / 2, i % 2 * 30).ToString("HH\\:mm", CultureInfo.InvariantCulture))).ToList();

    public IReadOnlyList<string> EstimateOptions { get; } = new[] { "", "10", "15", "20", "30", "45", "60", "90", "120", "180", "240" };

    public IReadOnlyList<ChoiceOption<RepeatKind>> RepeatKinds { get; } = new[]
    {
        new ChoiceOption<RepeatKind>(RepeatKind.None, "Does not repeat"),
        new ChoiceOption<RepeatKind>(RepeatKind.Daily, "Daily"),
        new ChoiceOption<RepeatKind>(RepeatKind.Weekdays, "Every weekday"),
        new ChoiceOption<RepeatKind>(RepeatKind.Weekly, "Weekly on chosen days"),
        new ChoiceOption<RepeatKind>(RepeatKind.MonthlyDay, "Monthly on a day"),
        new ChoiceOption<RepeatKind>(RepeatKind.MonthlyWeekday, "Monthly on a weekday"),
        new ChoiceOption<RepeatKind>(RepeatKind.Custom, "Custom (imported rule)"),
    };

    public IReadOnlyList<ChoiceOption<int>> Ordinals { get; } = new[]
    {
        new ChoiceOption<int>(1, "first"), new ChoiceOption<int>(2, "second"), new ChoiceOption<int>(3, "third"),
        new ChoiceOption<int>(4, "fourth"), new ChoiceOption<int>(-1, "last"),
    };

    public IReadOnlyList<ChoiceOption<DayOfWeek>> Weekdays { get; } =
        DateUtil.WeekDays(DayOfWeek.Monday).Select(d => new ChoiceOption<DayOfWeek>(d, CultureInfo.CurrentCulture.DateTimeFormat.GetDayName(d))).ToList();

    public ObservableCollection<WeekdayToggle> WeekdayToggles { get; } = new();
    public ObservableCollection<SubtaskEditItem> Subtasks { get; } = new();

    [ObservableProperty] private string _title;
    [ObservableProperty] private string _notes;
    [ObservableProperty] private PriorityOption _priority;
    [ObservableProperty] private bool _isUrgent;
    [ObservableProperty] private CategoryOption _category;
    [ObservableProperty] private StateOption _status;
    [ObservableProperty] private bool _hasDate;
    [ObservableProperty] private DateTime? _date;
    [ObservableProperty] private string _startTimeText;
    [ObservableProperty] private string _estimateText;
    [ObservableProperty] private DateTime? _dueDate;
    [ObservableProperty] private string _actualText;
    [ObservableProperty] private ChoiceOption<RepeatKind> _repeatChoice;
    [ObservableProperty] private string _intervalText;
    [ObservableProperty] private string _dayOfMonthText;
    [ObservableProperty] private ChoiceOption<int> _ordinal;
    [ObservableProperty] private ChoiceOption<DayOfWeek> _weekday;
    [ObservableProperty] private bool _hasUntil;
    [ObservableProperty] private DateTime? _until;
    [ObservableProperty] private string _newSubtask = "";
    [ObservableProperty] private string? _error;

    public bool ShowInterval => RepeatChoice.Value is RepeatKind.Daily or RepeatKind.Weekly;
    public string IntervalUnit => RepeatChoice.Value == RepeatKind.Daily ? "day(s)" : "week(s)";
    public bool ShowWeekdays => RepeatChoice.Value == RepeatKind.Weekly;
    public bool ShowDayOfMonth => RepeatChoice.Value == RepeatKind.MonthlyDay;
    public bool ShowOrdinal => RepeatChoice.Value == RepeatKind.MonthlyWeekday;
    public bool IsRepeating => RepeatChoice.Value != RepeatKind.None;
    public string RepeatSummary => BuildPattern().Describe();
    public bool CanDelete => !IsNew;

    partial void OnRepeatChoiceChanged(ChoiceOption<RepeatKind> value) => NotifyRepeat();
    partial void OnIntervalTextChanged(string value) => NotifyRepeat();
    partial void OnDayOfMonthTextChanged(string value) => NotifyRepeat();
    partial void OnOrdinalChanged(ChoiceOption<int> value) => NotifyRepeat();
    partial void OnWeekdayChanged(ChoiceOption<DayOfWeek> value) => NotifyRepeat();
    partial void OnHasUntilChanged(bool value) => NotifyRepeat();
    partial void OnUntilChanged(DateTime? value) => NotifyRepeat();

    private void NotifyRepeat()
    {
        OnPropertyChanged(nameof(ShowInterval));
        OnPropertyChanged(nameof(IntervalUnit));
        OnPropertyChanged(nameof(ShowWeekdays));
        OnPropertyChanged(nameof(ShowDayOfMonth));
        OnPropertyChanged(nameof(ShowOrdinal));
        OnPropertyChanged(nameof(IsRepeating));
        OnPropertyChanged(nameof(RepeatSummary));
    }

    [RelayCommand]
    private void AddSubtask()
    {
        var title = NewSubtask.Trim();
        if (title.Length == 0) return;
        Subtasks.Add(new SubtaskEditItem { Title = title });
        NewSubtask = "";
    }

    [RelayCommand]
    private void RemoveSubtask(SubtaskEditItem? item)
    {
        if (item is not null) Subtasks.Remove(item);
    }

    [RelayCommand]
    private void MoveSubtaskUp(SubtaskEditItem? item)
    {
        if (item is null) return;
        int i = Subtasks.IndexOf(item);
        if (i > 0) Subtasks.Move(i, i - 1);
    }

    [RelayCommand]
    private void ClearDue() => DueDate = null;

    private static int ParseInt(string? s, int fallback, int min, int max) =>
        int.TryParse((s ?? "").Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out var v) ? Math.Clamp(v, min, max) : fallback;

    public RepeatPattern BuildPattern()
    {
        var kind = RepeatChoice.Value;
        var p = new RepeatPattern { Kind = kind, Until = HasUntil && Until.HasValue ? DateOnly.FromDateTime(Until.Value) : null };
        switch (kind)
        {
            case RepeatKind.Daily:
                p.Interval = ParseInt(IntervalText, 1, 1, 365);
                break;
            case RepeatKind.Weekly:
                p.Interval = ParseInt(IntervalText, 1, 1, 52);
                p.Days = WeekdayToggles.Where(w => w.IsOn).Select(w => w.Day).ToList();
                if (p.Days.Count == 0) p.Days.Add(Date.HasValue ? Date.Value.DayOfWeek : DateTime.Today.DayOfWeek);
                break;
            case RepeatKind.MonthlyDay:
                p.DayOfMonth = ParseInt(DayOfMonthText, 1, 1, 31);
                break;
            case RepeatKind.MonthlyWeekday:
                p.WeekOrdinal = Ordinal.Value;
                p.Weekday = Weekday.Value;
                break;
            case RepeatKind.Custom:
                p.CustomRule = CustomRule;
                if (string.IsNullOrWhiteSpace(CustomRule)) p.Kind = RepeatKind.None;
                break;
        }
        return p;
    }

    public bool RepeatChanged => !BuildPattern().SameAs(_originalRepeat) && (BuildPattern().IsRepeating || _originalRepeat.IsRepeating);

    public string? Validate()
    {
        if (string.IsNullOrWhiteSpace(Title)) return "Give the task a title.";
        if (StartTimeText.Trim().Length > 0 && ParseTime(StartTimeText) is null) return "Start time should look like 09:30.";
        if (EstimateText.Trim().Length > 0 && ParseMinutes(EstimateText) is null) return "Estimate should be minutes, e.g. 45 or 1h30.";
        if (ActualText.Trim().Length > 0 && ParseMinutes(ActualText) is null) return "Logged time should be minutes, e.g. 25.";
        if (IsRepeating && HasUntil && Until.HasValue && Date.HasValue && HasDate && Until.Value.Date < Date.Value.Date)
            return "The repeat end date is before the task's date.";
        return null;
    }

    public static TimeOnly? ParseTime(string text)
    {
        var s = text.Trim().Replace('.', ':');
        if (s.Length == 0) return null;
        if (s.All(char.IsDigit) && s.Length is 3 or 4) s = s[..^2] + ":" + s[^2..];
        if (s.All(char.IsDigit) && s.Length is 1 or 2) s += ":00";
        return TimeOnly.TryParseExact(s, new[] { "H:mm", "HH:mm" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out var t) ? t
            : TimeOnly.TryParse(s, CultureInfo.CurrentCulture, DateTimeStyles.None, out t) ? t : null;
    }

    /// <summary>Parses "45", "45m", "1h", "1h30", "1:30", "1.5h".</summary>
    public static int? ParseMinutes(string text)
    {
        var s = text.Trim().ToLowerInvariant().Replace(" ", "");
        if (s.Length == 0) return null;
        if (int.TryParse(s.TrimEnd('m'), NumberStyles.Integer, CultureInfo.InvariantCulture, out var m) && m >= 0) return m;
        if (s.Contains(':') && TimeSpan.TryParseExact(s, @"h\:mm", CultureInfo.InvariantCulture, out var ts)) return (int)ts.TotalMinutes;
        var hIdx = s.IndexOf('h');
        if (hIdx > 0)
        {
            var hPart = s[..hIdx].Replace(',', '.');
            var mPart = s[(hIdx + 1)..].TrimEnd('m');
            if (double.TryParse(hPart, NumberStyles.Float, CultureInfo.InvariantCulture, out var h))
            {
                int extra = 0;
                if (mPart.Length > 0 && !int.TryParse(mPart, NumberStyles.Integer, CultureInfo.InvariantCulture, out extra)) return null;
                return (int)Math.Round(h * 60) + extra;
            }
        }
        return null;
    }

    public TaskItem BuildTask()
    {
        var t = Original.Clone();
        t.Title = Title.Trim();
        t.Notes = (Notes ?? "").TrimEnd();
        t.Priority = Priority.Value;
        t.IsUrgent = IsUrgent;
        t.CategoryId = Category.Id;
        t.Status = Status.Value;
        t.ScheduledDate = HasDate && Date.HasValue ? DateOnly.FromDateTime(Date.Value) : null;
        t.StartTime = t.ScheduledDate.HasValue ? ParseTime(StartTimeText) : null;
        t.EstimateMinutes = ParseMinutes(EstimateText) is int e and > 0 ? e : null;
        t.DueDate = DueDate.HasValue ? DateOnly.FromDateTime(DueDate.Value) : null;
        t.ActualMinutes = ParseMinutes(ActualText) ?? 0;
        t.Subtasks = Subtasks.Where(x => !string.IsNullOrWhiteSpace(x.Title))
            .Select(x => new Subtask { Id = x.Id, Title = x.Title.Trim(), IsDone = x.IsDone }).ToList();
        return t;
    }

    /// <summary>True when the edit changes anything compared with the stored task.</summary>
    public bool HasChanges() => IsNew || !Core.Planning.Planner.JsonSame(Original, BuildTask()) || RepeatChanged;
}

/// <summary>Quick add: title, date, priority and category. Trailing "!", "!!", "!!!" and "#category" words are understood.</summary>
public sealed partial class QuickAddViewModel : ObservableObject
{
    public QuickAddViewModel(DateOnly? date = null)
    {
        Categories = CategoryOption.FromStore();
        _category = Categories[0];
        _priority = PriorityOption.All[0];
        var today = AppServices.Current.Planner.Today;
        if (date is null) _dateChoice = "Inbox";
        else if (date == today) _dateChoice = "Today";
        else if (date == today.AddDays(1)) _dateChoice = "Tomorrow";
        else _dateChoice = "Pick";
        _pickedDate = (date ?? today).ToDateTime(TimeOnly.MinValue);
    }

    public List<CategoryOption> Categories { get; }
    public IReadOnlyList<PriorityOption> Priorities => PriorityOption.All;

    [ObservableProperty] private string _title = "";
    [ObservableProperty] private string _dateChoice;
    [ObservableProperty] private DateTime? _pickedDate;
    [ObservableProperty] private PriorityOption _priority;
    [ObservableProperty] private CategoryOption _category;

    public bool IsPick => DateChoice == "Pick";
    partial void OnDateChoiceChanged(string value) => OnPropertyChanged(nameof(IsPick));

    public TaskItem? Save()
    {
        var words = (Title ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries).ToList();
        var priority = Priority.Value;
        var categoryId = Category.Id;
        var cats = AppServices.Current.Planner.Store.Categories;
        for (int i = words.Count - 1; i >= 0; i--)
        {
            var w = words[i];
            if (w is "!" or "!!" or "!!!")
            {
                priority = (Core.Models.Priority)w.Length;
                words.RemoveAt(i);
            }
            else if (w.Length > 1 && w[0] == '#' && cats.FirstOrDefault(c => c.Name.Replace(" ", "").StartsWith(w[1..], StringComparison.OrdinalIgnoreCase)) is { } cat)
            {
                categoryId = cat.Id;
                words.RemoveAt(i);
            }
        }
        var title = string.Join(' ', words).Trim();
        if (title.Length == 0) return null;
        var today = AppServices.Current.Planner.Today;
        DateOnly? date = DateChoice switch
        {
            "Today" => today,
            "Tomorrow" => today.AddDays(1),
            "Pick" => PickedDate.HasValue ? DateOnly.FromDateTime(PickedDate.Value) : today,
            _ => null,
        };
        return AppServices.Current.Planner.AddTask(new TaskItem { Title = title, ScheduledDate = date, Priority = priority, CategoryId = categoryId });
    }
}

public sealed partial class MiniViewModel : ObservableObject, IPage
{
    [ObservableProperty] private List<TaskCardViewModel> _cards = new();
    [ObservableProperty] private string _header = "";
    [ObservableProperty] private string _remainingText = "";
    [ObservableProperty] private string _newTitle = "";

    public void Refresh()
    {
        var planner = AppServices.Current.Planner;
        var today = planner.Today;
        var ctx = CardContext.Create();
        var tasks = planner.OverdueBefore(today).Concat(planner.TasksOn(today)).ToList();
        Cards = ctx.Cards(tasks);
        int open = tasks.Count(t => !t.IsDone);
        Header = today.ToString("ddd d MMM", CultureInfo.CurrentCulture);
        RemainingText = open == 0 ? (tasks.Count == 0 ? "Nothing planned" : "All done") : $"{open} left";
    }

    [RelayCommand]
    private void Add()
    {
        var title = NewTitle.Trim();
        if (title.Length == 0) return;
        AppServices.Current.Planner.AddTask(new TaskItem { Title = title, ScheduledDate = AppServices.Current.Planner.Today });
        NewTitle = "";
    }
}
