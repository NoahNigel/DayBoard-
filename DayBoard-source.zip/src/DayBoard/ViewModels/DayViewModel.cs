using System.Collections.ObjectModel;
using System.Globalization;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Core.Planning;
using DayBoard.Infrastructure;
using DayBoard.Services;

namespace DayBoard.ViewModels;

/// <summary>A task or calendar event placed on the day timeline.</summary>
public sealed class TimelineItemViewModel
{
    public TaskCardViewModel? Card { get; init; }
    public EventChipViewModel? Event { get; init; }
    public bool IsEvent => Event is not null;

    /// <summary>Minutes from the top of the timeline.</summary>
    public double StartMinutes { get; init; }

    public double DurationMinutes { get; init; }
    public int Column { get; set; }
    public int Columns { get; set; } = 1;
    public string Title { get; init; } = "";
    public string TimeRange { get; init; } = "";
    public bool IsShort => DurationMinutes <= 30;
    public bool ShowMeta => DurationMinutes >= 60;
    public Brush? EventBrush => Event?.Brush;
    public Brush? EventTint => Event?.Tint;
    public string? Tooltip => Event?.Tooltip;

    internal double End => StartMinutes + Math.Max(DurationMinutes, 15);
}

public sealed partial class DayViewModel : DropZoneViewModel, IPage
{
    [ObservableProperty] private DateOnly _date;
    [ObservableProperty] private CapacityViewModel? _capacity;
    [ObservableProperty] private int _startHour;
    [ObservableProperty] private int _endHour;
    [ObservableProperty] private double _slotHeight = 26;
    [ObservableProperty] private bool _isToday;
    [ObservableProperty] private double _nowOffset;
    [ObservableProperty] private bool _hasOverdue;
    [ObservableProperty] private bool _hasUnscheduled;
    [ObservableProperty] private bool _hasAllDay;
    [ObservableProperty] private string _summary = "";

    public ObservableCollection<TimelineItemViewModel> Blocks { get; } = new();
    public ObservableCollection<TaskCardViewModel> Unscheduled { get; } = new();
    public ObservableCollection<TaskCardViewModel> Overdue { get; } = new();
    public ObservableCollection<EventChipViewModel> AllDayEvents { get; } = new();

    public double PixelsPerMinute => SlotHeight / 30.0;
    public double TimelineHeight => (EndHour - StartHour) * 60 * PixelsPerMinute;

    /// <summary>Raised after a refresh so the view can redraw the ruler and now-line.</summary>
    public event EventHandler? LayoutChanged;

    public void Refresh()
    {
        var s = AppServices.Current;
        var planner = s.Planner;
        var settings = s.Settings.Current;
        var today = planner.Today;
        IsToday = Date == today;
        planner.EnsureOccurrencesThrough(Date);

        s.Runner.ShowPanels(Date);

        var ctx = CardContext.Create();
        var tasks = planner.TasksOn(Date);
        var showDone = settings.ShowCompletedTasks;
        if (!showDone) tasks = tasks.Where(t => !t.IsDone).ToList();

        var events = s.Calendars.EventsBetween(Date, Date);
        var dayStart = Date.ToDateTime(TimeOnly.MinValue);
        var dayEnd = dayStart.AddDays(1);
        var timedEvents = events.Where(e => !e.Occurrence.IsAllDay).ToList();
        var allDay = events.Where(e => e.Occurrence.IsAllDay).ToList();

        // Grow the visible range so nothing scheduled falls outside it.
        int start = Math.Clamp(settings.DayStartHour, 0, 23);
        int end = Math.Clamp(settings.DayEndHour, start + 1, 24);
        foreach (var t in tasks.Where(t => t.StartTime.HasValue))
        {
            start = Math.Min(start, t.StartTime!.Value.Hour);
            var endMin = t.StartTime.Value.Hour * 60 + t.StartTime.Value.Minute + ctx.Card(t).BlockMinutes;
            end = Math.Max(end, Math.Min(24, (int)Math.Ceiling(endMin / 60.0)));
        }
        foreach (var e in timedEvents)
        {
            var st = e.Occurrence.Start < dayStart ? dayStart : e.Occurrence.Start;
            var en = e.Occurrence.End > dayEnd ? dayEnd : e.Occurrence.End;
            start = Math.Min(start, st.Hour);
            end = Math.Max(end, en == dayEnd ? 24 : Math.Min(24, en.Hour + (en.Minute > 0 ? 1 : 0)));
        }
        StartHour = start;
        EndHour = end;
        SlotHeight = settings.Density == Core.Models.Density.Compact ? 20 : 26;

        var items = new List<TimelineItemViewModel>();
        foreach (var t in tasks.Where(t => t.StartTime.HasValue))
        {
            var card = ctx.Card(t);
            var startMin = t.StartTime!.Value.Hour * 60 + t.StartTime.Value.Minute - start * 60;
            items.Add(new TimelineItemViewModel
            {
                Card = card,
                StartMinutes = startMin,
                DurationMinutes = card.BlockMinutes,
                Title = t.Title,
                TimeRange = card.TimeText ?? "",
            });
        }
        foreach (var e in timedEvents)
        {
            var st = e.Occurrence.Start < dayStart ? dayStart : e.Occurrence.Start;
            var en = e.Occurrence.End > dayEnd ? dayEnd : e.Occurrence.End;
            if (en <= st) en = st.AddMinutes(30);
            items.Add(new TimelineItemViewModel
            {
                Event = new EventChipViewModel(e, Date),
                StartMinutes = (st - dayStart).TotalMinutes - start * 60,
                DurationMinutes = Math.Max(15, (en - st).TotalMinutes),
                Title = e.Occurrence.Title,
                TimeRange = $"{e.Occurrence.Start:HH\\:mm}–{e.Occurrence.End:HH\\:mm}",
            });
        }
        LayoutColumns(items);

        Replace(Blocks, items.OrderBy(i => i.StartMinutes));
        Replace(Unscheduled, ctx.Cards(tasks.Where(t => !t.StartTime.HasValue)));
        Replace(Overdue, IsToday ? ctx.Cards(planner.OverdueBefore(Date)) : Enumerable.Empty<TaskCardViewModel>());
        Replace(AllDayEvents, allDay.Select(e => new EventChipViewModel(e, Date)));
        HasOverdue = Overdue.Count > 0;
        HasUnscheduled = Unscheduled.Count > 0;
        HasAllDay = AllDayEvents.Count > 0;
        Capacity = new CapacityViewModel(planner.CapacityFor(Date));
        int open = tasks.Count(t => !t.IsDone);
        Summary = tasks.Count == 0 ? "Nothing planned" : $"{open} open · {tasks.Count - open} done";
        UpdateNow();
        OnPropertyChanged(nameof(PixelsPerMinute));
        OnPropertyChanged(nameof(TimelineHeight));
        LayoutChanged?.Invoke(this, EventArgs.Empty);
    }

    public void UpdateNow()
    {
        var now = DateTime.Now;
        IsToday = Date == DateOnly.FromDateTime(now);
        NowOffset = ((now.Hour - StartHour) * 60 + now.Minute + now.Second / 60.0) * PixelsPerMinute;
    }

    /// <summary>Side-by-side columns for overlapping blocks (greedy per overlapping cluster).</summary>
    internal static void LayoutColumns(List<TimelineItemViewModel> items)
    {
        var sorted = items.OrderBy(i => i.StartMinutes).ThenByDescending(i => i.DurationMinutes).ToList();
        var cluster = new List<TimelineItemViewModel>();
        var columnEnds = new List<double>();
        double clusterEnd = double.MinValue;

        void Flush()
        {
            foreach (var c in cluster) c.Columns = Math.Max(1, columnEnds.Count);
            cluster.Clear();
            columnEnds.Clear();
        }

        foreach (var item in sorted)
        {
            if (item.StartMinutes >= clusterEnd) Flush();
            int col = columnEnds.FindIndex(e => e <= item.StartMinutes);
            if (col < 0)
            {
                col = columnEnds.Count;
                columnEnds.Add(item.End);
            }
            else
            {
                columnEnds[col] = item.End;
            }
            item.Column = col;
            cluster.Add(item);
            clusterEnd = Math.Max(clusterEnd, item.End);
        }
        Flush();
    }

    /// <summary>Time slot (snapped to 30 minutes) for a vertical position in the timeline.</summary>
    public TimeOnly SlotAt(double y)
    {
        var minutes = y / PixelsPerMinute + StartHour * 60;
        var snapped = (int)Math.Floor(minutes / 30) * 30;
        snapped = Math.Clamp(snapped, StartHour * 60, EndHour * 60 - 30);
        snapped = Math.Clamp(snapped, 0, 23 * 60 + 30);
        return new TimeOnly(snapped / 60, snapped % 60);
    }

    public double OffsetOf(TimeOnly t) => ((t.Hour - StartHour) * 60 + t.Minute) * PixelsPerMinute;

    public string Header => Date.ToString("dddd", CultureInfo.CurrentCulture);

    internal static void Replace<T>(ObservableCollection<T> target, IEnumerable<T> items)
    {
        target.Clear();
        foreach (var i in items) target.Add(i);
    }

    partial void OnDateChanged(DateOnly value) => OnPropertyChanged(nameof(Header));
}
