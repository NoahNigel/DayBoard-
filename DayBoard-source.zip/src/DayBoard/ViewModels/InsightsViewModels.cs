using System.Globalization;
using System.Windows.Media;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Models;
using DayBoard.Core.Stats;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;
using DayBoard.Services;

namespace DayBoard.ViewModels;

public sealed record RateRowViewModel(string Label, Brush Brush, int Done, int Total)
{
    public double Rate => Total == 0 ? 0 : (double)Done / Total;
    public string RateText => Total == 0 ? "–" : $"{Math.Round(Rate * 100)}%";
    public string CountText => $"{Done}/{Total}";
}

public sealed partial class StatsViewModel : ObservableObject, IPage
{
    [ObservableProperty] private string _period = "30";
    [ObservableProperty] private string _overallText = "";
    [ObservableProperty] private string _completedText = "";
    [ObservableProperty] private string _focusText = "";
    [ObservableProperty] private string _perDayText = "";
    [ObservableProperty] private List<RateRowViewModel> _byPriority = new();
    [ObservableProperty] private List<RateRowViewModel> _byCategory = new();
    [ObservableProperty] private int _heatYear = DateTime.Today.Year;
    [ObservableProperty] private DateOnly _heatMonth = new(DateTime.Today.Year, DateTime.Today.Month, 1);
    [ObservableProperty] private IReadOnlyDictionary<DateOnly, int> _yearData = new Dictionary<DateOnly, int>();
    [ObservableProperty] private IReadOnlyDictionary<DateOnly, int> _monthData = new Dictionary<DateOnly, int>();
    [ObservableProperty] private string _yearTotalText = "";
    [ObservableProperty] private string _monthTotalText = "";

    public string HeatMonthText => HeatMonth.ToString("MMMM yyyy", CultureInfo.CurrentCulture);
    public DayOfWeek WeekStart => AppServices.Current.Settings.Current.WeekStart;

    partial void OnPeriodChanged(string value) => Refresh();
    partial void OnHeatYearChanged(int value) => Refresh();
    partial void OnHeatMonthChanged(DateOnly value)
    {
        OnPropertyChanged(nameof(HeatMonthText));
        Refresh();
    }

    [RelayCommand] private void PrevYear() => HeatYear--;
    [RelayCommand] private void NextYear() => HeatYear++;
    [RelayCommand] private void PrevMonth() => HeatMonth = HeatMonth.AddMonths(-1);
    [RelayCommand] private void NextMonth() => HeatMonth = HeatMonth.AddMonths(1);

    public (DateOnly From, DateOnly To) Range(DateOnly today) => Period switch
    {
        "7" => (today.AddDays(-6), today),
        "30" => (today.AddDays(-29), today),
        "90" => (today.AddDays(-89), today),
        "Year" => (new DateOnly(today.Year, 1, 1), today),
        _ => (DateOnly.MinValue, today),
    };

    public void Refresh()
    {
        var s = AppServices.Current;
        var store = s.Planner.Store;
        var settings = s.Settings.Current;
        var today = s.Planner.Today;
        var (from, to) = Range(today);
        if (Period == "All")
        {
            var first = store.Tasks.Where(t => t.CompletedAt.HasValue).Select(t => DateOnly.FromDateTime(t.CompletedAt!.Value)).DefaultIfEmpty(today).Min();
            from = first;
        }

        var overall = StatsService.Overall(store.Tasks, store.Events, from, to, today);
        OverallText = overall.Total == 0 ? "–" : $"{Math.Round(overall.Rate * 100)}%";
        var completions = StatsService.CompletionsByDay(store.Tasks, from, to);
        int completed = completions.Values.Sum();
        CompletedText = completed.ToString(CultureInfo.CurrentCulture);
        int days = Math.Max(1, to.DayNumber - from.DayNumber + 1);
        PerDayText = (completed / (double)days).ToString("0.0", CultureInfo.CurrentCulture);
        var focus = store.Events.Where(e => e.Kind == TaskEventKind.Focus && DateOnly.FromDateTime(e.At) >= from && DateOnly.FromDateTime(e.At) <= to)
            .Sum(e => e.Minutes ?? 0);
        FocusText = DateUtil.FormatMinutes(focus);

        ByPriority = StatsService.RatesByPriority(store.Tasks, store.Events, from, to, today, p => ThemeService.PriorityHex(p, settings))
            .Select(r => new RateRowViewModel(r.Label, ColorUtil.Brush(r.Color), r.Done, r.Total)).ToList();
        ByCategory = StatsService.RatesByCategory(store.Tasks, store.Events, store.Categories, from, to, today)
            .Where(r => r.Total > 0 || r.Color is not null)
            .Select(r => new RateRowViewModel(r.Label, ColorUtil.Brush(r.Color ?? "#8A8F98"), r.Done, r.Total)).ToList();

        var y0 = new DateOnly(HeatYear, 1, 1);
        YearData = StatsService.CompletionsByDay(store.Tasks, y0, new DateOnly(HeatYear, 12, 31));
        YearTotalText = $"{YearData.Values.Sum()} tasks completed in {HeatYear}";
        var mEnd = HeatMonth.AddMonths(1).AddDays(-1);
        MonthData = StatsService.CompletionsByDay(store.Tasks, HeatMonth, mEnd);
        MonthTotalText = $"{MonthData.Values.Sum()} completed";
        OnPropertyChanged(nameof(WeekStart));
    }
}
