using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Models;
using DayBoard.Services;

namespace DayBoard.ViewModels;

public sealed partial class InboxViewModel : DropZoneViewModel, IPage
{
    [ObservableProperty] private string _newTitle = "";
    [ObservableProperty] private int _count;

    public ObservableCollection<TaskCardViewModel> Cards { get; } = new();

    public void Refresh()
    {
        var ctx = CardContext.Create();
        DayViewModel.Replace(Cards, ctx.Cards(AppServices.Current.Planner.Inbox()));
        Count = Cards.Count;
    }

    [RelayCommand]
    private void Add()
    {
        var title = NewTitle.Trim();
        if (title.Length == 0) return;
        AppServices.Current.Planner.AddTask(new TaskItem { Title = title, EstimateMinutes = null });
        NewTitle = "";
    }
}
