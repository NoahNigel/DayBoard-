using System.Windows;
using System.Windows.Controls;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Plugins;
using DayBoard.Services;
using DayBoard.ViewModels;
using Wpf.Ui.Controls;

namespace DayBoard.Hosting;

/// <summary>A sidebar button for a plugin page.</summary>
public sealed partial class PluginNavItem : ObservableObject
{
    public required string Key { get; init; }
    public required string Title { get; init; }
    public required SymbolRegular Symbol { get; init; }
    [ObservableProperty] private string _tooltip = "";
    [ObservableProperty] private bool _isSelected;
}

/// <summary>A page a plugin added to the sidebar.</summary>
public sealed class PluginPageEntry
{
    internal PluginPageEntry(PluginRunner runner, string pluginId, string key, PluginPage page, string title, string heading, DateNavigation navigation, SymbolRegular symbol)
    {
        PluginId = pluginId;
        Key = key;
        Page = page;
        Title = title;
        Heading = heading;
        Navigation = navigation;
        Symbol = symbol;
        Host = new PluginPageHost(runner, this);
    }

    public string PluginId { get; }
    public string Key { get; }
    public PluginPage Page { get; }
    public string Title { get; }

    /// <summary>The header title: the page's Heading (API 3), or its Title.</summary>
    public string Heading { get; }
    public DateNavigation Navigation { get; }
    public SymbolRegular Symbol { get; }

    /// <summary>What the main window shows for this page.</summary>
    public PluginPageHost Host { get; }
}

/// <summary>
/// Holds a plugin page's view in the main window. Created once per page, so the plugin's view keeps its state between
/// visits. It starts with no DataContext, so a plugin's bindings never see DayBoard's own view models.
/// </summary>
public sealed class PluginPageHost : Border, IPage
{
    private readonly PluginRunner _runner;
    private readonly PluginPageEntry _entry;
    private bool _shown;

    internal PluginPageHost(PluginRunner runner, PluginPageEntry entry)
    {
        _runner = runner;
        _entry = entry;
        DataContext = null;
        Focusable = false;
    }

    public void Refresh()
    {
        if (!_runner.IsRunning(_entry.PluginId)) return;
        if (Child is null)
        {
            var view = _runner.Guard(_entry.PluginId, "create page", _entry.Page.CreateView);
            if (view is null) return;
            Child = view;
        }
        _shown = true;
        _runner.Guard(_entry.PluginId, "show page", () => _entry.Page.Show(AppServices.Current.Main.SelectedDate));
    }

    /// <summary>Another page opened.</summary>
    public void HidePage()
    {
        if (!_shown) return;
        _shown = false;
        _runner.Guard(_entry.PluginId, "hide page", _entry.Page.Hide);
    }

    public string Subtitle(DateOnly date) => _runner.Guard(_entry.PluginId, "page subtitle", () => _entry.Page.Subtitle(date)) ?? "";
}

/// <summary>An item a plugin added to the task card menu.</summary>
public sealed record PluginTaskActionEntry(string PluginId, TaskAction Action, string Title, SymbolRegular Symbol);

/// <summary>A panel a plugin added to the top of the Day view.</summary>
public sealed class PluginPanelEntry
{
    private readonly PluginRunner _runner;

    internal PluginPanelEntry(PluginRunner runner, string pluginId, DayPanel panel)
    {
        _runner = runner;
        PluginId = pluginId;
        Panel = panel;
        Host = new Border { DataContext = null, Focusable = false };
    }

    public string PluginId { get; }
    public DayPanel Panel { get; }

    /// <summary>Holds the plugin's view. The Day view moves this into its panel area each time it's built.</summary>
    public Border Host { get; }

    /// <summary>The date the panel was last shown for, or null while it's hidden.</summary>
    public DateOnly? Shown { get; set; }

    /// <summary>Creates the plugin's view the first time. False when the plugin failed doing so.</summary>
    public bool EnsureView()
    {
        if (Host.Child is not null) return true;
        var view = _runner.Guard(PluginId, "create Day panel", Panel.CreateView);
        if (view is null) return false;
        Host.Child = view;
        return true;
    }

    /// <summary>Takes the panel out of the Day view it was in (the Day view is rebuilt whenever it's opened).</summary>
    public void Detach()
    {
        switch (Host.Parent)
        {
            case Panel p:
                p.Children.Remove(Host);
                break;
            case ContentControl c:
                c.Content = null;
                break;
            case Decorator d:
                d.Child = null;
                break;
        }
    }
}
