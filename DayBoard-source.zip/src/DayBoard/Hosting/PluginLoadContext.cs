using System.IO;
using System.Reflection;
using System.Runtime.Loader;

namespace DayBoard.Hosting;

/// <summary>
/// Loads one code plugin. Assemblies DayBoard has (WPF, WPF-UI, CommunityToolkit.Mvvm, the plugin API and .NET itself)
/// always come from DayBoard, so plugins share their types. Anything else comes from the plugin's folder.
/// Files are read into memory, so they're never locked and a plugin can be updated while it runs.
/// </summary>
internal sealed class PluginLoadContext : AssemblyLoadContext
{
    private readonly string _folder;

    public PluginLoadContext(string pluginId, string folder) : base("DayBoard plugin " + pluginId)
    {
        PluginId = pluginId;
        _folder = folder;
    }

    public string PluginId { get; }

    public Assembly LoadPlugin(string path) => LoadFromStream(new MemoryStream(File.ReadAllBytes(path)));

    protected override Assembly? Load(AssemblyName name)
    {
        if (string.IsNullOrEmpty(name.Name)) return null;
        var shared = Default.Assemblies.FirstOrDefault(a => string.Equals(a.GetName().Name, name.Name, StringComparison.OrdinalIgnoreCase));
        if (shared is not null) return shared;
        try
        {
            // Whatever version DayBoard has: two copies of WPF-UI (say) would break the plugin's controls.
            return Default.LoadFromAssemblyName(new AssemblyName(name.Name));
        }
        catch (Exception ex) when (ex is FileNotFoundException or FileLoadException or BadImageFormatException)
        {
        }
        var path = Path.Combine(_folder, name.Name + ".dll");
        return File.Exists(path) ? LoadFromStream(new MemoryStream(File.ReadAllBytes(path))) : null;
    }

    /// <summary>
    /// The plugin whose code is in this exception's stack, if any. <paramref name="builtIn"/> names the plugin an
    /// assembly of DayBoard's own belongs to (plugins that come with DayBoard don't have a load context of their own).
    /// </summary>
    public static string? PluginIn(Exception? ex, Func<Assembly, string?>? builtIn = null)
    {
        for (var e = ex; e is not null; e = e.InnerException)
        {
            try
            {
                foreach (var frame in new System.Diagnostics.StackTrace(e, false).GetFrames())
                {
                    var asm = frame.GetMethod()?.DeclaringType?.Assembly;
                    if (asm is null) continue;
                    if (GetLoadContext(asm) is PluginLoadContext plc) return plc.PluginId;
                    if (builtIn?.Invoke(asm) is { } id) return id;
                }
            }
            catch (Exception)
            {
                // Reading a stack trace must never make things worse.
            }
            if (e is AggregateException agg)
            {
                foreach (var inner in agg.InnerExceptions)
                {
                    if (PluginIn(inner, builtIn) is { } innerId) return innerId;
                }
            }
        }
        return null;
    }
}
