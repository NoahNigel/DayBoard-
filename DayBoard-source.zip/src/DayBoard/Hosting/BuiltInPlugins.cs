using DayBoard.Data.Plugins;

namespace DayBoard.Hosting;

/// <summary>
/// Plugins that come with DayBoard. They're written against the plugin API like any other code plugin, but they're part
/// of DayBoard.exe: on until they're unticked, updated with DayBoard, and never removed or replaced by a file.
/// </summary>
public static class BuiltInPlugins
{
    public static IReadOnlyList<InstalledPlugin> All(Version appVersion) => new[]
    {
        new InstalledPlugin
        {
            Id = LegacySettings.FocusPluginId,
            Directory = "",
            BuiltInType = "DayBoard.Focus.FocusPlugin, DayBoard.Focus",
            Manifest = new PluginManifest
            {
                FormatVersion = 1,
                Id = LegacySettings.FocusPluginId,
                Name = "Focus",
                Version = appVersion.ToString(3),
                Author = "DayBoard",
                Description = "A focus timer for one task at a time, with breaks. Time spent is logged to the task.",
                Kind = PluginKind.Code,
                ApiVersion = PluginFormat.CurrentApiVersion,
                Entry = "DayBoard.Focus.dll",
            },
        },
    };
}
