using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Threading;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Infrastructure;
using DayBoard.Plugins;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Hosting;

/// <summary>
/// Runs the ticked code plugins: loads each into its own load context (plugins that come with DayBoard are part of the
/// exe), starts and stops it, and keeps the pages, Day view panels and task menu items it adds. Every call into plugin
/// code is guarded: a plugin that throws is stopped and unticked, and DayBoard carries on.
/// </summary>
public sealed class PluginRunner
{
    public const int MaxPagesPerPlugin = 2;
    public const int MaxPanelsPerPlugin = 2;
    public const int MaxTaskActionsPerPlugin = 2;
    private const string KeyPrefix = "plugin:";

    private readonly Dictionary<string, Running> _running = new(StringComparer.Ordinal);
    private readonly Dictionary<string, string> _errors = new(StringComparer.Ordinal);
    private readonly Dictionary<Assembly, string> _builtInAssemblies = new();
    private bool _syncing;
    private bool _syncAgain;
    private bool _tasksQueued;

    public PluginRunner(PluginDataStore data, bool safeMode)
    {
        Data = data;
        SafeMode = safeMode;
    }

    private static AppServices S => AppServices.Current;

    public PluginDataStore Data { get; }

    /// <summary>Started with --safe-mode: no code plugins run until DayBoard restarts, except the ones that come with it.</summary>
    public bool SafeMode { get; }

    /// <summary>Raised after pages or panels were added or removed.</summary>
    public event EventHandler? Changed;

    // Plugins that come with DayBoard first, then the others by name: the order of their pages, panels and menu items.
    private IEnumerable<Running> Ordered => _running.Values
        .OrderBy(r => r.Plugin.IsBuiltIn ? 0 : 1).ThenBy(r => r.Plugin.Name, StringComparer.CurrentCultureIgnoreCase);

    public IReadOnlyList<PluginPageEntry> Pages => Ordered.SelectMany(r => r.Pages).ToList();

    public IReadOnlyList<PluginPanelEntry> Panels => Ordered.SelectMany(r => r.Panels).ToList();

    public IReadOnlyList<PluginTaskActionEntry> TaskActions => Ordered.SelectMany(r => r.TaskActions).ToList();

    public bool IsRunning(string pluginId) => _running.ContainsKey(pluginId);

    /// <summary>Why a plugin isn't running (it failed to start or stopped after an error), or null.</summary>
    public string? ErrorFor(string pluginId) => _errors.GetValueOrDefault(pluginId);

    public static string PageKey(string pluginId, string pageId) => $"{KeyPrefix}{pluginId}/{pageId}";

    public static bool IsPageKey(string? key) => key?.StartsWith(KeyPrefix, StringComparison.Ordinal) == true;

    public PluginPageEntry? FindPage(string? key) => key is null ? null : Pages.FirstOrDefault(p => p.Key == key);

    /// <summary>The pages and panels a running plugin added, for the message shown after adding it.</summary>
    public (int Pages, int Panels, string? FirstPage) Contributions(string pluginId) =>
        _running.TryGetValue(pluginId, out var r) ? (r.Pages.Count, r.Panels.Count, r.Pages.FirstOrDefault()?.Title) : (0, 0, null);

    // ---------------------------------------------------------------- start and stop

    /// <summary>Starts ticked code plugins that aren't running, and stops those that were unticked, removed or updated.</summary>
    public void Sync()
    {
        if (_syncing)
        {
            _syncAgain = true;
            return;
        }
        _syncing = true;
        try
        {
            do
            {
                _syncAgain = false;
                var settings = S.Settings.Current;
                var wanted = S.Plugins.All
                    .Where(p => p.IsUsable && p.IsCode && (p.IsBuiltIn || !SafeMode) && S.Plugins.IsOn(p, settings)).ToList();
                foreach (var r in _running.Values.ToList())
                {
                    var now = wanted.FirstOrDefault(p => p.Id == r.Plugin.Id);
                    if (now is null || Stamp(now) != r.Stamp) Stop(r.Plugin.Id);
                }
                foreach (var p in wanted)
                {
                    if (!_running.ContainsKey(p.Id)) Start(p);
                }
                foreach (var id in _errors.Keys.ToList())
                {
                    if (S.Plugins.All.All(p => p.Id != id)) _errors.Remove(id);
                }
            }
            while (_syncAgain);
        }
        finally
        {
            _syncing = false;
        }
    }

    // Changes when the plugin is updated (a new folder is written on every install).
    private static string Stamp(InstalledPlugin p)
    {
        if (p.IsBuiltIn) return "built in";
        try
        {
            var f = new FileInfo(p.EntryPath!);
            return $"{p.Manifest?.Version}|{f.Length}|{f.LastWriteTimeUtc.Ticks}";
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return p.Manifest?.Version ?? "";
        }
    }

    private void Start(InstalledPlugin plugin)
    {
        _errors.Remove(plugin.Id);
        Running? running = null;
        StartMarker.Write(plugin.Id);
        try
        {
            Type type;
            if (plugin.BuiltInType is { } builtIn)
            {
                type = Type.GetType(builtIn, throwOnError: true)!;
                _builtInAssemblies[type.Assembly] = plugin.Id;
            }
            else
            {
                var context = new PluginLoadContext(plugin.Id, plugin.Directory);
                type = FindEntryType(context.LoadPlugin(plugin.EntryPath!));
            }
            var instance = (IDayBoardPlugin)Activator.CreateInstance(type)!;
            running = new Running(plugin, Stamp(plugin), new PluginHostContext(this, plugin), instance);
            _running[plugin.Id] = running;
            instance.Start(running.Host);
            Log.Info($"Started plugin {plugin.Id} {plugin.Manifest?.Version}");
        }
        catch (Exception ex)
        {
            var error = ex is TargetInvocationException { InnerException: { } inner } ? inner : ex;
            Log.Error($"Start plugin {plugin.Id}", error);
            if (running is not null) StopQuietly(running);
            _running.Remove(plugin.Id);
            _errors[plugin.Id] = "Couldn't start: " + Describe(error);
            Changed?.Invoke(this, EventArgs.Empty);
            S.Main?.ShowToast($"{plugin.Name} couldn't start. Settings › Plugins says why.");
        }
        finally
        {
            StartMarker.Clear();
        }
    }

    private static Type FindEntryType(Assembly assembly)
    {
        Type[] types;
        try
        {
            types = assembly.GetExportedTypes();
        }
        catch (ReflectionTypeLoadException ex)
        {
            types = ex.Types.Where(t => t is not null).ToArray()!;
        }
        return types.FirstOrDefault(t => typeof(IDayBoardPlugin).IsAssignableFrom(t) && t is { IsAbstract: false, IsInterface: false } &&
                                         t.GetConstructor(Type.EmptyTypes) is not null)
               ?? throw new PluginException("It has no public IDayBoardPlugin class with a constructor that takes no arguments.");
    }

    private void Stop(string pluginId)
    {
        if (!_running.TryGetValue(pluginId, out var r)) return;
        // Leave its page first, so the page is hidden (and saves) while the plugin is still running.
        if (r.Pages.Any(p => p.Key == S.Main.CurrentView)) S.Main.CurrentView = PageKeys.Day;
        HidePanels(r);
        _running.Remove(pluginId);
        StopQuietly(r);
        Log.Info($"Stopped plugin {pluginId}");
        Changed?.Invoke(this, EventArgs.Empty);
    }

    private static void StopQuietly(Running r)
    {
        // The plugin can still use the host while it stops, to save what's pending (a note, focus time).
        try
        {
            r.Instance.Stop();
        }
        catch (Exception ex)
        {
            Log.Error($"Stop plugin {r.Plugin.Id}", ex);
        }
        r.Host.IsStopped = true;
    }

    /// <summary>Stops every plugin (DayBoard is closing). Plugins save what's pending in Stop.</summary>
    public void StopAll()
    {
        foreach (var r in _running.Values.ToList())
        {
            HidePanels(r);
            foreach (var p in r.Pages) p.Host.HidePage();
            _running.Remove(r.Plugin.Id);
            StopQuietly(r);
        }
    }

    /// <summary>Stops a plugin that threw, unticks it and says so. Its error shows in Settings › Plugins.</summary>
    public void Fault(string pluginId, Exception ex, string what)
    {
        Log.Error($"Plugin {pluginId} ({what})", ex);
        if (!_running.TryGetValue(pluginId, out var r)) return;
        r.Faulted = true;
        _errors[pluginId] = "Turned off after an error: " + Describe(ex);
        S.Settings.Update(s => S.Plugins.SetOn(s, pluginId, false));
        Stop(pluginId);
        S.Main.ShowToast($"{r.Plugin.Name} ran into a problem and was turned off. You can turn it back on in Settings › Plugins.");
    }

    private static string Describe(Exception ex)
    {
        var message = ex.Message.Trim();
        if (message.Length > 160) message = message[..159] + "…";
        return ex is PluginException ? message : $"{message} ({ex.GetType().Name})";
    }

    /// <summary>Runs plugin code. When it throws, the plugin is stopped and the default value is returned.</summary>
    internal T? Guard<T>(string pluginId, string what, Func<T> call)
    {
        if (!_running.TryGetValue(pluginId, out var r) || r.Faulted) return default;
        try
        {
            return call();
        }
        catch (Exception ex)
        {
            Fault(pluginId, ex, what);
            return default;
        }
    }

    internal void Guard(string pluginId, string what, Action call) => Guard<bool>(pluginId, what, () =>
    {
        call();
        return true;
    });

    /// <summary>Handles an unhandled UI exception thrown by plugin code. Returns false when it isn't a plugin's.</summary>
    public bool TryHandle(Exception ex)
    {
        if (FindPlugin(ex) is not { } id || !_running.ContainsKey(id)) return false;
        Fault(id, ex, "unhandled");
        return true;
    }

    /// <summary>The plugin whose code is in an exception's stack, if any.</summary>
    public string? FindPlugin(Exception ex) => PluginLoadContext.PluginIn(ex, a => _builtInAssemblies.GetValueOrDefault(a));

    // ---------------------------------------------------------------- pages and panels

    internal void AddPage(PluginHostContext host, PluginPage page)
    {
        if (host.IsStopped || !_running.TryGetValue(host.PluginId, out var r)) return;
        ArgumentNullException.ThrowIfNull(page);
        if (r.Pages.Count >= MaxPagesPerPlugin) throw new InvalidOperationException($"A plugin can add up to {MaxPagesPerPlugin} pages.");
        var id = page.Id?.Trim() ?? "";
        if (id.Length is 0 or > 40 || id.Any(c => !char.IsAsciiLetterOrDigit(c) && c != '-'))
            throw new ArgumentException("A page's Id must be 1 to 40 letters, digits or dashes.", nameof(page));
        var key = PageKey(host.PluginId, id);
        if (r.Pages.Any(p => p.Key == key)) throw new ArgumentException($"This plugin already has a page called \"{id}\".", nameof(page));
        var title = page.Title?.Trim() ?? "";
        if (title.Length == 0) throw new ArgumentException("A page needs a Title.", nameof(page));
        if (title.Length > 24) title = title[..24];
        var heading = page.Heading?.Trim() is { Length: > 0 } h ? h.Length > 60 ? h[..60] : h : title;
        var entry = new PluginPageEntry(this, host.PluginId, key, page, title, heading, page.Navigation, Symbols.Parse(page.Icon, Wpf.Ui.Controls.SymbolRegular.PuzzlePiece24));
        r.Pages.Add(entry);
        Changed?.Invoke(this, EventArgs.Empty);
    }

    internal void AddDayPanel(PluginHostContext host, DayPanel panel)
    {
        if (host.IsStopped || !_running.TryGetValue(host.PluginId, out var r)) return;
        ArgumentNullException.ThrowIfNull(panel);
        if (r.Panels.Count >= MaxPanelsPerPlugin) throw new InvalidOperationException($"A plugin can add up to {MaxPanelsPerPlugin} Day view panels.");
        r.Panels.Add(new PluginPanelEntry(this, host.PluginId, panel));
        Changed?.Invoke(this, EventArgs.Empty);
    }

    internal void AddTaskAction(PluginHostContext host, TaskAction action)
    {
        if (host.IsStopped || !_running.TryGetValue(host.PluginId, out var r)) return;
        ArgumentNullException.ThrowIfNull(action);
        if (r.TaskActions.Count >= MaxTaskActionsPerPlugin) throw new InvalidOperationException($"A plugin can add up to {MaxTaskActionsPerPlugin} task menu items.");
        var title = action.Title?.Trim() ?? "";
        if (title.Length == 0) throw new ArgumentException("A task action needs a Title.", nameof(action));
        if (title.Length > 40) title = title[..40];
        r.TaskActions.Add(new PluginTaskActionEntry(host.PluginId, action, title, Symbols.Parse(action.Icon, Wpf.Ui.Controls.SymbolRegular.PuzzlePiece24)));
    }

    /// <summary>A task menu item was clicked.</summary>
    public void RunTaskAction(PluginTaskActionEntry entry, Guid taskId) => Guard(entry.PluginId, "task menu item", () => entry.Action.Invoke(taskId));

    /// <summary>The Day view shows <paramref name="date"/>: panels that showed another day are hidden first.</summary>
    public void ShowPanels(DateOnly date)
    {
        foreach (var p in Panels)
        {
            if (!p.EnsureView()) continue;
            if (p.Shown is { } shown && shown != date) Guard(p.PluginId, "hide Day panel", p.Panel.Hide);
            if (!IsRunning(p.PluginId)) continue;
            p.Shown = date;
            Guard(p.PluginId, "show Day panel", () => p.Panel.Show(date));
        }
    }

    /// <summary>The Day view closed.</summary>
    public void HidePanels()
    {
        foreach (var r in _running.Values.ToList()) HidePanels(r);
    }

    private void HidePanels(Running r)
    {
        foreach (var p in r.Panels.Where(p => p.Shown is not null))
        {
            p.Shown = null;
            Guard(p.PluginId, "hide Day panel", p.Panel.Hide);
        }
    }

    // ---------------------------------------------------------------- events

    public void OnDateChanged()
    {
        foreach (var r in _running.Values.ToList()) r.Host.RaiseDateChanged();
    }

    public void OnThemeChanged()
    {
        foreach (var r in _running.Values.ToList()) r.Host.RaiseThemeChanged();
    }

    public void OnTaskDragEnded()
    {
        foreach (var r in _running.Values.ToList()) r.Host.RaiseTaskDragEnded();
    }

    /// <summary>Tasks changed. Several changes in a row are passed on as one.</summary>
    public void OnTasksChanged()
    {
        if (_tasksQueued || _running.Count == 0) return;
        _tasksQueued = true;
        Application.Current.Dispatcher.BeginInvoke(DispatcherPriority.Background, new Action(() =>
        {
            _tasksQueued = false;
            foreach (var r in _running.Values.ToList()) r.Host.RaiseTasksChanged();
        }));
    }

    private sealed class Running(InstalledPlugin plugin, string stamp, PluginHostContext host, IDayBoardPlugin instance)
    {
        public InstalledPlugin Plugin { get; } = plugin;
        public string Stamp { get; } = stamp;
        public PluginHostContext Host { get; } = host;
        public IDayBoardPlugin Instance { get; } = instance;
        public List<PluginPageEntry> Pages { get; } = new();
        public List<PluginPanelEntry> Panels { get; } = new();
        public List<PluginTaskActionEntry> TaskActions { get; } = new();
        public bool Faulted { get; set; }
    }
}

/// <summary>
/// Remembers which plugin was starting (or crashed DayBoard), so that if DayBoard closes unexpectedly, the next start
/// turns that plugin off instead of crashing again.
/// </summary>
public static class StartMarker
{
    private static string Path => System.IO.Path.Combine(AppPaths.DataDir, "plugin-check.txt");

    public static void Write(string pluginId) => Save("start " + pluginId);

    /// <summary>Plugin code crashed DayBoard (an exception on another thread).</summary>
    public static void WriteCrash(string pluginId) => Save("crash " + pluginId);

    public static void Clear()
    {
        try
        {
            File.Delete(Path);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }

    /// <summary>The plugin that made the last run end, if any, and clears the note.</summary>
    public static (string PluginId, bool Crashed)? TakeLast()
    {
        try
        {
            if (!File.Exists(Path)) return null;
            var text = File.ReadAllText(Path).Trim();
            Clear();
            var parts = text.Split(' ', 2);
            return parts.Length == 2 && PluginFormat.IsValidId(parts[1]) ? (parts[1], parts[0] == "crash") : null;
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
            return null;
        }
    }

    private static void Save(string text)
    {
        try
        {
            File.WriteAllText(Path, text);
        }
        catch (Exception ex) when (ex is IOException or UnauthorizedAccessException)
        {
        }
    }
}
