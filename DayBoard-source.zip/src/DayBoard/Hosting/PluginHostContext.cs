using System.IO;
using System.Windows;
using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Infrastructure;
using DayBoard.Plugins;
using DayBoard.Services;
using Microsoft.Win32;

namespace DayBoard.Hosting;

/// <summary>What one running code plugin gets from DayBoard. Calls from other threads are passed to the UI thread.</summary>
internal sealed class PluginHostContext : IDayBoardHost, IPluginStorage
{
    private readonly PluginRunner _runner;

    public PluginHostContext(PluginRunner runner, InstalledPlugin plugin)
    {
        _runner = runner;
        PluginId = plugin.Id;
        Name = plugin.Name;
    }

    public string Name { get; }

    /// <summary>Set when the plugin is stopped. Later calls that add things are ignored.</summary>
    public bool IsStopped { get; set; }

    private static AppServices S => AppServices.Current;

    // ---------------------------------------------------------------- IDayBoardHost

    public int ApiVersion => PluginFormat.CurrentApiVersion;

    public Version AppVersion => PluginService.AppVersion;

    public string PluginId { get; }

    public string DataFolder
    {
        get
        {
            var dir = Path.Combine(AppPaths.DataDir, "plugin-data", PluginId);
            Directory.CreateDirectory(dir);
            return dir;
        }
    }

    public DateOnly Today => OnUi(() => S.Planner.Today);

    public DateOnly SelectedDate => OnUi(() => S.Main.SelectedDate);

    public DayOfWeek WeekStart => OnUi(() => S.Settings.Current.WeekStart);

    public event EventHandler? DateChanged;
    public event EventHandler? TasksChanged;
    public event EventHandler? ThemeChanged;

    internal void RaiseDateChanged() => Raise(DateChanged, "date change");
    internal void RaiseTasksChanged() => Raise(TasksChanged, "task change");
    internal void RaiseThemeChanged() => Raise(ThemeChanged, "theme change");
    internal void RaiseTaskDragEnded() => Raise(TaskDragEnded, "end of a drag");

    public event EventHandler? TaskDragEnded;

    private void Raise(EventHandler? handler, string what)
    {
        if (handler is null || IsStopped) return;
        foreach (EventHandler h in handler.GetInvocationList())
        {
            if (IsStopped) return;
            _runner.Guard(PluginId, what, () => h(this, EventArgs.Empty));
        }
    }

    public bool IsDarkTheme => ThemeService.IsDark;

    public IPluginStorage Storage => this;

    public IReadOnlyList<PluginTask> TasksOn(DateOnly date) => OnUi(() => Snapshot(S.Planner.TasksOn(date)));

    public PluginTask? FindTask(Guid id) => OnUi(() => S.Planner.Store.FindTask(id) is { IsSkipped: false } t ? Snapshot(t) : null);

    public IReadOnlyList<PluginTask> InboxTasks() => OnUi(() => Snapshot(S.Planner.Inbox()));

    public IReadOnlyList<PluginTask> OverdueTasks() => OnUi(() => Snapshot(S.Planner.OverdueBefore(S.Planner.Today)));

    public IReadOnlyList<PluginTask> AllTasks() => OnUi(() => Snapshot(S.Planner.Visible
        .OrderBy(t => t.ScheduledDate ?? DateOnly.MaxValue)
        .ThenBy(t => t.StartTime ?? TimeOnly.MaxValue)
        .ThenBy(t => t.SortOrder)
        .ThenBy(t => t.CreatedAt)));

    public IReadOnlyList<PluginTaskHistory> TaskHistory(DateOnly from, DateOnly to) => OnUi(() =>
        (IReadOnlyList<PluginTaskHistory>)S.Planner.Store.Events
            .Where(e => InRange(DateOnly.FromDateTime(e.At), from, to) || e.FromDate is { } fd && InRange(fd, from, to))
            .OrderBy(e => e.At)
            .Select(e => new PluginTaskHistory(e.TaskId, (PluginHistoryKind)(int)e.Kind, e.At, e.FromDate, e.ToDate, e.Minutes))
            .ToList());

    private static bool InRange(DateOnly d, DateOnly from, DateOnly to) => d >= from && d <= to;

    public PluginCompletion Completion(DateOnly from, DateOnly to) => OnUi(() =>
    {
        var store = S.Planner.Store;
        var row = Core.Stats.StatsService.Overall(store.Tasks, store.Events, from, to, S.Planner.Today);
        return new PluginCompletion(row.Done, row.Total);
    });

    private static IReadOnlyList<PluginTask> Snapshot(IEnumerable<TaskItem> tasks)
    {
        var categories = S.Planner.Store.Categories.ToDictionary(c => c.Id, c => c.Name);
        return tasks.Select(t => Snapshot(t, categories)).ToList();
    }

    private static PluginTask Snapshot(TaskItem t) => Snapshot(t, null);

    private static PluginTask Snapshot(TaskItem t, Dictionary<Guid, string>? categories) => new(
        t.Id, t.Title, t.ScheduledDate, t.StartTime, t.EstimateMinutes, t.IsDone, t.Priority.ToString(),
        t.CategoryId is not { } cid ? null : categories is null ? S.Planner.Store.FindCategory(cid)?.Name : categories.GetValueOrDefault(cid))
    {
        ActualMinutes = t.ActualMinutes,
        Subtasks = t.Subtasks.Select(x => new PluginSubtask(x.Id, x.Title, x.IsDone)).ToList(),
        Status = (PluginTaskStatus)(int)t.Status,
        IsUrgent = t.IsUrgent,
        DueDate = t.DueDate,
        CompletedAt = t.CompletedAt,
        RolloverCount = t.RolloverCount,
    };

    public void LogTime(Guid taskId, int minutes) => OnUi(() =>
    {
        if (IsStopped) return;
        if (minutes is < 1 or > 24 * 60) throw new ArgumentOutOfRangeException(nameof(minutes), "Log 1 to 1440 minutes at a time.");
        S.Planner.LogFocusTime(taskId, minutes);
    });

    public void SetDone(Guid taskId, bool done) => OnUi(() =>
    {
        if (!IsStopped && S.Planner.Store.FindTask(taskId) is not null) S.Planner.SetDone(taskId, done);
    });

    public void ToggleSubtask(Guid taskId, Guid subtaskId) => OnUi(() =>
    {
        if (!IsStopped) S.Planner.ToggleSubtask(taskId, subtaskId);
    });

    public void SetStatus(Guid taskId, PluginTaskStatus status) => OnUi(() =>
    {
        if (!Enum.IsDefined(status)) throw new ArgumentOutOfRangeException(nameof(status));
        if (!IsStopped && S.Planner.Store.FindTask(taskId) is not null) S.Planner.SetStatus(taskId, (TaskState)(int)status);
    });

    public void SetQuadrant(Guid taskId, bool urgent, bool important) => OnUi(() =>
    {
        if (!IsStopped && S.Planner.Store.FindTask(taskId) is not null) S.Planner.SetQuadrant(taskId, urgent, important);
    });

    public FrameworkElement? CreateTaskCard(Guid taskId, bool showDate = false) => OnUi(() =>
    {
        if (IsStopped || S.Planner.Store.FindTask(taskId) is not { } task) return null;
        return (FrameworkElement)new Views.Controls.TaskCard { DataContext = ViewModels.CardContext.Create(showDate).Card(task) };
    });

    public void AddTaskAction(TaskAction action) => OnUi(() => _runner.AddTaskAction(this, action));

    public void ShowPage(string pageId) => OnUi(() =>
    {
        if (IsStopped || _runner.FindPage(PluginRunner.PageKey(PluginId, pageId)) is not { } page) return;
        S.Windows.ShowMain();
        S.Main.CurrentView = page.Key;
    });

    public void AddPage(PluginPage page) => OnUi(() => _runner.AddPage(this, page));

    public void AddDayPanel(DayPanel panel) => OnUi(() => _runner.AddDayPanel(this, panel));

    public void ShowDate(DateOnly date, string? pageId = null) => OnUi(() =>
    {
        if (IsStopped) return;
        var key = pageId is null ? null : PluginRunner.PageKey(PluginId, pageId);
        S.Windows.ShowMain();
        S.Main.ShowDate(date, key is not null && _runner.FindPage(key) is not null ? key : ViewModels.PageKeys.Day);
    });

    public void ShowToast(string message) => OnUi(() =>
    {
        if (!IsStopped && !string.IsNullOrWhiteSpace(message)) S.Main.ShowToast(Limit(message, 200));
    });

    public void ShowNotification(string title, string message) => OnUi(() =>
    {
        if (!IsStopped) S.Tray?.Notify(Limit(title, 60), Limit(message, 250));
    });

    /// <summary>The self-test answers the save dialog with this path.</summary>
    internal static string? SelfTestSavePath { get; set; }

    public string? AskSaveFile(string title, string fileName, string filter) => OnUi(() =>
    {
        if (IsStopped) return null;
        if (SelfTestSavePath is { } testPath) return testPath;
        var dlg = new SaveFileDialog
        {
            Title = title,
            FileName = fileName,
            AddExtension = true,
            OverwritePrompt = true,
        };
        try
        {
            dlg.Filter = filter;
        }
        catch (ArgumentException)
        {
            dlg.Filter = "All files (*.*)|*.*";
        }
        return dlg.ShowDialog(Application.Current.MainWindow) == true ? dlg.FileName : null;
    });

    public void Log(string message, Exception? error = null)
    {
        if (error is null) Data.Log.Info($"[{PluginId}] {message}");
        else Data.Log.Error($"[{PluginId}] {message}", error);
    }

    // ---------------------------------------------------------------- IPluginStorage

    string? IPluginStorage.Get(string key) => OnUi(() => _runner.Data.Get(PluginId, key));

    IReadOnlyDictionary<string, string> IPluginStorage.GetAll(string prefix) => OnUi(() => _runner.Data.GetAll(PluginId, prefix));

    void IPluginStorage.Set(string key, string? value) => OnUi(() => _runner.Data.Set(PluginId, key, value, DateTime.Now));

    // ---------------------------------------------------------------- helpers

    private static string Limit(string text, int max) => text.Length <= max ? text : text[..(max - 1)] + "…";

    private static T OnUi<T>(Func<T> f)
    {
        var d = Application.Current.Dispatcher;
        return d.CheckAccess() ? f() : d.Invoke(f);
    }

    private static void OnUi(Action a)
    {
        var d = Application.Current.Dispatcher;
        if (d.CheckAccess()) a();
        else d.Invoke(a);
    }
}
