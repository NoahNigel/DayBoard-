using System.Windows;
using System.Windows.Input;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views.Windows;

/// <summary>Small always-on-top window opened by the global hotkey. Enter saves, Esc or clicking away closes.</summary>
public partial class QuickAddWindow : Window
{
    private readonly QuickAddViewModel _vm;
    private bool _closing;

    public QuickAddWindow(QuickAddViewModel vm)
    {
        _vm = vm;
        InitializeComponent();
        DataContext = vm;
        PreviewKeyDown += OnKey;
        Deactivated += (_, _) =>
        {
            // Popups (combo boxes, date picker) belong to this window, so deactivation means the user clicked elsewhere.
            if (!_closing && IsLoaded) SafeClose();
        };
        PositionOnActiveScreen();
        Loaded += (_, _) =>
        {
            TitleBox.Focus();
            Keyboard.Focus(TitleBox);
        };
        MouseLeftButtonDown += (_, e) =>
        {
            if (e.OriginalSource is System.Windows.Controls.Border) DragMove();
        };
    }

    private void PositionOnActiveScreen()
    {
        // Centre horizontally in the upper third of the work area that contains the mouse.
        var area = SystemParameters.WorkArea;
        var owner = Application.Current.MainWindow;
        if (owner is { IsVisible: true, WindowState: not WindowState.Minimized })
        {
            Left = owner.Left + (owner.ActualWidth - Width) / 2;
            Top = owner.Top + Math.Max(60, owner.ActualHeight / 5);
        }
        else
        {
            Left = area.Left + (area.Width - Width) / 2;
            Top = area.Top + area.Height / 5;
        }
    }

    private void OnKey(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Escape)
        {
            e.Handled = true;
            SafeClose();
        }
        else if (e.Key == Key.Enter && Keyboard.Modifiers == ModifierKeys.None)
        {
            e.Handled = true;
            if (_vm.Save() is { } task)
            {
                AppServices.Current.Main.ShowToast($"Added \"{task.Title}\"", undo: true);
                AppServices.Current.Main.UpdateBadges();
            }
            SafeClose();
        }
    }

    private void SafeClose()
    {
        if (_closing) return;
        _closing = true;
        Dispatcher.BeginInvoke(Close);
    }
}
