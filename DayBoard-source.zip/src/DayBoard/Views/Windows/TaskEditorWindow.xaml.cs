using System.Windows;
using System.Windows.Input;
using CommunityToolkit.Mvvm.Input;
using DayBoard.Core.Models;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views.Windows;

public partial class TaskEditorWindow : Wpf.Ui.Controls.FluentWindow
{
    private readonly TaskEditorViewModel _vm;

    public TaskEditorWindow(TaskEditorViewModel vm)
    {
        _vm = vm;
        SaveCommand = new RelayCommand(Save);
        CancelCommand = new RelayCommand(Close);
        InitializeComponent();
        DataContext = vm;
        InputBindings.Add(new KeyBinding(SaveCommand, Key.Enter, ModifierKeys.Control));
        InputBindings.Add(new KeyBinding(SaveCommand, Key.S, ModifierKeys.Control));
        InputBindings.Add(new KeyBinding(CancelCommand, Key.Escape, ModifierKeys.None));
        Loaded += (_, _) =>
        {
            TitleBox.Focus();
            TitleBox.SelectAll();
        };
    }

    public IRelayCommand SaveCommand { get; }
    public IRelayCommand CancelCommand { get; }

    private void OnSave(object sender, RoutedEventArgs e) => Save();

    private void OnCancel(object sender, RoutedEventArgs e) => Close();

    private void OnSubtaskKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter) return;
        _vm.AddSubtaskCommand.Execute(null);
        e.Handled = true;
    }

    private void Save()
    {
        // Commit a pending checklist entry the user typed but didn't confirm with Enter.
        if (!string.IsNullOrWhiteSpace(_vm.NewSubtask)) _vm.AddSubtaskCommand.Execute(null);
        _vm.Error = _vm.Validate();
        if (_vm.Error is not null) return;

        var s = AppServices.Current;
        var task = _vm.BuildTask();
        var repeat = _vm.BuildPattern();
        if (_vm.IsNew)
        {
            s.Planner.AddTask(task, repeat);
            Close();
            return;
        }
        if (!_vm.HasChanges())
        {
            Close();
            return;
        }

        var scope = EditScope.ThisOccurrence;
        if (_vm.IsRecurringExisting)
        {
            // Changing the rule only makes sense for the whole series.
            var chosen = s.Windows.AskScope("Apply the change to", allowThisOccurrence: !_vm.RepeatChanged);
            if (chosen is null) return;
            scope = chosen.Value;
        }
        try
        {
            s.Planner.UpdateTask(task, repeat, scope);
            Close();
        }
        catch (InvalidOperationException ex)
        {
            _vm.Error = ex.Message;
        }
    }

    private void OnDelete(object sender, RoutedEventArgs e)
    {
        var id = _vm.Original.Id;
        Close();
        AppServices.Current.Windows.DeleteTask(id);
    }
}
