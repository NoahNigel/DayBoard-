using System.Windows;
using System.Windows.Input;
using System.Windows.Threading;
using DayBoard.Core.Models;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views.Windows;

/// <summary>Borderless, draggable, resizable always-on-top list of today's tasks. Remembers its position and size.</summary>
public partial class MiniWindow : Window
{
    private readonly DispatcherTimer _saveTimer = new() { Interval = TimeSpan.FromMilliseconds(600) };

    public MiniWindow(MiniViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
        var b = AppServices.Current.Settings.Current.MiniWindow;
        if (b is not null && WindowPlacement.IsOnScreen(b.Left, b.Top, b.Width, b.Height))
        {
            WindowStartupLocation = WindowStartupLocation.Manual;
            Left = b.Left;
            Top = b.Top;
            Width = Math.Max(MinWidth, b.Width);
            Height = Math.Max(MinHeight, b.Height);
        }
        else
        {
            var area = SystemParameters.WorkArea;
            WindowStartupLocation = WindowStartupLocation.Manual;
            Left = area.Right - Width - 24;
            Top = area.Top + 80;
        }
        _saveTimer.Tick += (_, _) =>
        {
            _saveTimer.Stop();
            SaveBounds();
        };
        LocationChanged += (_, _) => Debounce();
        SizeChanged += (_, _) => Debounce();
        Closing += (_, _) => SaveBounds();
    }

    private void Debounce()
    {
        if (!IsLoaded) return;
        _saveTimer.Stop();
        _saveTimer.Start();
    }

    private void SaveBounds()
    {
        if (WindowState != WindowState.Normal) return;
        AppServices.Current.Settings.Update(s => s.MiniWindow = new WindowBounds { Left = Left, Top = Top, Width = ActualWidth, Height = ActualHeight }, notify: false);
    }

    private void OnHeaderMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton == MouseButton.Left && e.ClickCount == 1) DragMove();
    }

    private void OnClose(object sender, RoutedEventArgs e) => Close();

    private void OnOpenMain(object sender, RoutedEventArgs e)
    {
        AppServices.Current.Windows.ShowMain();
        AppServices.Current.Main.ShowDate(AppServices.Current.Planner.Today);
    }

    private void OnCheck(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: TaskCardViewModel card })
            AppServices.Current.Planner.SetDone(card.Id, !card.IsDone);
        e.Handled = true;
    }

    private void OnAddKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || DataContext is not MiniViewModel vm) return;
        vm.AddCommand.Execute(null);
        e.Handled = true;
    }
}
