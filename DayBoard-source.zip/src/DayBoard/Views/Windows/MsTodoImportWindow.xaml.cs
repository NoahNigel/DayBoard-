using System.Windows;
using System.Windows.Interop;
using CommunityToolkit.Mvvm.ComponentModel;
using DayBoard.Data;
using DayBoard.Services;
using Microsoft.Identity.Client;

namespace DayBoard.Views.Windows;

public sealed partial class TodoListChoice : ObservableObject
{
    public TodoListChoice(TodoListInfo info) => Info = info;
    public TodoListInfo Info { get; }
    public string CountText => Info.OpenCount == 1 ? " · 1 open task" : $" · {Info.OpenCount} open tasks";
    [ObservableProperty] private bool _selected = true;
}

public partial class MsTodoImportWindow : Wpf.Ui.Controls.FluentWindow
{
    private readonly MsTodoImporter _importer = new();
    private readonly CancellationTokenSource _cts = new();
    private List<TodoListChoice> _lists = new();

    public MsTodoImportWindow()
    {
        InitializeComponent();
        Closed += (_, _) =>
        {
            _cts.Cancel();
            _importer.Dispose();
        };
        if (string.IsNullOrWhiteSpace(AppServices.Current.Settings.Current.MsTodoClientId))
        {
            Status.Text = "Add your Azure app's client ID in Settings first.";
            SignInButton.IsEnabled = false;
        }
    }

    private async void OnSignIn(object sender, RoutedEventArgs e)
    {
        var cfg = AppServices.Current.Settings.Current;
        SignInButton.IsEnabled = false;
        Status.Text = "Waiting for sign-in in your browser…";
        try
        {
            await _importer.SignInAsync(cfg.MsTodoClientId, cfg.MsTodoTenant, new WindowInteropHelper(this).Handle, _cts.Token);
            Status.Text = $"Signed in as {_importer.AccountName}. Loading lists…";
            var lists = await _importer.GetListsAsync(_cts.Token);
            _lists = lists.Select(l => new TodoListChoice(l)).ToList();
            Lists.ItemsSource = _lists;
            Status.Text = $"Signed in as {_importer.AccountName}. {lists.Count} list{(lists.Count == 1 ? "" : "s")} found.";
            ImportButton.IsEnabled = _lists.Count > 0;
        }
        catch (OperationCanceledException)
        {
            Status.Text = "Cancelled.";
        }
        catch (MsalException ex)
        {
            Log.Error("MS To Do sign-in", ex);
            Status.Text = ex.ErrorCode switch
            {
                "authentication_canceled" or "access_denied" => "Sign-in was cancelled.",
                _ => "Sign-in failed: " + ex.Message,
            };
        }
        catch (Exception ex) when (ex is System.Net.Http.HttpRequestException or InvalidOperationException)
        {
            Log.Error("MS To Do", ex);
            Status.Text = ex.Message;
        }
        finally
        {
            SignInButton.IsEnabled = true;
        }
    }

    private async void OnImport(object sender, RoutedEventArgs e)
    {
        var selected = _lists.Where(l => l.Selected).Select(l => l.Info).ToList();
        if (selected.Count == 0)
        {
            Status.Text = "Pick at least one list.";
            return;
        }
        ImportButton.IsEnabled = false;
        Status.Text = "Importing…";
        try
        {
            var store = AppServices.Current.Planner.Store;
            var options = new TodoImportOptions { IncludeCompleted = IncludeCompleted.IsChecked == true, ScheduleOnDueDate = ScheduleOnDue.IsChecked == true };
            var data = await _importer.BuildImportAsync(selected, options, store.Tasks, store.Categories, _cts.Token);
            int n = data.Tasks.Count == 0 ? 0 : AppServices.Current.Planner.Import(data);
            Status.Text = n == 0 ? "Nothing new to import (already imported tasks are skipped)." : $"Imported {n} task{(n == 1 ? "" : "s")}. Ctrl+Z in the main window undoes it.";
            if (n > 0) AppServices.Current.Main.ShowToast($"Imported {n} tasks from Microsoft To Do", undo: true);
        }
        catch (Exception ex) when (ex is System.Net.Http.HttpRequestException or InvalidOperationException or OperationCanceledException)
        {
            Log.Error("MS To Do import", ex);
            Status.Text = "Import failed: " + ex.Message;
        }
        finally
        {
            ImportButton.IsEnabled = true;
        }
    }

    private void OnClose(object sender, RoutedEventArgs e) => Close();
}
