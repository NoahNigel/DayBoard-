using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace DayBoard.Views.Windows;

/// <summary>Themed message box with custom buttons. The first button is the default; the last one is Cancel.</summary>
public partial class ChoiceDialog : Wpf.Ui.Controls.FluentWindow
{
    public ChoiceDialog(string title, string message, IReadOnlyList<string> buttons)
    {
        InitializeComponent();
        Title = title;
        Bar.Title = title;
        Heading.Text = title;
        Message.Text = message;
        for (int i = 0; i < buttons.Count; i++)
        {
            int index = i;
            bool last = i == buttons.Count - 1 && buttons.Count > 1;
            var b = new Button
            {
                Content = buttons[i],
                Margin = new Thickness(8, 0, 0, 0),
                MinWidth = 96,
                IsDefault = i == 0,
                IsCancel = last,
                Style = (Style)FindResource(i == 0 ? "DB.AccentButton" : "DB.OutlineButton"),
            };
            b.Click += (_, _) =>
            {
                Choice = index;
                Close();
            };
            Buttons.Children.Add(b);
        }
        PreviewKeyDown += (_, e) =>
        {
            if (e.Key == Key.Escape) Close();
        };
        Loaded += (_, _) =>
        {
            FitHeight();
            (Buttons.Children.Count > 0 ? Buttons.Children[0] : null)?.Focus();
        };
    }

    // Fits the window to the message. (WPF-UI windows have a minimum height of 320, and SizeToContent doesn't take.)
    private void FitHeight()
    {
        Root.Measure(new Size(Root.ActualWidth > 0 ? Root.ActualWidth : Width, double.PositiveInfinity));
        double chrome = ActualHeight - Root.ActualHeight;
        if (Root.ActualHeight > 0 && chrome >= 0) Height = Math.Ceiling(Root.DesiredSize.Height + chrome);
    }

    /// <summary>Index of the pressed button, or -1 if the dialog was closed.</summary>
    public int Choice { get; private set; } = -1;
}
