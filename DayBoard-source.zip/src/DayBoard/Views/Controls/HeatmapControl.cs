using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;

namespace DayBoard.Views.Controls;

/// <summary>GitHub-style completion heatmap for a year (week columns) or a month (calendar grid).</summary>
public sealed class HeatmapControl : FrameworkElement
{
    public static readonly DependencyProperty DataProperty = DependencyProperty.Register(nameof(Data), typeof(IReadOnlyDictionary<DateOnly, int>), typeof(HeatmapControl),
        new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty YearProperty = DependencyProperty.Register(nameof(Year), typeof(int), typeof(HeatmapControl),
        new FrameworkPropertyMetadata(DateTime.Today.Year, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty MonthProperty = DependencyProperty.Register(nameof(Month), typeof(DateOnly), typeof(HeatmapControl),
        new FrameworkPropertyMetadata(DateOnly.FromDateTime(DateTime.Today), FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty IsMonthProperty = DependencyProperty.Register(nameof(IsMonth), typeof(bool), typeof(HeatmapControl),
        new FrameworkPropertyMetadata(false, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    public static readonly DependencyProperty WeekStartProperty = DependencyProperty.Register(nameof(WeekStart), typeof(DayOfWeek), typeof(HeatmapControl),
        new FrameworkPropertyMetadata(DayOfWeek.Monday, FrameworkPropertyMetadataOptions.AffectsRender | FrameworkPropertyMetadataOptions.AffectsMeasure));

    private readonly ToolTip _tip = new() { Placement = System.Windows.Controls.Primitives.PlacementMode.Mouse };
    private readonly List<(Rect Rect, DateOnly Date)> _cells = new();
    private DateOnly? _hover;

    public HeatmapControl()
    {
        _tip.PlacementTarget = this;
        ThemeService.Changed += (_, _) => InvalidateVisual();
    }

    public IReadOnlyDictionary<DateOnly, int>? Data { get => (IReadOnlyDictionary<DateOnly, int>?)GetValue(DataProperty); set => SetValue(DataProperty, value); }
    public int Year { get => (int)GetValue(YearProperty); set => SetValue(YearProperty, value); }
    public DateOnly Month { get => (DateOnly)GetValue(MonthProperty); set => SetValue(MonthProperty, value); }
    public bool IsMonth { get => (bool)GetValue(IsMonthProperty); set => SetValue(IsMonthProperty, value); }
    public DayOfWeek WeekStart { get => (DayOfWeek)GetValue(WeekStartProperty); set => SetValue(WeekStartProperty, value); }

    private const double YearCell = 12, YearGap = 3, LeftLabels = 30, TopLabels = 18;
    private const double MonthCell = 36, MonthGap = 4;

    protected override Size MeasureOverride(Size availableSize)
    {
        if (IsMonth)
        {
            int weeks = MonthWeeks();
            return new Size(7 * (MonthCell + MonthGap), 18 + weeks * (MonthCell + MonthGap));
        }
        int cols = YearColumns();
        return new Size(LeftLabels + cols * (YearCell + YearGap), TopLabels + 7 * (YearCell + YearGap) + 26);
    }

    private int YearColumns()
    {
        var first = DateUtil.StartOfWeek(new DateOnly(Year, 1, 1), WeekStart);
        var last = new DateOnly(Year, 12, 31);
        return (last.DayNumber - first.DayNumber) / 7 + 1;
    }

    private int MonthWeeks()
    {
        var first = new DateOnly(Month.Year, Month.Month, 1);
        var start = DateUtil.StartOfWeek(first, WeekStart);
        var last = first.AddMonths(1).AddDays(-1);
        return (last.DayNumber - start.DayNumber) / 7 + 1;
    }

    private int Max()
    {
        var d = Data;
        return d is null || d.Count == 0 ? 0 : d.Values.Max();
    }

    private static int Level(int count, int max)
    {
        if (count <= 0) return 0;
        if (max <= 4) return Math.Min(4, count);
        return Math.Clamp((int)Math.Ceiling(count * 4.0 / max), 1, 4);
    }

    private Brush LevelBrush(int level) => ThemeService.Resource("DB.Heat" + level, level == 0 ? Brushes.WhiteSmoke : Brushes.SeaGreen);

    protected override void OnRender(DrawingContext dc)
    {
        _cells.Clear();
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(RenderSize));
        var text = ThemeService.Resource("DB.TextTertiary", Brushes.Gray);
        var strong = ThemeService.Resource("DB.TextSecondary", Brushes.DimGray);
        var accent = ThemeService.Resource("DB.Accent", Brushes.SlateBlue);
        var typeface = new Typeface(new FontFamily("Segoe UI Variable Text, Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        FormattedText Text(string s, double size, Brush b) => new(s, CultureInfo.CurrentCulture, FlowDirection.LeftToRight, typeface, size, b, dpi);
        var data = Data ?? new Dictionary<DateOnly, int>();
        int max = Max();
        var today = DateOnly.FromDateTime(DateTime.Today);
        var days = DateUtil.WeekDays(WeekStart);

        if (IsMonth)
        {
            for (int i = 0; i < 7; i++)
            {
                var ft = Text(DateUtil.ShortDayName(days[i]), 11, text);
                dc.DrawText(ft, new Point(i * (MonthCell + MonthGap) + (MonthCell - ft.Width) / 2, 0));
            }
            var first = new DateOnly(Month.Year, Month.Month, 1);
            var start = DateUtil.StartOfWeek(first, WeekStart);
            int weeks = MonthWeeks();
            for (int w = 0; w < weeks; w++)
            {
                for (int i = 0; i < 7; i++)
                {
                    var date = start.AddDays(w * 7 + i);
                    if (date.Month != first.Month) continue;
                    var rect = new Rect(i * (MonthCell + MonthGap), 18 + w * (MonthCell + MonthGap), MonthCell, MonthCell);
                    int count = data.GetValueOrDefault(date);
                    int level = Level(count, max);
                    dc.DrawRoundedRectangle(LevelBrush(level), date == today ? new Pen(accent, 2) : null, rect, 6, 6);
                    var num = Text(date.Day.ToString(CultureInfo.CurrentCulture), 11.5, level >= 3 ? Brushes.White : strong);
                    dc.DrawText(num, new Point(rect.X + 5, rect.Y + 3));
                    if (count > 0)
                    {
                        var c = Text(count.ToString(CultureInfo.CurrentCulture), 10.5, level >= 3 ? Brushes.White : text);
                        dc.DrawText(c, new Point(rect.Right - c.Width - 5, rect.Bottom - c.Height - 3));
                    }
                    _cells.Add((rect, date));
                }
            }
            return;
        }

        var yearStart = DateUtil.StartOfWeek(new DateOnly(Year, 1, 1), WeekStart);
        int cols = YearColumns();
        for (int r = 0; r < 7; r += 2)
        {
            var ft = Text(DateUtil.ShortDayName(days[r]), 10, text);
            dc.DrawText(ft, new Point(0, TopLabels + r * (YearCell + YearGap) - 1));
        }
        int lastMonth = 0;
        for (int c = 0; c < cols; c++)
        {
            var colStart = yearStart.AddDays(c * 7);
            var firstInYear = Enumerable.Range(0, 7).Select(i => colStart.AddDays(i)).FirstOrDefault(d => d.Year == Year);
            if (firstInYear.Year == Year)
            {
                var monthOfColumn = Enumerable.Range(0, 7).Select(i => colStart.AddDays(i)).Where(d => d.Year == Year && d.Day == 1).Select(d => d.Month).FirstOrDefault();
                int labelMonth = c == 0 ? firstInYear.Month : monthOfColumn;
                if (labelMonth != 0 && labelMonth != lastMonth)
                {
                    lastMonth = labelMonth;
                    var ft = Text(CultureInfo.CurrentCulture.DateTimeFormat.GetAbbreviatedMonthName(labelMonth), 10, text);
                    dc.DrawText(ft, new Point(LeftLabels + c * (YearCell + YearGap), 0));
                }
            }
            for (int r = 0; r < 7; r++)
            {
                var date = colStart.AddDays(r);
                if (date.Year != Year) continue;
                var rect = new Rect(LeftLabels + c * (YearCell + YearGap), TopLabels + r * (YearCell + YearGap), YearCell, YearCell);
                int count = data.GetValueOrDefault(date);
                dc.DrawRoundedRectangle(LevelBrush(Level(count, max)), date == today ? new Pen(accent, 1.5) : null, rect, 2.5, 2.5);
                _cells.Add((rect, date));
            }
        }

        // Legend
        double ly = TopLabels + 7 * (YearCell + YearGap) + 8;
        double lx = LeftLabels + cols * (YearCell + YearGap) - 5 * (YearCell + YearGap) - 70;
        var less = Text("Less", 10, text);
        dc.DrawText(less, new Point(lx, ly - 1));
        lx += less.Width + 6;
        for (int l = 0; l <= 4; l++)
        {
            dc.DrawRoundedRectangle(LevelBrush(l), null, new Rect(lx, ly, YearCell, YearCell), 2.5, 2.5);
            lx += YearCell + YearGap;
        }
        dc.DrawText(Text("More", 10, text), new Point(lx + 3, ly - 1));
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        var p = e.GetPosition(this);
        foreach (var (rect, date) in _cells)
        {
            if (!rect.Contains(p)) continue;
            if (_hover != date)
            {
                _hover = date;
                int n = Data?.GetValueOrDefault(date) ?? 0;
                _tip.Content = $"{date.ToString("ddd d MMM yyyy", CultureInfo.CurrentCulture)}: {(n == 0 ? "no tasks" : n == 1 ? "1 task" : $"{n} tasks")} completed";
                _tip.IsOpen = false;
                _tip.IsOpen = true;
            }
            return;
        }
        _hover = null;
        _tip.IsOpen = false;
    }

    protected override void OnMouseLeave(MouseEventArgs e)
    {
        base.OnMouseLeave(e);
        _hover = null;
        _tip.IsOpen = false;
    }
}
