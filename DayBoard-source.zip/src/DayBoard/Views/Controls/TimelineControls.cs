using System.Globalization;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using DayBoard.Infrastructure;

namespace DayBoard.Views.Controls;

/// <summary>Lays out timeline blocks by start/duration (minutes) and overlap column.</summary>
public sealed class TimelinePanel : Panel
{
    public static readonly DependencyProperty PixelsPerMinuteProperty = DependencyProperty.Register(
        nameof(PixelsPerMinute), typeof(double), typeof(TimelinePanel),
        new FrameworkPropertyMetadata(26.0 / 30, FrameworkPropertyMetadataOptions.AffectsMeasure | FrameworkPropertyMetadataOptions.AffectsArrange));

    public static readonly DependencyProperty StartProperty = DependencyProperty.RegisterAttached(
        "Start", typeof(double), typeof(TimelinePanel), new FrameworkPropertyMetadata(0.0, FrameworkPropertyMetadataOptions.AffectsParentArrange));

    public static readonly DependencyProperty DurationProperty = DependencyProperty.RegisterAttached(
        "Duration", typeof(double), typeof(TimelinePanel), new FrameworkPropertyMetadata(30.0, FrameworkPropertyMetadataOptions.AffectsParentArrange | FrameworkPropertyMetadataOptions.AffectsParentMeasure));

    public static readonly DependencyProperty ColumnProperty = DependencyProperty.RegisterAttached(
        "Column", typeof(int), typeof(TimelinePanel), new FrameworkPropertyMetadata(0, FrameworkPropertyMetadataOptions.AffectsParentArrange));

    public static readonly DependencyProperty ColumnsProperty = DependencyProperty.RegisterAttached(
        "Columns", typeof(int), typeof(TimelinePanel), new FrameworkPropertyMetadata(1, FrameworkPropertyMetadataOptions.AffectsParentArrange));

    public double PixelsPerMinute
    {
        get => (double)GetValue(PixelsPerMinuteProperty);
        set => SetValue(PixelsPerMinuteProperty, value);
    }

    public static double GetStart(DependencyObject d) => (double)d.GetValue(StartProperty);
    public static void SetStart(DependencyObject d, double v) => d.SetValue(StartProperty, v);
    public static double GetDuration(DependencyObject d) => (double)d.GetValue(DurationProperty);
    public static void SetDuration(DependencyObject d, double v) => d.SetValue(DurationProperty, v);
    public static int GetColumn(DependencyObject d) => (int)d.GetValue(ColumnProperty);
    public static void SetColumn(DependencyObject d, int v) => d.SetValue(ColumnProperty, v);
    public static int GetColumns(DependencyObject d) => (int)d.GetValue(ColumnsProperty);
    public static void SetColumns(DependencyObject d, int v) => d.SetValue(ColumnsProperty, v);

    private const double Gap = 3;

    protected override Size MeasureOverride(Size available)
    {
        double width = double.IsInfinity(available.Width) ? 400 : available.Width;
        foreach (UIElement child in InternalChildren)
        {
            int cols = Math.Max(1, GetColumns(child));
            child.Measure(new Size(Math.Max(0, width / cols - Gap), BlockHeight(child)));
        }
        return new Size(width, double.IsInfinity(available.Height) ? 0 : available.Height);
    }

    protected override Size ArrangeOverride(Size final)
    {
        foreach (UIElement child in InternalChildren)
        {
            int cols = Math.Max(1, GetColumns(child));
            int col = Math.Clamp(GetColumn(child), 0, cols - 1);
            double w = final.Width / cols;
            double y = GetStart(child) * PixelsPerMinute;
            child.Arrange(new Rect(col * w, y + 1, Math.Max(0, w - Gap), BlockHeight(child)));
        }
        return final;
    }

    private double BlockHeight(UIElement child) => Math.Max(16, GetDuration(child) * PixelsPerMinute - 2);
}

/// <summary>Hour labels and 30-minute grid lines behind the day timeline.</summary>
public sealed class TimelineRuler : FrameworkElement
{
    public static readonly DependencyProperty StartHourProperty = DependencyProperty.Register(nameof(StartHour), typeof(int), typeof(TimelineRuler),
        new FrameworkPropertyMetadata(7, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty EndHourProperty = DependencyProperty.Register(nameof(EndHour), typeof(int), typeof(TimelineRuler),
        new FrameworkPropertyMetadata(22, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty SlotHeightProperty = DependencyProperty.Register(nameof(SlotHeight), typeof(double), typeof(TimelineRuler),
        new FrameworkPropertyMetadata(26.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public static readonly DependencyProperty LabelWidthProperty = DependencyProperty.Register(nameof(LabelWidth), typeof(double), typeof(TimelineRuler),
        new FrameworkPropertyMetadata(60.0, FrameworkPropertyMetadataOptions.AffectsRender));

    public TimelineRuler()
    {
        IsHitTestVisible = false;
        ThemeService.Changed += (_, _) => InvalidateVisual();
    }

    public int StartHour { get => (int)GetValue(StartHourProperty); set => SetValue(StartHourProperty, value); }
    public int EndHour { get => (int)GetValue(EndHourProperty); set => SetValue(EndHourProperty, value); }
    public double SlotHeight { get => (double)GetValue(SlotHeightProperty); set => SetValue(SlotHeightProperty, value); }
    public double LabelWidth { get => (double)GetValue(LabelWidthProperty); set => SetValue(LabelWidthProperty, value); }

    protected override void OnRender(DrawingContext dc)
    {
        var line = new Pen(ThemeService.Resource("DB.GridLine", Brushes.LightGray), 1);
        var soft = new Pen(ThemeService.Resource("DB.GridLineSoft", Brushes.WhiteSmoke), 1) { DashStyle = new DashStyle(new double[] { 3, 3 }, 0) };
        var text = ThemeService.Resource("DB.TextTertiary", Brushes.Gray);
        var typeface = new Typeface(new FontFamily("Segoe UI Variable Text, Segoe UI"), FontStyles.Normal, FontWeights.Normal, FontStretches.Normal);
        double dpi = VisualTreeHelper.GetDpi(this).PixelsPerDip;
        double w = ActualWidth;
        // Background so empty-space clicks and drops hit the timeline.
        dc.DrawRectangle(Brushes.Transparent, null, new Rect(0, 0, w, ActualHeight));
        int slots = (EndHour - StartHour) * 2;
        for (int i = 0; i <= slots; i++)
        {
            double y = Math.Round(i * SlotHeight) + 0.5;
            bool hour = i % 2 == 0;
            dc.DrawLine(hour ? line : soft, new Point(LabelWidth - (hour ? 6 : 0), y), new Point(w, y));
            if (hour && i < slots)
            {
                int h = StartHour + i / 2;
                var label = new FormattedText($"{h:00}:00", CultureInfo.InvariantCulture, FlowDirection.LeftToRight, typeface, 11, text, dpi);
                dc.DrawText(label, new Point(LabelWidth - 12 - label.Width, y - label.Height / 2 + (i == 0 ? label.Height / 2 : 0)));
            }
        }
    }
}

public static class VisualTreeExt
{
    public static T? FindDescendant<T>(DependencyObject? root, string? name = null) where T : FrameworkElement
    {
        if (root is null) return null;
        int n = VisualTreeHelper.GetChildrenCount(root);
        for (int i = 0; i < n; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is T t && (name is null || t.Name == name)) return t;
            var found = FindDescendant<T>(child, name);
            if (found is not null) return found;
        }
        return null;
    }
}
