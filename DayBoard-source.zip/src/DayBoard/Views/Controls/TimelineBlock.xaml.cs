using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views.Controls;

public partial class TimelineBlock : UserControl
{
    private double _resizeStartHeight;
    private double _resizeDelta;

    public TimelineBlock()
    {
        InitializeComponent();
        TaskInteractions.Attach(this);
    }

    /// <summary>Set by the day view: shows/hides the resize preview (new duration in minutes).</summary>
    public static event Action<TimelineItemViewModel, double?>? ResizePreview;

    private TimelineItemViewModel? Item => DataContext as TimelineItemViewModel;

    private void OnDoneClick(object sender, RoutedEventArgs e)
    {
        if (Item?.Card is { } vm)
        {
            FocusMemory.RestoreNext(vm.Id);
            AppServices.Current.Planner.SetDone(vm.Id, !vm.IsDone);
        }
        e.Handled = true;
    }

    private void OnResizeStarted(object sender, DragStartedEventArgs e)
    {
        _resizeStartHeight = ActualHeight;
        _resizeDelta = 0;
        e.Handled = true;
    }

    private void OnResizeDelta(object sender, DragDeltaEventArgs e)
    {
        if (Item is not { } item) return;
        _resizeDelta += e.VerticalChange;
        ResizePreview?.Invoke(item, MinutesFor(item));
        e.Handled = true;
    }

    private void OnResizeCompleted(object sender, DragCompletedEventArgs e)
    {
        if (Item is not { Card: { } card } item) return;
        var minutes = MinutesFor(item);
        ResizePreview?.Invoke(item, null);
        if (minutes is int m && m != (card.Task.EstimateMinutes ?? 0)) AppServices.Current.Planner.SetEstimate(card.Id, m);
        e.Handled = true;
    }

    private int? MinutesFor(TimelineItemViewModel item)
    {
        var ppm = AppServices.Current.Main.Day.PixelsPerMinute;
        if (ppm <= 0) return null;
        var minutes = (item.DurationMinutes * ppm + _resizeDelta) / ppm;
        var snapped = (int)Math.Round(minutes / 15.0) * 15;
        return Math.Clamp(snapped, 15, 12 * 60);
    }
}
