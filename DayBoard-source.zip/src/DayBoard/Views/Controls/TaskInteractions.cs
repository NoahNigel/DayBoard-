using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using System.Windows.Media;
using DayBoard.Core.Models;
using DayBoard.Core.Time;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views.Controls;

/// <summary>Mouse, keyboard and context-menu behaviour shared by task cards and timeline blocks.</summary>
public static class TaskInteractions
{
    public static TaskCardViewModel? CardOf(object? dataContext) => dataContext switch
    {
        TaskCardViewModel c => c,
        TimelineItemViewModel { Card: { } c } => c,
        _ => null,
    };

    public static void Attach(FrameworkElement el)
    {
        var starter = new DragStarter();
        el.Focusable = true;
        el.FocusVisualStyle = null;
        el.ContextMenu ??= new ContextMenu();

        el.PreviewMouseLeftButtonDown += (_, e) =>
        {
            if (IsFromControl(e.OriginalSource as DependencyObject, el)) return;
            if (CardOf(el.DataContext) is not { } vm) return;
            if (e.ClickCount == 2)
            {
                starter.Reset();
                e.Handled = true;
                AppServices.Current.Windows.EditTask(vm.Id);
                return;
            }
            starter.MouseDown(e, el);
            el.Focus();
        };
        el.PreviewMouseMove += (_, e) =>
        {
            if (!starter.ShouldStart(e, el)) return;
            if (CardOf(el.DataContext) is { } vm) TaskDrag.Begin(el, vm.Id, vm.BlockMinutes);
        };
        el.PreviewMouseLeftButtonUp += (_, _) => starter.Reset();
        el.KeyDown += (_, e) =>
        {
            if (CardOf(el.DataContext) is { } vm && HandleKey(vm, e)) e.Handled = true;
        };
        el.ContextMenuOpening += (_, e) =>
        {
            if (CardOf(el.DataContext) is not { } vm || el.ContextMenu is null)
            {
                e.Handled = true;
                return;
            }
            Populate(el.ContextMenu, vm);
        };
        el.GotKeyboardFocus += (_, _) =>
        {
            if (CardOf(el.DataContext) is { } vm) FocusMemory.LastFocused = vm.Id;
        };
        el.Loaded += (_, _) =>
        {
            if (CardOf(el.DataContext) is { } vm && FocusMemory.ShouldRestore(vm.Id)) el.Focus();
        };
    }

    private static bool IsFromControl(DependencyObject? source, FrameworkElement root)
    {
        for (var d = source; d is not null && !ReferenceEquals(d, root); d = d is Visual ? VisualTreeHelper.GetParent(d) : LogicalTreeHelper.GetParent(d))
        {
            if (d is ButtonBase or Thumb or TextBox) return true;
        }
        return false;
    }

    public static bool HandleKey(TaskCardViewModel vm, KeyEventArgs e)
    {
        var s = AppServices.Current;
        var mods = Keyboard.Modifiers;
        switch (e.Key)
        {
            case Key.Enter when mods == ModifierKeys.None:
                s.Windows.EditTask(vm.Id);
                return true;
            case Key.Space when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetDone(vm.Id, !vm.IsDone);
                return true;
            case Key.Delete when mods == ModifierKeys.None:
                s.Windows.DeleteTask(vm.Id);
                return true;
            case Key.D when mods == ModifierKeys.Control:
                s.Planner.Duplicate(vm.Id);
                return true;
            case Key.D0 or Key.NumPad0 when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetPriority(vm.Id, Priority.None);
                return true;
            case Key.D1 or Key.NumPad1 when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetPriority(vm.Id, Priority.Low);
                return true;
            case Key.D2 or Key.NumPad2 when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetPriority(vm.Id, Priority.Medium);
                return true;
            case Key.D3 or Key.NumPad3 when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetPriority(vm.Id, Priority.High);
                return true;
            case Key.U when mods == ModifierKeys.None:
                FocusMemory.RestoreNext(vm.Id);
                s.Planner.SetUrgent(vm.Id, !vm.IsUrgent);
                return true;
        }
        return false;
    }

    public static void Populate(ContextMenu menu, TaskCardViewModel vm)
    {
        var s = AppServices.Current;
        var p = s.Planner;
        var id = vm.Id;
        var today = p.Today;
        menu.Items.Clear();

        menu.Items.Add(Item("Edit…", "Enter", () => s.Windows.EditTask(id), "Edit24"));
        menu.Items.Add(Item(vm.IsDone ? "Mark as not done" : "Mark done", "Space", () => p.SetDone(id, !vm.IsDone), "CheckmarkCircle24"));
        // Items that plugins add, such as Focus's "Focus on this".
        foreach (var action in s.Runner.TaskActions)
            menu.Items.Add(Item(action.Title, null, () => s.Runner.RunTaskAction(action, id), action.Symbol.ToString()));
        menu.Items.Add(new Separator());

        var move = Sub("Move to", "ArrowMove24");
        var nextWeek = DateUtil.StartOfWeek(today, s.Settings.Current.WeekStart).AddDays(7);
        move.Items.Add(Item("Today", null, () => p.MoveTo(id, today)));
        move.Items.Add(Item("Tomorrow", null, () => p.MoveTo(id, today.AddDays(1))));
        move.Items.Add(Item("Next week", null, () => p.MoveTo(id, nextWeek)));
        move.Items.Add(Item("Inbox", null, () => p.MoveTo(id, null)));
        menu.Items.Add(move);
        if (vm.HasTime && vm.Task.ScheduledDate is { } d)
            menu.Items.Add(Item("Remove time block", null, () => p.ClearTime(id, d), "CalendarDay24"));

        var prio = Sub("Priority", "Flag24");
        foreach (var (pr, key) in new[] { (Priority.None, "0"), (Priority.Low, "1"), (Priority.Medium, "2"), (Priority.High, "3") })
        {
            var mi = Item($"{pr.Label()} {pr.Glyph()}".Trim(), key, () => p.SetPriority(id, pr));
            mi.IsChecked = vm.Task.Priority == pr;
            prio.Items.Add(mi);
        }
        menu.Items.Add(prio);
        menu.Items.Add(Item(vm.IsUrgent ? "Unmark urgent" : "Mark urgent", "U", () => p.SetUrgent(id, !vm.IsUrgent), "Flash24"));

        var status = Sub("Status", "TaskListLtr24");
        foreach (var st in new[] { TaskState.ToDo, TaskState.Doing, TaskState.Done })
        {
            var mi = Item(st.Label(), null, () => p.SetStatus(id, st));
            mi.IsChecked = vm.Task.Status == st;
            status.Items.Add(mi);
        }
        menu.Items.Add(status);
        menu.Items.Add(new Separator());
        menu.Items.Add(Item("Duplicate", "Ctrl+D", () => p.Duplicate(id), "Copy24"));
        menu.Items.Add(Item("Delete", "Del", () => s.Windows.DeleteTask(id), "Delete24"));
    }

    private static MenuItem Item(string header, string? gesture, Action action, string? icon = null)
    {
        var mi = new MenuItem { Header = header, InputGestureText = gesture ?? "" };
        if (icon is not null) mi.Icon = new Wpf.Ui.Controls.SymbolIcon { Symbol = Symbols.Parse(icon), FontSize = 16 };
        mi.Click += (_, _) => action();
        return mi;
    }

    private static MenuItem Sub(string header, string icon) =>
        new() { Header = header, Icon = new Wpf.Ui.Controls.SymbolIcon { Symbol = Symbols.Parse(icon), FontSize = 16 } };
}

/// <summary>Keeps keyboard focus on a task after the views are rebuilt by a change it caused.</summary>
public static class FocusMemory
{
    private static Guid? _restore;
    private static DateTime _until;

    public static Guid? LastFocused { get; set; }

    public static void RestoreNext(Guid id)
    {
        _restore = id;
        _until = DateTime.Now.AddSeconds(2);
    }

    public static bool ShouldRestore(Guid id)
    {
        if (_restore != id || DateTime.Now > _until) return false;
        _restore = null;
        return true;
    }
}
