using System.Windows;
using System.Windows.Controls;
using DayBoard.Services;

namespace DayBoard.Views.Controls;

public partial class TaskCard : UserControl
{
    public static readonly DependencyProperty IsNarrowProperty =
        DependencyProperty.Register(nameof(IsNarrow), typeof(bool), typeof(TaskCard), new PropertyMetadata(false));

    /// <summary>Width threshold below which the compact (week column) layout is used.</summary>
    public const double NarrowWidth = 230;

    public TaskCard()
    {
        InitializeComponent();
        TaskInteractions.Attach(this);
        SizeChanged += (_, e) =>
        {
            if (e.WidthChanged) IsNarrow = e.NewSize.Width < NarrowWidth;
        };
    }

    public bool IsNarrow
    {
        get => (bool)GetValue(IsNarrowProperty);
        set => SetValue(IsNarrowProperty, value);
    }

    private void OnDoneClick(object sender, RoutedEventArgs e)
    {
        if (TaskInteractions.CardOf(DataContext) is { } vm)
        {
            FocusMemory.RestoreNext(vm.Id);
            AppServices.Current.Planner.SetDone(vm.Id, !vm.IsDone);
        }
        e.Handled = true;
    }
}
