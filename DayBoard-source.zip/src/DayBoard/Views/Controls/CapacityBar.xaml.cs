using System.Windows.Controls;

namespace DayBoard.Views.Controls;

public partial class CapacityBar : UserControl
{
    public CapacityBar() => InitializeComponent();
}
