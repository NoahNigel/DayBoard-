using System.Windows;
using System.Windows.Controls;
using DayBoard.ViewModels;

namespace DayBoard.Views.Controls;

public sealed class TimelineTemplateSelector : DataTemplateSelector
{
    public DataTemplate? TaskTemplate { get; set; }
    public DataTemplate? EventTemplate { get; set; }

    public override DataTemplate? SelectTemplate(object item, DependencyObject container) =>
        item is TimelineItemViewModel { IsEvent: true } ? EventTemplate : TaskTemplate;
}
