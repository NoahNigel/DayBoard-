using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;
using DayBoard.Views.Controls;

namespace DayBoard.Views;

public partial class DayView : UserControl
{
    private readonly ListDropIndicator _indicator = new();
    private bool _scrolledInitially;

    public DayView()
    {
        InitializeComponent();
        Loaded += OnLoaded;
        Unloaded += OnUnloaded;
    }

    private DayViewModel? Vm => DataContext as DayViewModel;

    private void OnLoaded(object sender, RoutedEventArgs e)
    {
        TimelineBlock.ResizePreview += OnResizePreview;
        TaskDrag.Ended += OnDragEnded;
        if (Vm is { } vm) vm.LayoutChanged += OnLayoutChanged;
        AppServices.Current.Runner.Changed += OnPluginsChanged;
        ShowPluginPanels();
        Dispatcher.BeginInvoke(ScrollToRelevantTime, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private void OnUnloaded(object sender, RoutedEventArgs e)
    {
        TimelineBlock.ResizePreview -= OnResizePreview;
        TaskDrag.Ended -= OnDragEnded;
        if (Vm is { } vm) vm.LayoutChanged -= OnLayoutChanged;
        AppServices.Current.Runner.Changed -= OnPluginsChanged;
        foreach (var p in AppServices.Current.Runner.Panels) p.Detach();
        PluginPanels.Children.Clear();
    }

    private void OnPluginsChanged(object? sender, EventArgs e) => ShowPluginPanels();

    /// <summary>Puts the plugins' panels at the top. They're kept by the plugin runner, as this view is rebuilt on each visit.</summary>
    private void ShowPluginPanels()
    {
        PluginPanels.Children.Clear();
        foreach (var p in AppServices.Current.Runner.Panels)
        {
            p.Detach();
            PluginPanels.Children.Add(p.Host);
        }
    }

    private void OnLayoutChanged(object? sender, EventArgs e)
    {
        UpdateNowLineWidth();
        if (!_scrolledInitially) Dispatcher.BeginInvoke(ScrollToRelevantTime, System.Windows.Threading.DispatcherPriority.Loaded);
    }

    private void UpdateNowLineWidth() => NowLine.Width = Math.Max(0, DropArea.ActualWidth + 6);

    /// <summary>Scrolls so the current time (or the first block) is in view.</summary>
    private void ScrollToRelevantTime()
    {
        if (Vm is not { } vm || Scroll.ActualHeight <= 0) return;
        _scrolledInitially = true;
        UpdateNowLineWidth();
        double target = vm.IsToday ? vm.NowOffset - Scroll.ActualHeight / 3 : vm.Blocks.Count > 0 ? vm.Blocks.Min(b => b.StartMinutes) * vm.PixelsPerMinute - 40 : 0;
        Scroll.ScrollToVerticalOffset(Math.Max(0, target));
    }

    protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
    {
        base.OnRenderSizeChanged(sizeInfo);
        UpdateNowLineWidth();
    }

    // ------------------------------------------------------------ timeline drops

    private void OnTimelineDragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (Vm is not { } vm || !TaskDrag.TryGet(e, out _))
        {
            e.Effects = DragDropEffects.None;
            return;
        }
        e.Effects = DragDropEffects.Move;
        var y = e.GetPosition(DropArea).Y;
        var slot = vm.SlotAt(y);
        var minutes = Math.Max(15, TaskDrag.CurrentMinutes);
        ShowGhost(vm.OffsetOf(slot), minutes * vm.PixelsPerMinute, $"{slot:HH\\:mm} – {slot.AddMinutes(minutes):HH\\:mm}");
        DragAutoScroll.Handle(Scroll, e);
    }

    private void ShowGhost(double top, double height, string text)
    {
        Ghost.Visibility = Visibility.Visible;
        Ghost.Width = Math.Max(0, DropArea.ActualWidth - 3);
        Ghost.Height = Math.Max(18, height - 2);
        Canvas.SetTop(Ghost, top + 1);
        Canvas.SetLeft(Ghost, 0);
        GhostText.Text = text;
    }

    private void HideGhost() => Ghost.Visibility = Visibility.Collapsed;

    private void OnTimelineDragLeave(object sender, DragEventArgs e)
    {
        if (!TaskDrag.IsInside(DropArea, e)) HideGhost();
    }

    private void OnTimelineDrop(object sender, DragEventArgs e)
    {
        HideGhost();
        e.Handled = true;
        if (Vm is not { } vm || !TaskDrag.TryGet(e, out var id)) return;
        var slot = vm.SlotAt(e.GetPosition(DropArea).Y);
        AppServices.Current.Planner.ScheduleAt(id, vm.Date, slot);
    }

    private void OnTimelineMouseDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ClickCount != 2 || Vm is not { } vm) return;
        if (!ReferenceEquals(e.OriginalSource, DropArea) && e.OriginalSource is not Canvas && e.OriginalSource is not TimelinePanel) return;
        var slot = vm.SlotAt(e.GetPosition(DropArea).Y);
        e.Handled = true;
        AppServices.Current.Windows.NewTask(vm.Date, slot);
    }

    private void OnResizePreview(TimelineItemViewModel item, double? minutes)
    {
        if (Vm is not { } vm) return;
        if (minutes is null)
        {
            HideGhost();
            return;
        }
        var start = TimeOnly.FromTimeSpan(TimeSpan.FromMinutes(vm.StartHour * 60 + item.StartMinutes));
        ShowGhost(item.StartMinutes * vm.PixelsPerMinute, minutes.Value * vm.PixelsPerMinute,
            $"{start:HH\\:mm} – {start.AddMinutes(minutes.Value):HH\\:mm}  ({Core.Time.DateUtil.FormatMinutes((int)minutes.Value)})");
    }

    // ------------------------------------------------------------ unscheduled list drops

    private void OnListDragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (!TaskDrag.TryGet(e, out _))
        {
            e.Effects = DragDropEffects.None;
            return;
        }
        e.Effects = DragDropEffects.Move;
        _indicator.Update(UnscheduledList, e);
        UnscheduledZone.Background = ThemeService.Resource("DB.DropTarget", UnscheduledZone.Background);
        DragAutoScroll.Handle(ListScroll, e);
    }

    private void OnListDragLeave(object sender, DragEventArgs e)
    {
        if (TaskDrag.IsInside(UnscheduledZone, e)) return;
        ClearListIndicator();
    }

    private void ClearListIndicator()
    {
        _indicator.Clear();
        UnscheduledZone.ClearValue(Border.BackgroundProperty);
    }

    private void OnListDrop(object sender, DragEventArgs e)
    {
        e.Handled = true;
        var visualIndex = ListDropIndicator.IndexAt(UnscheduledList, e);
        ClearListIndicator();
        if (Vm is not { } vm || !TaskDrag.TryGet(e, out var id)) return;
        int index = vm.Unscheduled.Take(visualIndex).Count(c => c.Id != id);
        AppServices.Current.Planner.ClearTime(id, vm.Date, index);
    }

    private void OnDragEnded(object? sender, EventArgs e)
    {
        HideGhost();
        ClearListIndicator();
    }

    private void OnAddClick(object sender, RoutedEventArgs e)
    {
        if (Vm is { } vm) AppServices.Current.Windows.NewTask(vm.Date, null);
    }
}
