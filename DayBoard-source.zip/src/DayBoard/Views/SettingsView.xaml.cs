using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DayBoard.Core.Models;
using DayBoard.Infrastructure;
using DayBoard.ViewModels;

namespace DayBoard.Views;

public partial class SettingsView : UserControl
{
    // Swatch dots show the active theme's version of each colour, so they're repainted when the theme changes.
    private readonly List<(Border Dot, string Color)> _swatchDots = new();
    private readonly List<Action> _priorityRows = new();

    public SettingsView()
    {
        InitializeComponent();
        Loaded += (_, _) => ThemeService.Changed += OnThemeChanged;
        Unloaded += (_, _) => ThemeService.Changed -= OnThemeChanged;
    }

    private void OnThemeChanged(object? sender, EventArgs e)
    {
        _swatchDots.RemoveAll(x => PresentationSource.FromVisual(x.Dot) is null && !x.Dot.IsLoaded);
        foreach (var (dot, color) in _swatchDots) dot.Background = ColorUtil.Brush(color);
        foreach (var sync in _priorityRows) sync();
    }

    private SettingsViewModel? Vm => DataContext as SettingsViewModel;

    private void OnHotkeyKeyDown(object sender, KeyEventArgs e)
    {
        e.Handled = true;
        var key = e.Key == Key.System ? e.SystemKey : e.Key;
        if (key is Key.Tab or Key.Escape)
        {
            if (key == Key.Tab) ((UIElement)sender).MoveFocus(new TraversalRequest(FocusNavigationDirection.Next));
            return;
        }
        Vm?.CaptureHotkey(Keyboard.Modifiers, key);
    }

    private void OnCategoryNameLostFocus(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: CategoryEditItem item }) item.Commit();
    }

    private void OnCategorySwatchClick(object sender, RoutedEventArgs e)
    {
        if (sender is not Button { DataContext: string color } button) return;
        var row = DragAutoScroll.FindAncestor<ContentPresenter>(DragAutoScroll.FindAncestor<ItemsControl>(button));
        if (row?.DataContext is CategoryEditItem item) item.Color = color;
    }

    private void OnSwatchLoaded(object sender, RoutedEventArgs e)
    {
        if (sender is not Border { DataContext: string color } b) return;
        b.Background = ColorUtil.Brush(color);
        if (!_swatchDots.Any(x => ReferenceEquals(x.Dot, b))) _swatchDots.Add((b, color));
    }

    private void OnIconPreviewLoaded(object sender, RoutedEventArgs e)
    {
        if (sender is Wpf.Ui.Controls.SymbolIcon { DataContext: string name } icon) icon.Symbol = Symbols.Parse(name);
    }

    /// <summary>Wires one priority-colour row (High / Medium / Low): preview, hex box and swatches.</summary>
    private void OnPriorityRowLoaded(object sender, RoutedEventArgs e)
    {
        if (sender is not Grid { DataContext: string spec } row || Vm is not { } vm) return;
        var parts = spec.Split('|');
        var level = parts[0];
        var preview = (Border)row.FindName("Preview");
        var glyph = (TextBlock)row.FindName("Glyph");
        var name = (TextBlock)row.FindName("Name");
        var hex = (TextBox)row.FindName("Hex");
        var swatches = (ItemsControl)row.FindName("Swatches");
        glyph.Text = parts[1];
        name.Text = level;

        string Current() => level switch { "High" => vm.PriorityHighColor, "Medium" => vm.PriorityMediumColor, _ => vm.PriorityLowColor };
        var priority = Enum.Parse<Priority>(level);

        void Sync()
        {
            // The preview shows what the app uses: the theme's suggestion while the colour is still DayBoard's default.
            var shown = ThemeService.PriorityHex(priority);
            preview.Background = ColorUtil.Brush(shown, 0x30);
            glyph.Foreground = ColorUtil.Brush(shown);
            if (!hex.IsKeyboardFocused) hex.Text = Current();
        }

        Sync();
        _priorityRows.Add(Sync);
        row.Unloaded += (_, _) => _priorityRows.Remove(Sync);
        hex.TextChanged += (_, _) =>
        {
            if (hex.IsKeyboardFocused && ColorUtil.Parse(hex.Text) is not null) vm.SetPriorityColorCommand.Execute($"{level}|{hex.Text.Trim()}");
        };
        PropertyChangedEventHandler handler = (_, args) =>
        {
            if (args.PropertyName?.StartsWith("Priority" + level, StringComparison.Ordinal) == true) Sync();
        };
        vm.PropertyChanged += handler;
        row.Unloaded += (_, _) => vm.PropertyChanged -= handler;

        if (swatches.Items.Count == 0)
        {
            foreach (var color in ColorUtil.Swatches)
            {
                var btn = new Button { Style = (Style)FindResource("Swatch"), ToolTip = color };
                var dot = new Border { Width = 18, Height = 18, CornerRadius = new CornerRadius(9), Background = ColorUtil.Brush(color) };
                _swatchDots.Add((dot, color));
                btn.Content = dot;
                btn.Click += (_, _) => vm.SetPriorityColorCommand.Execute($"{level}|{color}");
                swatches.Items.Add(btn);
            }
        }
    }
}
