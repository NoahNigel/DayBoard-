using System.Windows;
using System.Windows.Controls;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;
using DayBoard.Views.Controls;

namespace DayBoard.Views;

public partial class WeekView : UserControl
{
    private readonly ListDropIndicator _indicator = new();
    private WeekDayViewModel? _target;

    public WeekView()
    {
        InitializeComponent();
        Loaded += (_, _) => TaskDrag.Ended += OnDragEnded;
        Unloaded += (_, _) => TaskDrag.Ended -= OnDragEnded;
    }

    private void SetTarget(WeekDayViewModel? day)
    {
        if (ReferenceEquals(_target, day)) return;
        if (_target is not null) _target.IsDropTarget = false;
        _target = day;
        if (day is not null) day.IsDropTarget = true;
    }

    private void OnColumnDragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (sender is not Border { DataContext: WeekDayViewModel day } column || !TaskDrag.TryGet(e, out _))
        {
            e.Effects = DragDropEffects.None;
            return;
        }
        e.Effects = DragDropEffects.Move;
        SetTarget(day);
        if (VisualTreeExt.FindDescendant<ItemsControl>(column, "List") is { } list) _indicator.Update(list, e);
        DragAutoScroll.Handle(VisualTreeExt.FindDescendant<ScrollViewer>(column, "ColumnScroll"), e);
    }

    private void OnColumnDragLeave(object sender, DragEventArgs e)
    {
        if (sender is Border column && TaskDrag.IsInside(column, e)) return;
        Clear();
    }

    private void OnColumnDrop(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (sender is not Border { DataContext: WeekDayViewModel day } column || !TaskDrag.TryGet(e, out var id))
        {
            Clear();
            return;
        }
        int visualIndex = VisualTreeExt.FindDescendant<ItemsControl>(column, "List") is { } list ? ListDropIndicator.IndexAt(list, e) : day.Cards.Count;
        Clear();
        // Position among the day's untimed tasks (timed tasks are always shown first, in time order).
        int untimedIndex = day.Cards.Take(visualIndex).Count(c => c.Id != id && !c.HasTime);
        AppServices.Current.Planner.MoveTo(id, day.Date, untimedIndex);
    }

    private void Clear()
    {
        _indicator.Clear();
        SetTarget(null);
    }

    private void OnDragEnded(object? sender, EventArgs e) => Clear();

    private void OnHeaderClick(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: WeekDayViewModel day }) AppServices.Current.Main.ShowDate(day.Date);
    }

    private void OnAddClick(object sender, RoutedEventArgs e)
    {
        if (sender is FrameworkElement { DataContext: WeekDayViewModel day }) AppServices.Current.Windows.NewTask(day.Date, null);
    }
}
