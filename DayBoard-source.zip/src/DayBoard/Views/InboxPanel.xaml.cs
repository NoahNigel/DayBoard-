using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views;

public partial class InboxPanel : UserControl
{
    private readonly ListDropIndicator _indicator = new();

    public InboxPanel()
    {
        InitializeComponent();
        TaskDrag.Ended += (_, _) => Clear();
    }

    private InboxViewModel? Vm => DataContext as InboxViewModel;

    private void OnAddKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || Vm is null) return;
        Vm.AddCommand.Execute(null);
        e.Handled = true;
    }

    private void OnDragOver(object sender, DragEventArgs e)
    {
        e.Handled = true;
        if (Vm is null || !TaskDrag.TryGet(e, out _))
        {
            e.Effects = DragDropEffects.None;
            return;
        }
        e.Effects = DragDropEffects.Move;
        Vm.IsDropTarget = true;
        _indicator.Update(List, e);
        DragAutoScroll.Handle(Scroll, e);
    }

    private void OnDragLeave(object sender, DragEventArgs e)
    {
        if (TaskDrag.IsInside(Zone, e)) return;
        Clear();
    }

    private void OnDrop(object sender, DragEventArgs e)
    {
        e.Handled = true;
        int visualIndex = ListDropIndicator.IndexAt(List, e);
        Clear();
        if (Vm is not { } vm || !TaskDrag.TryGet(e, out var id)) return;
        int index = vm.Cards.Take(visualIndex).Count(c => c.Id != id);
        AppServices.Current.Planner.MoveTo(id, null, index);
    }

    private void Clear()
    {
        _indicator.Clear();
        if (Vm is { } vm) vm.IsDropTarget = false;
    }
}
