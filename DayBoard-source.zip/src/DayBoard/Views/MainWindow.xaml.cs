using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using DayBoard.Core.Models;
using DayBoard.Infrastructure;
using DayBoard.Services;
using DayBoard.ViewModels;

namespace DayBoard.Views;

public partial class MainWindow : Wpf.Ui.Controls.FluentWindow
{
    private bool _trayHintShown;

    public MainWindow(MainViewModel vm)
    {
        InitializeComponent();
        DataContext = vm;
        ApplySavedBounds(AppServices.Current.Settings.Current.MainWindow);
        Closing += OnClosing;
    }

    public void SetBadge(int remaining)
    {
        TaskbarInfo.Overlay = IconFactory.OverlayBadge(remaining);
        TaskbarInfo.Description = remaining == 1 ? "DayBoard: 1 task left today" : $"DayBoard: {remaining} tasks left today";
    }

    private void OnJumpClick(object sender, RoutedEventArgs e)
    {
        if (DataContext is MainViewModel vm)
        {
            var d = vm.SelectedDate.ToDateTime(TimeOnly.MinValue);
            JumpCalendar.DisplayDate = d;
        }
        JumpPopup.IsOpen = true;
    }

    private void OnJumpDate(object? sender, SelectionChangedEventArgs e)
    {
        if (JumpCalendar.SelectedDate is { } d && DataContext is MainViewModel vm)
        {
            JumpPopup.IsOpen = false;
            vm.SelectedDate = DateOnly.FromDateTime(d);
            JumpCalendar.SelectedDate = null;
        }
    }

    private void OnClosing(object? sender, CancelEventArgs e)
    {
        var app = (App)Application.Current;
        if (app.IsExiting) return;
        SaveBounds();
        if (AppServices.Current.Settings.Current.CloseToTray && AppServices.Current.Tray is not null)
        {
            e.Cancel = true;
            Hide();
            if (!_trayHintShown)
            {
                _trayHintShown = true;
                AppServices.Current.Tray?.Notify("DayBoard is still running", "It's in the system tray. Right-click the icon and choose Exit to quit.");
            }
            return;
        }
        e.Cancel = true;
        Dispatcher.BeginInvoke(app.ExitApp);
    }

    public void SaveBounds()
    {
        var b = WindowState == WindowState.Normal ? new Rect(Left, Top, ActualWidth, ActualHeight) : RestoreBounds;
        if (b.Width < 200 || b.Height < 200 || double.IsInfinity(b.Width)) return;
        AppServices.Current.Settings.Update(s => s.MainWindow = new WindowBounds
        {
            Left = b.Left,
            Top = b.Top,
            Width = b.Width,
            Height = b.Height,
            Maximized = WindowState == WindowState.Maximized,
        }, notify: false);
    }

    private void ApplySavedBounds(WindowBounds? b)
    {
        if (b is null || !WindowPlacement.IsOnScreen(b.Left, b.Top, b.Width, b.Height)) return;
        WindowStartupLocation = WindowStartupLocation.Manual;
        Left = b.Left;
        Top = b.Top;
        Width = Math.Max(MinWidth, b.Width);
        Height = Math.Max(MinHeight, b.Height);
        if (b.Maximized) WindowState = WindowState.Maximized;
    }
}

public static class WindowPlacement
{
    /// <summary>True when a meaningful part of the rectangle is on the virtual screen (all monitors).</summary>
    public static bool IsOnScreen(double left, double top, double width, double height)
    {
        var screen = new Rect(SystemParameters.VirtualScreenLeft, SystemParameters.VirtualScreenTop, SystemParameters.VirtualScreenWidth, SystemParameters.VirtualScreenHeight);
        var r = new Rect(left, top, Math.Max(1, width), Math.Max(1, height));
        var visible = Rect.Intersect(screen, r);
        return !visible.IsEmpty && visible.Width >= 80 && visible.Height >= 40;
    }
}
