using System.Windows.Controls;

namespace DayBoard.Views;

public partial class StatsView : UserControl
{
    public StatsView() => InitializeComponent();
}
