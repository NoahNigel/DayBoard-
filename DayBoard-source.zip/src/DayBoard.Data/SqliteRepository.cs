using System.Globalization;
using System.IO;
using System.Text.Json;
using DayBoard.Core.Models;
using DayBoard.Core.Store;
using Microsoft.Data.Sqlite;

namespace DayBoard.Data;

/// <summary>SQLite persistence (Microsoft.Data.Sqlite). One connection for the app's lifetime, WAL journal.</summary>
public sealed class SqliteRepository : IPlannerRepository, IDisposable
{
    private const int SchemaVersion = 3;
    private const string DateFmt = "yyyy-MM-dd";
    private const string TimeFmt = "HH:mm";
    private const string DateTimeFmt = "yyyy-MM-dd'T'HH:mm:ss.fffffff";
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    private readonly SqliteConnection _conn;

    public SqliteRepository(string path)
    {
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        _conn = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = path, Pooling = false }.ToString());
        _conn.Open();
        Exec("PRAGMA journal_mode=WAL;");
        Exec("PRAGMA synchronous=NORMAL;");
        Migrate();
    }

    public SqliteConnection Connection => _conn;

    private void Migrate()
    {
        var version = Convert.ToInt32(Scalar("PRAGMA user_version;"), Inv);
        if (version >= SchemaVersion) return;
        using var tx = _conn.BeginTransaction();
        if (version < 1)
        {
            Exec("""
                CREATE TABLE IF NOT EXISTS categories (
                    id TEXT PRIMARY KEY, name TEXT NOT NULL, color TEXT NOT NULL, icon TEXT NOT NULL, sort_order INTEGER NOT NULL DEFAULT 0);
                CREATE TABLE IF NOT EXISTS series (
                    id TEXT PRIMARY KEY, rrule TEXT NOT NULL, start_date TEXT NOT NULL, end_date TEXT,
                    title TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', priority INTEGER NOT NULL DEFAULT 0, urgent INTEGER NOT NULL DEFAULT 0,
                    category_id TEXT, start_time TEXT, estimate_min INTEGER, subtasks_json TEXT NOT NULL DEFAULT '[]',
                    exceptions_json TEXT NOT NULL DEFAULT '[]', materialized_through TEXT, created_at TEXT NOT NULL);
                CREATE TABLE IF NOT EXISTS tasks (
                    id TEXT PRIMARY KEY, title TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '', priority INTEGER NOT NULL DEFAULT 0,
                    urgent INTEGER NOT NULL DEFAULT 0, category_id TEXT, scheduled_date TEXT, start_time TEXT, estimate_min INTEGER,
                    actual_min INTEGER NOT NULL DEFAULT 0, due_date TEXT, status INTEGER NOT NULL DEFAULT 0, completed_at TEXT,
                    series_id TEXT, occurrence_date TEXT, is_exception INTEGER NOT NULL DEFAULT 0, is_skipped INTEGER NOT NULL DEFAULT 0,
                    sort_order REAL NOT NULL DEFAULT 0, rollover_count INTEGER NOT NULL DEFAULT 0, external_id TEXT,
                    created_at TEXT NOT NULL, updated_at TEXT NOT NULL);
                CREATE INDEX IF NOT EXISTS ix_tasks_date ON tasks(scheduled_date);
                CREATE INDEX IF NOT EXISTS ix_tasks_series ON tasks(series_id);
                CREATE TABLE IF NOT EXISTS subtasks (
                    id TEXT PRIMARY KEY, task_id TEXT NOT NULL, title TEXT NOT NULL, done INTEGER NOT NULL DEFAULT 0, sort_order INTEGER NOT NULL DEFAULT 0);
                CREATE INDEX IF NOT EXISTS ix_subtasks_task ON subtasks(task_id);
                CREATE TABLE IF NOT EXISTS task_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, kind INTEGER NOT NULL, at TEXT NOT NULL,
                    from_date TEXT, to_date TEXT, minutes INTEGER);
                CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
                """, tx);
        }
        if (version < 2)
        {
            // DayBoard 1.2: daily check-ins (mood, colour of the day, tags, journal note).
            Exec("""
                CREATE TABLE IF NOT EXISTS checkins (
                    date TEXT PRIMARY KEY, mood INTEGER, color TEXT, tags_json TEXT NOT NULL DEFAULT '[]',
                    note TEXT NOT NULL DEFAULT '', updated_at TEXT NOT NULL);
                """, tx);
        }
        if (version < 3)
        {
            // DayBoard 1.3: storage for code plugins. The Daily check-in became a code plugin, so its entries are copied
            // into that plugin's storage. The checkins table is left as it was, so DayBoard 1.2 still finds them.
            Exec($$"""
                CREATE TABLE IF NOT EXISTS plugin_data (
                    plugin_id TEXT NOT NULL, key TEXT NOT NULL, value TEXT NOT NULL, updated_at TEXT NOT NULL,
                    PRIMARY KEY (plugin_id, key));
                INSERT OR IGNORE INTO plugin_data (plugin_id, key, value, updated_at)
                    SELECT '{{Plugins.PluginDataStore.CheckInPluginId}}', 'checkin:' || date,
                           json_object('mood', mood, 'color', color,
                                       'tags', json(CASE WHEN json_valid(tags_json) THEN tags_json ELSE '[]' END),
                                       'note', note, 'updatedAt', updated_at),
                           updated_at
                    FROM checkins;
                """, tx);
        }
        Exec($"PRAGMA user_version = {SchemaVersion};", tx);
        tx.Commit();
    }

    // ------------------------------------------------------------------ load

    public PlannerData Load()
    {
        var data = new PlannerData();

        using (var cmd = _conn.CreateCommand())
        {
            cmd.CommandText = "SELECT id, name, color, icon, sort_order FROM categories;";
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                data.Categories.Add(new Category
                {
                    Id = Guid.Parse(r.GetString(0)),
                    Name = r.GetString(1),
                    Color = r.GetString(2),
                    Icon = r.GetString(3),
                    SortOrder = r.GetInt32(4),
                });
            }
        }

        using (var cmd = _conn.CreateCommand())
        {
            cmd.CommandText = """
                SELECT id, rrule, start_date, end_date, title, notes, priority, urgent, category_id, start_time, estimate_min,
                       subtasks_json, exceptions_json, materialized_through, created_at FROM series;
                """;
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                data.Series.Add(new TaskSeries
                {
                    Id = Guid.Parse(r.GetString(0)),
                    RRule = r.GetString(1),
                    StartDate = ParseDate(r.GetString(2)),
                    EndDate = NullableDate(r, 3),
                    Title = r.GetString(4),
                    Notes = r.GetString(5),
                    Priority = (Priority)r.GetInt32(6),
                    IsUrgent = r.GetInt32(7) != 0,
                    CategoryId = NullableGuid(r, 8),
                    StartTime = NullableTime(r, 9),
                    EstimateMinutes = r.IsDBNull(10) ? null : r.GetInt32(10),
                    SubtaskTitles = JsonSerializer.Deserialize<List<string>>(r.GetString(11)) ?? new(),
                    ExceptionDates = (JsonSerializer.Deserialize<List<string>>(r.GetString(12)) ?? new()).Select(ParseDate).ToHashSet(),
                    MaterializedThrough = NullableDate(r, 13),
                    CreatedAt = ParseDateTime(r.GetString(14)),
                });
            }
        }

        var subtasks = new Dictionary<Guid, List<Subtask>>();
        using (var cmd = _conn.CreateCommand())
        {
            cmd.CommandText = "SELECT id, task_id, title, done FROM subtasks ORDER BY task_id, sort_order;";
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                var taskId = Guid.Parse(r.GetString(1));
                if (!subtasks.TryGetValue(taskId, out var list)) subtasks[taskId] = list = new List<Subtask>();
                list.Add(new Subtask { Id = Guid.Parse(r.GetString(0)), Title = r.GetString(2), IsDone = r.GetInt32(3) != 0 });
            }
        }

        using (var cmd = _conn.CreateCommand())
        {
            cmd.CommandText = """
                SELECT id, title, notes, priority, urgent, category_id, scheduled_date, start_time, estimate_min, actual_min, due_date,
                       status, completed_at, series_id, occurrence_date, is_exception, is_skipped, sort_order, rollover_count,
                       external_id, created_at, updated_at FROM tasks;
                """;
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                var id = Guid.Parse(r.GetString(0));
                data.Tasks.Add(new TaskItem
                {
                    Id = id,
                    Title = r.GetString(1),
                    Notes = r.GetString(2),
                    Priority = (Priority)r.GetInt32(3),
                    IsUrgent = r.GetInt32(4) != 0,
                    CategoryId = NullableGuid(r, 5),
                    ScheduledDate = NullableDate(r, 6),
                    StartTime = NullableTime(r, 7),
                    EstimateMinutes = r.IsDBNull(8) ? null : r.GetInt32(8),
                    ActualMinutes = r.GetInt32(9),
                    DueDate = NullableDate(r, 10),
                    Status = (TaskState)r.GetInt32(11),
                    CompletedAt = r.IsDBNull(12) ? null : ParseDateTime(r.GetString(12)),
                    SeriesId = NullableGuid(r, 13),
                    OccurrenceDate = NullableDate(r, 14),
                    IsSeriesException = r.GetInt32(15) != 0,
                    IsSkipped = r.GetInt32(16) != 0,
                    SortOrder = r.GetDouble(17),
                    RolloverCount = r.GetInt32(18),
                    ExternalId = r.IsDBNull(19) ? null : r.GetString(19),
                    CreatedAt = ParseDateTime(r.GetString(20)),
                    UpdatedAt = ParseDateTime(r.GetString(21)),
                    Subtasks = subtasks.TryGetValue(id, out var st) ? st : new List<Subtask>(),
                });
            }
        }

        using (var cmd = _conn.CreateCommand())
        {
            cmd.CommandText = "SELECT id, task_id, kind, at, from_date, to_date, minutes FROM task_events ORDER BY id;";
            using var r = cmd.ExecuteReader();
            while (r.Read())
            {
                data.Events.Add(new TaskEvent
                {
                    Id = r.GetInt64(0),
                    TaskId = Guid.Parse(r.GetString(1)),
                    Kind = (TaskEventKind)r.GetInt32(2),
                    At = ParseDateTime(r.GetString(3)),
                    FromDate = NullableDate(r, 4),
                    ToDate = NullableDate(r, 5),
                    Minutes = r.IsDBNull(6) ? null : r.GetInt32(6),
                });
            }
        }

        return data;
    }

    // ------------------------------------------------------------------ save

    public void Save(StoreBatch batch)
    {
        using var tx = _conn.BeginTransaction();
        foreach (var (id, c) in batch.Categories)
        {
            if (c is null)
            {
                Exec("DELETE FROM categories WHERE id = $id;", tx, ("$id", id.ToString()));
                continue;
            }
            Exec("INSERT OR REPLACE INTO categories (id, name, color, icon, sort_order) VALUES ($id, $name, $color, $icon, $sort);", tx,
                ("$id", c.Id.ToString()), ("$name", c.Name), ("$color", c.Color), ("$icon", c.Icon), ("$sort", c.SortOrder));
        }

        foreach (var (id, s) in batch.Series)
        {
            if (s is null)
            {
                Exec("DELETE FROM series WHERE id = $id;", tx, ("$id", id.ToString()));
                continue;
            }
            Exec("""
                INSERT OR REPLACE INTO series (id, rrule, start_date, end_date, title, notes, priority, urgent, category_id, start_time,
                    estimate_min, subtasks_json, exceptions_json, materialized_through, created_at)
                VALUES ($id, $rrule, $start, $end, $title, $notes, $prio, $urgent, $cat, $time, $est, $subs, $ex, $mat, $created);
                """, tx,
                ("$id", s.Id.ToString()), ("$rrule", s.RRule), ("$start", Fmt(s.StartDate)), ("$end", Fmt(s.EndDate)),
                ("$title", s.Title), ("$notes", s.Notes), ("$prio", (int)s.Priority), ("$urgent", s.IsUrgent ? 1 : 0),
                ("$cat", s.CategoryId?.ToString()), ("$time", Fmt(s.StartTime)), ("$est", s.EstimateMinutes),
                ("$subs", JsonSerializer.Serialize(s.SubtaskTitles)),
                ("$ex", JsonSerializer.Serialize(s.ExceptionDates.OrderBy(d => d).Select(d => Fmt(d)).ToList())),
                ("$mat", Fmt(s.MaterializedThrough)), ("$created", Fmt(s.CreatedAt)));
        }

        foreach (var (id, t) in batch.Tasks)
        {
            Exec("DELETE FROM subtasks WHERE task_id = $id;", tx, ("$id", id.ToString()));
            if (t is null)
            {
                Exec("DELETE FROM tasks WHERE id = $id;", tx, ("$id", id.ToString()));
                continue;
            }
            Exec("""
                INSERT OR REPLACE INTO tasks (id, title, notes, priority, urgent, category_id, scheduled_date, start_time, estimate_min,
                    actual_min, due_date, status, completed_at, series_id, occurrence_date, is_exception, is_skipped, sort_order,
                    rollover_count, external_id, created_at, updated_at)
                VALUES ($id, $title, $notes, $prio, $urgent, $cat, $date, $time, $est, $act, $due, $status, $done, $series, $occ,
                    $exc, $skip, $sort, $roll, $ext, $created, $updated);
                """, tx,
                ("$id", t.Id.ToString()), ("$title", t.Title), ("$notes", t.Notes), ("$prio", (int)t.Priority),
                ("$urgent", t.IsUrgent ? 1 : 0), ("$cat", t.CategoryId?.ToString()), ("$date", Fmt(t.ScheduledDate)),
                ("$time", Fmt(t.StartTime)), ("$est", t.EstimateMinutes), ("$act", t.ActualMinutes), ("$due", Fmt(t.DueDate)),
                ("$status", (int)t.Status), ("$done", Fmt(t.CompletedAt)), ("$series", t.SeriesId?.ToString()),
                ("$occ", Fmt(t.OccurrenceDate)), ("$exc", t.IsSeriesException ? 1 : 0), ("$skip", t.IsSkipped ? 1 : 0),
                ("$sort", t.SortOrder), ("$roll", t.RolloverCount), ("$ext", t.ExternalId), ("$created", Fmt(t.CreatedAt)),
                ("$updated", Fmt(t.UpdatedAt)));
            for (int i = 0; i < t.Subtasks.Count; i++)
            {
                var st = t.Subtasks[i];
                Exec("INSERT OR REPLACE INTO subtasks (id, task_id, title, done, sort_order) VALUES ($id, $task, $title, $done, $sort);", tx,
                    ("$id", st.Id.ToString()), ("$task", t.Id.ToString()), ("$title", st.Title), ("$done", st.IsDone ? 1 : 0), ("$sort", i));
            }
        }

        foreach (var e in batch.Events)
        {
            Exec("INSERT INTO task_events (task_id, kind, at, from_date, to_date, minutes) VALUES ($task, $kind, $at, $from, $to, $min);", tx,
                ("$task", e.TaskId.ToString()), ("$kind", (int)e.Kind), ("$at", Fmt(e.At)), ("$from", Fmt(e.FromDate)),
                ("$to", Fmt(e.ToDate)), ("$min", e.Minutes));
            e.Id = Convert.ToInt64(Scalar("SELECT last_insert_rowid();", tx), Inv);
        }

        tx.Commit();
    }

    // ------------------------------------------------------------------ settings

    public string? GetSetting(string key)
    {
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = "SELECT value FROM settings WHERE key = $key;";
        cmd.Parameters.AddWithValue("$key", key);
        return cmd.ExecuteScalar() as string;
    }

    public void SetSetting(string key, string value) =>
        Exec("INSERT OR REPLACE INTO settings (key, value) VALUES ($key, $value);", null, ("$key", key), ("$value", value));

    // ------------------------------------------------------------------ helpers

    private void Exec(string sql, SqliteTransaction? tx = null, params (string Name, object? Value)[] args)
    {
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.Transaction = tx;
        foreach (var (name, value) in args) cmd.Parameters.AddWithValue(name, value ?? DBNull.Value);
        cmd.ExecuteNonQuery();
    }

    private object? Scalar(string sql, SqliteTransaction? tx = null)
    {
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = sql;
        cmd.Transaction = tx;
        return cmd.ExecuteScalar();
    }

    private static string? Fmt(DateOnly? d) => d?.ToString(DateFmt, Inv);
    private static string? Fmt(TimeOnly? t) => t?.ToString(TimeFmt, Inv);
    private static string? Fmt(DateTime? t) => t?.ToString(DateTimeFmt, Inv);

    private static DateOnly ParseDate(string s) => DateOnly.ParseExact(s, DateFmt, Inv);

    private static DateTime ParseDateTime(string s) =>
        DateTime.TryParseExact(s, DateTimeFmt, Inv, DateTimeStyles.None, out var d) ? d : DateTime.Parse(s, Inv);

    private static DateOnly? NullableDate(SqliteDataReader r, int i) => r.IsDBNull(i) ? null : ParseDate(r.GetString(i));
    private static TimeOnly? NullableTime(SqliteDataReader r, int i) => r.IsDBNull(i) ? null : TimeOnly.ParseExact(r.GetString(i), TimeFmt, Inv);
    private static Guid? NullableGuid(SqliteDataReader r, int i) => r.IsDBNull(i) ? null : Guid.Parse(r.GetString(i));

    public void Dispose()
    {
        try
        {
            Exec("PRAGMA wal_checkpoint(TRUNCATE);");
        }
        catch (SqliteException)
        {
        }
        _conn.Dispose();
    }
}
