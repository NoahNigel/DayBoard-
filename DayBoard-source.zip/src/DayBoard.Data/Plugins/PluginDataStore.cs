using System.Globalization;
using Microsoft.Data.Sqlite;

namespace DayBoard.Data.Plugins;

/// <summary>
/// Code plugins' key/value storage, in the plugin_data table of DayBoard's database (so it's in the daily backups).
/// Each plugin only sees its own keys. Kept when a plugin is removed, so adding it again brings its data back.
/// </summary>
public sealed class PluginDataStore
{
    /// <summary>The Daily check-in plugin. Its check-ins from DayBoard 1.2 are copied into its storage.</summary>
    public const string CheckInPluginId = "dayboard.feature.daily-checkin";

    public const int MaxKeyLength = 200;
    public const int MaxValueLength = 1_000_000;

    private readonly SqliteConnection _conn;

    public PluginDataStore(SqliteRepository repo) => _conn = repo.Connection;

    public string? Get(string pluginId, string key)
    {
        CheckKey(key);
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = "SELECT value FROM plugin_data WHERE plugin_id = $id AND key = $key;";
        cmd.Parameters.AddWithValue("$id", pluginId);
        cmd.Parameters.AddWithValue("$key", key);
        return cmd.ExecuteScalar() as string;
    }

    public IReadOnlyDictionary<string, string> GetAll(string pluginId, string prefix = "")
    {
        prefix ??= "";
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = "SELECT key, value FROM plugin_data WHERE plugin_id = $id AND substr(key, 1, length($prefix)) = $prefix ORDER BY key;";
        cmd.Parameters.AddWithValue("$id", pluginId);
        cmd.Parameters.AddWithValue("$prefix", prefix);
        var result = new Dictionary<string, string>(StringComparer.Ordinal);
        using var r = cmd.ExecuteReader();
        while (r.Read()) result[r.GetString(0)] = r.GetString(1);
        return result;
    }

    /// <summary>Saves a value; null removes the key.</summary>
    public void Set(string pluginId, string key, string? value, DateTime now)
    {
        CheckKey(key);
        if (value is { Length: > MaxValueLength }) throw new ArgumentException($"Values can be up to {MaxValueLength:N0} characters.", nameof(value));
        using var cmd = _conn.CreateCommand();
        if (value is null)
        {
            cmd.CommandText = "DELETE FROM plugin_data WHERE plugin_id = $id AND key = $key;";
        }
        else
        {
            cmd.CommandText = "INSERT OR REPLACE INTO plugin_data (plugin_id, key, value, updated_at) VALUES ($id, $key, $value, $at);";
            cmd.Parameters.AddWithValue("$value", value);
            cmd.Parameters.AddWithValue("$at", now.ToString("yyyy-MM-dd'T'HH:mm:ss.fffffff", CultureInfo.InvariantCulture));
        }
        cmd.Parameters.AddWithValue("$id", pluginId);
        cmd.Parameters.AddWithValue("$key", key);
        cmd.ExecuteNonQuery();
    }

    public int Count(string pluginId)
    {
        using var cmd = _conn.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM plugin_data WHERE plugin_id = $id;";
        cmd.Parameters.AddWithValue("$id", pluginId);
        return Convert.ToInt32(cmd.ExecuteScalar(), CultureInfo.InvariantCulture);
    }

    private static void CheckKey(string key)
    {
        if (string.IsNullOrEmpty(key) || key.Length > MaxKeyLength)
            throw new ArgumentException($"Keys must be 1 to {MaxKeyLength} characters.", nameof(key));
    }
}
