using System.Globalization;
using System.IO.Compression;
using System.Reflection;
using System.Reflection.Metadata;
using System.Reflection.PortableExecutable;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace DayBoard.Data.Plugins;

/// <summary>A plugin that can't be installed or loaded. The message is written for the user.</summary>
public sealed class PluginException(string message, bool outdated = false) : Exception(message)
{
    /// <summary>The plugin was made for an older DayBoard and a newer version of it is needed.</summary>
    public bool Outdated { get; } = outdated;
}

public enum PluginKind
{
    Theme,

    /// <summary>Runs its own .NET code inside DayBoard: sidebar pages, Day view panels, reminders and so on.</summary>
    Code,
}

/// <summary>The plugin.json manifest at the root of a .dayboard-plugin file.</summary>
public sealed class PluginManifest
{
    public int FormatVersion { get; init; }
    public string Id { get; init; } = "";
    public string Name { get; init; } = "";
    public string Version { get; init; } = "";
    public string Author { get; init; } = "";
    public string Description { get; init; } = "";
    public PluginKind Kind { get; init; }
    public string MinAppVersion { get; init; } = "";
    public string Entry { get; init; } = "";

    /// <summary>Code plugins: the plugin API version they were built for.</summary>
    public int ApiVersion { get; init; }

    public string KindLabel => Kind switch
    {
        PluginKind.Theme => "Colour theme",
        PluginKind.Code => "Code plugin",
        _ => Kind.ToString(),
    };
}

/// <summary>
/// Colours from a theme plugin, as 0xAARRGGBB. Slots the theme leaves out fall back to DayBoard's own palette.
/// </summary>
public sealed class ThemeDefinition
{
    public IReadOnlyDictionary<string, uint> Light { get; init; } = new Dictionary<string, uint>();
    public IReadOnlyDictionary<string, uint> Dark { get; init; } = new Dictionary<string, uint>();
    public uint? AccentLight { get; init; }
    public uint? AccentDark { get; init; }

    /// <summary>Replacements for <see cref="PluginFormat.StockSwatches"/>, in the same order, or null.</summary>
    public IReadOnlyList<uint>? Swatches { get; init; }

    public uint? PriorityLow { get; init; }
    public uint? PriorityMedium { get; init; }
    public uint? PriorityHigh { get; init; }

    public bool HasPriorityColors => PriorityLow.HasValue || PriorityMedium.HasValue || PriorityHigh.HasValue;
}

/// <summary>
/// The .dayboard-plugin file format: a zip with plugin.json at its root plus the file its "entry" names.
/// Plugins are data only. Nothing in a plugin is ever executed.
/// </summary>
public static class PluginFormat
{
    public const string FormatName = "dayboard-plugin";
    public const int CurrentFormatVersion = 1;
    public const string FileExtension = ".dayboard-plugin";
    public const string ManifestFile = "plugin.json";

    public const long MaxPackageBytes = 16 * 1024 * 1024;
    public const int MaxEntries = 64;

    /// <summary>Limit for text files (plugin.json, theme.json).</summary>
    public const int MaxFileBytes = 512 * 1024;

    /// <summary>Limit for each .dll in a code plugin.</summary>
    public const int MaxAssemblyBytes = 8 * 1024 * 1024;

    /// <summary>Limit for everything in a plugin file once unpacked.</summary>
    public const long MaxUnpackedBytes = 32 * 1024 * 1024;

    /// <summary>The plugin API version this DayBoard implements, and the assembly code plugins build against.</summary>
    public const int CurrentApiVersion = 3;
    public const string ApiAssemblyName = "DayBoard.Plugins";

    /// <summary>The colour slots a theme can set. They match the DB.* keys in Themes/Palette.*.xaml.</summary>
    public static readonly IReadOnlyList<string> ThemeSlots = new[]
    {
        "CardBackground", "CardBackgroundHover", "CardStroke", "CardStrokeHover", "ColumnBackground", "ColumnBackgroundToday",
        "DropTarget", "PanelBackground", "TextPrimary", "TextSecondary", "TextTertiary", "Divider", "GridLine", "GridLineSoft",
        "Accent", "AccentSoft", "AccentText", "OnAccent", "NowLine", "CapacityOk", "CapacityNear", "CapacityOver", "CapacityTrack",
        "ChipBackground", "NavHover", "NavSelected", "Heat0", "Heat1", "Heat2", "Heat3", "Heat4", "Danger", "Warning", "Success",
        "ToastBackground", "ToastText", "EventStripe", "ScrimBackground", "WindowBackground",
    };

    /// <summary>
    /// DayBoard's 12 category colours as they're stored (blue, indigo, violet, pink, red, orange, amber, lime, green,
    /// teal, cyan, slate). They're shown in the muted <see cref="StockLook.Swatches"/>, or a theme's "swatches" list,
    /// position by position. Stored colours don't change.
    /// </summary>
    public static readonly IReadOnlyList<string> StockSwatches = new[]
    {
        "#3B82F6", "#6366F1", "#8B5CF6", "#EC4899", "#E5484D", "#F97316",
        "#F59E0B", "#84CC16", "#10B981", "#14B8A6", "#06B6D4", "#64748B",
    };

    private static readonly Regex IdPattern = new("^[a-z0-9][a-z0-9-]*(\\.[a-z0-9][a-z0-9-]*)+$", RegexOptions.CultureInvariant);
    private static readonly Regex FileNamePattern = new("^[A-Za-z0-9][A-Za-z0-9._-]*$", RegexOptions.CultureInvariant);

    private static readonly Dictionary<string, string> SlotLookup =
        ThemeSlots.ToDictionary(s => s, s => s, StringComparer.OrdinalIgnoreCase);

    /// <summary>The name in a plugin.json that can't be used, for showing it in Settings. Null when there's none.</summary>
    public static string? TryReadName(string manifestJson)
    {
        try
        {
            using var doc = JsonDocument.Parse(manifestJson);
            return doc.RootElement.ValueKind == JsonValueKind.Object && doc.RootElement.TryGetProperty("name", out var n) &&
                   n.ValueKind == JsonValueKind.String && n.GetString() is { Length: > 0 and <= 60 } name ? name.Trim() : null;
        }
        catch (JsonException)
        {
            return null;
        }
    }

    public static bool IsValidId(string? id) => id is { Length: > 2 and <= 100 } && IdPattern.IsMatch(id);

    // ------------------------------------------------------------------ package

    /// <summary>Reads and checks a .dayboard-plugin file. Returns its manifest and the files to keep.</summary>
    public static (PluginManifest Manifest, Dictionary<string, byte[]> Files) ReadPackage(string path, Version appVersion)
    {
        var info = new FileInfo(path);
        if (!info.Exists) throw new PluginException("The plugin file couldn't be found.");
        if (info.Length > MaxPackageBytes) throw new PluginException("This file is too large to be a DayBoard plugin.");

        Dictionary<string, byte[]> raw;
        try
        {
            using var zip = ZipFile.OpenRead(path);
            raw = ReadEntries(zip);
        }
        catch (InvalidDataException)
        {
            throw new PluginException("This file isn't a DayBoard plugin.");
        }

        if (!raw.TryGetValue(ManifestFile, out var manifestBytes))
            throw new PluginException("This file isn't a DayBoard plugin (it has no plugin.json).");
        var manifest = ParseManifest(Decode(manifestBytes, ManifestFile), appVersion);
        if (!raw.TryGetValue(manifest.Entry, out var entryBytes))
            throw new PluginException($"The plugin is missing its {manifest.Entry} file.");
        var keep = new Dictionary<string, byte[]>(StringComparer.Ordinal)
        {
            [ManifestFile] = manifestBytes,
            [manifest.Entry] = entryBytes,
        };
        if (manifest.Kind == PluginKind.Code)
        {
            ValidatePluginAssembly(entryBytes, manifest.Entry);
            // A code plugin may bring its own libraries. Copies of assemblies DayBoard already has are never loaded.
            foreach (var (name, bytes) in raw)
            {
                if (name.EndsWith(".dll", StringComparison.OrdinalIgnoreCase)) keep[name] = bytes;
            }
        }
        else
        {
            ValidateContent(manifest, Decode(entryBytes, manifest.Entry));
        }
        return (manifest, keep);
    }

    private static Dictionary<string, byte[]> ReadEntries(ZipArchive zip)
    {
        var files = zip.Entries.Where(e => !e.FullName.EndsWith('/') && !e.FullName.EndsWith('\\')).ToList();
        if (files.Count > MaxEntries) throw new PluginException("This file has too many entries to be a DayBoard plugin.");

        // Accept zips made by compressing a folder ("FadedCherry/plugin.json"): strip one shared top folder.
        string prefix = "";
        var names = files.Select(e => e.FullName.Replace('\\', '/')).ToList();
        if (!names.Contains(ManifestFile) && names.Count > 0)
        {
            var first = names[0];
            int slash = first.IndexOf('/');
            if (slash > 0)
            {
                var candidate = first[..(slash + 1)];
                if (names.All(n => n.StartsWith(candidate, StringComparison.Ordinal))) prefix = candidate;
            }
        }

        var result = new Dictionary<string, byte[]>(StringComparer.Ordinal);
        long total = 0;
        for (int i = 0; i < files.Count; i++)
        {
            var name = names[i][prefix.Length..];
            // Only plain top-level file names are used; anything in a subfolder is ignored, never extracted.
            if (!FileNamePattern.IsMatch(name)) continue;
            int limit = LimitFor(name);
            if (files[i].Length > limit) throw new PluginException($"The plugin's {name} file is too large.");
            using var s = files[i].Open();
            var bytes = ReadLimited(s, name, limit);
            total += bytes.Length;
            if (total > MaxUnpackedBytes) throw new PluginException("This file is too large to be a DayBoard plugin.");
            result[name] = bytes;
        }
        return result;
    }

    public static int LimitFor(string fileName) =>
        fileName.EndsWith(".dll", StringComparison.OrdinalIgnoreCase) ? MaxAssemblyBytes : MaxFileBytes;

    private static byte[] ReadLimited(Stream s, string name, int limit)
    {
        using var ms = new MemoryStream();
        var buffer = new byte[16 * 1024];
        int n;
        while ((n = s.Read(buffer, 0, buffer.Length)) > 0)
        {
            if (ms.Length + n > limit) throw new PluginException($"The plugin's {name} file is too large.");
            ms.Write(buffer, 0, n);
        }
        return ms.ToArray();
    }

    private static string Decode(byte[] bytes, string name)
    {
        try
        {
            return new UTF8Encoding(false, true).GetString(bytes).TrimStart('﻿');
        }
        catch (DecoderFallbackException)
        {
            throw new PluginException($"The plugin's {name} file isn't valid text.");
        }
    }

    public static void ValidateContent(PluginManifest manifest, string entryText)
    {
        switch (manifest.Kind)
        {
            case PluginKind.Theme:
                ParseTheme(entryText);
                break;
        }
    }

    // ------------------------------------------------------------------ manifest

    public static PluginManifest ParseManifest(string json, Version appVersion)
    {
        JsonElement root;
        try
        {
            using var doc = JsonDocument.Parse(json, new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip });
            root = doc.RootElement.Clone();
        }
        catch (JsonException ex)
        {
            throw new PluginException("The plugin's plugin.json couldn't be read: " + ex.Message);
        }
        if (root.ValueKind != JsonValueKind.Object) throw new PluginException("This file isn't a DayBoard plugin.");

        if (!string.Equals(Str(root, "format"), FormatName, StringComparison.Ordinal))
            throw new PluginException("This file isn't a DayBoard plugin.");
        int formatVersion = root.TryGetProperty("formatVersion", out var fv) && fv.TryGetInt32(out var v) ? v : 0;
        if (formatVersion < 1) throw new PluginException("The plugin's plugin.json has no valid formatVersion.");
        if (formatVersion > CurrentFormatVersion) throw new PluginException("This plugin needs a newer version of DayBoard.");

        var id = Str(root, "id");
        if (!IsValidId(id)) throw new PluginException("The plugin's id is missing or invalid. Use lowercase words separated by dots, such as \"yourname.theme.sunset\".");
        var name = Str(root, "name")?.Trim();
        if (string.IsNullOrEmpty(name) || name.Length > 60) throw new PluginException("The plugin needs a name of up to 60 characters.");
        var version = Str(root, "version")?.Trim();
        if (string.IsNullOrEmpty(version) || version.Length > 20) throw new PluginException("The plugin needs a version, such as \"1.0.0\".");

        var kindText = Str(root, "kind")?.Trim() ?? "";
        PluginKind kind = kindText switch
        {
            "theme" => PluginKind.Theme,
            "code" => PluginKind.Code,
            "feature" => throw new PluginException(
                "This plugin was made for DayBoard 1.2. Add its new version (2.0 or later) to use it again. Anything it saved is kept.", outdated: true),
            _ => throw new PluginException(kindText.Length == 0
                ? "The plugin's plugin.json doesn't say what kind of plugin it is."
                : $"This version of DayBoard doesn't support \"{Clip(kindText, 30)}\" plugins."),
        };

        var min = Str(root, "minAppVersion")?.Trim() ?? "";
        if (min.Length > 0)
        {
            if (!System.Version.TryParse(min, out var minVersion)) throw new PluginException("The plugin's minAppVersion isn't a valid version.");
            if (Normalize(minVersion) > Normalize(appVersion))
                throw new PluginException($"This plugin needs DayBoard {min} or newer. You have {appVersion.ToString(3)}.");
        }

        var entry = Str(root, "entry")?.Trim() ?? "";
        if (entry.Length == 0 || !FileNamePattern.IsMatch(entry) || entry == ManifestFile)
            throw new PluginException("The plugin's entry must name a file next to plugin.json, such as \"theme.json\".");

        int apiVersion = 0;
        if (kind == PluginKind.Code)
        {
            if (!entry.EndsWith(".dll", StringComparison.OrdinalIgnoreCase))
                throw new PluginException("A code plugin's entry must be its .dll file.");
            apiVersion = root.TryGetProperty("apiVersion", out var av) && av.TryGetInt32(out var a) ? a : 0;
            if (apiVersion < 1) throw new PluginException("A code plugin's plugin.json needs an apiVersion, such as 1.");
            if (apiVersion > CurrentApiVersion)
                throw new PluginException($"This plugin needs a newer version of DayBoard (plugin API {apiVersion}). You have {appVersion.ToString(3)}.");
        }

        return new PluginManifest
        {
            FormatVersion = formatVersion,
            Id = id!,
            Name = name,
            Version = version,
            Author = Clip(Str(root, "author")?.Trim() ?? "", 60),
            Description = Clip(Str(root, "description")?.Trim() ?? "", 300),
            Kind = kind,
            MinAppVersion = min,
            Entry = entry,
            ApiVersion = apiVersion,
        };
    }

    private static Version Normalize(Version v) => new(v.Major, Math.Max(0, v.Minor), Math.Max(0, v.Build));

    private static string? Str(JsonElement obj, string name) =>
        obj.TryGetProperty(name, out var p) && p.ValueKind == JsonValueKind.String ? p.GetString() : null;

    private static string Clip(string s, int max) => s.Length <= max ? s : s[..(max - 1)] + "…";

    // ------------------------------------------------------------------ code

    /// <summary>
    /// Checks that a code plugin's .dll is a .NET assembly built against the plugin API with a public class that
    /// implements IDayBoardPlugin. Reads metadata only; nothing in the file runs.
    /// </summary>
    public static void ValidatePluginAssembly(byte[] bytes, string name)
    {
        try
        {
            using var pe = new PEReader(new MemoryStream(bytes), PEStreamOptions.PrefetchEntireImage);
            if (!pe.HasMetadata) throw new PluginException($"The plugin's {name} isn't a .NET assembly.");
            var md = pe.GetMetadataReader();
            if (!md.IsAssembly) throw new PluginException($"The plugin's {name} isn't a .NET assembly.");
            bool usesApi = md.AssemblyReferences.Any(h => md.GetString(md.GetAssemblyReference(h).Name) == ApiAssemblyName);
            if (!usesApi) throw new PluginException($"The plugin's {name} wasn't built for DayBoard (it doesn't use the plugin API).");
            bool hasEntryClass = md.TypeDefinitions.Select(md.GetTypeDefinition).Any(t =>
                (t.Attributes & TypeAttributes.VisibilityMask) == TypeAttributes.Public &&
                (t.Attributes & (TypeAttributes.Abstract | TypeAttributes.Interface)) == 0 &&
                t.GetInterfaceImplementations().Any(ih => IsPluginInterface(md, md.GetInterfaceImplementation(ih).Interface)));
            if (!hasEntryClass) throw new PluginException($"The plugin's {name} has no public class that implements IDayBoardPlugin.");
        }
        catch (BadImageFormatException)
        {
            throw new PluginException($"The plugin's {name} isn't a valid .NET assembly.");
        }
    }

    private static bool IsPluginInterface(MetadataReader md, EntityHandle handle)
    {
        if (handle.Kind != HandleKind.TypeReference) return false;
        var r = md.GetTypeReference((TypeReferenceHandle)handle);
        return md.GetString(r.Name) == "IDayBoardPlugin" && md.GetString(r.Namespace) == ApiAssemblyName;
    }

    // ------------------------------------------------------------------ theme

    public static ThemeDefinition ParseTheme(string json)
    {
        JsonElement root;
        try
        {
            using var doc = JsonDocument.Parse(json, new JsonDocumentOptions { AllowTrailingCommas = true, CommentHandling = JsonCommentHandling.Skip });
            root = doc.RootElement.Clone();
        }
        catch (JsonException ex)
        {
            throw new PluginException("The theme file couldn't be read: " + ex.Message);
        }
        if (root.ValueKind != JsonValueKind.Object) throw new PluginException("The theme file must be a JSON object.");

        var light = Slots(root, "light");
        var dark = Slots(root, "dark");
        if (light.Count == 0 && dark.Count == 0)
            throw new PluginException("The theme doesn't set any colours. Add a \"light\" or \"dark\" section.");

        uint? accentLight = null, accentDark = null;
        if (root.TryGetProperty("accent", out var accent) && accent.ValueKind == JsonValueKind.Object)
        {
            accentLight = OptionalColor(accent, "light", "accent › light");
            accentDark = OptionalColor(accent, "dark", "accent › dark");
        }

        List<uint>? swatches = null;
        if (root.TryGetProperty("swatches", out var sw) && sw.ValueKind != JsonValueKind.Null)
        {
            if (sw.ValueKind != JsonValueKind.Array || sw.GetArrayLength() != StockSwatches.Count)
                throw new PluginException($"The theme's \"swatches\" must list exactly {StockSwatches.Count} colours.");
            swatches = new List<uint>();
            int i = 0;
            foreach (var item in sw.EnumerateArray())
            {
                i++;
                swatches.Add(ParseColorOrThrow(item.ValueKind == JsonValueKind.String ? item.GetString() : null, $"swatches › {i}"));
            }
        }

        uint? low = null, medium = null, high = null;
        if (root.TryGetProperty("priority", out var pr) && pr.ValueKind == JsonValueKind.Object)
        {
            low = OptionalColor(pr, "low", "priority › low");
            medium = OptionalColor(pr, "medium", "priority › medium");
            high = OptionalColor(pr, "high", "priority › high");
        }

        return new ThemeDefinition
        {
            Light = light,
            Dark = dark,
            AccentLight = accentLight,
            AccentDark = accentDark,
            Swatches = swatches,
            PriorityLow = low,
            PriorityMedium = medium,
            PriorityHigh = high,
        };
    }

    private static Dictionary<string, uint> Slots(JsonElement root, string mode)
    {
        var map = new Dictionary<string, uint>(StringComparer.Ordinal);
        if (!root.TryGetProperty(mode, out var section) || section.ValueKind == JsonValueKind.Null) return map;
        if (section.ValueKind != JsonValueKind.Object) throw new PluginException($"The theme's \"{mode}\" section must be an object of colours.");
        foreach (var p in section.EnumerateObject())
        {
            // Unknown slots are ignored, so themes made for newer versions still load.
            if (!SlotLookup.TryGetValue(p.Name, out var slot)) continue;
            map[slot] = ParseColorOrThrow(p.Value.ValueKind == JsonValueKind.String ? p.Value.GetString() : null, $"{mode} › {slot}");
        }
        return map;
    }

    private static uint? OptionalColor(JsonElement obj, string name, string label) =>
        obj.TryGetProperty(name, out var p) && p.ValueKind != JsonValueKind.Null
            ? ParseColorOrThrow(p.ValueKind == JsonValueKind.String ? p.GetString() : null, label)
            : null;

    private static uint ParseColorOrThrow(string? text, string label) =>
        TryParseColor(text, out var c) ? c : throw new PluginException($"The theme has an invalid colour for {label}: \"{Clip(text ?? "", 20)}\". Use #RRGGBB or #AARRGGBB.");

    /// <summary>Parses #RGB, #RRGGBB or #AARRGGBB into 0xAARRGGBB.</summary>
    public static bool TryParseColor(string? text, out uint argb)
    {
        argb = 0;
        if (text is null) return false;
        var s = text.Trim();
        if (!s.StartsWith('#')) return false;
        s = s[1..];
        if (s.Length == 3) s = string.Concat(s.Select(ch => new string(ch, 2)));
        if (s.Length == 6) s = "FF" + s;
        if (s.Length != 8) return false;
        return uint.TryParse(s, NumberStyles.AllowHexSpecifier, CultureInfo.InvariantCulture, out argb);
    }

    public static string ToHex(uint argb) =>
        (argb >> 24) == 0xFF ? $"#{argb & 0xFFFFFF:X6}" : $"#{argb:X8}";
}
