using System.Text.Json;
using DayBoard.Core.Models;

namespace DayBoard.Data.Plugins;

/// <summary>Settings from before a feature became a plugin, in the form that plugin stores them.</summary>
public static class LegacySettings
{
    /// <summary>The Focus plugin's id. Focus was part of DayBoard itself until 1.4.</summary>
    public const string FocusPluginId = "dayboard.focus";

    /// <summary>The key Focus keeps its timer settings under.</summary>
    public const string FocusSettingsKey = "settings";

    /// <summary>The focus timer settings from DayBoard 1.3's Settings page, as the Focus plugin's JSON.</summary>
    public static string FocusTimer(AppSettings s) => JsonSerializer.Serialize(new
    {
        workMinutes = s.PomodoroWorkMinutes,
        breakMinutes = s.PomodoroBreakMinutes,
        longBreakMinutes = s.PomodoroLongBreakMinutes,
        longBreakEvery = s.PomodoroLongBreakEvery,
        autoStartBreak = s.PomodoroAutoStartBreak,
    });

    /// <summary>The Matrix, Kanban and Review views, which became plugins in DayBoard 1.6.</summary>
    public static readonly IReadOnlyList<MovedView> MovedViews = new MovedView[]
    {
        new("Matrix", "dayboard.matrix", "matrix", "Eisenhower matrix"),
        new("Kanban", "dayboard.kanban", "kanban", "Kanban board"),
        new("Review", "dayboard.weekly-review", "review", "Weekly review"),
    };

    /// <summary>Marks the one-time note about <see cref="MovedViews"/> in <see cref="AppSettings.SeenNotes"/>.</summary>
    public const string ViewsMovedNoteId = "1.6-views-to-plugins";

    /// <summary>
    /// The note, shown once, for someone who used DayBoard before 1.6 and hasn't added all three plugins. Marks it seen
    /// in <paramref name="settings"/> either way, so new installs never see it.
    /// </summary>
    public static string? TakeViewsMovedNote(AppSettings settings, bool usedBefore, IReadOnlyCollection<string> installedPluginIds)
    {
        if (settings.SeenNotes.Contains(ViewsMovedNoteId)) return null;
        settings.SeenNotes.Add(ViewsMovedNoteId);
        if (!usedBefore || MovedViews.All(v => installedPluginIds.Contains(v.PluginId))) return null;
        return "Kanban, Matrix and Review are plugins now. Add the ones you use in Settings › Plugins: " +
               "they're in the Plugins folder of the DayBoard download.";
    }

    /// <summary>Copies the focus timer settings into the Focus plugin's storage, unless it has its own already.</summary>
    public static bool CarryOverFocusTimer(PluginDataStore data, AppSettings settings, DateTime now)
    {
        if (data.Get(FocusPluginId, FocusSettingsKey) is not null) return false;
        data.Set(FocusPluginId, FocusSettingsKey, FocusTimer(settings), now);
        return true;
    }
}

/// <summary>A view that moved out of DayBoard into a plugin: its old name (as kept in LastView) and where it went.</summary>
public sealed record MovedView(string View, string PluginId, string PageId, string PluginName);
