namespace DayBoard.Data.Plugins;

/// <summary>
/// DayBoard's own colours outside the palette files (Themes/Palette.*.xaml): the "Dusty Plum" look since 1.5, chosen to
/// match the logo. A theme plugin that sets these replaces them while it's ticked.
/// </summary>
public static class StockLook
{
    /// <summary>The accent of the standard controls (tick boxes, focus lines).</summary>
    public const uint AccentLight = 0xFF7D5F80;
    public const uint AccentDark = 0xFFC2A3C4;

    /// <summary>
    /// How the 12 stock category colours (<see cref="PluginFormat.StockSwatches"/>, which is what's stored) are shown:
    /// muted versions in the same order. Stored colours never change.
    /// </summary>
    public static readonly IReadOnlyList<uint> Swatches = new uint[]
    {
        0xFF7E97B3, 0xFF7F86B0, 0xFF9A88B5, 0xFFC98A9A, 0xFFB5666A, 0xFFBF8B66,
        0xFFC9A04E, 0xFF9AAA6A, 0xFF7A9A6B, 0xFF6F9A94, 0xFF74A0AE, 0xFF8C8478,
    };

    /// <summary>The priority colours shown while the ones in Settings are still DayBoard's defaults.</summary>
    public const uint PriorityLow = 0xFF7E97B3;
    public const uint PriorityMedium = 0xFFC9A04E;
    public const uint PriorityHigh = 0xFFB5585A;
}
