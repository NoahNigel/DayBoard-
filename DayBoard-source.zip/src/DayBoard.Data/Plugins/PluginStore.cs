namespace DayBoard.Data.Plugins;

/// <summary>A plugin found in the plugins folder. <see cref="Error"/> is set when it can't be used.</summary>
public sealed class InstalledPlugin
{
    public required string Id { get; init; }
    public required string Directory { get; init; }
    public PluginManifest? Manifest { get; init; }
    public ThemeDefinition? Theme { get; init; }

    public bool IsCode => Manifest?.Kind == PluginKind.Code;

    /// <summary>Comes with DayBoard (such as Focus): on until it's unticked, and it can't be removed or replaced by a file.</summary>
    public bool IsBuiltIn => BuiltInType is not null;

    /// <summary>Built-in plugins: the plugin class, as "Namespace.Type, Assembly".</summary>
    public string? BuiltInType { get; init; }

    /// <summary>Code plugins: the .dll DayBoard loads.</summary>
    public string? EntryPath => Manifest is null ? null : Path.Combine(Directory, Manifest.Entry);
    public string? Error { get; init; }

    /// <summary>Made for an older DayBoard (a 1.2 feature plugin): its new version needs adding.</summary>
    public bool IsOutdated { get; init; }

    /// <summary>The name from a plugin.json that couldn't be used.</summary>
    public string? FallbackName { get; init; }

    public bool IsUsable => Error is null && Manifest is not null;
    public string Name => Manifest?.Name ?? FallbackName ?? Id;
}

/// <summary>
/// Installed plugins live in <c>&lt;data&gt;\plugins\&lt;id&gt;\</c> as their plugin.json plus the entry file (and, for a
/// code plugin, the libraries it brings). Nothing here runs plugin code: loading code plugins is up to the app.
/// </summary>
public sealed class PluginStore
{
    private readonly string _root;
    private readonly Version _appVersion;

    public PluginStore(string root, Version appVersion)
    {
        _root = root;
        _appVersion = appVersion;
    }

    public string Root => _root;

    public IReadOnlyList<InstalledPlugin> LoadAll()
    {
        var list = new List<InstalledPlugin>();
        if (!System.IO.Directory.Exists(_root)) return list;
        foreach (var dir in new DirectoryInfo(_root).GetDirectories())
        {
            if (dir.Name.StartsWith('.')) continue;
            list.Add(Load(dir.FullName));
        }
        return list.OrderBy(p => p.Name, StringComparer.CurrentCultureIgnoreCase).ToList();
    }

    private InstalledPlugin Load(string dir)
    {
        var folderId = Path.GetFileName(dir);
        string? manifestText = null;
        try
        {
            var manifestPath = Path.Combine(dir, PluginFormat.ManifestFile);
            if (!File.Exists(manifestPath)) throw new PluginException("Its plugin.json is missing.");
            manifestText = ReadText(manifestPath);
            var manifest = PluginFormat.ParseManifest(manifestText, _appVersion);
            if (manifest.Id != folderId) throw new PluginException("Its folder name doesn't match its id.");
            var entryPath = Path.Combine(dir, manifest.Entry);
            if (!File.Exists(entryPath)) throw new PluginException($"Its {manifest.Entry} file is missing.");
            ThemeDefinition? theme = null;
            if (manifest.Kind == PluginKind.Theme)
            {
                theme = PluginFormat.ParseTheme(ReadText(entryPath));
            }
            else if (manifest.Kind == PluginKind.Code)
            {
                if (new FileInfo(entryPath).Length > PluginFormat.MaxAssemblyBytes) throw new PluginException($"Its {manifest.Entry} file is too large.");
                PluginFormat.ValidatePluginAssembly(File.ReadAllBytes(entryPath), manifest.Entry);
            }
            return new InstalledPlugin { Id = manifest.Id, Directory = dir, Manifest = manifest, Theme = theme };
        }
        catch (Exception ex) when (ex is PluginException or IOException or UnauthorizedAccessException)
        {
            return new InstalledPlugin
            {
                Id = folderId,
                Directory = dir,
                Error = ex.Message,
                IsOutdated = ex is PluginException { Outdated: true },
                FallbackName = manifestText is null ? null : PluginFormat.TryReadName(manifestText),
            };
        }
    }

    private static string ReadText(string path)
    {
        if (new FileInfo(path).Length > PluginFormat.MaxFileBytes) throw new PluginException($"Its {Path.GetFileName(path)} file is too large.");
        return File.ReadAllText(path).TrimStart('﻿');
    }

    /// <summary>
    /// Installs a .dayboard-plugin file. A plugin with the same id is replaced (an update).
    /// Throws <see cref="PluginException"/> with a readable message when the file isn't a valid plugin.
    /// </summary>
    public InstalledPlugin Install(string packagePath)
    {
        var (manifest, files) = PluginFormat.ReadPackage(packagePath, _appVersion);
        System.IO.Directory.CreateDirectory(_root);
        var target = Path.Combine(_root, manifest.Id);
        var incoming = Path.Combine(_root, ".incoming-" + Guid.NewGuid().ToString("N"));
        var old = Path.Combine(_root, ".old-" + Guid.NewGuid().ToString("N"));
        try
        {
            System.IO.Directory.CreateDirectory(incoming);
            foreach (var (name, bytes) in files) File.WriteAllBytes(Path.Combine(incoming, name), bytes);
            if (System.IO.Directory.Exists(target)) System.IO.Directory.Move(target, old);
            System.IO.Directory.Move(incoming, target);
        }
        catch
        {
            if (!System.IO.Directory.Exists(target) && System.IO.Directory.Exists(old)) System.IO.Directory.Move(old, target);
            TryDelete(incoming);
            throw;
        }
        TryDelete(old);
        var installed = Load(target);
        return installed.IsUsable ? installed : throw new PluginException(installed.Error ?? "The plugin couldn't be installed.");
    }

    public void Remove(string id)
    {
        if (!PluginFormat.IsValidId(id) && !IsPlainFolderName(id)) throw new ArgumentException("Invalid plugin id.", nameof(id));
        var dir = Path.Combine(_root, id);
        if (System.IO.Directory.Exists(dir)) System.IO.Directory.Delete(dir, recursive: true);
    }

    // A broken plugin may sit in a folder whose name isn't a valid id; it can still be removed, but never with path tricks.
    private static bool IsPlainFolderName(string name) =>
        name.Length is > 0 and <= 100 && !name.StartsWith('.') && name.IndexOfAny(Path.GetInvalidFileNameChars()) < 0 &&
        name.IndexOfAny(new[] { '/', '\\', ':' }) < 0;

    /// <summary>Clears leftovers from an install that was interrupted.</summary>
    public void CleanUp()
    {
        if (!System.IO.Directory.Exists(_root)) return;
        foreach (var dir in new DirectoryInfo(_root).GetDirectories(".*")) TryDelete(dir.FullName);
    }

    private static void TryDelete(string dir)
    {
        try
        {
            if (System.IO.Directory.Exists(dir)) System.IO.Directory.Delete(dir, recursive: true);
        }
        catch (IOException)
        {
        }
        catch (UnauthorizedAccessException)
        {
        }
    }
}
