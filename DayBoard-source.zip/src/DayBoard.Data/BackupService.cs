using System.Globalization;
using System.IO;
using Microsoft.Data.Sqlite;

namespace DayBoard.Data;

/// <summary>Daily copies of the database (SQLite online backup), keeping the most recent 14.</summary>
public static class BackupService
{
    public const int Keep = 14;
    private const string Prefix = "dayboard-";

    public static string? RunDailyIfNeeded(SqliteRepository repo, DateOnly today, string? dir = null)
    {
        dir ??= AppPaths.BackupDir;
        var path = Path.Combine(dir, $"{Prefix}{today:yyyy-MM-dd}.db");
        if (File.Exists(path)) return null;
        return BackupNow(repo, path, dir);
    }

    public static string BackupNow(SqliteRepository repo, string? path = null, string? dir = null)
    {
        dir ??= AppPaths.BackupDir;
        Directory.CreateDirectory(dir);
        path ??= Path.Combine(dir, $"{Prefix}{DateTime.Now:yyyy-MM-dd}.db");
        var tmp = path + ".tmp";
        if (File.Exists(tmp)) File.Delete(tmp);
        using (var dest = new SqliteConnection(new SqliteConnectionStringBuilder { DataSource = tmp, Pooling = false }.ToString()))
        {
            dest.Open();
            repo.Connection.BackupDatabase(dest);
        }
        File.Move(tmp, path, overwrite: true);
        Prune(dir);
        return path;
    }

    public static IReadOnlyList<FileInfo> List(string? dir = null)
    {
        var info = new DirectoryInfo(dir ?? AppPaths.BackupDir);
        return info.Exists ? info.GetFiles(Prefix + "*.db").OrderByDescending(f => f.Name).ToList() : Array.Empty<FileInfo>();
    }

    private static void Prune(string dir)
    {
        foreach (var old in List(dir).Skip(Keep))
        {
            try
            {
                old.Delete();
            }
            catch (IOException ex)
            {
                Log.Error("Prune backup", ex);
            }
        }
    }

    /// <summary>Schedules a backup to replace the live database on the next start.</summary>
    public static void ScheduleRestore(string backupFile) => File.Copy(backupFile, AppPaths.PendingRestore, overwrite: true);

    /// <summary>Called at startup before the database is opened.</summary>
    public static bool ApplyPendingRestore()
    {
        if (!File.Exists(AppPaths.PendingRestore)) return false;
        try
        {
            if (File.Exists(AppPaths.Database))
            {
                var stamp = DateTime.Now.ToString("yyyyMMdd-HHmmss", CultureInfo.InvariantCulture);
                File.Copy(AppPaths.Database, Path.Combine(AppPaths.BackupDir, $"before-restore-{stamp}.db"), overwrite: true);
            }
            foreach (var suffix in new[] { "-wal", "-shm" })
            {
                var f = AppPaths.Database + suffix;
                if (File.Exists(f)) File.Delete(f);
            }
            File.Move(AppPaths.PendingRestore, AppPaths.Database, overwrite: true);
            return true;
        }
        catch (Exception ex)
        {
            Log.Error("Apply restore", ex);
            return false;
        }
    }
}
