using System.Text.Json;
using System.Text.Json.Serialization;
using DayBoard.Core.Models;

namespace DayBoard.Data;

/// <summary>Loads and saves <see cref="AppSettings"/> as one JSON document in the settings table.</summary>
public sealed class SettingsStore
{
    private const string Key = "app";
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = false,
        Converters = { new JsonStringEnumConverter() },
    };

    private readonly SqliteRepository _repo;

    public SettingsStore(SqliteRepository repo) => _repo = repo;

    public AppSettings Load()
    {
        var json = _repo.GetSetting(Key);
        if (string.IsNullOrWhiteSpace(json)) return new AppSettings();
        try
        {
            return JsonSerializer.Deserialize<AppSettings>(json, Options) ?? new AppSettings();
        }
        catch (JsonException ex)
        {
            Log.Error("Settings are unreadable, using defaults", ex);
            return new AppSettings();
        }
    }

    public void Save(AppSettings settings) => _repo.SetSetting(Key, JsonSerializer.Serialize(settings, Options));
}
