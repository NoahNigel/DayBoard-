using System.IO;

namespace DayBoard.Data;

/// <summary>All data lives under %LOCALAPPDATA%\DayBoard.</summary>
public static class AppPaths
{
    /// <summary>%LOCALAPPDATA%\DayBoard, or the DAYBOARD_DATA_DIR environment variable (the self-test uses a temporary folder).</summary>
    public static string DataDir { get; set; } =
        Environment.GetEnvironmentVariable("DAYBOARD_DATA_DIR") is { Length: > 0 } custom
            ? custom
            : Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "DayBoard");
    public static string Database => Path.Combine(DataDir, "dayboard.db");
    public static string PendingRestore => Path.Combine(DataDir, "dayboard.db.restore");
    public static string BackupDir => Path.Combine(DataDir, "backups");
    public static string CalendarCacheDir => Path.Combine(DataDir, "calendars");
    public static string LogDir => Path.Combine(DataDir, "logs");
    public static string PluginDir => Path.Combine(DataDir, "plugins");

    /// <summary>Path of the running executable (the single-file .exe when published).</summary>
    public static string ExecutablePath => Environment.ProcessPath ?? Path.Combine(AppContext.BaseDirectory, "DayBoard.exe");

    /// <summary>The Plugins folder that comes next to DayBoard.exe in the download, when it's there.</summary>
    public static string? BundledPluginDir
    {
        get
        {
            try
            {
                var dir = Path.Combine(Path.GetDirectoryName(ExecutablePath) ?? AppContext.BaseDirectory, "Plugins");
                return Directory.Exists(dir) ? dir : null;
            }
            catch (Exception ex) when (ex is IOException or UnauthorizedAccessException or ArgumentException)
            {
                return null;
            }
        }
    }

    public static void EnsureCreated()
    {
        Directory.CreateDirectory(DataDir);
        Directory.CreateDirectory(BackupDir);
        Directory.CreateDirectory(CalendarCacheDir);
        Directory.CreateDirectory(LogDir);
    }
}

public static class Log
{
    private static readonly object Gate = new();

    public static void Error(string context, Exception ex) => Write("ERROR", $"{context}: {ex}");

    public static void Info(string message) => Write("INFO", message);

    private static void Write(string level, string message)
    {
        try
        {
            lock (Gate)
            {
                Directory.CreateDirectory(AppPaths.LogDir);
                var path = Path.Combine(AppPaths.LogDir, $"dayboard-{DateTime.Now:yyyy-MM}.log");
                File.AppendAllText(path, $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} [{level}] {message}{Environment.NewLine}");
            }
        }
        catch
        {
            // Logging must never take the app down.
        }
    }
}
