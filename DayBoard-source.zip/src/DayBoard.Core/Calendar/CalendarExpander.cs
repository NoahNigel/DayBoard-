using DayBoard.Core.Recurrence;

namespace DayBoard.Core.Calendar;

/// <summary>A concrete event instance in the machine's local time. All-day events span whole dates (End exclusive).</summary>
public sealed record CalendarOccurrence(string Uid, string Title, string? Location, DateTime Start, DateTime End, bool IsAllDay)
{
    public bool Overlaps(DateTime from, DateTime to) =>
        End > Start ? Start < to && End > from : Start >= from && Start < to;

    public bool CoversDate(DateOnly date)
    {
        var dayStart = date.ToDateTime(TimeOnly.MinValue);
        return Overlaps(dayStart, dayStart.AddDays(1));
    }
}

/// <summary>
/// Resolves TZIDs: system/IANA/Windows ids, Mozilla-style prefixed ids, Windows display names,
/// and finally the feed's own VTIMEZONE definition. Unknown zones fall back to local time.
/// </summary>
public sealed class TimeZoneResolver
{
    private readonly IReadOnlyDictionary<string, IcsTimeZone> _feedZones;
    private readonly Dictionary<string, TimeZoneInfo?> _cache = new(StringComparer.OrdinalIgnoreCase);

    public TimeZoneResolver(IReadOnlyDictionary<string, IcsTimeZone> feedZones, TimeZoneInfo local)
    {
        _feedZones = feedZones;
        Local = local;
    }

    public TimeZoneInfo Local { get; }

    public TimeZoneInfo? FindSystemZone(string tzid)
    {
        if (_cache.TryGetValue(tzid, out var cached)) return cached;
        var result = TryFind(tzid);
        _cache[tzid] = result;
        return result;
    }

    private static TimeZoneInfo? TryFind(string tzid)
    {
        var id = tzid.Trim().Trim('"');
        foreach (var candidate in Candidates(id))
        {
            try
            {
                return TimeZoneInfo.FindSystemTimeZoneById(candidate);
            }
            catch (TimeZoneNotFoundException)
            {
            }
            catch (InvalidTimeZoneException)
            {
            }
            if (TimeZoneInfo.TryConvertWindowsIdToIanaId(candidate, out var iana))
            {
                try { return TimeZoneInfo.FindSystemTimeZoneById(iana); } catch (TimeZoneNotFoundException) { } catch (InvalidTimeZoneException) { }
            }
            if (TimeZoneInfo.TryConvertIanaIdToWindowsId(candidate, out var win))
            {
                try { return TimeZoneInfo.FindSystemTimeZoneById(win); } catch (TimeZoneNotFoundException) { } catch (InvalidTimeZoneException) { }
            }
        }

        // Outlook sometimes uses display names such as "(UTC+01:00) Amsterdam, Berlin, Bern, Rome, Stockholm, Vienna".
        foreach (var z in TimeZoneInfo.GetSystemTimeZones())
        {
            if (string.Equals(z.DisplayName, id, StringComparison.OrdinalIgnoreCase) ||
                string.Equals(z.StandardName, id, StringComparison.OrdinalIgnoreCase))
                return z;
        }
        return null;
    }

    private static IEnumerable<string> Candidates(string id)
    {
        yield return id;
        // "/mozilla.org/20050126_1/Europe/Amsterdam" or "/citadel.org/.../Europe/Amsterdam"
        var parts = id.Split('/', StringSplitOptions.RemoveEmptyEntries);
        for (int take = Math.Min(3, parts.Length); take >= 2; take--)
        {
            if (parts.Length > take) yield return string.Join("/", parts[^take..]);
        }
    }

    /// <summary>Converts a feed value to UTC.</summary>
    public DateTime ToUtc(IcsDateValue v) => v.IsUtc ? DateTime.SpecifyKind(v.Value, DateTimeKind.Utc) : WallToUtc(v.Value, v.TzId);

    /// <summary>Converts a wall-clock time in a feed zone (null = floating/local) to UTC.</summary>
    public DateTime WallToUtc(DateTime wall, string? tzid)
    {
        wall = DateTime.SpecifyKind(wall, DateTimeKind.Unspecified);
        if (tzid is not null)
        {
            if (FindSystemZone(tzid) is { } tz) return ConvertWall(wall, tz);
            if (_feedZones.TryGetValue(tzid, out var vtz) && vtz.Observances.Count > 0)
                return DateTime.SpecifyKind(wall - vtz.OffsetAt(wall), DateTimeKind.Utc);
        }
        return ConvertWall(wall, Local);
    }

    private static DateTime ConvertWall(DateTime wall, TimeZoneInfo tz)
    {
        // Times in the spring-forward gap don't exist; shift them forward like calendar apps do.
        if (tz.IsInvalidTime(wall)) wall = wall.AddHours(1);
        return TimeZoneInfo.ConvertTimeToUtc(wall, tz);
    }

    public DateTime UtcToLocal(DateTime utc) =>
        DateTime.SpecifyKind(TimeZoneInfo.ConvertTimeFromUtc(DateTime.SpecifyKind(utc, DateTimeKind.Utc), Local), DateTimeKind.Unspecified);
}

/// <summary>Expands a parsed feed into event instances that overlap a local time range.</summary>
public static class CalendarExpander
{
    public static List<CalendarOccurrence> Expand(IcsCalendar cal, DateTime rangeStart, DateTime rangeEnd, TimeZoneInfo? local = null)
    {
        var resolver = new TimeZoneResolver(cal.TimeZones, local ?? TimeZoneInfo.Local);
        var result = new List<CalendarOccurrence>();

        // Instances that were moved or cancelled individually (RECURRENCE-ID), keyed by UID.
        var overrides = new Dictionary<string, HashSet<DateTime>>(StringComparer.Ordinal);
        var overrideDates = new Dictionary<string, HashSet<DateOnly>>(StringComparer.Ordinal);
        foreach (var ev in cal.Events.Where(e => e.RecurrenceId.HasValue))
        {
            var rid = ev.RecurrenceId!.Value;
            if (rid.IsDate)
            {
                if (!overrideDates.TryGetValue(ev.Uid, out var ds)) overrideDates[ev.Uid] = ds = new HashSet<DateOnly>();
                ds.Add(DateOnly.FromDateTime(rid.Value));
            }
            else
            {
                if (!overrides.TryGetValue(ev.Uid, out var set)) overrides[ev.Uid] = set = new HashSet<DateTime>();
                set.Add(resolver.ToUtc(rid));
            }
        }

        foreach (var ev in cal.Events)
        {
            if (ev.IsCancelled) continue;
            try
            {
                if (ev.RRule is not null && ev.RecurrenceId is null)
                    ExpandRecurring(ev, resolver, rangeStart, rangeEnd, overrides, overrideDates, result);
                else
                    AddSingle(ev, ev.Start, resolver, rangeStart, rangeEnd, result);
            }
            catch (Exception ex) when (ex is FormatException or ArgumentException)
            {
                // Skip malformed events instead of failing the whole feed.
            }
        }

        return result.OrderBy(o => o.Start).ThenBy(o => o.Title).ToList();
    }

    private static void AddSingle(IcsEvent ev, IcsDateValue start, TimeZoneResolver resolver, DateTime from, DateTime to, List<CalendarOccurrence> result)
    {
        var occ = Build(ev, start, resolver);
        if (occ.Overlaps(from, to)) result.Add(occ);
    }

    private static CalendarOccurrence Build(IcsEvent ev, IcsDateValue start, TimeZoneResolver resolver)
    {
        if (start.IsDate)
        {
            var s = start.Value.Date;
            DateTime e;
            if (ev.End is { } end && end.Value.Date > ev.Start.Value.Date) e = s + (end.Value.Date - ev.Start.Value.Date);
            else if (ev.Duration is { } d && d.TotalDays >= 1) e = s.AddDays(Math.Max(1, (int)Math.Round(d.TotalDays)));
            else e = s.AddDays(1);
            return new CalendarOccurrence(ev.Uid, ev.Summary, ev.Location, s, e, true);
        }

        var startUtc = resolver.ToUtc(start);
        TimeSpan length = TimeSpan.Zero;
        if (ev.End is { } en && !en.IsDate) length = resolver.ToUtc(en) - resolver.ToUtc(ev.Start);
        else if (ev.Duration is { } du) length = du;
        if (length < TimeSpan.Zero) length = TimeSpan.Zero;
        var localStart = resolver.UtcToLocal(startUtc);
        return new CalendarOccurrence(ev.Uid, ev.Summary, ev.Location, localStart, localStart + length, false);
    }

    private static void ExpandRecurring(IcsEvent ev, TimeZoneResolver resolver, DateTime from, DateTime to,
        Dictionary<string, HashSet<DateTime>> overrides, Dictionary<string, HashSet<DateOnly>> overrideDates, List<CalendarOccurrence> result)
    {
        var rule = RecurrenceRule.Parse(ev.RRule!);
        var dtStartDate = DateOnly.FromDateTime(ev.Start.Value);
        var timeOfDay = TimeOnly.FromDateTime(ev.Start.Value);

        // Generous date window in the event's own zone; exact overlap is checked per instance.
        int spanDays = 1;
        if (ev.End is { } end) spanDays = Math.Max(1, (int)Math.Ceiling((end.Value - ev.Start.Value).TotalDays));
        else if (ev.Duration is { } du) spanDays = Math.Max(1, (int)Math.Ceiling(du.TotalDays));
        var fromDate = DateOnly.FromDateTime(from).AddDays(-(spanDays + 2));
        var toDate = DateOnly.FromDateTime(to).AddDays(2);

        DateTime? untilUtc = null;
        if (rule.Until is { Time: { } ut } u)
        {
            var wall = u.Date.ToDateTime(ut);
            untilUtc = u.IsUtc ? DateTime.SpecifyKind(wall, DateTimeKind.Utc) : resolver.WallToUtc(wall, ev.Start.TzId);
        }

        var exUtc = new HashSet<DateTime>();
        var exDates = new HashSet<DateOnly>();
        foreach (var x in ev.ExDates)
        {
            if (x.IsDate) exDates.Add(DateOnly.FromDateTime(x.Value));
            else exUtc.Add(resolver.ToUtc(x));
        }
        overrides.TryGetValue(ev.Uid, out var movedUtc);
        overrideDates.TryGetValue(ev.Uid, out var movedDates);

        var instances = rule.Occurrences(dtStartDate, fromDate, toDate)
            .Select(d => ev.Start with { Value = d.ToDateTime(ev.Start.IsDate ? TimeOnly.MinValue : timeOfDay) })
            .Concat(ev.RDates.Where(r => r.IsDate == ev.Start.IsDate))
            .Distinct();

        foreach (var inst in instances)
        {
            var date = DateOnly.FromDateTime(inst.Value);
            if (exDates.Contains(date) || (movedDates?.Contains(date) ?? false)) continue;
            if (!inst.IsDate)
            {
                var instUtc = resolver.ToUtc(inst);
                if (untilUtc.HasValue && instUtc > untilUtc.Value) continue;
                if (exUtc.Contains(instUtc) || (movedUtc?.Contains(instUtc) ?? false)) continue;
            }
            AddSingle(ev, inst, resolver, from, to, result);
        }
    }
}
