using System.Globalization;

namespace DayBoard.Core.Calendar;

/// <summary>A DATE or DATE-TIME value as written in the feed (wall-clock value plus how to interpret it).</summary>
public readonly record struct IcsDateValue(DateTime Value, bool IsDate, bool IsUtc, string? TzId)
{
    public static bool TryParse(IcsProperty? prop, out IcsDateValue result)
    {
        result = default;
        if (prop is null) return false;
        var raw = prop.Value.Trim();
        // EXDATE/RDATE may hold a list; callers split first.
        if (raw.Contains(',')) raw = raw.Split(',')[0];
        bool dateParam = string.Equals(prop.Param("VALUE"), "DATE", StringComparison.OrdinalIgnoreCase);
        return TryParse(raw, dateParam, prop.Param("TZID"), out result);
    }

    public static bool TryParse(string raw, bool dateOnly, string? tzid, out IcsDateValue result)
    {
        result = default;
        raw = raw.Trim();
        if (raw.Length >= 8 && (dateOnly || raw.Length == 8))
        {
            if (DateTime.TryParseExact(raw[..8], "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
            {
                result = new IcsDateValue(d, true, false, null);
                return true;
            }
            return false;
        }

        bool utc = raw.EndsWith('Z') || raw.EndsWith('z');
        var core = utc ? raw[..^1] : raw;
        if (DateTime.TryParseExact(core, new[] { "yyyyMMdd'T'HHmmss", "yyyyMMdd'T'HHmm" }, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
        {
            result = new IcsDateValue(dt, false, utc, utc ? null : NormalizeTzId(tzid));
            return true;
        }
        return false;
    }

    public static List<IcsDateValue> ParseList(IcsProperty prop)
    {
        var list = new List<IcsDateValue>();
        bool dateParam = string.Equals(prop.Param("VALUE"), "DATE", StringComparison.OrdinalIgnoreCase);
        if (string.Equals(prop.Param("VALUE"), "PERIOD", StringComparison.OrdinalIgnoreCase)) return list;
        foreach (var part in prop.Value.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            if (TryParse(part, dateParam, prop.Param("TZID"), out var v)) list.Add(v);
        }
        return list;
    }

    private static string? NormalizeTzId(string? tzid) => string.IsNullOrWhiteSpace(tzid) ? null : tzid.Trim().Trim('"');
}

public sealed class IcsEvent
{
    public string Uid { get; set; } = "";
    public string Summary { get; set; } = "";
    public string? Location { get; set; }
    public IcsDateValue Start { get; set; }
    public IcsDateValue? End { get; set; }
    public TimeSpan? Duration { get; set; }
    public string? RRule { get; set; }
    public List<IcsDateValue> ExDates { get; } = new();
    public List<IcsDateValue> RDates { get; } = new();
    public IcsDateValue? RecurrenceId { get; set; }
    public bool IsCancelled { get; set; }
    public bool IsAllDay => Start.IsDate;
}

/// <summary>One VTIMEZONE observance (STANDARD or DAYLIGHT).</summary>
public sealed class IcsObservance
{
    public DateTime Start { get; set; }
    public TimeSpan OffsetFrom { get; set; }
    public TimeSpan OffsetTo { get; set; }
    public string? RRule { get; set; }
    public List<DateTime> RDates { get; } = new();
}

public sealed class IcsTimeZone
{
    public string TzId { get; set; } = "";
    public List<IcsObservance> Observances { get; } = new();

    /// <summary>UTC offset in effect at a wall-clock time in this zone.</summary>
    public TimeSpan OffsetAt(DateTime wall)
    {
        DateTime? bestOnset = null;
        TimeSpan bestOffset = default;
        foreach (var o in Observances)
        {
            foreach (var onset in Onsets(o, wall))
            {
                if (onset <= wall && (bestOnset is null || onset > bestOnset))
                {
                    bestOnset = onset;
                    bestOffset = o.OffsetTo;
                }
            }
        }
        if (bestOnset is not null) return bestOffset;
        var earliest = Observances.OrderBy(o => o.Start).FirstOrDefault();
        return earliest?.OffsetFrom ?? TimeSpan.Zero;
    }

    private static IEnumerable<DateTime> Onsets(IcsObservance o, DateTime wall)
    {
        yield return o.Start;
        foreach (var r in o.RDates) yield return r;
        if (o.RRule is not null && Recurrence.RecurrenceRule.TryParse(o.RRule, out var rule))
        {
            var startDate = DateOnly.FromDateTime(o.Start);
            var to = DateOnly.FromDateTime(wall);
            var from = to.AddYears(-1);
            if (from < startDate) from = startDate;
            foreach (var d in rule.Occurrences(startDate, from, to))
                yield return d.ToDateTime(TimeOnly.FromDateTime(o.Start));
        }
    }
}

public sealed class IcsCalendar
{
    public string? Name { get; set; }
    public List<IcsEvent> Events { get; } = new();
    public Dictionary<string, IcsTimeZone> TimeZones { get; } = new(StringComparer.OrdinalIgnoreCase);

    public static IcsCalendar Parse(string text)
    {
        var root = IcsReader.Parse(text);
        var cal = new IcsCalendar();
        var vcal = root.Children.FirstOrDefault(c => c.Name == "VCALENDAR") ?? root;
        cal.Name = vcal.Get("X-WR-CALNAME")?.Text;

        foreach (var tz in vcal.Descendants("VTIMEZONE"))
        {
            var id = tz.Get("TZID")?.Value.Trim();
            if (string.IsNullOrEmpty(id)) continue;
            var zone = new IcsTimeZone { TzId = id };
            foreach (var obs in tz.Children.Where(c => c.Name is "STANDARD" or "DAYLIGHT"))
            {
                if (!IcsDateValue.TryParse(obs.Get("DTSTART"), out var start)) continue;
                var o = new IcsObservance
                {
                    Start = start.Value,
                    OffsetFrom = ParseOffset(obs.Get("TZOFFSETFROM")?.Value),
                    OffsetTo = ParseOffset(obs.Get("TZOFFSETTO")?.Value),
                    RRule = obs.Get("RRULE")?.Value,
                };
                foreach (var rd in obs.GetAll("RDATE"))
                    o.RDates.AddRange(IcsDateValue.ParseList(rd).Select(x => x.Value));
                zone.Observances.Add(o);
            }
            cal.TimeZones[id] = zone;
        }

        foreach (var ve in vcal.Descendants("VEVENT"))
        {
            if (!IcsDateValue.TryParse(ve.Get("DTSTART"), out var start)) continue;
            var ev = new IcsEvent
            {
                Uid = ve.Get("UID")?.Value.Trim() ?? Guid.NewGuid().ToString(),
                Summary = ve.Get("SUMMARY")?.Text.Trim() ?? "(busy)",
                Location = ve.Get("LOCATION")?.Text.Trim(),
                Start = start,
                RRule = ve.Get("RRULE")?.Value,
                IsCancelled = string.Equals(ve.Get("STATUS")?.Value.Trim(), "CANCELLED", StringComparison.OrdinalIgnoreCase),
            };
            if (string.IsNullOrWhiteSpace(ev.Summary)) ev.Summary = "(busy)";
            if (IcsDateValue.TryParse(ve.Get("DTEND"), out var end)) ev.End = end;
            if (ve.Get("DURATION") is { } dur && TryParseDuration(dur.Value, out var ts)) ev.Duration = ts;
            if (IcsDateValue.TryParse(ve.Get("RECURRENCE-ID"), out var rid)) ev.RecurrenceId = rid;
            foreach (var ex in ve.GetAll("EXDATE")) ev.ExDates.AddRange(IcsDateValue.ParseList(ex));
            foreach (var rd in ve.GetAll("RDATE")) ev.RDates.AddRange(IcsDateValue.ParseList(rd));
            cal.Events.Add(ev);
        }
        return cal;
    }

    public static TimeSpan ParseOffset(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return TimeSpan.Zero;
        s = s.Trim();
        int sign = s[0] == '-' ? -1 : 1;
        var digits = s.TrimStart('+', '-');
        if (digits.Length < 4) return TimeSpan.Zero;
        int h = int.Parse(digits[..2], CultureInfo.InvariantCulture);
        int m = int.Parse(digits.Substring(2, 2), CultureInfo.InvariantCulture);
        int sec = digits.Length >= 6 ? int.Parse(digits.Substring(4, 2), CultureInfo.InvariantCulture) : 0;
        return sign * new TimeSpan(h, m, sec);
    }

    /// <summary>Parses an RFC 5545 duration such as P1D, PT1H30M, -PT15M, P2W.</summary>
    public static bool TryParseDuration(string s, out TimeSpan result)
    {
        result = TimeSpan.Zero;
        s = s.Trim().ToUpperInvariant();
        if (s.Length < 2) return false;
        int sign = 1, i = 0;
        if (s[i] == '+' || s[i] == '-')
        {
            if (s[i] == '-') sign = -1;
            i++;
        }
        if (i >= s.Length || s[i] != 'P') return false;
        i++;
        bool inTime = false;
        long total = 0;
        int num = -1;
        for (; i < s.Length; i++)
        {
            char c = s[i];
            if (c == 'T')
            {
                inTime = true;
                continue;
            }
            if (char.IsDigit(c))
            {
                num = (num < 0 ? 0 : num * 10) + (c - '0');
                continue;
            }
            if (num < 0) return false;
            total += c switch
            {
                'W' => num * 7L * 86400,
                'D' => num * 86400L,
                'H' when inTime => num * 3600L,
                'M' when inTime => num * 60L,
                'S' when inTime => num,
                _ => 0,
            };
            num = -1;
        }
        result = TimeSpan.FromSeconds(sign * total);
        return true;
    }
}
