using System.Text;

namespace DayBoard.Core.Calendar;

public sealed class IcsProperty
{
    public string Name { get; init; } = "";
    public Dictionary<string, string> Parameters { get; } = new(StringComparer.OrdinalIgnoreCase);
    public string Value { get; init; } = "";

    public string? Param(string name) => Parameters.TryGetValue(name, out var v) ? v : null;

    /// <summary>The value with RFC 5545 TEXT escapes resolved.</summary>
    public string Text => IcsReader.UnescapeText(Value);
}

public sealed class IcsComponent
{
    public string Name { get; init; } = "";
    public List<IcsProperty> Properties { get; } = new();
    public List<IcsComponent> Children { get; } = new();

    public IcsProperty? Get(string name) => Properties.FirstOrDefault(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

    public IEnumerable<IcsProperty> GetAll(string name) => Properties.Where(p => p.Name.Equals(name, StringComparison.OrdinalIgnoreCase));

    public IEnumerable<IcsComponent> Descendants(string name)
    {
        foreach (var c in Children)
        {
            if (c.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) yield return c;
            foreach (var d in c.Descendants(name)) yield return d;
        }
    }
}

/// <summary>Tolerant RFC 5545 content-line parser (unfolding, parameters with quoted values, nested components).</summary>
public static class IcsReader
{
    public static IcsComponent Parse(string text)
    {
        var root = new IcsComponent { Name = "ROOT" };
        var stack = new Stack<IcsComponent>();
        stack.Push(root);

        foreach (var line in Unfold(text))
        {
            if (line.Length == 0) continue;
            var prop = ParseLine(line);
            if (prop is null) continue;

            if (prop.Name.Equals("BEGIN", StringComparison.OrdinalIgnoreCase))
            {
                var comp = new IcsComponent { Name = prop.Value.Trim().ToUpperInvariant() };
                stack.Peek().Children.Add(comp);
                stack.Push(comp);
            }
            else if (prop.Name.Equals("END", StringComparison.OrdinalIgnoreCase))
            {
                var name = prop.Value.Trim();
                // Pop to the matching BEGIN; ignore stray ENDs.
                if (stack.Any(c => c.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) && stack.Count > 1)
                {
                    while (stack.Count > 1)
                    {
                        var popped = stack.Pop();
                        if (popped.Name.Equals(name, StringComparison.OrdinalIgnoreCase)) break;
                    }
                }
            }
            else
            {
                stack.Peek().Properties.Add(prop);
            }
        }
        return root;
    }

    public static IEnumerable<string> Unfold(string text)
    {
        if (text.Length > 0 && text[0] == '﻿') text = text[1..];
        var sb = new StringBuilder();
        bool has = false;
        using var reader = new StringReader(text);
        string? raw;
        while ((raw = reader.ReadLine()) is not null)
        {
            if (raw.Length > 0 && (raw[0] == ' ' || raw[0] == '\t'))
            {
                sb.Append(raw, 1, raw.Length - 1);
                continue;
            }
            if (has) yield return sb.ToString();
            sb.Clear();
            sb.Append(raw);
            has = true;
        }
        if (has) yield return sb.ToString();
    }

    public static IcsProperty? ParseLine(string line)
    {
        int i = 0;
        while (i < line.Length && line[i] != ';' && line[i] != ':') i++;
        if (i >= line.Length) return null;
        var name = line[..i].Trim();
        if (name.Length == 0) return null;

        var parameters = new List<(string, string)>();
        while (i < line.Length && line[i] == ';')
        {
            i++;
            int ns = i;
            while (i < line.Length && line[i] != '=' && line[i] != ':' && line[i] != ';') i++;
            var pname = line[ns..i].Trim();
            var values = new List<string>();
            if (i < line.Length && line[i] == '=')
            {
                i++;
                while (true)
                {
                    if (i < line.Length && line[i] == '"')
                    {
                        int qs = ++i;
                        while (i < line.Length && line[i] != '"') i++;
                        values.Add(line[qs..Math.Min(i, line.Length)]);
                        if (i < line.Length) i++; // closing quote
                    }
                    else
                    {
                        int vs = i;
                        while (i < line.Length && line[i] != ',' && line[i] != ';' && line[i] != ':') i++;
                        values.Add(line[vs..i]);
                    }
                    if (i < line.Length && line[i] == ',')
                    {
                        i++;
                        continue;
                    }
                    break;
                }
            }
            if (pname.Length > 0) parameters.Add((pname, string.Join(",", values)));
        }

        if (i >= line.Length || line[i] != ':') return null;
        var prop = new IcsProperty { Name = name.ToUpperInvariant(), Value = line[(i + 1)..] };
        foreach (var (k, v) in parameters) prop.Parameters[k] = v;
        return prop;
    }

    public static string UnescapeText(string value)
    {
        if (value.IndexOf('\\') < 0) return value;
        var sb = new StringBuilder(value.Length);
        for (int i = 0; i < value.Length; i++)
        {
            char c = value[i];
            if (c == '\\' && i + 1 < value.Length)
            {
                char n = value[++i];
                sb.Append(n switch
                {
                    'n' or 'N' => '\n',
                    _ => n,
                });
            }
            else
            {
                sb.Append(c);
            }
        }
        return sb.ToString();
    }
}
