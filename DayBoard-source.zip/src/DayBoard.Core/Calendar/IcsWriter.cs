using System.Globalization;
using System.Text;
using DayBoard.Core.Models;

namespace DayBoard.Core.Calendar;

/// <summary>Writes scheduled tasks as an iCalendar file: timed tasks as timed events (length = estimate), others as all-day events.</summary>
public static class IcsWriter
{
    public static string WriteTasks(IEnumerable<TaskItem> tasks, Func<Guid?, Category?> categoryOf, DateTime nowUtc,
        int defaultMinutes = 30, TimeZoneInfo? local = null)
    {
        local ??= TimeZoneInfo.Local;
        var sb = new StringBuilder();
        void Line(string s) => AppendFolded(sb, s);

        Line("BEGIN:VCALENDAR");
        Line("VERSION:2.0");
        Line("PRODID:-//DayBoard//DayBoard 1.0//EN");
        Line("CALSCALE:GREGORIAN");
        Line("METHOD:PUBLISH");
        Line("X-WR-CALNAME:DayBoard");

        var stamp = nowUtc.ToString("yyyyMMdd'T'HHmmss'Z'", CultureInfo.InvariantCulture);
        foreach (var t in tasks.Where(t => t.ScheduledDate.HasValue && !t.IsSkipped))
        {
            var date = t.ScheduledDate!.Value;
            Line("BEGIN:VEVENT");
            Line($"UID:{t.Id:D}@dayboard");
            Line($"DTSTAMP:{stamp}");
            if (t.StartTime is { } st)
            {
                var startLocal = date.ToDateTime(st);
                if (local.IsInvalidTime(startLocal)) startLocal = startLocal.AddHours(1);
                var startUtc = TimeZoneInfo.ConvertTimeToUtc(DateTime.SpecifyKind(startLocal, DateTimeKind.Unspecified), local);
                var endUtc = startUtc.AddMinutes(t.EstimateMinutes is > 0 ? t.EstimateMinutes.Value : defaultMinutes);
                Line($"DTSTART:{startUtc:yyyyMMdd'T'HHmmss'Z'}");
                Line($"DTEND:{endUtc:yyyyMMdd'T'HHmmss'Z'}");
            }
            else
            {
                Line($"DTSTART;VALUE=DATE:{date:yyyyMMdd}");
                Line($"DTEND;VALUE=DATE:{date.AddDays(1):yyyyMMdd}");
            }
            Line("SUMMARY:" + Escape((t.IsDone ? "✓ " : "") + t.Title));

            var desc = new StringBuilder();
            if (!string.IsNullOrWhiteSpace(t.Notes)) desc.Append(t.Notes.Trim());
            if (t.Subtasks.Count > 0)
            {
                if (desc.Length > 0) desc.Append("\n\n");
                foreach (var s in t.Subtasks) desc.Append(s.IsDone ? "[x] " : "[ ] ").Append(s.Title).Append('\n');
            }
            if (desc.Length > 0) Line("DESCRIPTION:" + Escape(desc.ToString().TrimEnd()));
            if (categoryOf(t.CategoryId) is { } cat) Line("CATEGORIES:" + Escape(cat.Name));
            int prio = t.Priority switch { Priority.High => 1, Priority.Medium => 5, Priority.Low => 9, _ => 0 };
            if (prio > 0) Line($"PRIORITY:{prio}");
            Line("TRANSP:" + (t.StartTime.HasValue ? "OPAQUE" : "TRANSPARENT"));
            Line("END:VEVENT");
        }
        Line("END:VCALENDAR");
        return sb.ToString();
    }

    public static string Escape(string text) => text
        .Replace("\\", "\\\\")
        .Replace(";", "\\;")
        .Replace(",", "\\,")
        .Replace("\r\n", "\\n")
        .Replace("\n", "\\n")
        .Replace("\r", "\\n");

    /// <summary>Appends a content line folded at 75 octets with CRLF line endings.</summary>
    public static void AppendFolded(StringBuilder sb, string line)
    {
        var bytes = 0;
        var first = true;
        var current = new StringBuilder();
        foreach (var rune in line.EnumerateRunes())
        {
            int len = rune.Utf8SequenceLength;
            int limit = first ? 75 : 74; // continuation lines start with a space
            if (bytes + len > limit)
            {
                sb.Append(current).Append("\r\n ");
                current.Clear();
                bytes = 0;
                first = false;
            }
            current.Append(rune.ToString());
            bytes += len;
        }
        sb.Append(current).Append("\r\n");
    }
}
