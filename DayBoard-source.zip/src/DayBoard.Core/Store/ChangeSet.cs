using DayBoard.Core.Models;

namespace DayBoard.Core.Store;

/// <summary>One reversible change to a single entity: a before/after snapshot (null = absent).</summary>
public interface IChange
{
    Guid EntityId { get; }
    void Apply(TaskStore store, bool revert, StoreBatch batch);
}

public sealed class TaskChange : IChange
{
    public TaskChange(TaskItem? before, TaskItem? after)
    {
        if (before is null && after is null) throw new ArgumentException("A change needs a before or after state.");
        Before = before?.Clone();
        After = after?.Clone();
    }

    public TaskItem? Before { get; }
    public TaskItem? After { get; }
    public Guid EntityId => (Before ?? After)!.Id;

    public void Apply(TaskStore store, bool revert, StoreBatch batch) =>
        store.SetTaskInternal(EntityId, revert ? Before : After, batch);
}

public sealed class CategoryChange : IChange
{
    public CategoryChange(Category? before, Category? after)
    {
        if (before is null && after is null) throw new ArgumentException("A change needs a before or after state.");
        Before = before?.Clone();
        After = after?.Clone();
    }

    public Category? Before { get; }
    public Category? After { get; }
    public Guid EntityId => (Before ?? After)!.Id;

    public void Apply(TaskStore store, bool revert, StoreBatch batch) =>
        store.SetCategoryInternal(EntityId, revert ? Before : After, batch);
}

public sealed class SeriesChange : IChange
{
    public SeriesChange(TaskSeries? before, TaskSeries? after)
    {
        if (before is null && after is null) throw new ArgumentException("A change needs a before or after state.");
        Before = before?.Clone();
        After = after?.Clone();
    }

    public TaskSeries? Before { get; }
    public TaskSeries? After { get; }
    public Guid EntityId => (Before ?? After)!.Id;

    public void Apply(TaskStore store, bool revert, StoreBatch batch) =>
        store.SetSeriesInternal(EntityId, revert ? Before : After, batch);
}

/// <summary>A user action: an ordered list of entity changes applied together and undone together.</summary>
public sealed class ChangeSet
{
    public ChangeSet(string description) => Description = description;

    public string Description { get; set; }
    public List<IChange> Changes { get; } = new();
    public bool IsEmpty => Changes.Count == 0;

    public IEnumerable<Guid> SeriesIds => Changes.OfType<SeriesChange>().Select(c => c.EntityId)
        .Concat(Changes.OfType<TaskChange>().Select(c => (c.After ?? c.Before)!.SeriesId).Where(x => x.HasValue).Select(x => x!.Value))
        .Distinct();

    public IEnumerable<Guid> TaskIds => Changes.OfType<TaskChange>().Select(c => c.EntityId);

    public ChangeSet Add(IChange change)
    {
        // Coalesce repeated changes to the same entity so that undo restores the original state in one step.
        int idx = Changes.FindIndex(c => c.GetType() == change.GetType() && c.EntityId == change.EntityId);
        if (idx < 0)
        {
            Changes.Add(change);
            return this;
        }

        // Created and then deleted within the same action: nothing to record.
        switch (Changes[idx], change)
        {
            case (TaskChange a, TaskChange b):
                if (a.Before is null && b.After is null) Changes.RemoveAt(idx);
                else Changes[idx] = new TaskChange(a.Before, b.After);
                break;
            case (CategoryChange a, CategoryChange b):
                if (a.Before is null && b.After is null) Changes.RemoveAt(idx);
                else Changes[idx] = new CategoryChange(a.Before, b.After);
                break;
            case (SeriesChange a, SeriesChange b):
                if (a.Before is null && b.After is null) Changes.RemoveAt(idx);
                else Changes[idx] = new SeriesChange(a.Before, b.After);
                break;
            default:
                Changes[idx] = change;
                break;
        }
        return this;
    }

    public ChangeSet Task(TaskItem? before, TaskItem? after) => before is null && after is null ? this : Add(new TaskChange(before, after));
    public ChangeSet Category(Category? before, Category? after) => before is null && after is null ? this : Add(new CategoryChange(before, after));
    public ChangeSet Series(TaskSeries? before, TaskSeries? after) => before is null && after is null ? this : Add(new SeriesChange(before, after));
}
