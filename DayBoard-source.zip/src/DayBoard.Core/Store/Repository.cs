using DayBoard.Core.Models;

namespace DayBoard.Core.Store;

/// <summary>Persistence for the planner. The app uses SQLite; tests use <see cref="InMemoryRepository"/>.</summary>
public interface IPlannerRepository
{
    PlannerData Load();

    /// <summary>Writes a batch atomically. Assigns ids to new events.</summary>
    void Save(StoreBatch batch);
}

public sealed class PlannerData
{
    public List<TaskItem> Tasks { get; set; } = new();
    public List<Category> Categories { get; set; } = new();
    public List<TaskSeries> Series { get; set; } = new();
    public List<TaskEvent> Events { get; set; } = new();
}

/// <summary>A set of writes. A null value means delete.</summary>
public sealed class StoreBatch
{
    public Dictionary<Guid, TaskItem?> Tasks { get; } = new();
    public Dictionary<Guid, Category?> Categories { get; } = new();
    public Dictionary<Guid, TaskSeries?> Series { get; } = new();
    public List<TaskEvent> Events { get; } = new();

    public bool IsEmpty => Tasks.Count == 0 && Categories.Count == 0 && Series.Count == 0 && Events.Count == 0;

    public StoreBatch PutTask(TaskItem t)
    {
        Tasks[t.Id] = t.Clone();
        return this;
    }

    public StoreBatch DeleteTask(Guid id)
    {
        Tasks[id] = null;
        return this;
    }

    public StoreBatch PutSeries(TaskSeries s)
    {
        Series[s.Id] = s.Clone();
        return this;
    }

    public StoreBatch DeleteSeries(Guid id)
    {
        Series[id] = null;
        return this;
    }

    public StoreBatch PutCategory(Category c)
    {
        Categories[c.Id] = c.Clone();
        return this;
    }

    public StoreBatch DeleteCategory(Guid id)
    {
        Categories[id] = null;
        return this;
    }

    public StoreBatch AddEvent(TaskEvent e)
    {
        Events.Add(e);
        return this;
    }
}

public sealed class InMemoryRepository : IPlannerRepository
{
    private readonly PlannerData _data;
    private long _nextEventId = 1;

    public InMemoryRepository(PlannerData? initial = null) => _data = initial ?? new PlannerData();

    public int SaveCount { get; private set; }

    public PlannerData Load() => new()
    {
        Tasks = _data.Tasks.Select(t => t.Clone()).ToList(),
        Categories = _data.Categories.Select(c => c.Clone()).ToList(),
        Series = _data.Series.Select(s => s.Clone()).ToList(),
        Events = _data.Events.ToList(),
    };

    public void Save(StoreBatch batch)
    {
        SaveCount++;
        foreach (var (id, t) in batch.Tasks)
        {
            _data.Tasks.RemoveAll(x => x.Id == id);
            if (t is not null) _data.Tasks.Add(t.Clone());
        }
        foreach (var (id, c) in batch.Categories)
        {
            _data.Categories.RemoveAll(x => x.Id == id);
            if (c is not null) _data.Categories.Add(c.Clone());
        }
        foreach (var (id, s) in batch.Series)
        {
            _data.Series.RemoveAll(x => x.Id == id);
            if (s is not null) _data.Series.Add(s.Clone());
        }
        foreach (var e in batch.Events)
        {
            if (e.Id == 0) e.Id = _nextEventId++;
            _data.Events.Add(e);
        }
    }
}
