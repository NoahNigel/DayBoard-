namespace DayBoard.Core.Store;

/// <summary>
/// Command-pattern undo/redo. Every user action is a <see cref="ChangeSet"/> executed through here,
/// including deletes and drags. System actions (rollover, recurrence generation) bypass it.
/// </summary>
public sealed class UndoService
{
    private readonly TaskStore _store;
    private readonly LinkedList<ChangeSet> _undo = new();
    private readonly Stack<ChangeSet> _redo = new();

    public UndoService(TaskStore store) => _store = store;

    public int Capacity { get; set; } = 300;

    /// <summary>Called after a change set was applied (revert = true for undo). Used to re-sync recurring series.</summary>
    public Action<ChangeSet, bool>? AfterApply { get; set; }

    public event EventHandler? StateChanged;

    public bool CanUndo => _undo.Count > 0;
    public bool CanRedo => _redo.Count > 0;
    public string? UndoDescription => _undo.Last?.Value.Description;
    public string? RedoDescription => _redo.Count > 0 ? _redo.Peek().Description : null;
    public int UndoCount => _undo.Count;

    public bool Execute(ChangeSet changeSet)
    {
        if (changeSet.IsEmpty) return false;
        using (_store.SuspendNotifications())
        {
            _store.Apply(changeSet, revert: false);
            AfterApply?.Invoke(changeSet, false);
        }
        _undo.AddLast(changeSet);
        while (_undo.Count > Capacity) _undo.RemoveFirst();
        _redo.Clear();
        StateChanged?.Invoke(this, EventArgs.Empty);
        return true;
    }

    public bool Undo()
    {
        if (_undo.Last is null) return false;
        var cs = _undo.Last.Value;
        _undo.RemoveLast();
        using (_store.SuspendNotifications())
        {
            _store.Apply(cs, revert: true);
            AfterApply?.Invoke(cs, true);
        }
        _redo.Push(cs);
        StateChanged?.Invoke(this, EventArgs.Empty);
        return true;
    }

    public bool Redo()
    {
        if (_redo.Count == 0) return false;
        var cs = _redo.Pop();
        using (_store.SuspendNotifications())
        {
            _store.Apply(cs, revert: false);
            AfterApply?.Invoke(cs, false);
        }
        _undo.AddLast(cs);
        StateChanged?.Invoke(this, EventArgs.Empty);
        return true;
    }

    public void Clear()
    {
        _undo.Clear();
        _redo.Clear();
        StateChanged?.Invoke(this, EventArgs.Empty);
    }
}
