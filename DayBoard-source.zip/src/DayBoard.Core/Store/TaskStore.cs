using DayBoard.Core.Models;

namespace DayBoard.Core.Store;

/// <summary>
/// In-memory model of all planner data with write-through persistence. Everything is loaded at startup
/// (a personal planner holds thousands of rows at most), so views query with LINQ.
/// Returned objects are the live instances: treat them as read-only and change data through change sets.
/// </summary>
public sealed class TaskStore
{
    private readonly IPlannerRepository _repo;
    private readonly Dictionary<Guid, TaskItem> _tasks = new();
    private readonly Dictionary<Guid, Category> _categories = new();
    private readonly Dictionary<Guid, TaskSeries> _series = new();
    private readonly List<TaskEvent> _events = new();
    private int _suspend;
    private bool _pendingNotify;

    public TaskStore(IPlannerRepository repo)
    {
        _repo = repo;
        var data = repo.Load();
        foreach (var t in data.Tasks) _tasks[t.Id] = t;
        foreach (var c in data.Categories) _categories[c.Id] = c;
        foreach (var s in data.Series) _series[s.Id] = s;
        _events.AddRange(data.Events);
    }

    /// <summary>Raised after every persisted change.</summary>
    public event EventHandler? Changed;

    /// <summary>Increments on every change; lets views skip redundant refreshes.</summary>
    public int Version { get; private set; }

    public IReadOnlyCollection<TaskItem> Tasks => _tasks.Values;
    public IReadOnlyCollection<TaskSeries> Series => _series.Values;
    public IReadOnlyList<TaskEvent> Events => _events;
    public IReadOnlyList<Category> Categories => _categories.Values.OrderBy(c => c.SortOrder).ThenBy(c => c.Name).ToList();

    public TaskItem? FindTask(Guid id) => _tasks.GetValueOrDefault(id);
    public TaskItem? FindTask(Guid? id) => id.HasValue ? _tasks.GetValueOrDefault(id.Value) : null;
    public Category? FindCategory(Guid? id) => id.HasValue ? _categories.GetValueOrDefault(id.Value) : null;
    public TaskSeries? FindSeries(Guid? id) => id.HasValue ? _series.GetValueOrDefault(id.Value) : null;

    public PlannerData Snapshot() => new()
    {
        Tasks = _tasks.Values.Select(t => t.Clone()).ToList(),
        Categories = _categories.Values.Select(c => c.Clone()).ToList(),
        Series = _series.Values.Select(s => s.Clone()).ToList(),
        Events = _events.ToList(),
    };

    /// <summary>Applies (or reverts) a change set and persists it as one transaction.</summary>
    public void Apply(ChangeSet changeSet, bool revert)
    {
        var batch = new StoreBatch();
        IEnumerable<IChange> changes = revert ? Enumerable.Reverse(changeSet.Changes) : changeSet.Changes;
        foreach (var change in changes) change.Apply(this, revert, batch);
        Persist(batch);
    }

    /// <summary>Applies a batch of system writes that are not part of undo history (rollover, recurrence generation).</summary>
    public void Commit(StoreBatch batch)
    {
        foreach (var (id, t) in batch.Tasks)
        {
            if (t is null) _tasks.Remove(id);
            else _tasks[id] = t.Clone();
        }
        foreach (var (id, c) in batch.Categories)
        {
            if (c is null) _categories.Remove(id);
            else _categories[id] = c.Clone();
        }
        foreach (var (id, s) in batch.Series)
        {
            if (s is null) _series.Remove(id);
            else _series[id] = s.Clone();
        }
        Persist(batch);
    }

    internal void SetTaskInternal(Guid id, TaskItem? value, StoreBatch batch)
    {
        if (value is null)
        {
            _tasks.Remove(id);
            batch.DeleteTask(id);
        }
        else
        {
            var copy = value.Clone();
            _tasks[id] = copy;
            batch.PutTask(copy);
        }
    }

    internal void SetCategoryInternal(Guid id, Category? value, StoreBatch batch)
    {
        if (value is null)
        {
            _categories.Remove(id);
            batch.DeleteCategory(id);
        }
        else
        {
            var copy = value.Clone();
            _categories[id] = copy;
            batch.PutCategory(copy);
        }
    }

    internal void SetSeriesInternal(Guid id, TaskSeries? value, StoreBatch batch)
    {
        if (value is null)
        {
            _series.Remove(id);
            batch.DeleteSeries(id);
        }
        else
        {
            var copy = value.Clone();
            _series[id] = copy;
            batch.PutSeries(copy);
        }
    }

    private void Persist(StoreBatch batch)
    {
        if (batch.IsEmpty) return;
        _repo.Save(batch);
        _events.AddRange(batch.Events);
        Version++;
        if (_suspend > 0) _pendingNotify = true;
        else Changed?.Invoke(this, EventArgs.Empty);
    }

    /// <summary>Batches change notifications until the returned scope is disposed.</summary>
    public IDisposable SuspendNotifications()
    {
        _suspend++;
        return new Scope(this);
    }

    private sealed class Scope : IDisposable
    {
        private TaskStore? _owner;
        public Scope(TaskStore owner) => _owner = owner;

        public void Dispose()
        {
            var o = _owner;
            if (o is null) return;
            _owner = null;
            o._suspend--;
            if (o._suspend == 0 && o._pendingNotify)
            {
                o._pendingNotify = false;
                o.Changed?.Invoke(o, EventArgs.Empty);
            }
        }
    }
}
