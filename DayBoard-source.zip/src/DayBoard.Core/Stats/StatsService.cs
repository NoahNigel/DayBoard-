using DayBoard.Core.Models;

namespace DayBoard.Core.Stats;

public sealed record RateRow(string Label, string? Color, int Done, int Total)
{
    public double Rate => Total == 0 ? 0 : (double)Done / Total;
}

/// <summary>
/// Completion statistics. A "planned instance" is a task completed in the period, a task still open on a past day of
/// the period, or a slip (rollover/skip/overdue) from a day in the period. Rate = completed / planned instances.
/// </summary>
public static class StatsService
{
    public static Dictionary<DateOnly, int> CompletionsByDay(IEnumerable<TaskItem> tasks, DateOnly from, DateOnly to)
    {
        var map = new Dictionary<DateOnly, int>();
        foreach (var t in tasks)
        {
            if (!t.IsDone || t.CompletedAt is null || t.IsSkipped) continue;
            var d = DateOnly.FromDateTime(t.CompletedAt.Value);
            if (d < from || d > to) continue;
            map[d] = map.GetValueOrDefault(d) + 1;
        }
        return map;
    }

    private sealed record Instance(TaskItem Task, bool Done);

    private static List<Instance> Instances(IReadOnlyCollection<TaskItem> tasks, IEnumerable<TaskEvent> events, DateOnly from, DateOnly to, DateOnly today)
    {
        var byId = tasks.ToDictionary(t => t.Id);
        var list = new List<Instance>();
        foreach (var t in tasks)
        {
            if (t.IsSkipped) continue;
            if (t.IsDone && t.CompletedAt is { } c)
            {
                var d = DateOnly.FromDateTime(c);
                if (d >= from && d <= to) list.Add(new Instance(t, true));
            }
            else if (!t.IsDone && t.ScheduledDate is { } s && s >= from && s <= to && s < today)
            {
                list.Add(new Instance(t, false));
            }
        }
        foreach (var e in events)
        {
            if (e.Kind is not (TaskEventKind.Rolled or TaskEventKind.Skipped)) continue;
            if (e.FromDate is not { } fd || fd < from || fd > to) continue;
            if (byId.TryGetValue(e.TaskId, out var t)) list.Add(new Instance(t, false));
        }
        return list;
    }

    public static List<RateRow> RatesByPriority(IReadOnlyCollection<TaskItem> tasks, IEnumerable<TaskEvent> events,
        DateOnly from, DateOnly to, DateOnly today, Func<Priority, string?>? colorOf = null)
    {
        var inst = Instances(tasks, events, from, to, today);
        return new[] { Priority.High, Priority.Medium, Priority.Low, Priority.None }
            .Select(p =>
            {
                var group = inst.Where(i => i.Task.Priority == p).ToList();
                return new RateRow(p.Label(), colorOf?.Invoke(p), group.Count(i => i.Done), group.Count);
            })
            .ToList();
    }

    public static List<RateRow> RatesByCategory(IReadOnlyCollection<TaskItem> tasks, IEnumerable<TaskEvent> events,
        IReadOnlyList<Category> categories, DateOnly from, DateOnly to, DateOnly today)
    {
        var inst = Instances(tasks, events, from, to, today);
        var rows = categories.Select(c =>
        {
            var group = inst.Where(i => i.Task.CategoryId == c.Id).ToList();
            return new RateRow(c.Name, c.Color, group.Count(i => i.Done), group.Count);
        }).ToList();
        var known = categories.Select(c => c.Id).ToHashSet();
        var none = inst.Where(i => i.Task.CategoryId is null || !known.Contains(i.Task.CategoryId.Value)).ToList();
        rows.Add(new RateRow("No category", null, none.Count(i => i.Done), none.Count));
        return rows;
    }

    public static RateRow Overall(IReadOnlyCollection<TaskItem> tasks, IEnumerable<TaskEvent> events, DateOnly from, DateOnly to, DateOnly today)
    {
        var inst = Instances(tasks, events, from, to, today);
        return new RateRow("All", null, inst.Count(i => i.Done), inst.Count);
    }
}
