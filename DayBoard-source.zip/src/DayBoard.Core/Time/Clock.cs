namespace DayBoard.Core.Time;

public interface IClock
{
    DateTime Now { get; }
}

public sealed class SystemClock : IClock
{
    public static readonly SystemClock Instance = new();
    public DateTime Now => DateTime.Now;
}

/// <summary>Settable clock for tests.</summary>
public sealed class ManualClock : IClock
{
    public ManualClock(DateTime now) => Now = now;
    public DateTime Now { get; set; }
}

public static class ClockExtensions
{
    public static DateOnly Today(this IClock clock) => DateOnly.FromDateTime(clock.Now);
}

public static class DateUtil
{
    public static DateOnly StartOfWeek(DateOnly date, DayOfWeek weekStart)
    {
        int diff = ((int)date.DayOfWeek - (int)weekStart + 7) % 7;
        return date.AddDays(-diff);
    }

    public static IEnumerable<DateOnly> Range(DateOnly from, DateOnly toInclusive)
    {
        for (var d = from; d <= toInclusive; d = d.AddDays(1)) yield return d;
    }

    public static DateOnly Max(DateOnly a, DateOnly b) => a > b ? a : b;
    public static DateOnly Min(DateOnly a, DateOnly b) => a < b ? a : b;

    public static int DaysInMonth(int year, int month) => DateTime.DaysInMonth(year, month);

    /// <summary>"45m", "1h", "2h 30m".</summary>
    public static string FormatMinutes(int minutes)
    {
        if (minutes <= 0) return "0m";
        int h = minutes / 60, m = minutes % 60;
        if (h == 0) return $"{m}m";
        return m == 0 ? $"{h}h" : $"{h}h {m}m";
    }

    public static string ShortDayName(DayOfWeek d) => d switch
    {
        DayOfWeek.Monday => "Mon",
        DayOfWeek.Tuesday => "Tue",
        DayOfWeek.Wednesday => "Wed",
        DayOfWeek.Thursday => "Thu",
        DayOfWeek.Friday => "Fri",
        DayOfWeek.Saturday => "Sat",
        _ => "Sun",
    };

    public static IReadOnlyList<DayOfWeek> WeekDays(DayOfWeek weekStart) =>
        Enumerable.Range(0, 7).Select(i => (DayOfWeek)(((int)weekStart + i) % 7)).ToList();
}
