using DayBoard.Core.Models;
using DayBoard.Core.Store;
using DayBoard.Core.Time;

namespace DayBoard.Core.Planning;

/// <summary>
/// Generates concrete occurrences for recurring series a few weeks ahead (and further when the user
/// navigates ahead), and keeps generated future occurrences in sync after a series changes or is undone.
/// Occurrences are never generated retroactively for days the app wasn't running.
/// </summary>
public sealed class SeriesService
{
    private readonly TaskStore _store;
    private readonly IClock _clock;

    public SeriesService(TaskStore store, IClock clock)
    {
        _store = store;
        _clock = clock;
    }

    /// <summary>How far ahead occurrences exist at minimum.</summary>
    public int HorizonDays { get; set; } = 28;

    public DateOnly DefaultHorizon => _clock.Today().AddDays(HorizonDays);

    public TaskItem NewOccurrence(TaskSeries series, DateOnly date, double sortOrder)
    {
        var now = _clock.Now;
        var t = new TaskItem
        {
            SeriesId = series.Id,
            OccurrenceDate = date,
            ScheduledDate = date,
            SortOrder = sortOrder,
            CreatedAt = now,
            UpdatedAt = now,
            Subtasks = series.SubtaskTitles.Select(x => new Subtask { Title = x }).ToList(),
        };
        series.CopyTemplateTo(t);
        return t;
    }

    /// <summary>Generates missing occurrences up to <paramref name="through"/> (at least the default horizon). Not undoable.</summary>
    public int EnsureMaterialized(DateOnly? through = null)
    {
        var today = _clock.Today();
        var target = DateUtil.Max(through ?? today, DefaultHorizon);
        var batch = new StoreBatch();
        var sorter = new SortOrderAllocator(_store);
        int created = 0;

        foreach (var s in _store.Series.ToList())
        {
            if (s.MaterializedThrough.HasValue && s.MaterializedThrough.Value >= target) continue;
            if (s.EndDate.HasValue && s.EndDate.Value < today)
            {
                continue;
            }

            var from = s.MaterializedThrough?.AddDays(1) ?? s.StartDate;
            if (from < today) from = today;
            var existing = ExistingOccurrenceDates(s.Id);
            foreach (var d in s.OccurrencesBetween(from, target))
            {
                if (existing.Contains(d)) continue;
                batch.PutTask(NewOccurrence(s, d, sorter.Next(d)));
                created++;
            }
            var updated = s.Clone();
            updated.MaterializedThrough = target;
            batch.PutSeries(updated);
        }

        if (!batch.IsEmpty) _store.Commit(batch);
        return created;
    }

    public HashSet<DateOnly> ExistingOccurrenceDates(Guid seriesId) =>
        _store.Tasks.Where(t => t.SeriesId == seriesId && t.OccurrenceDate.HasValue)
            .Select(t => t.OccurrenceDate!.Value)
            .ToHashSet();

    /// <summary>
    /// After series were changed (or a change was undone): removes generated future occurrences that the rule no
    /// longer produces and fills in occurrences that are missing. Done, edited-on-their-own, and past occurrences are kept.
    /// </summary>
    public void Reconcile(IEnumerable<Guid> seriesIds)
    {
        var today = _clock.Today();
        var batch = new StoreBatch();
        var sorter = new SortOrderAllocator(_store);

        foreach (var id in seriesIds.Distinct().ToList())
        {
            var occurrences = _store.Tasks.Where(t => t.SeriesId == id).ToList();
            var s = _store.FindSeries(id);
            if (s is null)
            {
                foreach (var t in occurrences)
                {
                    if (IsUntouchedFuture(t, today)) batch.DeleteTask(t.Id);
                }
                continue;
            }

            var through = DateUtil.Max(s.MaterializedThrough ?? DefaultHorizon, today);
            var valid = s.OccurrencesBetween(today, through).ToHashSet();
            foreach (var t in occurrences)
            {
                if (t.IsDone || t.IsSeriesException || t.OccurrenceDate is null || t.OccurrenceDate.Value < today) continue;
                // Occurrences before the rule's start belong to an earlier version of the rule (edited "from here on").
                if (t.OccurrenceDate.Value < s.StartDate) continue;
                if (t.OccurrenceDate.Value > through) continue;
                if (!valid.Contains(t.OccurrenceDate.Value)) batch.DeleteTask(t.Id);
            }

            var existing = occurrences.Where(t => t.OccurrenceDate.HasValue).Select(t => t.OccurrenceDate!.Value).ToHashSet();
            foreach (var d in valid.OrderBy(x => x))
            {
                if (!existing.Contains(d)) batch.PutTask(NewOccurrence(s, d, sorter.Next(d)));
            }
        }

        if (!batch.IsEmpty) _store.Commit(batch);
    }

    private static bool IsUntouchedFuture(TaskItem t, DateOnly today) =>
        !t.IsDone && !t.IsSeriesException && t.ActualMinutes == 0 &&
        (t.OccurrenceDate ?? t.ScheduledDate ?? today) >= today;
}

/// <summary>Hands out sort orders that append to the end of a day's list.</summary>
public sealed class SortOrderAllocator
{
    public const double Step = 1024;
    // Keyed by date; DateOnly.MinValue stands for the inbox (Dictionary keys can't be null).
    private readonly Dictionary<DateOnly, double> _max = new();
    private readonly TaskStore _store;

    public SortOrderAllocator(TaskStore store) => _store = store;

    public double Next(DateOnly? date)
    {
        var key = date ?? DateOnly.MinValue;
        if (!_max.TryGetValue(key, out var max))
        {
            var day = _store.Tasks.Where(t => t.ScheduledDate == date && !t.IsSkipped).ToList();
            max = day.Count == 0 ? 0 : day.Max(t => t.SortOrder);
        }
        max += Step;
        _max[key] = max;
        return max;
    }

    public double First(DateOnly? date)
    {
        var day = _store.Tasks.Where(t => t.ScheduledDate == date && !t.IsSkipped).ToList();
        return day.Count == 0 ? Step : day.Min(t => t.SortOrder) - Step;
    }
}
