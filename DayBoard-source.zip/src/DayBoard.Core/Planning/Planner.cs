using System.Text.Json;
using DayBoard.Core.Models;
using DayBoard.Core.Recurrence;
using DayBoard.Core.Store;
using DayBoard.Core.Time;

namespace DayBoard.Core.Planning;

/// <summary>
/// Facade over the store: queries for the views and every user operation, each built as one undoable change set.
/// </summary>
public sealed class Planner
{
    private readonly Func<AppSettings> _settings;

    public Planner(IPlannerRepository repository, IClock clock, Func<AppSettings> settings)
    {
        Clock = clock;
        _settings = settings;
        Store = new TaskStore(repository);
        Undo = new UndoService(Store);
        Series = new SeriesService(Store, clock);
        Rollover = new RolloverService(Store, clock);
        Undo.AfterApply = (cs, _) =>
        {
            var ids = cs.SeriesIds.ToList();
            if (ids.Count > 0) Series.Reconcile(ids);
        };
    }

    public TaskStore Store { get; }
    public UndoService Undo { get; }
    public SeriesService Series { get; }
    public RolloverService Rollover { get; }
    public IClock Clock { get; }
    public DateOnly Today => Clock.Today();
    private AppSettings Settings => _settings();

    // ---------------------------------------------------------------- queries

    public IEnumerable<TaskItem> Visible => Store.Tasks.Where(t => !t.IsSkipped);

    /// <summary>Timed tasks first (by start time), then the manual order.</summary>
    public static List<TaskItem> InDisplayOrder(IEnumerable<TaskItem> tasks) => tasks
        .OrderBy(t => t.StartTime.HasValue ? 0 : 1)
        .ThenBy(t => t.StartTime ?? TimeOnly.MinValue)
        .ThenBy(t => t.SortOrder)
        .ThenBy(t => t.CreatedAt)
        .ToList();

    public List<TaskItem> TasksOn(DateOnly date) => InDisplayOrder(Visible.Where(t => t.ScheduledDate == date));

    public List<TaskItem> Inbox(bool includeDone = false) =>
        Visible.Where(t => t.ScheduledDate is null && (includeDone || !t.IsDone)).OrderBy(t => t.SortOrder).ThenBy(t => t.CreatedAt).ToList();

    /// <summary>Unfinished tasks scheduled before <paramref name="day"/>.</summary>
    public List<TaskItem> OverdueBefore(DateOnly day) =>
        Visible.Where(t => !t.IsDone && t.ScheduledDate.HasValue && t.ScheduledDate.Value < day)
            .OrderBy(t => t.ScheduledDate).ThenBy(t => t.SortOrder).ToList();

    public List<TaskItem> OpenTasks() => Visible.Where(t => !t.IsDone).ToList();

    public CapacityInfo CapacityFor(DateOnly date) => CapacityInfo.For(TasksOn(date), Settings.CapacityMinutes);

    public RepeatPattern RepeatOf(TaskItem task)
    {
        var s = Store.FindSeries(task.SeriesId);
        if (s is null) return RepeatPattern.None;
        var p = RepeatPattern.FromRRule(s.RRule, s.StartDate);
        if (p.Until is null && s.EndDate.HasValue) p.Until = s.EndDate;
        return p;
    }

    public string? RecurrenceRuleOf(TaskItem task) => Store.FindSeries(task.SeriesId)?.RRule;

    // ---------------------------------------------------------------- maintenance

    /// <summary>Generates upcoming recurring occurrences and rolls unfinished tasks over. Call on startup and at midnight.</summary>
    public RolloverResult RunDailyMaintenance()
    {
        Series.EnsureMaterialized();
        return Rollover.Run(Settings.RolloverMode);
    }

    /// <summary>Makes sure recurring occurrences exist for a date range the user is looking at.</summary>
    public void EnsureOccurrencesThrough(DateOnly date)
    {
        if (date > Series.DefaultHorizon) Series.EnsureMaterialized(date);
    }

    // ---------------------------------------------------------------- operations

    public bool Execute(ChangeSet cs) => Undo.Execute(cs);

    public TaskItem AddTask(TaskItem draft, RepeatPattern? repeat = null)
    {
        var task = draft.Clone();
        var now = Clock.Now;
        task.CreatedAt = now;
        task.UpdatedAt = now;
        task.Title = task.Title.Trim();
        NormalizeCompletion(task, null);
        var cs = new ChangeSet($"Add \"{Short(task.Title)}\"");
        var sorter = new SortOrderAllocator(Store);

        if (repeat is { IsRepeating: true } && repeat.ToRRule() is { } rrule)
        {
            CreateSeriesFrom(task, rrule, repeat.Until, cs, sorter);
        }
        else
        {
            if (task.SortOrder == 0) task.SortOrder = sorter.Next(task.ScheduledDate);
            cs.Task(null, task);
        }

        Execute(cs);
        return Store.FindTask(task.Id) ?? task;
    }

    /// <summary>Turns <paramref name="task"/> into the first occurrence of a new series and generates the following ones.</summary>
    private void CreateSeriesFrom(TaskItem task, string rrule, DateOnly? until, ChangeSet cs, SortOrderAllocator sorter)
    {
        var start = task.ScheduledDate ?? Today;
        var series = new TaskSeries { RRule = NormalizeRule(rrule), StartDate = start, EndDate = until, CreatedAt = Clock.Now };
        series.CopyTemplateFrom(task);
        var first = series.OccurrencesBetween(start, start.AddYears(10)).Cast<DateOnly?>().FirstOrDefault();
        if (first is null)
        {
            // The rule never produces a date: keep it as a normal task.
            if (task.SortOrder == 0) task.SortOrder = sorter.Next(task.ScheduledDate);
            cs.Task(null, task);
            return;
        }

        task.SeriesId = series.Id;
        task.OccurrenceDate = first;
        task.ScheduledDate = first;
        task.IsSeriesException = false;
        task.SortOrder = sorter.Next(first);

        var through = DateUtil.Max(Series.DefaultHorizon, first.Value);
        series.MaterializedThrough = through;
        cs.Series(null, series);
        cs.Task(Store.FindTask(task.Id), task);

        foreach (var d in series.OccurrencesBetween(first.Value.AddDays(1), through))
        {
            if (d < Today) continue;
            cs.Task(null, Series.NewOccurrence(series, d, sorter.Next(d)));
        }
    }

    /// <summary>Saves an edited task. For an occurrence of a recurring series, <paramref name="scope"/> decides whether the
    /// edit applies to this occurrence only or to it and all future occurrences (the whole series).</summary>
    public void UpdateTask(TaskItem edited, RepeatPattern? repeat, EditScope scope = EditScope.ThisOccurrence)
    {
        var before = Store.FindTask(edited.Id) ?? throw new InvalidOperationException("Task no longer exists.");
        var task = edited.Clone();
        task.Title = task.Title.Trim();
        task.UpdatedAt = Clock.Now;
        NormalizeCompletion(task, before);
        var cs = new ChangeSet($"Edit \"{Short(task.Title)}\"");
        var series = Store.FindSeries(before.SeriesId);
        var sorter = new SortOrderAllocator(Store);

        if (task.ScheduledDate != before.ScheduledDate && task.SortOrder == before.SortOrder)
            task.SortOrder = sorter.Next(task.ScheduledDate);

        if (series is null)
        {
            if (repeat is { IsRepeating: true } && repeat.ToRRule() is { } rrule)
            {
                CreateSeriesFrom(task, rrule, repeat.Until, cs, sorter);
                cs.Description = $"Make \"{Short(task.Title)}\" repeat";
            }
            else
            {
                cs.Task(before, task);
            }
            Execute(cs);
            return;
        }

        if (scope == EditScope.ThisOccurrence)
        {
            if (TemplateDiffers(before, task)) task.IsSeriesException = true;
            cs.Task(before, task);
            Execute(cs);
            return;
        }

        // Whole series: this occurrence and every future unfinished occurrence that wasn't edited on its own.
        cs.Description = $"Edit series \"{Short(task.Title)}\"";
        var occDate = before.OccurrenceDate ?? before.ScheduledDate ?? Today;
        var updated = series.Clone();
        updated.CopyTemplateFrom(task);

        if (repeat is null || !repeat.IsRepeating)
        {
            updated.EndDate = occDate; // stop repeating after this occurrence
        }
        else
        {
            var newRule = NormalizeRule(repeat.ToRRule()!);
            if (!string.Equals(newRule, NormalizeRule(series.RRule), StringComparison.OrdinalIgnoreCase))
            {
                updated.RRule = newRule;
                updated.StartDate = occDate;
            }
            updated.EndDate = repeat.Until;
        }

        task.IsSeriesException = false;
        if (updated.EndDate is null || occDate <= updated.EndDate)
        {
            if (!updated.OccursOn(occDate))
            {
                // The new rule doesn't produce this occurrence's date: move it to the rule's first date from here on
                // (unless the user picked a date themselves), or keep it as a one-off.
                var next = updated.OccurrencesBetween(occDate, occDate.AddYears(5)).Cast<DateOnly?>().FirstOrDefault();
                if (next is { } n && task.ScheduledDate == before.ScheduledDate)
                {
                    task.ScheduledDate = n;
                    task.OccurrenceDate = n;
                    task.SortOrder = sorter.Next(n);
                }
                else
                {
                    task.IsSeriesException = true;
                }
            }
        }
        cs.Task(before, task);
        cs.Series(series, updated);

        var others = Store.Tasks
            .Where(o => o.SeriesId == series.Id && o.Id != task.Id && !o.IsDone && !o.IsSeriesException &&
                        o.OccurrenceDate.HasValue && o.OccurrenceDate.Value >= occDate)
            .ToList();
        var remaining = new HashSet<DateOnly>();
        if (task.OccurrenceDate.HasValue) remaining.Add(task.OccurrenceDate.Value);
        foreach (var o in Store.Tasks.Where(o => o.SeriesId == series.Id && o.OccurrenceDate.HasValue && (o.IsDone || o.IsSeriesException)))
            remaining.Add(o.OccurrenceDate!.Value);

        foreach (var o in others)
        {
            if (!updated.OccursOn(o.OccurrenceDate!.Value))
            {
                cs.Task(o, null);
                continue;
            }
            var c = o.Clone();
            updated.CopyTemplateTo(c);
            c.Subtasks = MergeSubtasks(o.Subtasks, updated.SubtaskTitles);
            c.UpdatedAt = Clock.Now;
            cs.Task(o, c);
            remaining.Add(o.OccurrenceDate!.Value);
        }

        var through = DateUtil.Max(updated.MaterializedThrough ?? Series.DefaultHorizon, Today);
        var genFrom = DateUtil.Max(occDate.AddDays(1), Today);
        foreach (var d in updated.OccurrencesBetween(genFrom, through))
        {
            if (!remaining.Contains(d)) cs.Task(null, Series.NewOccurrence(updated, d, sorter.Next(d)));
        }

        Execute(cs);
    }

    /// <summary>Canonical rule text without UNTIL (the series end lives in <see cref="TaskSeries.EndDate"/>).</summary>
    private static string NormalizeRule(string rule)
    {
        var stripped = string.Join(";", rule.Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Where(p => !p.TrimStart().StartsWith("UNTIL=", StringComparison.OrdinalIgnoreCase)));
        return RecurrenceRule.TryParse(stripped, out var r) ? r.ToString() : stripped;
    }

    private static bool TemplateDiffers(TaskItem a, TaskItem b) =>
        a.Title != b.Title || a.Notes != b.Notes || a.Priority != b.Priority || a.IsUrgent != b.IsUrgent ||
        a.CategoryId != b.CategoryId || a.StartTime != b.StartTime || a.EstimateMinutes != b.EstimateMinutes ||
        !a.Subtasks.Select(s => s.Title).SequenceEqual(b.Subtasks.Select(s => s.Title));

    private static List<Subtask> MergeSubtasks(List<Subtask> existing, List<string> titles)
    {
        var pool = existing.ToList();
        var result = new List<Subtask>();
        foreach (var title in titles)
        {
            var match = pool.FirstOrDefault(s => s.Title == title);
            if (match is not null)
            {
                pool.Remove(match);
                result.Add(match.Clone());
            }
            else
            {
                result.Add(new Subtask { Title = title });
            }
        }
        return result;
    }

    private void NormalizeCompletion(TaskItem task, TaskItem? before)
    {
        if (task.Status == TaskState.Done) task.CompletedAt ??= before?.CompletedAt ?? Clock.Now;
        else task.CompletedAt = null;
    }

    public void DeleteTask(Guid id, EditScope scope = EditScope.ThisOccurrence)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        var series = Store.FindSeries(t.SeriesId);
        var cs = new ChangeSet($"Delete \"{Short(t.Title)}\"");
        cs.Task(t, null);

        if (series is not null && t.OccurrenceDate is { } occ)
        {
            if (scope == EditScope.ThisOccurrence)
            {
                var updated = series.Clone();
                updated.ExceptionDates.Add(occ);
                cs.Series(series, updated);
            }
            else
            {
                cs.Description = $"Delete series \"{Short(t.Title)}\"";
                var future = Store.Tasks.Where(o => o.SeriesId == series.Id && o.Id != t.Id && !o.IsDone &&
                                                    o.OccurrenceDate.HasValue && o.OccurrenceDate.Value >= occ).ToList();
                foreach (var o in future) cs.Task(o, null);
                var deleted = future.Select(o => o.Id).Append(t.Id).ToHashSet();
                bool anyLeft = Store.Tasks.Any(o => o.SeriesId == series.Id && !deleted.Contains(o.Id));
                if (anyLeft)
                {
                    var updated = series.Clone();
                    updated.EndDate = occ.AddDays(-1);
                    cs.Series(series, updated);
                }
                else
                {
                    cs.Series(series, null);
                }
            }
        }

        Execute(cs);
    }

    public void SetDone(Guid id, bool done)
    {
        var t = Store.FindTask(id);
        if (t is null || t.IsDone == done) return;
        var c = t.Clone();
        c.Status = done ? TaskState.Done : TaskState.ToDo;
        c.CompletedAt = done ? Clock.Now : null;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet(done ? $"Complete \"{Short(t.Title)}\"" : $"Reopen \"{Short(t.Title)}\"").Task(t, c));
    }

    public void SetStatus(Guid id, TaskState state, int? index = null)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        var c = t.Clone();
        c.Status = state;
        c.CompletedAt = state == TaskState.Done ? (t.IsDone ? t.CompletedAt : Clock.Now) : null;
        c.UpdatedAt = Clock.Now;
        if (t.Status == state) return;
        Execute(new ChangeSet($"Move \"{Short(t.Title)}\" to {state.Label()}").Task(t, c));
    }

    /// <summary>
    /// Moves a task to a day (or the inbox when <paramref name="date"/> is null). <paramref name="untimedIndex"/> is the
    /// position among the target's untimed tasks (for drops between cards). The time block is kept for a day move and
    /// cleared for the inbox.
    /// </summary>
    public void MoveTo(Guid id, DateOnly? date, int? untimedIndex = null)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        var cs = new ChangeSet(date is null ? $"Move \"{Short(t.Title)}\" to inbox" : $"Move \"{Short(t.Title)}\" to {date:ddd d MMM}");
        var c = t.Clone();
        c.ScheduledDate = date;
        if (date is null) c.StartTime = null;
        PlaceInList(c, t, date, untimedIndex, cs);
        if (t.ScheduledDate == date) cs.Description = $"Reorder \"{Short(t.Title)}\"";
        CommitMove(t, c, cs);
    }

    /// <summary>Puts a task in a time slot (day view drop).</summary>
    public void ScheduleAt(Guid id, DateOnly date, TimeOnly time)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        if (t.ScheduledDate == date && t.StartTime == time) return;
        var c = t.Clone();
        c.ScheduledDate = date;
        c.StartTime = time;
        c.UpdatedAt = Clock.Now;
        if (t.ScheduledDate != date) c.SortOrder = new SortOrderAllocator(Store).Next(date);
        Execute(new ChangeSet($"Schedule \"{Short(t.Title)}\" at {time:HH\\:mm}").Task(t, c));
    }

    /// <summary>Removes a task's time block and places it in the day's unscheduled list.</summary>
    public void ClearTime(Guid id, DateOnly date, int? untimedIndex = null)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        var cs = new ChangeSet($"Unschedule \"{Short(t.Title)}\"");
        var c = t.Clone();
        c.ScheduledDate = date;
        c.StartTime = null;
        PlaceInList(c, t, date, untimedIndex, cs);
        CommitMove(t, c, cs);
    }

    private void CommitMove(TaskItem before, TaskItem after, ChangeSet cs)
    {
        bool changed = !JsonSame(before, after);
        if (!changed && cs.IsEmpty) return;
        after.UpdatedAt = Clock.Now;
        cs.Task(before, after);
        Execute(cs);
    }

    private void PlaceInList(TaskItem moving, TaskItem original, DateOnly? date, int? untimedIndex, ChangeSet cs)
    {
        var list = Visible.Where(x => x.Id != moving.Id && x.ScheduledDate == date && (date is null ? !x.IsDone : x.StartTime is null))
            .OrderBy(x => x.SortOrder).ThenBy(x => x.CreatedAt).ToList();
        if (untimedIndex is int idx)
        {
            moving.SortOrder = SortOrderAt(list, idx, cs);
        }
        else if (original.ScheduledDate != date)
        {
            moving.SortOrder = list.Count == 0 ? SortOrderAllocator.Step : list.Max(x => x.SortOrder) + SortOrderAllocator.Step;
        }
    }

    private double SortOrderAt(List<TaskItem> list, int index, ChangeSet cs)
    {
        index = Math.Clamp(index, 0, list.Count);
        if (list.Count == 0) return SortOrderAllocator.Step;
        if (index == 0) return list[0].SortOrder - SortOrderAllocator.Step;
        if (index == list.Count) return list[^1].SortOrder + SortOrderAllocator.Step;
        double a = list[index - 1].SortOrder, b = list[index].SortOrder;
        if (b - a > 1e-6) return (a + b) / 2;

        // Gap exhausted: renumber the list (recorded in the same change set).
        for (int i = 0; i < list.Count; i++)
        {
            var c = list[i].Clone();
            c.SortOrder = (i + 1) * SortOrderAllocator.Step;
            cs.Task(list[i], c);
            list[i] = c;
        }
        return (list[index - 1].SortOrder + list[index].SortOrder) / 2;
    }

    public void SetEstimate(Guid id, int? minutes)
    {
        var t = Store.FindTask(id);
        if (t is null || t.EstimateMinutes == minutes) return;
        var c = t.Clone();
        c.EstimateMinutes = minutes is > 0 ? minutes : null;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet($"Set estimate of \"{Short(t.Title)}\"").Task(t, c));
    }

    public void SetPriority(Guid id, Priority priority)
    {
        var t = Store.FindTask(id);
        if (t is null || t.Priority == priority) return;
        var c = t.Clone();
        c.Priority = priority;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet($"Set priority of \"{Short(t.Title)}\"").Task(t, c));
    }

    public void SetUrgent(Guid id, bool urgent)
    {
        var t = Store.FindTask(id);
        if (t is null || t.IsUrgent == urgent) return;
        var c = t.Clone();
        c.IsUrgent = urgent;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet(urgent ? $"Mark \"{Short(t.Title)}\" urgent" : $"Unmark \"{Short(t.Title)}\" urgent").Task(t, c));
    }

    /// <summary>Eisenhower drop: sets the urgent flag, and raises priority to Medium (important) or lowers it to Low (not important) if needed.</summary>
    public void SetQuadrant(Guid id, bool urgent, bool important)
    {
        var t = Store.FindTask(id);
        if (t is null) return;
        var c = t.Clone();
        c.IsUrgent = urgent;
        if (important && !c.Priority.IsImportant()) c.Priority = Priority.Medium;
        if (!important && c.Priority.IsImportant()) c.Priority = Priority.Low;
        if (c.IsUrgent == t.IsUrgent && c.Priority == t.Priority) return;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet($"Move \"{Short(t.Title)}\" in matrix").Task(t, c));
    }

    public void ToggleSubtask(Guid taskId, Guid subtaskId)
    {
        var t = Store.FindTask(taskId);
        var sub = t?.Subtasks.FirstOrDefault(s => s.Id == subtaskId);
        if (t is null || sub is null) return;
        var c = t.Clone();
        var target = c.Subtasks.First(s => s.Id == subtaskId);
        target.IsDone = !target.IsDone;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet(target.IsDone ? $"Check \"{Short(sub.Title)}\"" : $"Uncheck \"{Short(sub.Title)}\"").Task(t, c));
    }

    /// <summary>Adds focus minutes to the task's actual time (undoable) and records a focus event for stats.</summary>
    public void LogFocusTime(Guid id, int minutes)
    {
        var t = Store.FindTask(id);
        if (t is null || minutes <= 0) return;
        var c = t.Clone();
        c.ActualMinutes += minutes;
        c.UpdatedAt = Clock.Now;
        Execute(new ChangeSet($"Log {minutes} min on \"{Short(t.Title)}\"").Task(t, c));
        Store.Commit(new StoreBatch().AddEvent(new TaskEvent { TaskId = id, Kind = TaskEventKind.Focus, At = Clock.Now, Minutes = minutes, FromDate = Today }));
    }

    public TaskItem? Duplicate(Guid id)
    {
        var t = Store.FindTask(id);
        if (t is null) return null;
        var c = t.Clone();
        c.Id = Guid.NewGuid();
        c.SeriesId = null;
        c.OccurrenceDate = null;
        c.IsSeriesException = false;
        c.IsSkipped = false;
        c.Status = TaskState.ToDo;
        c.CompletedAt = null;
        c.ActualMinutes = 0;
        c.RolloverCount = 0;
        c.ExternalId = null;
        c.CreatedAt = c.UpdatedAt = Clock.Now;
        c.Subtasks = t.Subtasks.Select(s => new Subtask { Title = s.Title }).ToList();
        c.SortOrder = t.SortOrder + 0.5;
        Execute(new ChangeSet($"Duplicate \"{Short(t.Title)}\"").Task(null, c));
        return c;
    }

    public void SaveCategory(Category category)
    {
        var before = Store.FindCategory(category.Id);
        var c = category.Clone();
        if (before is null && c.SortOrder == 0) c.SortOrder = Store.Categories.Count == 0 ? 0 : Store.Categories.Max(x => x.SortOrder) + 1;
        var cs = new ChangeSet(before is null ? $"Add category \"{c.Name}\"" : $"Edit category \"{c.Name}\"").Category(before, c);
        if (before is not null && JsonSame(before, c)) return;
        Execute(cs);
    }

    public void DeleteCategory(Guid id)
    {
        var cat = Store.FindCategory(id);
        if (cat is null) return;
        var cs = new ChangeSet($"Delete category \"{cat.Name}\"").Category(cat, null);
        foreach (var t in Store.Tasks.Where(t => t.CategoryId == id).ToList())
        {
            var c = t.Clone();
            c.CategoryId = null;
            cs.Task(t, c);
        }
        foreach (var s in Store.Series.Where(s => s.CategoryId == id).ToList())
        {
            var c = s.Clone();
            c.CategoryId = null;
            cs.Series(s, c);
        }
        Execute(cs);
    }

    /// <summary>Merges imported data (by id; categories also by name). Undoable as one step. Returns the number of tasks imported.</summary>
    public int Import(PlannerData data)
    {
        var cs = new ChangeSet("Import");
        var catMap = new Dictionary<Guid, Guid>();
        foreach (var c in data.Categories)
        {
            var existing = Store.FindCategory(c.Id) ??
                           Store.Categories.FirstOrDefault(x => string.Equals(x.Name, c.Name, StringComparison.OrdinalIgnoreCase));
            var copy = c.Clone();
            if (existing is not null) copy.Id = existing.Id;
            catMap[c.Id] = copy.Id;
            cs.Category(existing, copy);
        }

        Guid? MapCat(Guid? id) => id.HasValue && catMap.TryGetValue(id.Value, out var m) ? m : id.HasValue && Store.FindCategory(id) is not null ? id : null;

        foreach (var s in data.Series)
        {
            var copy = s.Clone();
            copy.CategoryId = MapCat(copy.CategoryId);
            cs.Series(Store.FindSeries(s.Id), copy);
        }

        int count = 0;
        foreach (var t in data.Tasks)
        {
            var copy = t.Clone();
            copy.CategoryId = MapCat(copy.CategoryId);
            if (copy.SeriesId.HasValue && Store.FindSeries(copy.SeriesId) is null && data.Series.All(s => s.Id != copy.SeriesId))
            {
                copy.SeriesId = null;
                copy.OccurrenceDate = null;
            }
            var existing = Store.FindTask(t.Id);
            if (existing is not null && JsonSame(existing, copy)) continue;
            cs.Task(existing, copy);
            count++;
        }

        cs.Description = $"Import {count} task{(count == 1 ? "" : "s")}";
        Execute(cs);
        return count;
    }

    // ---------------------------------------------------------------- helpers

    private static readonly JsonSerializerOptions CompareOptions = new() { WriteIndented = false };

    public static bool JsonSame<T>(T a, T b) =>
        JsonSerializer.Serialize(a, CompareOptions) == JsonSerializer.Serialize(b, CompareOptions);

    private static string Short(string title) => title.Length <= 40 ? title : title[..39] + "…";
}
