using DayBoard.Core.Models;

namespace DayBoard.Core.Planning;

public enum CapacityLevel
{
    Ok,
    Near,
    Over,
}

/// <summary>Planned minutes (sum of estimates of the day's tasks, done or not) against the daily capacity.</summary>
public readonly record struct CapacityInfo(int PlannedMinutes, int CapacityMinutes, int UnestimatedCount, int DoneMinutes)
{
    /// <summary>Bar turns amber from this share of capacity.</summary>
    public const double NearThreshold = 0.85;

    public double Ratio => CapacityMinutes <= 0 ? (PlannedMinutes > 0 ? double.PositiveInfinity : 0) : (double)PlannedMinutes / CapacityMinutes;

    public CapacityLevel Level => Ratio > 1.0 ? CapacityLevel.Over : Ratio >= NearThreshold ? CapacityLevel.Near : CapacityLevel.Ok;

    public static CapacityInfo For(IEnumerable<TaskItem> dayTasks, int capacityMinutes)
    {
        int planned = 0, unestimated = 0, done = 0;
        foreach (var t in dayTasks)
        {
            if (t.IsSkipped) continue;
            if (t.EstimateMinutes is int m && m > 0)
            {
                planned += m;
                if (t.IsDone) done += m;
            }
            else if (!t.IsDone)
            {
                unestimated++;
            }
        }
        return new CapacityInfo(planned, capacityMinutes, unestimated, done);
    }
}
