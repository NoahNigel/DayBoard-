using DayBoard.Core.Models;
using DayBoard.Core.Store;
using DayBoard.Core.Time;

namespace DayBoard.Core.Planning;

public readonly record struct RolloverResult(int Moved, int Skipped, int Flagged)
{
    public int Total => Moved + Skipped + Flagged;
}

/// <summary>
/// Runs on startup and at midnight. In "move" mode unfinished tasks from past days move to today
/// (time block cleared, rollover count +1). For recurring tasks only the latest missed occurrence moves,
/// and only if the series has no occurrence today; older missed occurrences are marked skipped.
/// In "flag" mode tasks stay where they are and are flagged overdue. Rollover is a system action, so it isn't on the undo stack.
/// </summary>
public sealed class RolloverService
{
    private readonly TaskStore _store;
    private readonly IClock _clock;

    public RolloverService(TaskStore store, IClock clock)
    {
        _store = store;
        _clock = clock;
    }

    public RolloverResult Run(RolloverMode mode)
    {
        var today = _clock.Today();
        var now = _clock.Now;
        var candidates = _store.Tasks
            .Where(t => !t.IsDone && !t.IsSkipped && t.ScheduledDate.HasValue && t.ScheduledDate.Value < today)
            .OrderBy(t => t.ScheduledDate)
            .ThenBy(t => t.SortOrder)
            .ToList();
        if (candidates.Count == 0) return default;

        var batch = new StoreBatch();

        if (mode == RolloverMode.FlagOverdue)
        {
            var already = _store.Events.Where(e => e.Kind == TaskEventKind.Overdue)
                .Select(e => (e.TaskId, e.FromDate))
                .ToHashSet();
            int flagged = 0;
            foreach (var t in candidates)
            {
                if (already.Contains((t.Id, t.ScheduledDate))) continue;
                batch.AddEvent(new TaskEvent { TaskId = t.Id, Kind = TaskEventKind.Overdue, At = now, FromDate = t.ScheduledDate });
                flagged++;
            }
            if (!batch.IsEmpty) _store.Commit(batch);
            return new RolloverResult(0, 0, flagged);
        }

        int moved = 0, skipped = 0;
        var toMove = new List<TaskItem>();

        bool HasSeries(TaskItem t) => t.SeriesId.HasValue && _store.FindSeries(t.SeriesId) is not null;

        toMove.AddRange(candidates.Where(t => !HasSeries(t)));

        foreach (var group in candidates.Where(HasSeries).GroupBy(t => t.SeriesId!.Value))
        {
            var series = _store.FindSeries(group.Key)!;
            var ordered = group.OrderBy(t => t.ScheduledDate).ToList();
            var latest = ordered[^1];
            foreach (var older in ordered.Take(ordered.Count - 1))
            {
                Skip(older);
            }

            bool occursToday = _store.Tasks.Any(x => x.SeriesId == series.Id && !x.IsSkipped && x.ScheduledDate == today)
                               || series.OccursOn(today);
            if (occursToday) Skip(latest);
            else toMove.Add(latest);
        }

        // Rolled-over tasks go to the top of today's list, keeping their relative order.
        var todays = _store.Tasks.Where(t => t.ScheduledDate == today && !t.IsSkipped).ToList();
        double top = todays.Count == 0 ? 0 : todays.Min(t => t.SortOrder);
        var orderedMoves = toMove.OrderBy(t => t.ScheduledDate).ThenBy(t => t.SortOrder).ToList();
        for (int i = 0; i < orderedMoves.Count; i++)
        {
            var t = orderedMoves[i];
            var c = t.Clone();
            c.ScheduledDate = today;
            c.StartTime = null;
            c.RolloverCount++;
            c.SortOrder = top - SortOrderAllocator.Step * (orderedMoves.Count - i);
            c.UpdatedAt = now;
            batch.PutTask(c);
            batch.AddEvent(new TaskEvent { TaskId = t.Id, Kind = TaskEventKind.Rolled, At = now, FromDate = t.ScheduledDate, ToDate = today });
            moved++;
        }

        _store.Commit(batch);
        return new RolloverResult(moved, skipped, 0);

        void Skip(TaskItem t)
        {
            var c = t.Clone();
            c.IsSkipped = true;
            c.UpdatedAt = now;
            batch.PutTask(c);
            batch.AddEvent(new TaskEvent { TaskId = t.Id, Kind = TaskEventKind.Skipped, At = now, FromDate = t.ScheduledDate });
            skipped++;
        }
    }
}
