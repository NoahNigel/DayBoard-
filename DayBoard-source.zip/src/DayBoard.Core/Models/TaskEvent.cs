namespace DayBoard.Core.Models;

/// <summary>Append-only history entry used by the weekly review (slips) and focus statistics.</summary>
public sealed class TaskEvent
{
    public long Id { get; set; }
    public Guid TaskId { get; set; }
    public TaskEventKind Kind { get; set; }
    public DateTime At { get; set; }
    public DateOnly? FromDate { get; set; }
    public DateOnly? ToDate { get; set; }
    public int? Minutes { get; set; }
}
