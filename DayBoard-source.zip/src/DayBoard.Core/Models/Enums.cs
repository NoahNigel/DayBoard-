namespace DayBoard.Core.Models;

public enum Priority
{
    None = 0,
    Low = 1,
    Medium = 2,
    High = 3,
}

/// <summary>Workflow state of a task (named TaskState to avoid clashing with System.Threading.Tasks.TaskStatus).</summary>
public enum TaskState
{
    ToDo = 0,
    Doing = 1,
    Done = 2,
}

public enum RolloverMode
{
    /// <summary>Unfinished tasks from past days move to today and their rollover count increases.</summary>
    MoveToToday = 0,

    /// <summary>Unfinished tasks stay on their day and are flagged as overdue.</summary>
    FlagOverdue = 1,
}

public enum ThemeMode
{
    System = 0,
    Light = 1,
    Dark = 2,
}

public enum Density
{
    Comfortable = 0,
    Compact = 1,
}

/// <summary>Which occurrences an edit or delete of a recurring task applies to.</summary>
public enum EditScope
{
    ThisOccurrence = 0,
    WholeSeries = 1,
}

public enum TaskEventKind
{
    /// <summary>Rollover moved the task from a past day to today.</summary>
    Rolled = 0,

    /// <summary>A recurring occurrence was missed and skipped because a newer occurrence exists.</summary>
    Skipped = 1,

    /// <summary>The task was flagged overdue (rollover mode "flag as overdue").</summary>
    Overdue = 2,

    /// <summary>Focus time was logged.</summary>
    Focus = 3,
}

public static class PriorityExtensions
{
    /// <summary>Text glyph used next to the colour so priority never relies on colour alone.</summary>
    public static string Glyph(this Priority p) => p switch
    {
        Priority.Low => "!",
        Priority.Medium => "!!",
        Priority.High => "!!!",
        _ => "",
    };

    public static string Label(this Priority p) => p switch
    {
        Priority.Low => "Low",
        Priority.Medium => "Medium",
        Priority.High => "High",
        _ => "None",
    };

    /// <summary>Importance axis of the Eisenhower matrix: Medium and High count as important.</summary>
    public static bool IsImportant(this Priority p) => p >= Priority.Medium;
}

public static class TaskStateExtensions
{
    public static string Label(this TaskState s) => s switch
    {
        TaskState.Doing => "Doing",
        TaskState.Done => "Done",
        _ => "To do",
    };
}
