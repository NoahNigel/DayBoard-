namespace DayBoard.Core.Models;

/// <summary>All user settings. Stored as one JSON document in the database.</summary>
public sealed class AppSettings
{
    // Appearance
    public ThemeMode Theme { get; set; } = ThemeMode.System;
    public Density Density { get; set; } = Density.Comfortable;
    public string PriorityLowColor { get; set; } = "#3B82F6";
    public string PriorityMediumColor { get; set; } = "#F59E0B";
    public string PriorityHighColor { get; set; } = "#E5484D";

    // Plugins
    /// <summary>Id of the theme plugin in use, or null for DayBoard's own colours.</summary>
    public string? ThemePluginId { get; set; }

    /// <summary>Ids of the code plugins that are ticked (turned on). Named for DayBoard 1.2's feature plugins, which it replaces.</summary>
    [System.Text.Json.Serialization.JsonPropertyName("EnabledFeaturePlugins")]
    public List<string> EnabledPlugins { get; set; } = new();

    /// <summary>Ids of the plugins that come with DayBoard (such as Focus) that were unticked. They're on otherwise.</summary>
    public List<string> DisabledBuiltInPlugins { get; set; } = new();

    // Planning
    public DayOfWeek WeekStart { get; set; } = DayOfWeek.Monday;
    public int DayStartHour { get; set; } = 7;
    public int DayEndHour { get; set; } = 22;
    public double CapacityHours { get; set; } = 6;
    public int DefaultEstimateMinutes { get; set; } = 30;
    public RolloverMode RolloverMode { get; set; } = RolloverMode.MoveToToday;
    public bool ShowCompletedTasks { get; set; } = true;

    // Windows integration
    public bool HotkeyEnabled { get; set; } = true;

    /// <summary>Comma separated: Control, Alt, Shift, Windows.</summary>
    public string HotkeyModifiers { get; set; } = "Control, Alt";

    /// <summary>WPF Key name, e.g. "Space".</summary>
    public string HotkeyKey { get; set; } = "Space";

    public bool CloseToTray { get; set; } = true;
    public bool StartWithWindows { get; set; }

    /// <summary>Keep a shortcut in the Start menu, so Windows search finds DayBoard.</summary>
    public bool StartMenuShortcut { get; set; } = true;
    public bool StartMinimized { get; set; }

    // Focus timer, as set in DayBoard 1.3 and earlier. Focus is a built-in plugin since 1.4 and keeps its own settings;
    // these are copied into its storage once.
    public int PomodoroWorkMinutes { get; set; } = 25;
    public int PomodoroBreakMinutes { get; set; } = 5;
    public int PomodoroLongBreakMinutes { get; set; } = 15;
    public int PomodoroLongBreakEvery { get; set; } = 4;
    public bool PomodoroAutoStartBreak { get; set; } = true;

    // Calendars
    public int CalendarRefreshMinutes { get; set; } = 30;
    public List<CalendarSubscription> Calendars { get; set; } = new();

    // Microsoft To Do import
    public string MsTodoClientId { get; set; } = "";
    public string MsTodoTenant { get; set; } = "common";

    // Window state
    public WindowBounds? MainWindow { get; set; }
    public WindowBounds? MiniWindow { get; set; }
    public bool MiniWindowOpen { get; set; }
    public string LastView { get; set; } = "Day";
    public bool InboxVisible { get; set; } = true;

    public string? LastBackupDate { get; set; }
    public bool SeededDefaults { get; set; }

    /// <summary>One-time notes that were shown already, such as "1.6-views-to-plugins".</summary>
    public List<string> SeenNotes { get; set; } = new();

    public AppSettings Clone()
    {
        var c = (AppSettings)MemberwiseClone();
        c.Calendars = Calendars.Select(x => x.Clone()).ToList();
        c.EnabledPlugins = new List<string>(EnabledPlugins);
        c.DisabledBuiltInPlugins = new List<string>(DisabledBuiltInPlugins);
        c.SeenNotes = new List<string>(SeenNotes);
        c.MainWindow = MainWindow?.Clone();
        c.MiniWindow = MiniWindow?.Clone();
        return c;
    }

    public int CapacityMinutes => (int)Math.Round(CapacityHours * 60);

    public string PriorityColor(Priority p) => p switch
    {
        Priority.Low => PriorityLowColor,
        Priority.Medium => PriorityMediumColor,
        Priority.High => PriorityHighColor,
        _ => "#8A8F98",
    };
}

public sealed class WindowBounds
{
    public double Left { get; set; }
    public double Top { get; set; }
    public double Width { get; set; }
    public double Height { get; set; }
    public bool Maximized { get; set; }

    public WindowBounds Clone() => (WindowBounds)MemberwiseClone();
}

/// <summary>A read-only iCal feed (e.g. a Google or Outlook "secret address").</summary>
public sealed class CalendarSubscription
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "Calendar";
    public string Url { get; set; } = "";
    public string Color { get; set; } = "#7C8DB5";
    public bool Enabled { get; set; } = true;
    public DateTime? LastRefreshed { get; set; }
    public string? LastError { get; set; }

    public CalendarSubscription Clone() => (CalendarSubscription)MemberwiseClone();
}
