namespace DayBoard.Core.Models;

public sealed class Category
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Name { get; set; } = "";

    /// <summary>Colour as #RRGGBB.</summary>
    public string Color { get; set; } = "#5B6CF0";

    /// <summary>Fluent System Icons symbol name (WPF-UI SymbolRegular), e.g. "Briefcase24".</summary>
    public string Icon { get; set; } = "Tag24";

    public int SortOrder { get; set; }

    public Category Clone() => (Category)MemberwiseClone();

    public static IReadOnlyList<Category> Defaults() => new[]
    {
        new Category { Name = "Work", Color = "#3B82F6", Icon = "Briefcase24", SortOrder = 0 },
        new Category { Name = "Personal", Color = "#10B981", Icon = "Person24", SortOrder = 1 },
        new Category { Name = "Health", Color = "#EC4899", Icon = "Heart24", SortOrder = 2 },
        new Category { Name = "Errands", Color = "#F59E0B", Icon = "Cart24", SortOrder = 3 },
        new Category { Name = "Learning", Color = "#8B5CF6", Icon = "Book24", SortOrder = 4 },
    };
}
