using System.Text.Json.Serialization;

namespace DayBoard.Core.Models;

public sealed class TaskItem
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public string Notes { get; set; } = "";
    public Priority Priority { get; set; }
    public bool IsUrgent { get; set; }
    public Guid? CategoryId { get; set; }

    /// <summary>Day the task is planned for. Null means the task lives in the inbox.</summary>
    public DateOnly? ScheduledDate { get; set; }

    /// <summary>Optional time block start on <see cref="ScheduledDate"/>.</summary>
    public TimeOnly? StartTime { get; set; }

    public int? EstimateMinutes { get; set; }
    public int ActualMinutes { get; set; }
    public DateOnly? DueDate { get; set; }
    public TaskState Status { get; set; }

    /// <summary>Local time the task was completed.</summary>
    public DateTime? CompletedAt { get; set; }

    /// <summary>Recurring series this task is an occurrence of.</summary>
    public Guid? SeriesId { get; set; }

    /// <summary>The date the series generated this occurrence for (stays the same when the occurrence is moved).</summary>
    public DateOnly? OccurrenceDate { get; set; }

    /// <summary>True when this occurrence was edited on its own ("this occurrence"), so series edits leave it alone.</summary>
    public bool IsSeriesException { get; set; }

    /// <summary>A missed recurring occurrence that rollover skipped because a newer occurrence exists. Hidden from views.</summary>
    public bool IsSkipped { get; set; }

    public List<Subtask> Subtasks { get; set; } = new();
    public double SortOrder { get; set; }
    public int RolloverCount { get; set; }

    /// <summary>Identifier in an external system, e.g. "mstodo:&lt;id&gt;", used to avoid duplicate imports.</summary>
    public string? ExternalId { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;
    public DateTime UpdatedAt { get; set; } = DateTime.Now;

    [JsonIgnore] public bool IsDone => Status == TaskState.Done;
    [JsonIgnore] public bool IsRecurring => SeriesId.HasValue;
    [JsonIgnore] public int SubtasksDone => Subtasks.Count(s => s.IsDone);

    public TaskItem Clone()
    {
        var c = (TaskItem)MemberwiseClone();
        c.Subtasks = Subtasks.Select(s => s.Clone()).ToList();
        return c;
    }

    public bool IsOverdue(DateOnly today) =>
        !IsDone && ((ScheduledDate.HasValue && ScheduledDate.Value < today) || (DueDate.HasValue && DueDate.Value < today));

    public override string ToString() => $"{Title} ({ScheduledDate?.ToString("yyyy-MM-dd") ?? "inbox"})";
}

public sealed class Subtask
{
    public Guid Id { get; set; } = Guid.NewGuid();
    public string Title { get; set; } = "";
    public bool IsDone { get; set; }

    public Subtask Clone() => (Subtask)MemberwiseClone();
}
