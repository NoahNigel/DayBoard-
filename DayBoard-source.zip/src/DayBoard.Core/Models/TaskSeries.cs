using DayBoard.Core.Recurrence;

namespace DayBoard.Core.Models;

/// <summary>
/// A recurring task. The series holds the template and the RRULE; concrete occurrences are
/// <see cref="TaskItem"/>s with <see cref="TaskItem.SeriesId"/> set, created ahead of time by the SeriesService.
/// </summary>
public sealed class TaskSeries
{
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>RFC 5545 RRULE value (without the "RRULE:" prefix), e.g. "FREQ=WEEKLY;BYDAY=MO,WE".</summary>
    public string RRule { get; set; } = "FREQ=DAILY";

    /// <summary>DTSTART of the rule.</summary>
    public DateOnly StartDate { get; set; }

    /// <summary>Last date an occurrence may fall on (the series stops after it). Null = open-ended.</summary>
    public DateOnly? EndDate { get; set; }

    // Template copied into each new occurrence.
    public string Title { get; set; } = "";
    public string Notes { get; set; } = "";
    public Priority Priority { get; set; }
    public bool IsUrgent { get; set; }
    public Guid? CategoryId { get; set; }
    public TimeOnly? StartTime { get; set; }
    public int? EstimateMinutes { get; set; }
    public List<string> SubtaskTitles { get; set; } = new();

    /// <summary>Occurrence dates that were deleted individually and must not be generated again.</summary>
    public HashSet<DateOnly> ExceptionDates { get; set; } = new();

    /// <summary>Occurrences have been generated up to and including this date.</summary>
    public DateOnly? MaterializedThrough { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.Now;

    public TaskSeries Clone()
    {
        var c = (TaskSeries)MemberwiseClone();
        c.SubtaskTitles = new List<string>(SubtaskTitles);
        c.ExceptionDates = new HashSet<DateOnly>(ExceptionDates);
        return c;
    }

    public RecurrenceRule Rule => RecurrenceRule.Parse(RRule);

    /// <summary>Occurrence dates of this series between <paramref name="from"/> and <paramref name="to"/> (inclusive).</summary>
    public IEnumerable<DateOnly> OccurrencesBetween(DateOnly from, DateOnly to)
    {
        if (EndDate.HasValue && EndDate.Value < to) to = EndDate.Value;
        if (to < from) yield break;
        foreach (var d in Rule.Occurrences(StartDate, from, to))
        {
            if (!ExceptionDates.Contains(d)) yield return d;
        }
    }

    public bool OccursOn(DateOnly date) => OccurrencesBetween(date, date).Any();

    public void CopyTemplateTo(TaskItem t)
    {
        t.Title = Title;
        t.Notes = Notes;
        t.Priority = Priority;
        t.IsUrgent = IsUrgent;
        t.CategoryId = CategoryId;
        t.StartTime = StartTime;
        t.EstimateMinutes = EstimateMinutes;
    }

    public void CopyTemplateFrom(TaskItem t)
    {
        Title = t.Title;
        Notes = t.Notes;
        Priority = t.Priority;
        IsUrgent = t.IsUrgent;
        CategoryId = t.CategoryId;
        StartTime = t.StartTime;
        EstimateMinutes = t.EstimateMinutes;
        SubtaskTitles = t.Subtasks.Select(s => s.Title).ToList();
    }
}
