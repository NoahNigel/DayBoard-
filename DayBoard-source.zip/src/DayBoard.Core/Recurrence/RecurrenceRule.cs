using System.Globalization;
using System.Text;
using DayBoard.Core.Time;

namespace DayBoard.Core.Recurrence;

public enum Frequency
{
    Daily,
    Weekly,
    Monthly,
    Yearly,
}

/// <summary>A BYDAY entry: weekday with optional ordinal (0 = every, 1 = first, -1 = last).</summary>
public readonly record struct WeekdayNum(int Ordinal, DayOfWeek Day)
{
    public override string ToString() =>
        (Ordinal != 0 ? Ordinal.ToString(CultureInfo.InvariantCulture) : "") + RecurrenceRule.DayCode(Day);
}

/// <summary>UNTIL value: a date, or a date-time (UTC when <see cref="IsUtc"/>).</summary>
public readonly record struct RRuleUntil(DateOnly Date, TimeOnly? Time, bool IsUtc)
{
    public override string ToString()
    {
        var s = Date.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        if (Time is { } t) s += "T" + t.ToString("HHmmss", CultureInfo.InvariantCulture) + (IsUtc ? "Z" : "");
        return s;
    }
}

/// <summary>
/// Date-level RFC 5545 recurrence rule (FREQ DAILY/WEEKLY/MONTHLY/YEARLY with INTERVAL, COUNT, UNTIL,
/// BYDAY, BYMONTHDAY, BYMONTH, BYSETPOS, WKST). Used for recurring tasks and for iCal event expansion.
/// Sub-daily frequencies are treated as daily; BYYEARDAY/BYWEEKNO/BYHOUR etc. are ignored.
/// </summary>
public sealed class RecurrenceRule
{
    public Frequency Frequency { get; init; } = Frequency.Daily;
    public int Interval { get; init; } = 1;
    public int? Count { get; init; }
    public RRuleUntil? Until { get; init; }
    public IReadOnlyList<WeekdayNum> ByDay { get; init; } = Array.Empty<WeekdayNum>();
    public IReadOnlyList<int> ByMonthDay { get; init; } = Array.Empty<int>();
    public IReadOnlyList<int> ByMonth { get; init; } = Array.Empty<int>();
    public IReadOnlyList<int> BySetPos { get; init; } = Array.Empty<int>();
    public DayOfWeek WeekStart { get; init; } = DayOfWeek.Monday;

    /// <summary>True when the source used parts this engine ignores (for diagnostics).</summary>
    public bool HasIgnoredParts { get; init; }

    private static readonly Dictionary<string, DayOfWeek> DayCodes = new(StringComparer.OrdinalIgnoreCase)
    {
        ["MO"] = DayOfWeek.Monday,
        ["TU"] = DayOfWeek.Tuesday,
        ["WE"] = DayOfWeek.Wednesday,
        ["TH"] = DayOfWeek.Thursday,
        ["FR"] = DayOfWeek.Friday,
        ["SA"] = DayOfWeek.Saturday,
        ["SU"] = DayOfWeek.Sunday,
    };

    public static string DayCode(DayOfWeek d) => d switch
    {
        DayOfWeek.Monday => "MO",
        DayOfWeek.Tuesday => "TU",
        DayOfWeek.Wednesday => "WE",
        DayOfWeek.Thursday => "TH",
        DayOfWeek.Friday => "FR",
        DayOfWeek.Saturday => "SA",
        _ => "SU",
    };

    public static bool TryParse(string? text, out RecurrenceRule rule)
    {
        try
        {
            rule = Parse(text ?? "");
            return true;
        }
        catch (FormatException)
        {
            rule = new RecurrenceRule();
            return false;
        }
    }

    public static RecurrenceRule Parse(string text)
    {
        var s = text.Trim();
        if (s.StartsWith("RRULE:", StringComparison.OrdinalIgnoreCase)) s = s[6..];
        if (s.Length == 0) throw new FormatException("Empty RRULE");

        Frequency? freq = null;
        int interval = 1;
        int? count = null;
        RRuleUntil? until = null;
        var byDay = new List<WeekdayNum>();
        var byMonthDay = new List<int>();
        var byMonth = new List<int>();
        var bySetPos = new List<int>();
        var wkst = DayOfWeek.Monday;
        bool ignored = false;

        foreach (var part in s.Split(';', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
        {
            int eq = part.IndexOf('=');
            if (eq <= 0) throw new FormatException($"Bad RRULE part '{part}'");
            var key = part[..eq].Trim().ToUpperInvariant();
            var val = part[(eq + 1)..].Trim();
            switch (key)
            {
                case "FREQ":
                    freq = val.ToUpperInvariant() switch
                    {
                        "DAILY" => Frequency.Daily,
                        "WEEKLY" => Frequency.Weekly,
                        "MONTHLY" => Frequency.Monthly,
                        "YEARLY" => Frequency.Yearly,
                        "HOURLY" or "MINUTELY" or "SECONDLY" => Frequency.Daily,
                        _ => throw new FormatException($"Unknown FREQ '{val}'"),
                    };
                    if (val.ToUpperInvariant() is "HOURLY" or "MINUTELY" or "SECONDLY") ignored = true;
                    break;
                case "INTERVAL":
                    interval = Math.Max(1, ParseInt(val));
                    break;
                case "COUNT":
                    count = Math.Max(0, ParseInt(val));
                    break;
                case "UNTIL":
                    until = ParseUntil(val);
                    break;
                case "BYDAY":
                    foreach (var item in val.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
                    {
                        if (item.Length < 2) throw new FormatException($"Bad BYDAY '{item}'");
                        var code = item[^2..];
                        if (!DayCodes.TryGetValue(code, out var dow)) throw new FormatException($"Bad BYDAY '{item}'");
                        var ordText = item[..^2];
                        int ord = ordText.Length == 0 ? 0 : ParseInt(ordText);
                        byDay.Add(new WeekdayNum(ord, dow));
                    }
                    break;
                case "BYMONTHDAY":
                    byMonthDay.AddRange(ParseIntList(val).Where(x => x != 0 && x >= -31 && x <= 31));
                    break;
                case "BYMONTH":
                    byMonth.AddRange(ParseIntList(val).Where(x => x >= 1 && x <= 12));
                    break;
                case "BYSETPOS":
                    bySetPos.AddRange(ParseIntList(val).Where(x => x != 0));
                    break;
                case "WKST":
                    if (DayCodes.TryGetValue(val, out var w)) wkst = w;
                    break;
                default:
                    ignored = true;
                    break;
            }
        }

        if (freq is null) throw new FormatException("RRULE without FREQ");
        return new RecurrenceRule
        {
            Frequency = freq.Value,
            Interval = interval,
            Count = count,
            Until = until,
            ByDay = byDay,
            ByMonthDay = byMonthDay,
            ByMonth = byMonth,
            BySetPos = bySetPos,
            WeekStart = wkst,
            HasIgnoredParts = ignored,
        };
    }

    private static int ParseInt(string s) =>
        int.TryParse(s, NumberStyles.AllowLeadingSign, CultureInfo.InvariantCulture, out var v)
            ? v
            : throw new FormatException($"Bad number '{s}'");

    private static IEnumerable<int> ParseIntList(string s) =>
        s.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).Select(ParseInt);

    private static RRuleUntil ParseUntil(string v)
    {
        v = v.Trim();
        if (v.Length >= 8 && DateOnly.TryParseExact(v[..8], "yyyyMMdd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d))
        {
            if (v.Length == 8) return new RRuleUntil(d, null, false);
            if (v.Length >= 15 && (v[8] == 'T' || v[8] == 't') &&
                TimeOnly.TryParseExact(v.Substring(9, 6), "HHmmss", CultureInfo.InvariantCulture, DateTimeStyles.None, out var t))
            {
                bool utc = v.EndsWith('Z') || v.EndsWith('z');
                return new RRuleUntil(d, t, utc);
            }
        }
        throw new FormatException($"Bad UNTIL '{v}'");
    }

    public override string ToString()
    {
        var sb = new StringBuilder();
        sb.Append("FREQ=").Append(Frequency.ToString().ToUpperInvariant());
        if (Interval > 1) sb.Append(";INTERVAL=").Append(Interval.ToString(CultureInfo.InvariantCulture));
        if (Count.HasValue) sb.Append(";COUNT=").Append(Count.Value.ToString(CultureInfo.InvariantCulture));
        if (Until.HasValue) sb.Append(";UNTIL=").Append(Until.Value.ToString());
        if (ByDay.Count > 0) sb.Append(";BYDAY=").Append(string.Join(",", ByDay.Select(x => x.ToString())));
        if (ByMonthDay.Count > 0) sb.Append(";BYMONTHDAY=").Append(string.Join(",", ByMonthDay.Select(x => x.ToString(CultureInfo.InvariantCulture))));
        if (ByMonth.Count > 0) sb.Append(";BYMONTH=").Append(string.Join(",", ByMonth.Select(x => x.ToString(CultureInfo.InvariantCulture))));
        if (BySetPos.Count > 0) sb.Append(";BYSETPOS=").Append(string.Join(",", BySetPos.Select(x => x.ToString(CultureInfo.InvariantCulture))));
        if (WeekStart != DayOfWeek.Monday) sb.Append(";WKST=").Append(DayCode(WeekStart));
        return sb.ToString();
    }

    /// <summary>
    /// Inclusive date bound implied by UNTIL. For a date-time UNTIL the bound is loosened by a day so that
    /// time-zone conversion can't drop a valid occurrence; callers with times apply the exact check.
    /// </summary>
    public DateOnly? UntilDateBound => Until is null ? null : Until.Value.Time is null ? Until.Value.Date : Until.Value.Date.AddDays(1);

    /// <summary>
    /// Occurrence dates between <paramref name="from"/> and <paramref name="to"/> (inclusive) for a rule starting at
    /// <paramref name="dtStart"/>. COUNT is counted from <paramref name="dtStart"/>.
    /// </summary>
    public IEnumerable<DateOnly> Occurrences(DateOnly dtStart, DateOnly from, DateOnly to)
    {
        if (to < from) yield break;
        var untilBound = UntilDateBound;
        int interval = Math.Max(1, Interval);
        int produced = 0;

        long startPeriod = 0;
        if (Count is null && from > dtStart)
        {
            // Jump close to "from" without enumerating every period since dtStart.
            startPeriod = Math.Max(0, PeriodsBetween(dtStart, from) / interval - 1);
        }

        for (long k = startPeriod; k < startPeriod + 500_000; k++)
        {
            var periodStart = PeriodStart(dtStart, k * interval);
            if (periodStart is null) yield break;
            if (periodStart.Value > to) yield break;
            if (untilBound.HasValue && periodStart.Value > untilBound.Value) yield break;

            foreach (var d in Expand(periodStart.Value, dtStart))
            {
                if (d < dtStart) continue;
                if (untilBound.HasValue && d > untilBound.Value) yield break;
                if (Count.HasValue && produced >= Count.Value) yield break;
                if (d > to) yield break;
                produced++;
                if (d >= from) yield return d;
            }
        }
    }

    private long PeriodsBetween(DateOnly dtStart, DateOnly date) => Frequency switch
    {
        Frequency.Daily => date.DayNumber - dtStart.DayNumber,
        Frequency.Weekly => (DateUtil.StartOfWeek(date, WeekStart).DayNumber - DateUtil.StartOfWeek(dtStart, WeekStart).DayNumber) / 7,
        Frequency.Monthly => (date.Year - dtStart.Year) * 12L + (date.Month - dtStart.Month),
        _ => date.Year - dtStart.Year,
    };

    private DateOnly? PeriodStart(DateOnly dtStart, long n)
    {
        try
        {
            return Frequency switch
            {
                Frequency.Daily => n > 3_000_000 ? null : dtStart.AddDays((int)n),
                Frequency.Weekly => n > 500_000 ? null : DateUtil.StartOfWeek(dtStart, WeekStart).AddDays((int)(n * 7)),
                Frequency.Monthly => n > 100_000 ? null : new DateOnly(dtStart.Year, dtStart.Month, 1).AddMonths((int)n),
                _ => n > 8000 ? null : new DateOnly(dtStart.Year, 1, 1).AddYears((int)n),
            };
        }
        catch (ArgumentOutOfRangeException)
        {
            return null;
        }
    }

    private List<DateOnly> Expand(DateOnly periodStart, DateOnly dtStart)
    {
        var result = new List<DateOnly>();
        switch (Frequency)
        {
            case Frequency.Daily:
            {
                var d = periodStart;
                if (ByMonth.Count > 0 && !ByMonth.Contains(d.Month)) break;
                if (ByMonthDay.Count > 0 && !ByMonthDay.Any(md => ResolveMonthDay(d.Year, d.Month, md) == d.Day)) break;
                if (ByDay.Count > 0 && !ByDay.Any(x => x.Day == d.DayOfWeek)) break;
                result.Add(d);
                break;
            }
            case Frequency.Weekly:
            {
                var days = ByDay.Count > 0 ? ByDay.Select(x => x.Day).ToHashSet() : new HashSet<DayOfWeek> { dtStart.DayOfWeek };
                for (int i = 0; i < 7; i++)
                {
                    var d = periodStart.AddDays(i);
                    if (!days.Contains(d.DayOfWeek)) continue;
                    if (ByMonth.Count > 0 && !ByMonth.Contains(d.Month)) continue;
                    result.Add(d);
                }
                break;
            }
            case Frequency.Monthly:
            {
                if (ByMonth.Count > 0 && !ByMonth.Contains(periodStart.Month)) break;
                result.AddRange(ExpandMonth(periodStart.Year, periodStart.Month, dtStart));
                break;
            }
            case Frequency.Yearly:
            {
                int year = periodStart.Year;
                if (ByMonth.Count > 0)
                {
                    foreach (var m in ByMonth.Distinct().OrderBy(x => x))
                    {
                        if (ByMonthDay.Count == 0 && ByDay.Count == 0)
                        {
                            if (dtStart.Day <= DateUtil.DaysInMonth(year, m)) result.Add(new DateOnly(year, m, dtStart.Day));
                        }
                        else
                        {
                            result.AddRange(ExpandMonth(year, m, dtStart));
                        }
                    }
                }
                else if (ByMonthDay.Count > 0)
                {
                    for (int m = 1; m <= 12; m++) result.AddRange(ExpandMonth(year, m, dtStart));
                }
                else if (ByDay.Count > 0)
                {
                    result.AddRange(ExpandYearByDay(year));
                }
                else if (dtStart.Day <= DateUtil.DaysInMonth(year, dtStart.Month))
                {
                    result.Add(new DateOnly(year, dtStart.Month, dtStart.Day));
                }
                break;
            }
        }

        result = result.Distinct().OrderBy(d => d).ToList();
        if (BySetPos.Count > 0 && Frequency != Frequency.Daily) result = ApplySetPos(result);
        return result;
    }

    private IEnumerable<DateOnly> ExpandMonth(int year, int month, DateOnly dtStart)
    {
        int dim = DateUtil.DaysInMonth(year, month);
        if (ByMonthDay.Count > 0)
        {
            foreach (var md in ByMonthDay)
            {
                int day = ResolveMonthDay(year, month, md);
                if (day < 1) continue;
                var d = new DateOnly(year, month, day);
                if (ByDay.Count > 0 && !ByDay.Any(x => x.Day == d.DayOfWeek)) continue;
                yield return d;
            }
            yield break;
        }

        if (ByDay.Count > 0)
        {
            foreach (var wd in ByDay)
            {
                if (wd.Ordinal == 0)
                {
                    for (int day = 1; day <= dim; day++)
                    {
                        var d = new DateOnly(year, month, day);
                        if (d.DayOfWeek == wd.Day) yield return d;
                    }
                }
                else
                {
                    var d = NthWeekdayOfMonth(year, month, wd.Day, wd.Ordinal);
                    if (d.HasValue) yield return d.Value;
                }
            }
            yield break;
        }

        if (dtStart.Day <= dim) yield return new DateOnly(year, month, dtStart.Day);
    }

    private IEnumerable<DateOnly> ExpandYearByDay(int year)
    {
        var first = new DateOnly(year, 1, 1);
        var last = new DateOnly(year, 12, 31);
        foreach (var wd in ByDay)
        {
            if (wd.Ordinal == 0)
            {
                for (var d = first; d <= last; d = d.AddDays(1))
                    if (d.DayOfWeek == wd.Day) yield return d;
            }
            else if (wd.Ordinal > 0)
            {
                int offset = ((int)wd.Day - (int)first.DayOfWeek + 7) % 7;
                var d = first.AddDays(offset + 7 * (wd.Ordinal - 1));
                if (d.Year == year) yield return d;
            }
            else
            {
                int offset = ((int)last.DayOfWeek - (int)wd.Day + 7) % 7;
                var d = last.AddDays(-(offset + 7 * (-wd.Ordinal - 1)));
                if (d.Year == year) yield return d;
            }
        }
    }

    private List<DateOnly> ApplySetPos(List<DateOnly> sorted)
    {
        var picked = new List<DateOnly>();
        foreach (var pos in BySetPos)
        {
            int idx = pos > 0 ? pos - 1 : sorted.Count + pos;
            if (idx >= 0 && idx < sorted.Count) picked.Add(sorted[idx]);
        }
        return picked.Distinct().OrderBy(d => d).ToList();
    }

    /// <summary>Resolves a BYMONTHDAY value (negative counts from the end) to a day number, or 0 if invalid.</summary>
    public static int ResolveMonthDay(int year, int month, int monthDay)
    {
        int dim = DateUtil.DaysInMonth(year, month);
        int day = monthDay > 0 ? monthDay : dim + monthDay + 1;
        return day >= 1 && day <= dim ? day : 0;
    }

    public static DateOnly? NthWeekdayOfMonth(int year, int month, DayOfWeek dow, int n)
    {
        int dim = DateUtil.DaysInMonth(year, month);
        if (n > 0)
        {
            var first = new DateOnly(year, month, 1);
            int offset = ((int)dow - (int)first.DayOfWeek + 7) % 7;
            int day = 1 + offset + 7 * (n - 1);
            return day <= dim ? new DateOnly(year, month, day) : null;
        }
        if (n < 0)
        {
            var last = new DateOnly(year, month, dim);
            int offset = ((int)last.DayOfWeek - (int)dow + 7) % 7;
            int day = dim - offset - 7 * (-n - 1);
            return day >= 1 ? new DateOnly(year, month, day) : null;
        }
        return null;
    }
}
