using System.Globalization;
using DayBoard.Core.Time;

namespace DayBoard.Core.Recurrence;

public enum RepeatKind
{
    None,
    Daily,
    Weekdays,
    Weekly,
    MonthlyDay,
    MonthlyWeekday,

    /// <summary>A rule that came from elsewhere (e.g. import) and doesn't fit the presets.</summary>
    Custom,
}

/// <summary>
/// The recurrence options offered in the task editor, convertible to and from an RRULE:
/// daily (every N days), weekdays, weekly on chosen days (every N weeks), monthly on day X
/// (clamped to the last day in shorter months), and monthly on the first/second/third/fourth/last weekday.
/// </summary>
public sealed class RepeatPattern
{
    public RepeatKind Kind { get; set; } = RepeatKind.None;

    /// <summary>Every N days (Daily) or every N weeks (Weekly).</summary>
    public int Interval { get; set; } = 1;

    public List<DayOfWeek> Days { get; set; } = new();
    public int DayOfMonth { get; set; } = 1;

    /// <summary>1..4, or -1 for "last".</summary>
    public int WeekOrdinal { get; set; } = 1;

    public DayOfWeek Weekday { get; set; } = DayOfWeek.Monday;
    public DateOnly? Until { get; set; }

    /// <summary>Original rule text for <see cref="RepeatKind.Custom"/>.</summary>
    public string? CustomRule { get; set; }

    public static RepeatPattern None => new() { Kind = RepeatKind.None };

    public bool IsRepeating => Kind != RepeatKind.None;

    public RepeatPattern Clone() => new()
    {
        Kind = Kind,
        Interval = Interval,
        Days = new List<DayOfWeek>(Days),
        DayOfMonth = DayOfMonth,
        WeekOrdinal = WeekOrdinal,
        Weekday = Weekday,
        Until = Until,
        CustomRule = CustomRule,
    };

    public string? ToRRule()
    {
        string? core = Kind switch
        {
            RepeatKind.None => null,
            RepeatKind.Daily => Interval > 1 ? $"FREQ=DAILY;INTERVAL={Interval}" : "FREQ=DAILY",
            RepeatKind.Weekdays => "FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR",
            RepeatKind.Weekly => WeeklyRule(),
            RepeatKind.MonthlyDay => MonthlyDayRule(),
            RepeatKind.MonthlyWeekday => $"FREQ=MONTHLY;BYDAY={(WeekOrdinal == -1 ? -1 : Math.Clamp(WeekOrdinal, 1, 4)).ToString(CultureInfo.InvariantCulture)}{RecurrenceRule.DayCode(Weekday)}",
            RepeatKind.Custom => StripUntil(CustomRule),
            _ => null,
        };
        if (core is null) return null;
        if (Until.HasValue) core += ";UNTIL=" + Until.Value.ToString("yyyyMMdd", CultureInfo.InvariantCulture);
        return core;
    }

    private string WeeklyRule()
    {
        var days = Days.Count == 0 ? new List<DayOfWeek> { DayOfWeek.Monday } : Days;
        var ordered = days.Distinct().OrderBy(d => ((int)d + 6) % 7).Select(RecurrenceRule.DayCode);
        var s = "FREQ=WEEKLY";
        if (Interval > 1) s += $";INTERVAL={Interval}";
        return s + ";BYDAY=" + string.Join(",", ordered);
    }

    private string MonthlyDayRule()
    {
        int day = Math.Clamp(DayOfMonth, 1, 31);
        if (day <= 28) return $"FREQ=MONTHLY;BYMONTHDAY={day}";
        // "Day 30" in a 28/29-day month means the last day: pick the last of 28..day that exists.
        var days = string.Join(",", Enumerable.Range(28, day - 27));
        return $"FREQ=MONTHLY;BYMONTHDAY={days};BYSETPOS=-1";
    }

    private static string? StripUntil(string? rule)
    {
        if (string.IsNullOrWhiteSpace(rule)) return null;
        var parts = rule.Split(';', StringSplitOptions.RemoveEmptyEntries)
            .Where(p => !p.TrimStart().StartsWith("UNTIL=", StringComparison.OrdinalIgnoreCase));
        return string.Join(";", parts);
    }

    public static RepeatPattern FromRRule(string? rrule, DateOnly startDate)
    {
        if (string.IsNullOrWhiteSpace(rrule) || !RecurrenceRule.TryParse(rrule, out var r)) return None;
        var p = new RepeatPattern { Until = r.Until?.Date, Interval = r.Interval };

        bool noBy = r.ByDay.Count == 0 && r.ByMonthDay.Count == 0 && r.ByMonth.Count == 0 && r.BySetPos.Count == 0;
        if (r.Count is null && !r.HasIgnoredParts)
        {
            if (r.Frequency == Frequency.Daily && noBy)
            {
                p.Kind = RepeatKind.Daily;
                return p;
            }

            if (r.Frequency == Frequency.Weekly && r.ByMonthDay.Count == 0 && r.ByMonth.Count == 0 && r.BySetPos.Count == 0 &&
                r.ByDay.All(x => x.Ordinal == 0))
            {
                var days = r.ByDay.Count == 0 ? new List<DayOfWeek> { startDate.DayOfWeek } : r.ByDay.Select(x => x.Day).Distinct().ToList();
                var weekdays = new[] { DayOfWeek.Monday, DayOfWeek.Tuesday, DayOfWeek.Wednesday, DayOfWeek.Thursday, DayOfWeek.Friday };
                if (r.Interval == 1 && days.Count == 5 && weekdays.All(days.Contains))
                {
                    p.Kind = RepeatKind.Weekdays;
                    p.Interval = 1;
                    return p;
                }
                p.Kind = RepeatKind.Weekly;
                p.Days = days.OrderBy(d => ((int)d + 6) % 7).ToList();
                return p;
            }

            if (r.Frequency == Frequency.Monthly && r.Interval == 1 && r.ByMonth.Count == 0)
            {
                if (r.ByDay.Count == 0 && r.ByMonthDay.Count == 1 && r.ByMonthDay[0] is >= 1 and <= 28 && r.BySetPos.Count == 0)
                {
                    p.Kind = RepeatKind.MonthlyDay;
                    p.DayOfMonth = r.ByMonthDay[0];
                    return p;
                }
                if (r.ByDay.Count == 0 && r.BySetPos.Count == 1 && r.BySetPos[0] == -1 && r.ByMonthDay.Count >= 2 &&
                    r.ByMonthDay.OrderBy(x => x).SequenceEqual(Enumerable.Range(28, r.ByMonthDay.Count)))
                {
                    p.Kind = RepeatKind.MonthlyDay;
                    p.DayOfMonth = r.ByMonthDay.Max();
                    return p;
                }
                if (r.ByDay.Count == 0 && r.ByMonthDay.Count == 0 && r.BySetPos.Count == 0)
                {
                    p.Kind = RepeatKind.MonthlyDay;
                    p.DayOfMonth = startDate.Day;
                    return p;
                }
                if (r.ByMonthDay.Count == 0 && r.BySetPos.Count == 0 && r.ByDay.Count == 1 &&
                    (r.ByDay[0].Ordinal is >= 1 and <= 4 || r.ByDay[0].Ordinal == -1))
                {
                    p.Kind = RepeatKind.MonthlyWeekday;
                    p.WeekOrdinal = r.ByDay[0].Ordinal;
                    p.Weekday = r.ByDay[0].Day;
                    p.Interval = 1;
                    return p;
                }
            }
        }

        p.Kind = RepeatKind.Custom;
        p.CustomRule = rrule;
        return p;
    }

    public string Describe(CultureInfo? culture = null)
    {
        culture ??= CultureInfo.CurrentCulture;
        string text = Kind switch
        {
            RepeatKind.None => "Does not repeat",
            RepeatKind.Daily => Interval > 1 ? $"Every {Interval} days" : "Every day",
            RepeatKind.Weekdays => "Every weekday (Mon–Fri)",
            RepeatKind.Weekly => (Interval > 1 ? $"Every {Interval} weeks on " : "Weekly on ") +
                                 string.Join(", ", (Days.Count == 0 ? new List<DayOfWeek> { DayOfWeek.Monday } : Days)
                                     .OrderBy(d => ((int)d + 6) % 7).Select(DateUtil.ShortDayName)),
            RepeatKind.MonthlyDay => $"Monthly on day {DayOfMonth}" + (DayOfMonth > 28 ? " (or the last day)" : ""),
            RepeatKind.MonthlyWeekday => $"Monthly on the {OrdinalWord(WeekOrdinal)} {culture.DateTimeFormat.GetDayName(Weekday)}",
            RepeatKind.Custom => $"Custom ({CustomRule})",
            _ => "",
        };
        if (Kind != RepeatKind.None && Until.HasValue)
            text += " until " + Until.Value.ToString("d MMM yyyy", culture);
        return text;
    }

    public static string OrdinalWord(int n) => n switch
    {
        1 => "first",
        2 => "second",
        3 => "third",
        4 => "fourth",
        -1 => "last",
        _ => n.ToString(CultureInfo.InvariantCulture),
    };

    /// <summary>Sensible defaults for a pattern kind relative to a start date (used by the editor when switching kinds).</summary>
    public static RepeatPattern DefaultFor(RepeatKind kind, DateOnly start)
    {
        var p = new RepeatPattern { Kind = kind };
        switch (kind)
        {
            case RepeatKind.Weekly:
                p.Days = new List<DayOfWeek> { start.DayOfWeek };
                break;
            case RepeatKind.MonthlyDay:
                p.DayOfMonth = start.Day;
                break;
            case RepeatKind.MonthlyWeekday:
                p.Weekday = start.DayOfWeek;
                int nth = (start.Day - 1) / 7 + 1;
                bool isLast = start.AddDays(7).Month != start.Month;
                p.WeekOrdinal = isLast && nth >= 4 ? -1 : Math.Min(nth, 4);
                break;
        }
        return p;
    }

    public bool SameAs(RepeatPattern? other) =>
        other is not null && string.Equals(ToRRule(), other.ToRRule(), StringComparison.OrdinalIgnoreCase);
}
