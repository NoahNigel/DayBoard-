using System.Globalization;
using System.Text;
using DayBoard.Core.Models;
using DayBoard.Core.Store;

namespace DayBoard.Core.Export;

/// <summary>Flat CSV of all tasks (RFC 4180 quoting), for spreadsheets.</summary>
public static class CsvExporter
{
    public static readonly string[] Header =
    {
        "Id", "Title", "Notes", "Priority", "Urgent", "Category", "ScheduledDate", "StartTime", "EstimateMinutes",
        "ActualMinutes", "DueDate", "Status", "CompletedAt", "Recurrence", "SubtasksDone", "SubtasksTotal", "Subtasks",
        "RolloverCount", "CreatedAt",
    };

    public static string Export(PlannerData data)
    {
        var cats = data.Categories.ToDictionary(c => c.Id);
        var series = data.Series.ToDictionary(s => s.Id);
        var sb = new StringBuilder();
        sb.AppendLine(string.Join(",", Header));
        var inv = CultureInfo.InvariantCulture;
        foreach (var t in data.Tasks.Where(t => !t.IsSkipped).OrderBy(t => t.ScheduledDate ?? DateOnly.MaxValue).ThenBy(t => t.SortOrder))
        {
            var fields = new[]
            {
                t.Id.ToString("D"),
                t.Title,
                t.Notes,
                t.Priority.Label(),
                t.IsUrgent ? "yes" : "no",
                t.CategoryId is { } cid && cats.TryGetValue(cid, out var c) ? c.Name : "",
                t.ScheduledDate?.ToString("yyyy-MM-dd", inv) ?? "",
                t.StartTime?.ToString("HH:mm", inv) ?? "",
                t.EstimateMinutes?.ToString(inv) ?? "",
                t.ActualMinutes.ToString(inv),
                t.DueDate?.ToString("yyyy-MM-dd", inv) ?? "",
                t.Status.Label(),
                t.CompletedAt?.ToString("yyyy-MM-dd HH:mm", inv) ?? "",
                t.SeriesId is { } sid && series.TryGetValue(sid, out var s) ? s.RRule : "",
                t.SubtasksDone.ToString(inv),
                t.Subtasks.Count.ToString(inv),
                string.Join(" | ", t.Subtasks.Select(x => (x.IsDone ? "[x] " : "[ ] ") + x.Title)),
                t.RolloverCount.ToString(inv),
                t.CreatedAt.ToString("yyyy-MM-dd HH:mm", inv),
            };
            sb.AppendLine(string.Join(",", fields.Select(Quote)));
        }
        return sb.ToString();
    }

    public static string Quote(string? value)
    {
        value ??= "";
        bool needs = value.IndexOfAny(new[] { ',', '"', '\n', '\r' }) >= 0 || value.StartsWith(' ') || value.EndsWith(' ');
        // Guard against spreadsheet formula injection.
        if (value.Length > 0 && "=+-@".Contains(value[0]) && !double.TryParse(value, NumberStyles.Any, CultureInfo.InvariantCulture, out _))
        {
            value = "'" + value;
        }
        return needs ? "\"" + value.Replace("\"", "\"\"") + "\"" : value;
    }
}
