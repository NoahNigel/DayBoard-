using System.Text.Json;
using System.Text.Json.Serialization;
using DayBoard.Core.Models;
using DayBoard.Core.Store;

namespace DayBoard.Core.Export;

/// <summary>Full JSON export/import of tasks, categories and recurring series.</summary>
public static class JsonPorter
{
    public const string FormatName = "DayBoard";
    public const int FormatVersion = 1;

    public static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        DefaultIgnoreCondition = JsonIgnoreCondition.WhenWritingNull,
        Converters = { new JsonStringEnumConverter(JsonNamingPolicy.CamelCase) },
    };

    public sealed class ExportDocument
    {
        public string? Format { get; set; }
        public int Version { get; set; }
        public DateTime ExportedAt { get; set; }
        public List<Category> Categories { get; set; } = new();
        public List<TaskSeries> Series { get; set; } = new();
        public List<TaskItem> Tasks { get; set; } = new();
    }

    public static string Export(PlannerData data, DateTime now)
    {
        var doc = new ExportDocument
        {
            Format = FormatName,
            Version = FormatVersion,
            ExportedAt = now,
            Categories = data.Categories.OrderBy(c => c.SortOrder).ToList(),
            Series = data.Series.OrderBy(s => s.CreatedAt).ToList(),
            Tasks = data.Tasks.OrderBy(t => t.ScheduledDate ?? DateOnly.MaxValue).ThenBy(t => t.SortOrder).ToList(),
        };
        return JsonSerializer.Serialize(doc, Options);
    }

    /// <summary>Parses an export file. Throws <see cref="FormatException"/> with a readable message on bad input.</summary>
    public static PlannerData Import(string json)
    {
        ExportDocument? doc;
        try
        {
            doc = JsonSerializer.Deserialize<ExportDocument>(json, Options);
        }
        catch (JsonException ex)
        {
            throw new FormatException("This file isn't valid DayBoard JSON: " + ex.Message, ex);
        }
        if (doc is null || !string.Equals(doc.Format, FormatName, StringComparison.OrdinalIgnoreCase))
            throw new FormatException("This file isn't a DayBoard export (missing \"format\": \"DayBoard\").");
        if (doc.Version > FormatVersion)
            throw new FormatException($"This file was written by a newer DayBoard (format version {doc.Version}).");

        foreach (var t in doc.Tasks)
        {
            t.Title ??= "";
            t.Notes ??= "";
            t.Subtasks ??= new List<Subtask>();
        }
        foreach (var s in doc.Series)
        {
            s.SubtaskTitles ??= new List<string>();
            s.ExceptionDates ??= new HashSet<DateOnly>();
        }
        return new PlannerData { Categories = doc.Categories, Series = doc.Series, Tasks = doc.Tasks };
    }
}
