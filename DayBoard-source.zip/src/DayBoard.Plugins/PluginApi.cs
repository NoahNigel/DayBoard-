using System.Windows;

namespace DayBoard.Plugins;

/// <summary>
/// The entry point of a code plugin: one public class with a parameterless constructor.
/// DayBoard creates it once and calls <see cref="Start"/> when the plugin is ticked in Settings (and at start-up while it
/// stays ticked) and <see cref="Stop"/> when it's unticked or DayBoard closes. Both run on the UI thread.
/// </summary>
public interface IDayBoardPlugin
{
    /// <summary>Add pages and panels here, and subscribe to host events.</summary>
    void Start(IDayBoardHost host);

    /// <summary>Save anything pending and stop timers. Pages and panels the plugin added are removed by DayBoard.</summary>
    void Stop();
}

/// <summary>
/// What DayBoard offers a plugin. One instance per plugin, valid between Start and Stop.
/// Members marked "API 2" need DayBoard 1.4 or later, and "API 3" DayBoard 1.6 or later: a plugin that uses them sets
/// "apiVersion" to that number in its plugin.json.
/// </summary>
public interface IDayBoardHost
{
    /// <summary>The plugin API version DayBoard implements (1 for DayBoard 1.3, 2 for DayBoard 1.4, 3 for DayBoard 1.6).</summary>
    int ApiVersion { get; }

    Version AppVersion { get; }

    /// <summary>The plugin's id from its plugin.json.</summary>
    string PluginId { get; }

    /// <summary>A folder for files the plugin wants to keep, inside DayBoard's data folder. Created on first use.</summary>
    string DataFolder { get; }

    DateOnly Today { get; }

    /// <summary>The date selected in the Day view, week view and date-navigated pages.</summary>
    DateOnly SelectedDate { get; }

    /// <summary>The first day of the week, from Settings.</summary>
    DayOfWeek WeekStart { get; }

    /// <summary>Raised when the selected date changes, and at midnight when "today" moves on.</summary>
    event EventHandler? DateChanged;

    /// <summary>Raised after tasks change (added, edited, moved, completed, undone).</summary>
    event EventHandler? TasksChanged;

    /// <summary>Raised after the light/dark mode or the colour theme changes.</summary>
    event EventHandler? ThemeChanged;

    bool IsDarkTheme { get; }

    /// <summary>The plugin's own storage, saved in DayBoard's database (and so in its daily backups).</summary>
    IPluginStorage Storage { get; }

    /// <summary>A read-only snapshot of the tasks planned for a day, in display order.</summary>
    IReadOnlyList<PluginTask> TasksOn(DateOnly date);

    /// <summary>API 2. One task, or null when it doesn't exist (any more).</summary>
    PluginTask? FindTask(Guid id);

    /// <summary>API 2. The open tasks in the inbox (tasks without a date), in the inbox's order.</summary>
    IReadOnlyList<PluginTask> InboxTasks();

    /// <summary>API 2. Open tasks planned before today, oldest first.</summary>
    IReadOnlyList<PluginTask> OverdueTasks();

    /// <summary>
    /// API 2. Adds minutes to a task's logged time. Stats and the weekly review count it as focus time.
    /// Like any change in DayBoard it can be undone (Ctrl+Z).
    /// </summary>
    void LogTime(Guid taskId, int minutes);

    /// <summary>API 2. Marks a task done or not done (undoable).</summary>
    void SetDone(Guid taskId, bool done);

    /// <summary>API 2. Ticks or unticks an item of a task's checklist (undoable).</summary>
    void ToggleSubtask(Guid taskId, Guid subtaskId);

    /// <summary>
    /// API 3. Every task, open and done, planned or in the inbox, ordered by date (inbox last), then start time, then
    /// the order you put them in.
    /// </summary>
    IReadOnlyList<PluginTask> AllTasks();

    /// <summary>
    /// API 3. Task history entries whose day (the day they were recorded, or <see cref="PluginTaskHistory.FromDate"/>)
    /// is between <paramref name="from"/> and <paramref name="to"/>, oldest first.
    /// </summary>
    IReadOnlyList<PluginTaskHistory> TaskHistory(DateOnly from, DateOnly to);

    /// <summary>API 3. The completion rate for a period, worked out as Stats does.</summary>
    PluginCompletion Completion(DateOnly from, DateOnly to);

    /// <summary>API 3. Moves a task to To do, Doing or Done (undoable). Done marks it done.</summary>
    void SetStatus(Guid taskId, PluginTaskStatus status);

    /// <summary>
    /// API 3. Puts a task in a quadrant of the Eisenhower matrix (undoable): sets urgent, and raises the priority to
    /// Medium or lowers it to Low when it doesn't match <paramref name="important"/>.
    /// </summary>
    void SetQuadrant(Guid taskId, bool urgent, bool important);

    /// <summary>
    /// API 3. DayBoard's own card for a task, as the inbox and the week show it: tick it done, double-click to edit,
    /// right-click for its menu, and drag it to the Day view, the week, the inbox or a plugin's drop zone (see
    /// <see cref="TaskDragData"/>). Null when the task doesn't exist. Cards show the task as it was when they were made,
    /// so make new ones in <see cref="PluginPage.Show"/>.
    /// </summary>
    /// <param name="taskId">The task.</param>
    /// <param name="showDate">Show the task's date on the card ("Today", "Tue 17 Nov", "Inbox").</param>
    FrameworkElement? CreateTaskCard(Guid taskId, bool showDate = false);

    /// <summary>API 3. Raised when a task drag ends, dropped or not. Clear drop highlights here.</summary>
    event EventHandler? TaskDragEnded;

    /// <summary>API 2. Adds an item to the menu of every task card (right-click a task).</summary>
    void AddTaskAction(TaskAction action);

    /// <summary>API 2. Opens one of this plugin's pages without changing the selected date.</summary>
    void ShowPage(string pageId);

    /// <summary>Adds a page to the sidebar.</summary>
    void AddPage(PluginPage page);

    /// <summary>Adds a panel to the top of the Day view.</summary>
    void AddDayPanel(DayPanel panel);

    /// <summary>Selects a date and opens the Day view, or one of this plugin's pages when <paramref name="pageId"/> is given.</summary>
    void ShowDate(DateOnly date, string? pageId = null);

    /// <summary>Shows a short message at the bottom of the main window.</summary>
    void ShowToast(string message);

    /// <summary>Shows a Windows notification from the tray icon (for reminders). Does nothing when there's no tray icon.</summary>
    void ShowNotification(string title, string message);

    /// <summary>Asks where to save a file. Returns the chosen path, or null when cancelled.</summary>
    /// <param name="title">The dialog's title.</param>
    /// <param name="fileName">The suggested file name.</param>
    /// <param name="filter">A file dialog filter, such as "Markdown files (*.md)|*.md".</param>
    string? AskSaveFile(string title, string fileName, string filter);

    /// <summary>Writes to DayBoard's log file, tagged with the plugin's id.</summary>
    void Log(string message, Exception? error = null);
}

/// <summary>API 2. An item in the menu of a task card, such as Focus's "Focus on this".</summary>
public abstract class TaskAction
{
    /// <summary>The menu text, such as "Focus on this".</summary>
    public abstract string Title { get; }

    /// <summary>A Fluent System Icons name as used by WPF-UI, such as "Timer24".</summary>
    public virtual string Icon => "PuzzlePiece24";

    /// <summary>Called when the item is clicked, with the task's id.</summary>
    public abstract void Invoke(Guid taskId);
}

/// <summary>How the header's ‹ Today › buttons move the selected date while a plugin page is shown.</summary>
public enum DateNavigation
{
    None,
    Day,
    Week,
    Month,
}

/// <summary>A page in the sidebar. DayBoard shows the header (title, subtitle, date buttons) and the view below it.</summary>
public abstract class PluginPage
{
    /// <summary>Unique within the plugin, such as "journal".</summary>
    public abstract string Id { get; }

    /// <summary>The sidebar label and page title. Keep it to one short word.</summary>
    public abstract string Title { get; }

    /// <summary>API 3. The title in the header, when it should say more than the sidebar label (such as "Eisenhower matrix").</summary>
    public virtual string? Heading => null;

    /// <summary>A Fluent System Icons name as used by WPF-UI, such as "Notebook24".</summary>
    public virtual string Icon => "PuzzlePiece24";

    public virtual DateNavigation Navigation => DateNavigation.None;

    /// <summary>The header subtitle for a date.</summary>
    public virtual string? Subtitle(DateOnly date) => null;

    /// <summary>Creates the page's content. Called once, the first time the page opens.</summary>
    public abstract FrameworkElement CreateView();

    /// <summary>Called when the page opens, when the date changes while it's open, and after tasks or the theme change.</summary>
    public virtual void Show(DateOnly date)
    {
    }

    /// <summary>Called when another page opens. Save anything pending here.</summary>
    public virtual void Hide()
    {
    }
}

/// <summary>A panel at the top of the Day view, such as the daily check-in. It can collapse its own view to hide itself.</summary>
public abstract class DayPanel
{
    /// <summary>Creates the panel. Called once.</summary>
    public abstract FrameworkElement CreateView();

    /// <summary>Called when the Day view shows a date, and after tasks or the theme change.</summary>
    public virtual void Show(DateOnly date)
    {
    }

    /// <summary>Called when the Day view closes or moves to another date. Save anything pending here.</summary>
    public virtual void Hide()
    {
    }
}

/// <summary>
/// API 3. Task drags: DayBoard's task cards (and <see cref="IDayBoardHost.CreateTaskCard"/>) drag a task with this data
/// format. To accept them, set AllowDrop on an element and handle DragOver and Drop.
/// </summary>
public static class TaskDragData
{
    /// <summary>The drag data format: the task's id as text.</summary>
    public const string Format = "DayBoard.TaskId";

    /// <summary>The task being dragged, when the drag is one of DayBoard's task drags.</summary>
    public static bool TryGetTask(DragEventArgs e, out Guid taskId)
    {
        taskId = default;
        return e.Data.GetDataPresent(Format) && Guid.TryParse(e.Data.GetData(Format) as string, out taskId);
    }

    /// <summary>
    /// True while the drag is still over <paramref name="element"/>. DragLeave is also raised when the pointer moves onto
    /// one of the element's children, so check this before clearing a highlight.
    /// </summary>
    public static bool IsOver(FrameworkElement element, DragEventArgs e)
    {
        var p = e.GetPosition(element);
        return p.X >= 0 && p.Y >= 0 && p.X < element.ActualWidth && p.Y < element.ActualHeight;
    }
}
