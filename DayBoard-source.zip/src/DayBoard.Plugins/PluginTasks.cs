namespace DayBoard.Plugins;

/// <summary>
/// A task as plugins see it: a snapshot. Plugins change tasks only through the host (API 2: log time, mark done,
/// tick checklist items; API 3: status and matrix quadrant), so every change can be undone.
/// </summary>
public sealed record PluginTask(
    Guid Id,
    string Title,
    DateOnly? Date,
    TimeOnly? StartTime,
    int? EstimateMinutes,
    bool IsDone,
    string Priority,
    string? Category)
{
    /// <summary>API 2. Time logged on the task, in minutes.</summary>
    public int ActualMinutes { get; init; }

    /// <summary>API 2. The task's checklist.</summary>
    public IReadOnlyList<PluginSubtask> Subtasks { get; init; } = Array.Empty<PluginSubtask>();

    /// <summary>API 3. To do, doing or done.</summary>
    public PluginTaskStatus Status { get; init; }

    /// <summary>API 3. Marked urgent (the matrix's urgent column).</summary>
    public bool IsUrgent { get; init; }

    /// <summary>API 3. Medium or High priority: what the Eisenhower matrix counts as important.</summary>
    public bool IsImportant => Priority is "Medium" or "High";

    /// <summary>API 3. The deadline, when the task has one.</summary>
    public DateOnly? DueDate { get; init; }

    /// <summary>API 3. When it was marked done (local time).</summary>
    public DateTime? CompletedAt { get; init; }

    /// <summary>API 3. How many times it moved on to a later day unfinished.</summary>
    public int RolloverCount { get; init; }
}

/// <summary>API 2. An item of a task's checklist.</summary>
public sealed record PluginSubtask(Guid Id, string Title, bool IsDone);

/// <summary>API 3. A task's workflow state.</summary>
public enum PluginTaskStatus
{
    ToDo = 0,
    Doing = 1,
    Done = 2,
}

/// <summary>API 3. What a history entry records.</summary>
public enum PluginHistoryKind
{
    /// <summary>The task was unfinished on <see cref="PluginTaskHistory.FromDate"/> and moved on to a later day.</summary>
    RolledOver = 0,

    /// <summary>A repeating task's occurrence on <see cref="PluginTaskHistory.FromDate"/> was missed and skipped, because a newer one exists.</summary>
    Skipped = 1,

    /// <summary>The task was left unfinished on <see cref="PluginTaskHistory.FromDate"/> and flagged overdue.</summary>
    Overdue = 2,

    /// <summary>Time was logged on the task (<see cref="PluginTaskHistory.Minutes"/>).</summary>
    Focus = 3,
}

/// <summary>
/// API 3. One entry of DayBoard's task history, which the weekly review and Stats are built from. A skipped occurrence
/// may belong to a task that <see cref="IDayBoardHost.FindTask"/> no longer returns.
/// </summary>
public sealed record PluginTaskHistory(Guid TaskId, PluginHistoryKind Kind, DateTime At, DateOnly? FromDate, DateOnly? ToDate, int? Minutes);

/// <summary>API 3. A completion rate as Stats works it out: tasks done out of tasks planned in a period.</summary>
public sealed record PluginCompletion(int Done, int Planned)
{
    public double Rate => Planned == 0 ? 0 : (double)Done / Planned;
}
