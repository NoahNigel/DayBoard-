using System.Text.Json;

namespace DayBoard.Plugins;

// Kept apart from the WPF parts of the API so plain .NET code (and tests) can use it.

/// <summary>Key/value storage for one plugin. Values are text, usually JSON.</summary>
public interface IPluginStorage
{
    string? Get(string key);

    /// <summary>All entries whose key starts with <paramref name="prefix"/>.</summary>
    IReadOnlyDictionary<string, string> GetAll(string prefix = "");

    /// <summary>Saves a value; null removes the key.</summary>
    void Set(string key, string? value);
}

public static class PluginStorageExtensions
{
    private static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web);

    public static T? GetJson<T>(this IPluginStorage storage, string key)
    {
        var text = storage.Get(key);
        if (text is null) return default;
        try
        {
            return JsonSerializer.Deserialize<T>(text, Json);
        }
        catch (JsonException)
        {
            return default;
        }
    }

    public static void SetJson<T>(this IPluginStorage storage, string key, T? value) =>
        storage.Set(key, value is null ? null : JsonSerializer.Serialize(value, Json));
}
