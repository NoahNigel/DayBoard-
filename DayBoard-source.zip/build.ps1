<#
  Builds, tests and publishes DayBoard.
  Output: .\artifacts\DayBoard.exe, one .dayboard-plugin file per folder in .\plugins and one per code plugin in
          .\plugins-src, and .\artifacts\DayBoard-win-x64.zip with the exe and those plugins in a Plugins folder
  Usage:  powershell -ExecutionPolicy Bypass -File .\build.ps1 [-SkipTests] [-SelfTest]
#>
param([switch]$SkipTests, [switch]$SelfTest)
$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
$env:DOTNET_CLI_TELEMETRY_OPTOUT = '1'
$env:DOTNET_NOLOGO = '1'

Write-Host '== build' -ForegroundColor Cyan
dotnet build DayBoard.sln -c Release
if ($LASTEXITCODE -ne 0) { throw 'Build failed' }

if (-not $SkipTests) {
    Write-Host '== unit tests' -ForegroundColor Cyan
    dotnet run --project tests\DayBoard.Core.Tests -c Release --no-build
    if ($LASTEXITCODE -ne 0) { throw 'Unit tests failed' }
}

Write-Host '== publish (self-contained single file)' -ForegroundColor Cyan
$publish = Join-Path $PSScriptRoot 'artifacts\publish'
if (Test-Path $publish) { Remove-Item $publish -Recurse -Force }
dotnet publish src\DayBoard\DayBoard.csproj -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o $publish
if ($LASTEXITCODE -ne 0) { throw 'Publish failed' }

$exe = Join-Path $publish 'DayBoard.exe'
$artifacts = Join-Path $PSScriptRoot 'artifacts'
Copy-Item $exe (Join-Path $artifacts 'DayBoard.exe') -Force

Write-Host '== plugins' -ForegroundColor Cyan
# A plugin is a zip of its folder's files (plugin.json at the root), renamed to .dayboard-plugin.
Add-Type -AssemblyName System.IO.Compression.FileSystem
$plugins = @()
foreach ($dir in Get-ChildItem (Join-Path $PSScriptRoot 'plugins') -Directory) {
    $file = Join-Path $artifacts "$($dir.Name).dayboard-plugin"
    if (Test-Path $file) { Remove-Item $file -Force }
    [System.IO.Compression.ZipFile]::CreateFromDirectory($dir.FullName, $file)
    $plugins += $file
    Write-Host "Packed $file"
}
# Code plugins pack themselves when built in Release (see the PackPlugin target in their project files).
foreach ($packed in Get-ChildItem (Join-Path $PSScriptRoot 'plugins-src') -Recurse -Filter '*.dayboard-plugin' | Where-Object { $_.FullName -match '\\bin\\Release\\' }) {
    $file = Join-Path $artifacts $packed.Name
    Copy-Item $packed.FullName $file -Force
    $plugins += $file
    Write-Host "Copied $file"
}

Write-Host '== zip' -ForegroundColor Cyan
# DayBoard.exe, and a Plugins folder with the optional plugins (Settings > Plugins > Add plugin opens there).
$stage = Join-Path $artifacts 'zip'
if (Test-Path $stage) { Remove-Item $stage -Recurse -Force }
New-Item -ItemType Directory -Path (Join-Path $stage 'Plugins') | Out-Null
Copy-Item $exe $stage
Copy-Item (Join-Path $PSScriptRoot 'LICENSE') (Join-Path $stage 'LICENSE.txt')
Copy-Item (Join-Path $PSScriptRoot 'THIRD-PARTY-NOTICES.md') $stage
foreach ($plugin in $plugins) { Copy-Item $plugin (Join-Path $stage 'Plugins') }
$zip = Join-Path $artifacts 'DayBoard-win-x64.zip'
if (Test-Path $zip) { Remove-Item $zip -Force }
Compress-Archive -Path (Join-Path $stage '*') -DestinationPath $zip
Remove-Item $stage -Recurse -Force
Write-Host "Published $zip ($([math]::Round((Get-Item $exe).Length / 1MB, 1)) MB exe, $($plugins.Count) plugins)" -ForegroundColor Green

if ($SelfTest) {
    Write-Host '== UI self-test' -ForegroundColor Cyan
    $out = Join-Path $artifacts 'selftest'
    if (Test-Path $out) { Remove-Item $out -Recurse -Force }
    $selfTestArgs = @('--selftest', "`"$out`"")
    # The self-test uses the first theme, and the code plugins it knows (check-in, Kanban, matrix, review).
    foreach ($plugin in $plugins) { $selfTestArgs += @('--plugin', "`"$plugin`"") }
    $p = Start-Process -FilePath $exe -ArgumentList $selfTestArgs -PassThru
    if (-not $p.WaitForExit(300000)) { $p.Kill(); throw 'Self-test timed out' }
    Get-Content (Join-Path $out 'selftest.log')
    if ($p.ExitCode -ne 0) { throw "Self-test failed (exit $($p.ExitCode))" }
}
