# Third-party notices

DayBoard is MIT licensed (see [LICENSE](LICENSE)). `DayBoard.exe` also contains the following open-source components, each under its own licence:

| Component | Version | Licence | Copyright |
|---|---|---|---|
| [.NET runtime and WPF](https://github.com/dotnet/runtime) (in the self-contained build) | 10.0 | MIT | .NET Foundation and Contributors |
| [WPF UI](https://github.com/lepoco/wpfui), including its Fluent System Icons font | 4.3.0 | MIT | Leszek Pomianowski and WPF UI Contributors |
| [CommunityToolkit.Mvvm](https://github.com/CommunityToolkit/dotnet) | 8.4.2 | MIT | .NET Foundation and Contributors |
| [H.NotifyIcon](https://github.com/HavenDV/H.NotifyIcon) | 2.4.1 | MIT | HavenDV and contributors |
| [Microsoft.Data.Sqlite](https://github.com/dotnet/efcore) | 10.0.13 | MIT | Microsoft Corporation |
| [Microsoft Authentication Library (MSAL.NET)](https://github.com/AzureAD/microsoft-authentication-library-for-dotnet) and Microsoft.IdentityModel.Abstractions | 4.91.1, 8.14.0 | MIT | Microsoft Corporation |
| [SQLitePCLRaw](https://github.com/ericsink/SQLitePCL.raw) | 2.1.13 | Apache-2.0 | SourceGear, LLC |
| [SQLite](https://sqlite.org) (inside SQLitePCLRaw) | | Public domain | |

The MIT and Apache-2.0 licence texts are at https://opensource.org/license/mit and https://www.apache.org/licenses/LICENSE-2.0.
