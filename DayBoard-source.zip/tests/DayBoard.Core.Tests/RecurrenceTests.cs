using System.Globalization;
using DayBoard.Core.Recurrence;

namespace DayBoard.Core.Tests;

public class RecurrenceTests
{
    private static DateOnly D(string s) => DateOnly.ParseExact(s, "yyyyMMdd", CultureInfo.InvariantCulture);

    // Expected values generated with python-dateutil's rrule as an independent reference.
    private static void Case(string rule, string start, string from, string to, string expected)
    {
        var r = RecurrenceRule.Parse(rule);
        var actual = r.Occurrences(D(start), D(from), D(to)).Select(d => d.ToString("yyyyMMdd", CultureInfo.InvariantCulture));
        Assert.Sequence(expected.Split(',', StringSplitOptions.RemoveEmptyEntries), actual, $"{rule} from {start}");
    }

    [Test]
    public void MatchesReferenceImplementation()
    {
        Case("FREQ=DAILY", "20261020", "20261020", "20261026", "20261020,20261021,20261022,20261023,20261024,20261025,20261026");
        Case("FREQ=DAILY;INTERVAL=3", "20261001", "20261020", "20261031", "20261022,20261025,20261028,20261031");
        Case("FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR", "20261022", "20261022", "20261102", "20261022,20261023,20261026,20261027,20261028,20261029,20261030,20261102");
        Case("FREQ=WEEKLY;INTERVAL=2;BYDAY=MO,TH", "20261005", "20261005", "20261105", "20261005,20261008,20261019,20261022,20261102,20261105");
        Case("FREQ=WEEKLY;INTERVAL=2;BYDAY=MO,TH", "20261008", "20261101", "20261130", "20261102,20261105,20261116,20261119,20261130");
        Case("FREQ=MONTHLY;BYMONTHDAY=31", "20260101", "20260101", "20261231", "20260131,20260331,20260531,20260731,20260831,20261031,20261231");
        Case("FREQ=MONTHLY;BYMONTHDAY=28,29,30,31;BYSETPOS=-1", "20260131", "20260101", "20260630", "20260131,20260228,20260331,20260430,20260531,20260630");
        Case("FREQ=MONTHLY;BYMONTHDAY=28,29,30;BYSETPOS=-1", "20240130", "20240101", "20240531", "20240130,20240229,20240330,20240430,20240530");
        Case("FREQ=MONTHLY;BYDAY=-1FR", "20260101", "20260101", "20260630", "20260130,20260227,20260327,20260424,20260529,20260626");
        Case("FREQ=MONTHLY;BYDAY=2TU", "20261001", "20261001", "20270228", "20261013,20261110,20261208,20270112,20270209");
        Case("FREQ=MONTHLY;BYDAY=MO,TU,WE,TH,FR;BYSETPOS=-1", "20260101", "20260101", "20260430", "20260130,20260227,20260331,20260430");
        Case("FREQ=YEARLY;BYMONTH=11;BYDAY=4TH", "20201126", "20251001", "20281231", "20251127,20261126,20271125,20281123");
        Case("FREQ=YEARLY", "20200229", "20200101", "20281231", "20200229,20240229,20280229");
        Case("FREQ=WEEKLY;COUNT=5;BYDAY=SA", "20261003", "20261001", "20261231", "20261003,20261010,20261017,20261024,20261031");
        Case("FREQ=DAILY;UNTIL=20261025", "20261020", "20261001", "20261031", "20261020,20261021,20261022,20261023,20261024,20261025");
        Case("FREQ=WEEKLY;WKST=SU;INTERVAL=2;BYDAY=SU,TU", "20261004", "20261004", "20261031", "20261004,20261006,20261018,20261020");
        Case("FREQ=MONTHLY;INTERVAL=2;BYMONTHDAY=15", "20260115", "20260801", "20261231", "20260915,20261115");
        Case("FREQ=DAILY;COUNT=10", "20261001", "20261008", "20261031", "20261008,20261009,20261010");
    }

    [Test]
    public void ParseAndFormatRoundTrip()
    {
        var r = RecurrenceRule.Parse("RRULE:freq=weekly;interval=2;byday=MO,-1FR;until=20261231;wkst=SU");
        Assert.Equal(Frequency.Weekly, r.Frequency);
        Assert.Equal(2, r.Interval);
        Assert.Equal(-1, r.ByDay[1].Ordinal);
        Assert.Equal("FREQ=WEEKLY;INTERVAL=2;UNTIL=20261231;BYDAY=MO,-1FR;WKST=SU", r.ToString());
        Assert.False(RecurrenceRule.TryParse("INTERVAL=2", out _));
        Assert.False(RecurrenceRule.TryParse("FREQ=FORTNIGHTLY", out _));
    }

    [Test]
    public void SkipAheadGivesSameResultAsFullEnumeration()
    {
        var r = RecurrenceRule.Parse("FREQ=WEEKLY;INTERVAL=3;BYDAY=TU,SA");
        var start = new DateOnly(2019, 3, 5);
        var all = r.Occurrences(start, start, new DateOnly(2026, 12, 31)).Where(d => d >= new DateOnly(2026, 10, 1)).ToList();
        var jumped = r.Occurrences(start, new DateOnly(2026, 10, 1), new DateOnly(2026, 12, 31)).ToList();
        Assert.Sequence(all, jumped);
        Assert.True(jumped.Count > 0);
    }

    [Test]
    public void PresetsProduceExpectedRules()
    {
        var start = new DateOnly(2026, 10, 22); // Thursday
        Assert.Equal("FREQ=DAILY", new RepeatPattern { Kind = RepeatKind.Daily }.ToRRule());
        Assert.Equal("FREQ=DAILY;INTERVAL=2", new RepeatPattern { Kind = RepeatKind.Daily, Interval = 2 }.ToRRule());
        Assert.Equal("FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR", new RepeatPattern { Kind = RepeatKind.Weekdays }.ToRRule());
        Assert.Equal("FREQ=WEEKLY;INTERVAL=2;BYDAY=MO,FR",
            new RepeatPattern { Kind = RepeatKind.Weekly, Interval = 2, Days = { DayOfWeek.Friday, DayOfWeek.Monday } }.ToRRule());
        Assert.Equal("FREQ=MONTHLY;BYMONTHDAY=15", new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 15 }.ToRRule());
        Assert.Equal("FREQ=MONTHLY;BYMONTHDAY=28,29,30,31;BYSETPOS=-1", new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 31 }.ToRRule());
        Assert.Equal("FREQ=MONTHLY;BYDAY=-1FR", new RepeatPattern { Kind = RepeatKind.MonthlyWeekday, WeekOrdinal = -1, Weekday = DayOfWeek.Friday }.ToRRule());
        Assert.Equal("FREQ=MONTHLY;BYDAY=1MO;UNTIL=20270101",
            new RepeatPattern { Kind = RepeatKind.MonthlyWeekday, WeekOrdinal = 1, Weekday = DayOfWeek.Monday, Until = new DateOnly(2027, 1, 1) }.ToRRule());

        var def = RepeatPattern.DefaultFor(RepeatKind.MonthlyWeekday, start);
        Assert.Equal(4, def.WeekOrdinal);
        Assert.Equal(DayOfWeek.Thursday, def.Weekday);
        var last = RepeatPattern.DefaultFor(RepeatKind.MonthlyWeekday, new DateOnly(2026, 10, 30));
        Assert.Equal(-1, last.WeekOrdinal);
    }

    [Test]
    public void PresetsRoundTripThroughRRule()
    {
        var start = new DateOnly(2026, 10, 22);
        var patterns = new[]
        {
            new RepeatPattern { Kind = RepeatKind.Daily, Interval = 3 },
            new RepeatPattern { Kind = RepeatKind.Weekdays },
            new RepeatPattern { Kind = RepeatKind.Weekly, Interval = 2, Days = { DayOfWeek.Monday, DayOfWeek.Wednesday } },
            new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 30 },
            new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 5, Until = new DateOnly(2027, 6, 1) },
            new RepeatPattern { Kind = RepeatKind.MonthlyWeekday, WeekOrdinal = 2, Weekday = DayOfWeek.Tuesday },
        };
        foreach (var p in patterns)
        {
            var back = RepeatPattern.FromRRule(p.ToRRule(), start);
            Assert.Equal(p.Kind, back.Kind);
            Assert.Equal(p.ToRRule(), back.ToRRule());
        }
        Assert.Equal(RepeatKind.Custom, RepeatPattern.FromRRule("FREQ=YEARLY;BYMONTH=3", start).Kind);
        Assert.Equal(RepeatKind.None, RepeatPattern.FromRRule(null, start).Kind);
    }

    [Test]
    public void DescribeIsReadable()
    {
        var en = CultureInfo.GetCultureInfo("en-US");
        Assert.Equal("Every 2 weeks on Mon, Fri",
            new RepeatPattern { Kind = RepeatKind.Weekly, Interval = 2, Days = { DayOfWeek.Friday, DayOfWeek.Monday } }.Describe(en));
        Assert.Equal("Monthly on the last Friday", new RepeatPattern { Kind = RepeatKind.MonthlyWeekday, WeekOrdinal = -1, Weekday = DayOfWeek.Friday }.Describe(en));
        Assert.Equal("Monthly on day 31 (or the last day)", new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 31 }.Describe(en));
    }
}
