using DayBoard.Core.Models;
using DayBoard.Core.Planning;
using DayBoard.Core.Recurrence;
using DayBoard.Core.Store;
using DayBoard.Core.Time;

namespace DayBoard.Core.Tests;

internal sealed class Fixture
{
    public Fixture(DateTime? now = null, PlannerData? data = null)
    {
        Clock = new ManualClock(now ?? new DateTime(2026, 10, 22, 9, 0, 0)); // Thursday
        Repo = new InMemoryRepository(data);
        Planner = new Planner(Repo, Clock, () => Settings);
    }

    public ManualClock Clock { get; }
    public InMemoryRepository Repo { get; }
    public AppSettings Settings { get; } = new();
    public Planner Planner { get; }
    public TaskStore Store => Planner.Store;
    public DateOnly Today => Planner.Today;

    public TaskItem Add(string title, DateOnly? date, TimeOnly? time = null, int? estimate = null) =>
        Planner.AddTask(new TaskItem { Title = title, ScheduledDate = date, StartTime = time, EstimateMinutes = estimate });

    public List<string> TitlesOn(DateOnly d) => Planner.TasksOn(d).Select(t => t.Title).ToList();

    /// <summary>Reloads everything from the repository, as the app does on restart.</summary>
    public Planner Reload() => new(Repo, Clock, () => Settings);
}

public class PlannerTests
{
    [Test]
    public void AddUndoRedo()
    {
        var f = new Fixture();
        var t = f.Add("Write report", f.Today, estimate: 60);
        Assert.Equal(1, f.Store.Tasks.Count);
        Assert.True(f.Planner.Undo.CanUndo);
        f.Planner.Undo.Undo();
        Assert.Equal(0, f.Store.Tasks.Count);
        f.Planner.Undo.Redo();
        Assert.Equal("Write report", f.Store.FindTask(t.Id)!.Title);
        Assert.Equal(1, f.Reload().Store.Tasks.Count); // persisted
    }

    [Test]
    public void DeleteIsUndoableIncludingSubtasks()
    {
        var f = new Fixture();
        var t = f.Planner.AddTask(new TaskItem
        {
            Title = "Trip",
            ScheduledDate = f.Today,
            Subtasks = { new Subtask { Title = "Book train", IsDone = true }, new Subtask { Title = "Pack" } },
        });
        f.Planner.DeleteTask(t.Id);
        Assert.Equal(0, f.Store.Tasks.Count);
        f.Planner.Undo.Undo();
        var back = Assert.NotNull(f.Store.FindTask(t.Id));
        Assert.Equal(2, back.Subtasks.Count);
        Assert.Equal(1, back.SubtasksDone);
    }

    [Test]
    public void DragBetweenDaysAndReorder()
    {
        var f = new Fixture();
        var tomorrow = f.Today.AddDays(1);
        var a = f.Add("A", f.Today);
        var b = f.Add("B", f.Today);
        var c = f.Add("C", tomorrow);
        f.Add("Timed", tomorrow, new TimeOnly(9, 0));

        // Drop A between C (index 0) and the end of tomorrow's untimed list => after C.
        f.Planner.MoveTo(a.Id, tomorrow, 1);
        Assert.Sequence(new[] { "Timed", "C", "A" }, f.TitlesOn(tomorrow));
        // Drop B at the top of tomorrow's untimed list.
        f.Planner.MoveTo(b.Id, tomorrow, 0);
        Assert.Sequence(new[] { "Timed", "B", "C", "A" }, f.TitlesOn(tomorrow));
        Assert.Equal(0, f.Planner.TasksOn(f.Today).Count);

        f.Planner.Undo.Undo();
        f.Planner.Undo.Undo();
        Assert.Sequence(new[] { "A", "B" }, f.TitlesOn(f.Today));
        Assert.Sequence(new[] { "Timed", "C" }, f.TitlesOn(tomorrow));

        // Dropping a task where it already is records nothing.
        int before = f.Planner.Undo.UndoCount;
        f.Planner.MoveTo(c.Id, tomorrow, 0);
        Assert.Equal(before, f.Planner.Undo.UndoCount);
    }

    [Test]
    public void ReorderRenumbersWhenGapIsExhausted()
    {
        var f = new Fixture();
        var a = f.Add("A", f.Today);
        var b = f.Add("B", f.Today);
        var x = f.Add("X", f.Today.AddDays(1));
        var squeezed = f.Store.FindTask(b.Id)!.Clone();
        squeezed.SortOrder = f.Store.FindTask(a.Id)!.SortOrder + 1e-9;
        f.Planner.Execute(new ChangeSet("squeeze").Task(f.Store.FindTask(b.Id), squeezed));

        f.Planner.MoveTo(x.Id, f.Today, 1);
        Assert.Sequence(new[] { "A", "X", "B" }, f.TitlesOn(f.Today));
        f.Planner.Undo.Undo(); // one step undoes the move and the renumbering
        Assert.Sequence(new[] { "A", "B" }, f.TitlesOn(f.Today));
        Assert.Equal(squeezed.SortOrder, f.Store.FindTask(b.Id)!.SortOrder);
    }

    [Test]
    public void TimelineScheduleAndUnschedule()
    {
        var f = new Fixture();
        var t = f.Add("Deep work", null);
        Assert.Equal(1, f.Planner.Inbox().Count);
        f.Planner.ScheduleAt(t.Id, f.Today, new TimeOnly(10, 30));
        var s = f.Store.FindTask(t.Id)!;
        Assert.Equal(f.Today, s.ScheduledDate);
        Assert.Equal(new TimeOnly(10, 30), s.StartTime);
        f.Planner.ClearTime(t.Id, f.Today);
        Assert.Equal(null, f.Store.FindTask(t.Id)!.StartTime);
        f.Planner.MoveTo(t.Id, null);
        Assert.Equal(1, f.Planner.Inbox().Count);
        f.Planner.Undo.Undo();
        f.Planner.Undo.Undo();
        f.Planner.Undo.Undo();
        Assert.Equal(1, f.Planner.Inbox().Count);
    }

    [Test]
    public void DoneSetsCompletedAtAndUndoClearsIt()
    {
        var f = new Fixture();
        var t = f.Add("Call", f.Today);
        f.Planner.SetDone(t.Id, true);
        Assert.Equal(f.Clock.Now, f.Store.FindTask(t.Id)!.CompletedAt);
        f.Planner.Undo.Undo();
        Assert.Equal(null, f.Store.FindTask(t.Id)!.CompletedAt);
        f.Planner.SetStatus(t.Id, TaskState.Doing);
        Assert.Equal(TaskState.Doing, f.Store.FindTask(t.Id)!.Status);
        f.Planner.SetStatus(t.Id, TaskState.Done);
        Assert.True(f.Store.FindTask(t.Id)!.CompletedAt.HasValue);
    }

    [Test]
    public void EisenhowerDropAdjustsUrgencyAndImportance()
    {
        var f = new Fixture();
        var t = f.Planner.AddTask(new TaskItem { Title = "x", Priority = Priority.Low });
        f.Planner.SetQuadrant(t.Id, urgent: true, important: true);
        Assert.Equal(Priority.Medium, f.Store.FindTask(t.Id)!.Priority);
        Assert.True(f.Store.FindTask(t.Id)!.IsUrgent);
        f.Planner.SetPriority(t.Id, Priority.High);
        f.Planner.SetQuadrant(t.Id, urgent: false, important: true);
        Assert.Equal(Priority.High, f.Store.FindTask(t.Id)!.Priority);
        f.Planner.SetQuadrant(t.Id, urgent: false, important: false);
        Assert.Equal(Priority.Low, f.Store.FindTask(t.Id)!.Priority);
    }

    [Test]
    public void CapacityLevels()
    {
        var f = new Fixture();
        f.Settings.CapacityHours = 2;
        f.Add("a", f.Today, estimate: 60);
        Assert.Equal(CapacityLevel.Ok, f.Planner.CapacityFor(f.Today).Level);
        f.Add("b", f.Today, estimate: 45);
        Assert.Equal(CapacityLevel.Near, f.Planner.CapacityFor(f.Today).Level); // 105/120 = 87.5%
        f.Add("c", f.Today, estimate: 30);
        var cap = f.Planner.CapacityFor(f.Today);
        Assert.Equal(CapacityLevel.Over, cap.Level);
        Assert.Equal(135, cap.PlannedMinutes);
        f.Add("unestimated", f.Today);
        Assert.Equal(1, f.Planner.CapacityFor(f.Today).UnestimatedCount);
    }

    [Test]
    public void CategoryDeleteClearsReferencesAndUndoRestores()
    {
        var f = new Fixture();
        var cat = new Category { Name = "Work" };
        f.Planner.SaveCategory(cat);
        var t = f.Planner.AddTask(new TaskItem { Title = "x", CategoryId = cat.Id });
        f.Planner.DeleteCategory(cat.Id);
        Assert.Equal(null, f.Store.FindTask(t.Id)!.CategoryId);
        f.Planner.Undo.Undo();
        Assert.Equal(cat.Id, f.Store.FindTask(t.Id)!.CategoryId);
        Assert.Equal("Work", f.Store.FindCategory(cat.Id)!.Name);
    }

    [Test]
    public void FocusTimeIsLoggedAndUndoable()
    {
        var f = new Fixture();
        var t = f.Add("Focus", f.Today, estimate: 50);
        f.Planner.LogFocusTime(t.Id, 25);
        f.Planner.LogFocusTime(t.Id, 25);
        Assert.Equal(50, f.Store.FindTask(t.Id)!.ActualMinutes);
        Assert.Equal(2, f.Store.Events.Count(e => e.Kind == TaskEventKind.Focus));
        f.Planner.Undo.Undo();
        Assert.Equal(25, f.Store.FindTask(t.Id)!.ActualMinutes);
    }

    [Test]
    public void ImportMergesCategoriesByName()
    {
        var f = new Fixture();
        var work = new Category { Name = "Work" };
        f.Planner.SaveCategory(work);
        var importedCat = new Category { Name = "work", Color = "#000000" };
        var data = new PlannerData
        {
            Categories = { importedCat },
            Tasks = { new TaskItem { Title = "Imported", CategoryId = importedCat.Id, ScheduledDate = f.Today } },
        };
        int n = f.Planner.Import(data);
        Assert.Equal(1, n);
        Assert.Equal(1, f.Store.Categories.Count);
        Assert.Equal(work.Id, f.Store.Tasks.Single().CategoryId);
        f.Planner.Undo.Undo();
        Assert.Equal(0, f.Store.Tasks.Count);
        Assert.Equal("#5B6CF0", f.Store.FindCategory(work.Id)!.Color);
    }
}
