using DayBoard.Core.Models;
using DayBoard.Core.Recurrence;

namespace DayBoard.Core.Tests;

public class RolloverTests
{
    [Test]
    public void UnfinishedPastTasksMoveToToday()
    {
        var f = new Fixture(new DateTime(2026, 10, 21, 18, 0, 0));
        var t = f.Add("Email Bob", f.Today, new TimeOnly(10, 0), 15);
        var done = f.Add("Done already", f.Today);
        f.Planner.SetDone(done.Id, true);

        f.Clock.Now = new DateTime(2026, 10, 22, 8, 0, 0);
        var r = f.Planner.RunDailyMaintenance();
        Assert.Equal(1, r.Moved);
        var moved = f.Store.FindTask(t.Id)!;
        Assert.Equal(f.Today, moved.ScheduledDate);
        Assert.Equal(null, moved.StartTime);
        Assert.Equal(1, moved.RolloverCount);
        Assert.Equal(new DateOnly(2026, 10, 21), f.Store.FindTask(done.Id)!.ScheduledDate);
        var ev = f.Store.Events.Single(e => e.Kind == TaskEventKind.Rolled);
        Assert.Equal(new DateOnly(2026, 10, 21), ev.FromDate);

        // Idempotent within the day.
        Assert.Equal(0, f.Planner.RunDailyMaintenance().Total);

        // Rolled tasks go to the top of today's list.
        f.Clock.Now = new DateTime(2026, 10, 22, 9, 0, 0);
        var other = f.Add("Other", f.Today.AddDays(-1));
        f.Add("Today task", f.Today);
        f.Planner.RunDailyMaintenance();
        Assert.Equal("Other", f.Planner.TasksOn(f.Today)[0].Title);
        Assert.Equal(1, f.Store.FindTask(other.Id)!.RolloverCount);
    }

    [Test]
    public void MissedDailyOccurrencesAreSkippedNotStacked()
    {
        var f = new Fixture(new DateTime(2026, 10, 20, 7, 0, 0));
        f.Planner.AddTask(new TaskItem { Title = "Stretch", ScheduledDate = f.Today }, new RepeatPattern { Kind = RepeatKind.Daily });
        f.Clock.Now = new DateTime(2026, 10, 22, 7, 0, 0);
        var r = f.Planner.RunDailyMaintenance();
        Assert.Equal(2, r.Skipped);
        Assert.Equal(0, r.Moved);
        Assert.Equal(1, f.Planner.TasksOn(f.Today).Count(t => t.Title == "Stretch"));
        Assert.Equal(2, f.Store.Tasks.Count(t => t.IsSkipped));
    }

    [Test]
    public void MissedWeeklyOccurrenceMovesWhenNothingIsDueToday()
    {
        var f = new Fixture(new DateTime(2026, 10, 19, 7, 0, 0)); // Monday
        f.Planner.AddTask(new TaskItem { Title = "Plan week", ScheduledDate = f.Today }, new RepeatPattern { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Monday } });
        f.Clock.Now = new DateTime(2026, 10, 22, 7, 0, 0); // Thursday
        var r = f.Planner.RunDailyMaintenance();
        Assert.Equal(1, r.Moved);
        var today = f.Planner.TasksOn(f.Today).Single();
        Assert.Equal("Plan week", today.Title);
        Assert.Equal(1, today.RolloverCount);
        Assert.Equal(new DateOnly(2026, 10, 19), today.OccurrenceDate);
        Assert.Equal(1, f.Planner.TasksOn(new DateOnly(2026, 10, 26)).Count);
    }

    [Test]
    public void FlagModeLeavesTasksAndFlagsOnce()
    {
        var f = new Fixture(new DateTime(2026, 10, 21, 18, 0, 0));
        f.Settings.RolloverMode = RolloverMode.FlagOverdue;
        var t = f.Add("Taxes", f.Today);
        f.Clock.Now = new DateTime(2026, 10, 22, 8, 0, 0);
        Assert.Equal(1, f.Planner.RunDailyMaintenance().Flagged);
        Assert.Equal(0, f.Planner.RunDailyMaintenance().Flagged);
        Assert.Equal(new DateOnly(2026, 10, 21), f.Store.FindTask(t.Id)!.ScheduledDate);
        Assert.Equal(0, f.Store.FindTask(t.Id)!.RolloverCount);
        Assert.True(f.Store.FindTask(t.Id)!.IsOverdue(f.Today));
        Assert.Equal(1, f.Planner.OverdueBefore(f.Today).Count);
    }
}
