using DayBoard.Core.Models;
using DayBoard.Core.Planning;
using DayBoard.Core.Recurrence;

namespace DayBoard.Core.Tests;

public class SeriesTests
{
    private static readonly RepeatPattern MonThu = new() { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Monday, DayOfWeek.Thursday } };

    private static List<DateOnly> Dates(Fixture f, string title) =>
        f.Store.Tasks.Where(t => t.Title == title && !t.IsSkipped).Select(t => t.ScheduledDate!.Value).OrderBy(d => d).ToList();

    private static DateOnly D(int month, int day) => new(2026, month, day);

    [Test]
    public void CreatingASeriesGeneratesOccurrencesAndUndoRemovesThemAll()
    {
        var f = new Fixture(); // Thu 22 Oct 2026, horizon 28 days => through 19 Nov
        var t = f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today, EstimateMinutes = 60 }, MonThu);
        Assert.Sequence(new[] { D(10, 22), D(10, 26), D(10, 29), D(11, 2), D(11, 5), D(11, 9), D(11, 12), D(11, 16), D(11, 19) }, Dates(f, "Gym"));
        Assert.True(t.SeriesId.HasValue);
        Assert.Equal(1, f.Store.Series.Count);

        f.Planner.EnsureOccurrencesThrough(D(12, 31));
        Assert.Equal(21, Dates(f, "Gym").Count);

        f.Planner.Undo.Undo();
        Assert.Equal(0, f.Store.Tasks.Count);
        Assert.Equal(0, f.Store.Series.Count);

        f.Planner.Undo.Redo();
        Assert.Equal(9, Dates(f, "Gym").Count);
    }

    [Test]
    public void FirstOccurrenceIsFirstMatchingDay()
    {
        var f = new Fixture();
        var weeklyMon = new RepeatPattern { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Monday } };
        var t = f.Planner.AddTask(new TaskItem { Title = "Plan week" }, weeklyMon); // from the inbox
        Assert.Equal(D(10, 26), f.Store.FindTask(t.Id)!.ScheduledDate);
    }

    [Test]
    public void DeleteThisOccurrenceStaysDeleted()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var mon = f.Store.Tasks.Single(t => t.ScheduledDate == D(10, 26));
        f.Planner.DeleteTask(mon.Id, EditScope.ThisOccurrence);
        Assert.False(Dates(f, "Gym").Contains(D(10, 26)));
        f.Planner.EnsureOccurrencesThrough(D(12, 1));
        f.Planner.RunDailyMaintenance();
        Assert.False(Dates(f, "Gym").Contains(D(10, 26)));
        f.Planner.Undo.Undo();
        Assert.True(Dates(f, "Gym").Contains(D(10, 26)));
    }

    [Test]
    public void EditWholeSeriesUpdatesFutureAndChangesRule()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var thu29 = f.Store.Tasks.Single(t => t.ScheduledDate == D(10, 29)).Clone();
        thu29.Title = "Run";
        var fridays = new RepeatPattern { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Friday } };
        f.Planner.UpdateTask(thu29, fridays, EditScope.WholeSeries);

        Assert.Sequence(new[] { D(10, 22), D(10, 26) }, Dates(f, "Gym"));
        Assert.Sequence(new[] { D(10, 30), D(11, 6), D(11, 13) }, Dates(f, "Run")); // the edited Thursday moves to Friday
        Assert.Equal("FREQ=WEEKLY;BYDAY=FR", f.Store.Series.Single().RRule);

        f.Planner.Undo.Undo();
        Assert.Equal(9, Dates(f, "Gym").Count);
        Assert.Equal(0, Dates(f, "Run").Count);
    }

    [Test]
    public void ThisOccurrenceEditIsKeptBySeriesEdits()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var mon = f.Store.Tasks.Single(t => t.ScheduledDate == D(10, 26)).Clone();
        mon.Title = "Gym (with Sam)";
        f.Planner.UpdateTask(mon, f.Planner.RepeatOf(mon), EditScope.ThisOccurrence);
        Assert.True(f.Store.FindTask(mon.Id)!.IsSeriesException);

        var thu = f.Store.Tasks.Single(t => t.ScheduledDate == D(10, 22)).Clone();
        thu.Title = "Gym session";
        thu.Priority = Priority.High;
        f.Planner.UpdateTask(thu, f.Planner.RepeatOf(thu), EditScope.WholeSeries);
        Assert.Equal("Gym (with Sam)", f.Store.FindTask(mon.Id)!.Title);
        Assert.Equal(8, f.Store.Tasks.Count(t => t.Title == "Gym session" && t.Priority == Priority.High));
        Assert.Equal("Gym session", f.Store.Series.Single().Title);
    }

    [Test]
    public void DeleteWholeSeriesFromAnOccurrence()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var nov2 = f.Store.Tasks.Single(t => t.ScheduledDate == D(11, 2));
        f.Planner.DeleteTask(nov2.Id, EditScope.WholeSeries);
        Assert.Sequence(new[] { D(10, 22), D(10, 26), D(10, 29) }, Dates(f, "Gym"));
        Assert.Equal(D(11, 1), f.Store.Series.Single().EndDate);
        f.Planner.EnsureOccurrencesThrough(D(12, 31));
        Assert.Equal(3, Dates(f, "Gym").Count);
        f.Planner.Undo.Undo();
        Assert.Equal(9, Dates(f, "Gym").Count);
    }

    [Test]
    public void StopRepeatingEndsSeriesAfterThisOccurrence()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var oct29 = f.Store.Tasks.Single(t => t.ScheduledDate == D(10, 29)).Clone();
        f.Planner.UpdateTask(oct29, RepeatPattern.None, EditScope.WholeSeries);
        Assert.Sequence(new[] { D(10, 22), D(10, 26), D(10, 29) }, Dates(f, "Gym"));
    }

    [Test]
    public void ConvertingATaskToRecurring()
    {
        var f = new Fixture();
        var t = f.Add("Water plants", f.Today);
        var edited = f.Store.FindTask(t.Id)!.Clone();
        f.Planner.UpdateTask(edited, new RepeatPattern { Kind = RepeatKind.Daily, Interval = 7 });
        Assert.Sequence(new[] { D(10, 22), D(10, 29), D(11, 5), D(11, 12), D(11, 19) }, Dates(f, "Water plants"));
        Assert.Equal(RepeatKind.Daily, f.Planner.RepeatOf(f.Store.FindTask(t.Id)!).Kind);
        f.Planner.Undo.Undo();
        Assert.Equal(1, f.Store.Tasks.Count);
        Assert.Equal(null, f.Store.FindTask(t.Id)!.SeriesId);
    }

    [Test]
    public void MonthlyLastWeekdayAndClampedDay()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Invoice", ScheduledDate = f.Today }, new RepeatPattern { Kind = RepeatKind.MonthlyDay, DayOfMonth = 31 });
        f.Planner.EnsureOccurrencesThrough(new DateOnly(2027, 3, 31));
        Assert.Sequence(new[] { D(10, 31), D(11, 30), D(12, 31), new DateOnly(2027, 1, 31), new DateOnly(2027, 2, 28), new DateOnly(2027, 3, 31) }, Dates(f, "Invoice"));

        f.Planner.AddTask(new TaskItem { Title = "Review", ScheduledDate = f.Today }, new RepeatPattern { Kind = RepeatKind.MonthlyWeekday, WeekOrdinal = -1, Weekday = DayOfWeek.Friday });
        f.Planner.EnsureOccurrencesThrough(new DateOnly(2027, 1, 31));
        Assert.Sequence(new[] { D(10, 30), D(11, 27), D(12, 25), new DateOnly(2027, 1, 29) }, Dates(f, "Review"));
    }

    [Test]
    public void SeriesSurvivesReload()
    {
        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Gym", ScheduledDate = f.Today }, MonThu);
        var p2 = f.Reload();
        p2.RunDailyMaintenance();
        Assert.Equal(9, p2.Store.Tasks.Count(t => t.Title == "Gym"));
        Assert.Equal(RepeatKind.Weekly, p2.RepeatOf(p2.Store.Tasks.First()).Kind);
    }
}
