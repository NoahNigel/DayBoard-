using System.Runtime.CompilerServices;

namespace DayBoard.Core.Tests;

// Assertions shared by the console runner (DayBoard.Core.Tests) and the xUnit project (DayBoard.Tests.xUnit).

public sealed class AssertionException(string message) : Exception(message);

public static class Assert
{
    public static void True(bool condition, string? message = null, [CallerArgumentExpression(nameof(condition))] string? expr = null)
    {
        if (!condition) throw new AssertionException(message ?? $"Expected true: {expr}");
    }

    public static void False(bool condition, string? message = null, [CallerArgumentExpression(nameof(condition))] string? expr = null)
    {
        if (condition) throw new AssertionException(message ?? $"Expected false: {expr}");
    }

    public static void Equal<T>(T expected, T actual, [CallerArgumentExpression(nameof(actual))] string? expr = null)
    {
        if (!EqualityComparer<T>.Default.Equals(expected, actual))
            throw new AssertionException($"{expr}: expected <{expected}> but was <{actual}>");
    }

    public static void Sequence<T>(IEnumerable<T> expected, IEnumerable<T> actual, [CallerArgumentExpression(nameof(actual))] string? expr = null)
    {
        var e = expected.ToList();
        var a = actual.ToList();
        if (!e.SequenceEqual(a))
            throw new AssertionException($"{expr}:\n  expected [{string.Join(", ", e)}]\n  but was  [{string.Join(", ", a)}]");
    }

    public static T NotNull<T>(T? value, [CallerArgumentExpression(nameof(value))] string? expr = null) where T : class =>
        value ?? throw new AssertionException($"Expected non-null: {expr}");

    public static void Throws<TException>(Action action) where TException : Exception
    {
        try
        {
            action();
        }
        catch (TException)
        {
            return;
        }
        catch (Exception ex)
        {
            throw new AssertionException($"Expected {typeof(TException).Name} but got {ex.GetType().Name}: {ex.Message}");
        }
        throw new AssertionException($"Expected {typeof(TException).Name} but nothing was thrown");
    }
}
