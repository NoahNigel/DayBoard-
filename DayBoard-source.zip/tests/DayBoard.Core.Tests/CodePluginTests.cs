using System.Globalization;
using System.IO.Compression;
using System.Text;
using DailyCheckIn.Model;
using DayBoard.Focus.Model;
using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;
using DayBoard.Plugins;
using Microsoft.Data.Sqlite;

namespace DayBoard.Core.Tests;

/// <summary>Code plugins: the package format, their storage, and the Daily check-in plugin (DayBoard 1.3).</summary>
public class CodePluginTests
{
    private static readonly Version App = new(1, 4, 0);
    private static readonly DateTime Now = new(2026, 10, 27, 21, 0, 0);
    private static readonly DateOnly Today = new(2026, 10, 27);
    private const string CheckInId = PluginDataStore.CheckInPluginId;

    private static string TempDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), "dayboard-code-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir is not null && !File.Exists(Path.Combine(dir.FullName, "DayBoard.sln"))) dir = dir.Parent;
        return dir?.FullName ?? throw new AssertionException("Repository root not found.");
    }

    /// <summary>The Daily check-in plugin's built dll (the solution builds it before the tests).</summary>
    private static string BuiltCheckInDll()
    {
        var bin = Path.Combine(RepoRoot(), "plugins-src", "DailyCheckIn", "bin");
        var dll = Directory.Exists(bin)
            ? Directory.GetFiles(bin, "DailyCheckIn.dll", SearchOption.AllDirectories).OrderByDescending(File.GetLastWriteTimeUtc).FirstOrDefault()
            : null;
        return dll ?? throw new AssertionException("Build plugins-src/DailyCheckIn first (it's part of DayBoard.sln).");
    }

    private static string Package(string dir, Dictionary<string, byte[]> files)
    {
        var path = Path.Combine(dir, Guid.NewGuid().ToString("N") + ".dayboard-plugin");
        using var zip = ZipFile.Open(path, ZipArchiveMode.Create);
        foreach (var (name, bytes) in files)
        {
            using var s = zip.CreateEntry(name).Open();
            s.Write(bytes);
        }
        return path;
    }

    private static byte[] Utf8(string s) => new UTF8Encoding(false).GetBytes(s);

    private static string CheckInManifest() => File.ReadAllText(Path.Combine(RepoRoot(), "plugins-src", "DailyCheckIn", "plugin.json"));

    private static string Manifest(string kind = "code", string entry = "Thing.dll", string? apiVersion = "1") => $$"""
        { "format": "dayboard-plugin", "formatVersion": 1, "id": "test.code.thing", "name": "Thing", "version": "1.0.0",
          "kind": "{{kind}}", {{(apiVersion is null ? "" : $"\"apiVersion\": {apiVersion},")}} "entry": "{{entry}}" }
        """;

    private static string Reject(string manifest)
    {
        try
        {
            PluginFormat.ParseManifest(manifest, App);
        }
        catch (PluginException ex)
        {
            return ex.Message;
        }
        throw new AssertionException("Expected rejection of " + manifest);
    }

    // ------------------------------------------------------------------ format

    [Test]
    public void CodePluginManifestsAreChecked()
    {
        var m = PluginFormat.ParseManifest(Manifest(), App);
        Assert.Equal(PluginKind.Code, m.Kind);
        Assert.Equal(1, m.ApiVersion);
        Assert.Equal("Code plugin", m.KindLabel);
        Assert.True(Reject(Manifest(apiVersion: null)).Contains("needs an apiVersion"));
        Assert.Equal(2, PluginFormat.ParseManifest(Manifest(apiVersion: "2"), App).ApiVersion); // DayBoard 1.4's API
        Assert.Equal(3, PluginFormat.ParseManifest(Manifest(apiVersion: "3"), App).ApiVersion); // DayBoard 1.6's API
        Assert.True(Reject(Manifest(apiVersion: "4")).Contains("needs a newer version of DayBoard"));
        Assert.True(Reject(Manifest(entry: "thing.json")).Contains("must be its .dll"));
        Assert.True(Reject(Manifest(entry: "../Thing.dll")).Contains("must name a file"));
    }

    [Test]
    public void DayBoard12FeaturePluginsAskForTheirNewVersion()
    {
        var old = """
            { "format": "dayboard-plugin", "formatVersion": 1, "id": "dayboard.feature.daily-checkin", "name": "Daily check-in",
              "version": "1.0.0", "kind": "feature", "minAppVersion": "1.2.0", "entry": "feature.json" }
            """;
        try
        {
            PluginFormat.ParseManifest(old, App);
            throw new AssertionException("A feature plugin was accepted.");
        }
        catch (PluginException ex)
        {
            Assert.True(ex.Outdated);
            Assert.True(ex.Message.Contains("new version"), ex.Message);
        }

        // Installed under DayBoard 1.2, it's listed by name, as outdated, and adding the new version replaces it.
        var dir = TempDir();
        var root = Path.Combine(dir, "plugins");
        var folder = Path.Combine(root, CheckInId);
        Directory.CreateDirectory(folder);
        File.WriteAllText(Path.Combine(folder, "plugin.json"), old);
        File.WriteAllText(Path.Combine(folder, "feature.json"), "{ \"feature\": \"daily-checkin\" }");
        var store = new PluginStore(root, App);
        var listed = store.LoadAll().Single();
        Assert.True(listed.IsOutdated && !listed.IsUsable);
        Assert.Equal("Daily check-in", listed.Name);

        var updated = store.Install(Package(dir, new() { ["plugin.json"] = Utf8(CheckInManifest()), ["DailyCheckIn.dll"] = File.ReadAllBytes(BuiltCheckInDll()) }));
        Assert.True(updated.IsUsable && updated.IsCode);
        Assert.Sequence(new[] { "DailyCheckIn.dll", "plugin.json" }, Directory.GetFiles(updated.Directory).Select(Path.GetFileName).OrderBy(x => x));
    }

    [Test]
    public void OnlyRealPluginAssembliesAreAccepted()
    {
        static string RejectDll(byte[] bytes)
        {
            try
            {
                PluginFormat.ValidatePluginAssembly(bytes, "Thing.dll");
            }
            catch (PluginException ex)
            {
                return ex.Message;
            }
            throw new AssertionException("Expected the dll to be refused.");
        }

        PluginFormat.ValidatePluginAssembly(File.ReadAllBytes(BuiltCheckInDll()), "DailyCheckIn.dll");
        Assert.True(RejectDll(Utf8("MZ but not really a program")).Contains("isn't"));
        Assert.True(RejectDll(new byte[4096]).Contains("isn't"));
        // A real .NET assembly that wasn't built against the plugin API (this test project).
        Assert.True(RejectDll(File.ReadAllBytes(typeof(CodePluginTests).Assembly.Location)).Contains("doesn't use the plugin API"));
    }

    [Test]
    public void CodePackagesKeepTheirLibrariesAndThemesDont()
    {
        var dir = TempDir();
        var dll = File.ReadAllBytes(BuiltCheckInDll());
        var (_, code) = PluginFormat.ReadPackage(Package(dir, new()
        {
            ["plugin.json"] = Utf8(CheckInManifest()),
            ["DailyCheckIn.dll"] = dll,
            ["Helper.dll"] = new byte[] { 1, 2, 3 },
            ["readme.txt"] = Utf8("hi"),
            ["sub/Other.dll"] = new byte[] { 4 },
        }), App);
        Assert.Sequence(new[] { "DailyCheckIn.dll", "Helper.dll", "plugin.json" }, code.Keys.OrderBy(k => k, StringComparer.Ordinal));

        var theme = """
            { "format": "dayboard-plugin", "formatVersion": 1, "id": "test.theme.x", "name": "X", "version": "1",
              "kind": "theme", "entry": "theme.json" }
            """;
        var (_, themeFiles) = PluginFormat.ReadPackage(Package(dir, new()
        {
            ["plugin.json"] = Utf8(theme),
            ["theme.json"] = Utf8("{ \"light\": { \"Accent\": \"#FF336699\" } }"),
            ["Helper.dll"] = dll,
        }), App);
        Assert.Sequence(new[] { "plugin.json", "theme.json" }, themeFiles.Keys.OrderBy(k => k, StringComparer.Ordinal));
    }

    [Test]
    public void TheDailyCheckInPluginIsComplete()
    {
        var m = PluginFormat.ParseManifest(CheckInManifest(), App);
        Assert.Equal(CheckInId, m.Id); // the same id as in DayBoard 1.2, so its tick and its data carry over
        Assert.Equal(PluginKind.Code, m.Kind);
        Assert.Equal("DailyCheckIn.dll", m.Entry);
        Assert.Equal("1.3.0", m.MinAppVersion);
        Assert.True(Version.Parse(m.Version) >= new Version(2, 0));
        try
        {
            PluginFormat.ParseManifest(CheckInManifest(), new Version(1, 2, 0));
            throw new AssertionException("DayBoard 1.2 should refuse it.");
        }
        catch (PluginException ex)
        {
            Assert.True(ex.Message.Contains("1.3.0"), ex.Message);
        }

        // The Release build packs it; a Debug-only build has no package yet.
        var packed = Path.Combine(Path.GetDirectoryName(BuiltCheckInDll())!, "DailyCheckIn.dayboard-plugin");
        if (File.Exists(packed))
        {
            var (manifest, files) = PluginFormat.ReadPackage(packed, App);
            Assert.Equal(CheckInId, manifest.Id);
            Assert.Sequence(new[] { "DailyCheckIn.dll", "plugin.json" }, files.Keys.OrderBy(k => k, StringComparer.Ordinal));
        }
    }

    // ------------------------------------------------------------------ storage

    [Test]
    public void PluginStorageIsPerPluginAndPersists()
    {
        var db = Path.Combine(TempDir(), "t.db");
        using (var repo = new SqliteRepository(db))
        {
            var data = new PluginDataStore(repo);
            data.Set("a.plugin.one", "x:1", "one", Now);
            data.Set("a.plugin.one", "x:2", "two", Now);
            data.Set("a.plugin.one", "x%_", "wild", Now);
            data.Set("a.plugin.one", "y", "why", Now);
            data.Set("a.plugin.two", "x:1", "other", Now);
            Assert.Equal("one", data.Get("a.plugin.one", "x:1"));
            Assert.Equal("other", data.Get("a.plugin.two", "x:1"));
            Assert.Sequence(new[] { "x%_", "x:1", "x:2" }, data.GetAll("a.plugin.one", "x").Keys.OrderBy(k => k, StringComparer.Ordinal));
            Assert.Sequence(new[] { "x%_" }, data.GetAll("a.plugin.one", "x%").Keys); // a prefix, not a pattern
            data.Set("a.plugin.one", "x:2", null, Now);
            Assert.Equal(null, data.Get("a.plugin.one", "x:2"));
            Assert.Throws<ArgumentException>(() => data.Set("a.plugin.one", "", "v", Now));
            Assert.Throws<ArgumentException>(() => data.Set("a.plugin.one", new string('k', 201), "v", Now));
            Assert.Throws<ArgumentException>(() => data.Set("a.plugin.one", "big", new string('v', PluginDataStore.MaxValueLength + 1), Now));
        }
        using (var repo = new SqliteRepository(db))
        {
            var data = new PluginDataStore(repo);
            Assert.Equal(3, data.Count("a.plugin.one"));
            Assert.Equal("why", data.Get("a.plugin.one", "y"));
        }
    }

    [Test]
    public void CheckInsFromDayBoard12MoveIntoThePluginsStorage()
    {
        var db = Path.Combine(TempDir(), "old.db");
        Guid taskId;
        using (var repo = new SqliteRepository(db))
        {
            var p = new Planning.Planner(repo, new Time.ManualClock(Now), () => new AppSettings());
            taskId = p.AddTask(new TaskItem { Title = "Kept", ScheduledDate = Today }).Id;
        }
        // Turn it back into a DayBoard 1.2 database with three check-ins, one with damaged tags.
        using (var conn = new SqliteConnection($"Data Source={db};Pooling=False"))
        {
            conn.Open();
            using var cmd = conn.CreateCommand();
            cmd.CommandText = """
                DROP TABLE plugin_data;
                INSERT INTO checkins (date, mood, color, tags_json, note, updated_at) VALUES
                    ('2026-10-27', 4, '#7A9A6B', '["calm","long walk"]', 'Walked by the canal.' || char(10) || 'Felt "good".', '2026-10-27T21:00:00.0000000'),
                    ('2026-10-26', NULL, NULL, '["tired"]', '', '2026-10-26T22:15:00.0000000'),
                    ('2026-10-25', 2, NULL, 'not json', 'Rainy.', '2026-10-25T20:00:00.0000000');
                PRAGMA user_version = 2;
                """;
            cmd.ExecuteNonQuery();
        }
        using (var repo = new SqliteRepository(db))
        {
            var data = new PluginDataStore(repo);
            Assert.Equal(3, data.Count(CheckInId));
            var store = new CheckInStore(new Storage(data, CheckInId));
            var c = Assert.NotNull(store.Get(Today));
            Assert.Equal(4, c.Mood);
            Assert.Equal("#7A9A6B", c.Color);
            Assert.Sequence(new[] { "calm", "long walk" }, c.Tags);
            Assert.Equal("Walked by the canal.\nFelt \"good\".", c.Note);
            Assert.Equal(Now, c.UpdatedAt);
            Assert.Sequence(new[] { "tired" }, store.Get(Today.AddDays(-1))!.Tags);
            Assert.Equal(null, store.Get(Today.AddDays(-1))!.Mood);
            Assert.Equal(0, store.Get(Today.AddDays(-2))!.Tags.Count); // damaged tags are dropped, the rest is kept
            Assert.Equal("Rainy.", store.Get(Today.AddDays(-2))!.Note);

            // The old table is left alone, so DayBoard 1.2 still has its copy.
            using var cmd = repo.Connection.CreateCommand();
            cmd.CommandText = "SELECT COUNT(*) FROM checkins;";
            Assert.Equal(3L, (long)cmd.ExecuteScalar()!);
            var p = new Planning.Planner(repo, new Time.ManualClock(Now), () => new AppSettings());
            Assert.Equal("Kept", p.Store.FindTask(taskId)!.Title);
        }
    }

    [Test]
    public void EnabledPluginsKeepTheirDayBoard12SettingName()
    {
        using var repo = new SqliteRepository(Path.Combine(TempDir(), "s.db"));
        var settings = new SettingsStore(repo);
        repo.SetSetting("app", "{\"Theme\":\"Dark\",\"EnabledFeaturePlugins\":[\"dayboard.feature.daily-checkin\"]}"); // written by 1.2
        var s = settings.Load();
        Assert.Sequence(new[] { CheckInId }, s.EnabledPlugins);
        s.EnabledPlugins.Add("test.code.thing");
        settings.Save(s);
        Assert.True(repo.GetSetting("app")!.Contains("\"EnabledFeaturePlugins\":[\"dayboard.feature.daily-checkin\",\"test.code.thing\"]"));
        var clone = s.Clone();
        clone.EnabledPlugins.Clear();
        Assert.Equal(2, s.EnabledPlugins.Count);
    }

    // ------------------------------------------------------------------ Focus (built in since 1.4)

    [Test]
    public void FocusTimerSettingsCarryOverOnce()
    {
        using var repo = new SqliteRepository(Path.Combine(TempDir(), "f.db"));
        var data = new PluginDataStore(repo);
        var old = new AppSettings { PomodoroWorkMinutes = 50, PomodoroBreakMinutes = 10, PomodoroLongBreakMinutes = 30, PomodoroLongBreakEvery = 3, PomodoroAutoStartBreak = false };
        Assert.True(LegacySettings.CarryOverFocusTimer(data, old, Now));

        // Stored the way the Focus plugin reads it (host.Storage.GetJson uses the web defaults).
        var json = data.Get(LegacySettings.FocusPluginId, FocusSettings.Key)!;
        var read = System.Text.Json.JsonSerializer.Deserialize<FocusSettings>(json, new System.Text.Json.JsonSerializerOptions(System.Text.Json.JsonSerializerDefaults.Web))!;
        Assert.Equal(new FocusSettings { WorkMinutes = 50, BreakMinutes = 10, LongBreakMinutes = 30, LongBreakEvery = 3, AutoStartBreak = false }, read);

        // Once Focus has its own settings, they're left alone.
        Assert.False(LegacySettings.CarryOverFocusTimer(data, new AppSettings(), Now));
        Assert.Equal(json, data.Get(LegacySettings.FocusPluginId, FocusSettings.Key));
    }

    [Test]
    public void FocusSettingsStayWithinLimits()
    {
        var n = new FocusSettings { WorkMinutes = 0, BreakMinutes = 500, LongBreakMinutes = -3, LongBreakEvery = 1 }.Normalized();
        Assert.Equal(new FocusSettings { WorkMinutes = 1, BreakMinutes = 60, LongBreakMinutes = 1, LongBreakEvery = 2 }, n);
        Assert.Equal(new FocusSettings(), new FocusSettings().Normalized());
        Assert.Equal("45m", FocusSettings.FormatMinutes(45));
        Assert.Equal("2h", FocusSettings.FormatMinutes(120));
        Assert.Equal("1h 30m", FocusSettings.FormatMinutes(90));
        Assert.Equal("0m", FocusSettings.FormatMinutes(0));
    }

    [Test]
    public void UntickedBuiltInPluginsAreRemembered()
    {
        using var repo = new SqliteRepository(Path.Combine(TempDir(), "b.db"));
        var settings = new SettingsStore(repo);
        var s = settings.Load();
        Assert.Equal(0, s.DisabledBuiltInPlugins.Count); // built-in plugins start ticked
        s.DisabledBuiltInPlugins.Add(LegacySettings.FocusPluginId);
        settings.Save(s);
        Assert.Sequence(new[] { LegacySettings.FocusPluginId }, settings.Load().DisabledBuiltInPlugins);
        var clone = s.Clone();
        clone.DisabledBuiltInPlugins.Clear();
        Assert.Equal(1, s.DisabledBuiltInPlugins.Count);
    }

    // ------------------------------------------------------------------ the Daily check-in's model

    [Test]
    public void CheckInStoreSavesLoadsAndRemoves()
    {
        var storage = new MemoryStorage();
        var store = new CheckInStore(storage);
        DateOnly? changed = null;
        store.Changed += (_, d) => changed = d;
        store.Save(new CheckIn
        {
            Date = Today, Mood = 4, Color = "#7a9a6b", Tags = { " calm ", "Calm", "#focused", "", "a  very   spaced tag" },
            Note = "Walked by the canal.\nFelt good.  \n",
        }, Now);
        Assert.Equal(Today, changed);
        store.Save(new CheckIn { Date = Today.AddDays(-1), Mood = 2, Tags = { "tired" } }, Now);
        store.Save(new CheckIn { Date = Today.AddDays(-2), Tags = { "calm" } }, Now);
        Assert.Equal(3, store.Count);
        Assert.Sequence(new[] { "calm", "a very spaced tag", "focused", "tired" }, store.UsedTags()); // most used first, then A–Z
        Assert.True(storage.Items["checkin:2026-10-27"].StartsWith("{\"mood\":4,\"color\":\"#7A9A6B\",\"tags\":[\"calm\",\"focused\",\"a very spaced tag\"]"),
            storage.Items["checkin:2026-10-27"]);

        var again = new CheckInStore(storage);
        var c = Assert.NotNull(again.Get(Today));
        Assert.Equal(4, c.Mood);
        Assert.Sequence(new[] { "calm", "focused", "a very spaced tag" }, c.Tags);
        Assert.Equal("Walked by the canal.\nFelt good.", c.Note);
        Assert.Equal(Now, c.UpdatedAt);
        Assert.Equal(2, again.Between(Today.AddDays(-1), Today).Count);

        // Changing a returned copy doesn't change the store; clearing everything removes the day.
        c.Mood = 1;
        Assert.Equal(4, again.Get(Today)!.Mood);
        again.Save(new CheckIn { Date = Today.AddDays(-1) }, Now);
        Assert.Equal(null, again.Get(Today.AddDays(-1)));
        Assert.False(storage.Items.ContainsKey("checkin:2026-10-26"));
        again.Save(new CheckIn { Date = Today, Mood = 9 }, Now); // out of range: not a mood
        Assert.Equal(null, again.Get(Today));

        // Damaged or foreign keys are skipped, never fatal.
        storage.Items["checkin:2026-10-01"] = "{ broken";
        storage.Items["checkin:someday"] = "{\"mood\":3}";
        Assert.Equal(1, new CheckInStore(storage).Count);
    }

    [Test]
    public void ExportsTheJournalAsMarkdown()
    {
        var en = CultureInfo.GetCultureInfo("en-GB");
        var md = JournalExporter.ToMarkdown(new[]
        {
            new CheckIn { Date = Today, Mood = 5, Color = "#7A9A6B", Tags = { "calm", "social" }, Note = "Dinner with friends.\n# not a heading" },
            new CheckIn { Date = Today.AddDays(-1), Mood = 2 },
            new CheckIn { Date = Today.AddDays(-2) },
        }, CheckInOptions.ColorName, en);
        Assert.Equal(
            "# DayBoard journal\n\n" +
            "## Monday 26 October 2026\n\nFeeling: Low (2/5)\n\n" +
            "## Tuesday 27 October 2026\n\nFeeling: Great (5/5) · Colour: Sage · Tags: calm, social\n\nDinner with friends.\n\\# not a heading\n",
            md);
    }

    [Test]
    public void CheckInOptionsAreTheSameAsInDayBoard12()
    {
        Assert.Equal(8, CheckInOptions.Colors.Count);
        Assert.Equal("Sage", CheckInOptions.ColorName("#7a9a6b"));
        Assert.Equal(null, CheckInOptions.ColorName("#123456"));
        Assert.Sequence(new[] { "calm", "focused", "tired", "stressed", "social", "active", "grateful", "anxious" }, CheckInOptions.Tags);
    }

    private sealed class MemoryStorage : IPluginStorage
    {
        public Dictionary<string, string> Items { get; } = new(StringComparer.Ordinal);

        public string? Get(string key) => Items.GetValueOrDefault(key);

        public IReadOnlyDictionary<string, string> GetAll(string prefix = "") =>
            Items.Where(kv => kv.Key.StartsWith(prefix, StringComparison.Ordinal)).ToDictionary(kv => kv.Key, kv => kv.Value);

        public void Set(string key, string? value)
        {
            if (value is null) Items.Remove(key);
            else Items[key] = value;
        }
    }

    /// <summary>The database storage as the app hands it to a plugin.</summary>
    private sealed class Storage(PluginDataStore data, string pluginId) : IPluginStorage
    {
        public string? Get(string key) => data.Get(pluginId, key);
        public IReadOnlyDictionary<string, string> GetAll(string prefix = "") => data.GetAll(pluginId, prefix);
        public void Set(string key, string? value) => data.Set(pluginId, key, value, Now);
    }
}
