using DayBoard.Core.Export;
using DayBoard.Core.Models;
using DayBoard.Core.Recurrence;
using DayBoard.Core.Stats;

namespace DayBoard.Core.Tests;

public class ExportAndStatsTests
{
    [Test]
    public void JsonRoundTrip()
    {
        var f = new Fixture();
        var cat = new Category { Name = "Home", Color = "#112233", Icon = "Home24" };
        f.Planner.SaveCategory(cat);
        f.Planner.AddTask(new TaskItem
        {
            Title = "Gym", ScheduledDate = f.Today, StartTime = new TimeOnly(7, 30), Priority = Priority.High, IsUrgent = true,
            CategoryId = cat.Id, EstimateMinutes = 45, Subtasks = { new Subtask { Title = "Warm up", IsDone = true } },
        }, new RepeatPattern { Kind = RepeatKind.Weekdays });
        var json = JsonPorter.Export(f.Store.Snapshot(), f.Clock.Now);
        Assert.True(json.Contains("\"format\": \"DayBoard\""));
        Assert.True(json.Contains("\"priority\": \"high\""));

        var data = JsonPorter.Import(json);
        Assert.Equal(f.Store.Tasks.Count, data.Tasks.Count);
        Assert.Equal(1, data.Series.Count);
        var gym = data.Tasks.First(t => t.ScheduledDate == f.Today);
        Assert.Equal(new TimeOnly(7, 30), gym.StartTime);
        Assert.True(gym.Subtasks[0].IsDone);

        var g = new Fixture();
        g.Planner.Import(data);
        Assert.Equal(f.Store.Tasks.Count, g.Store.Tasks.Count);
        Assert.Equal("FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR", g.Store.Series.Single().RRule);
        Assert.Equal("#112233", g.Store.Categories.Single().Color);
    }

    [Test]
    public void JsonImportRejectsOtherFiles()
    {
        Assert.Throws<FormatException>(() => JsonPorter.Import("{\"hello\": 1}"));
        Assert.Throws<FormatException>(() => JsonPorter.Import("not json"));
        Assert.Throws<FormatException>(() => JsonPorter.Import("{\"format\":\"DayBoard\",\"version\":99}"));
    }

    [Test]
    public void CsvQuotesAndGuardsFormulas()
    {
        Assert.Equal("plain", CsvExporter.Quote("plain"));
        Assert.Equal("\"a,b\"", CsvExporter.Quote("a,b"));
        Assert.Equal("\"say \"\"hi\"\"\"", CsvExporter.Quote("say \"hi\""));
        Assert.Equal("'=SUM(A1)", CsvExporter.Quote("=SUM(A1)"));
        Assert.Equal("-5", CsvExporter.Quote("-5"));

        var f = new Fixture();
        f.Planner.AddTask(new TaskItem { Title = "Line\nbreak, comma", ScheduledDate = f.Today });
        var csv = CsvExporter.Export(f.Store.Snapshot());
        Assert.True(csv.StartsWith("Id,Title,Notes"));
        Assert.True(csv.Contains("\"Line\nbreak, comma\""));
    }

    [Test]
    public void CompletionStats()
    {
        var f = new Fixture(new DateTime(2026, 10, 19, 9, 0, 0)); // Monday
        var a = f.Planner.AddTask(new TaskItem { Title = "A", ScheduledDate = f.Today, Priority = Priority.High, EstimateMinutes = 30 });
        var b = f.Planner.AddTask(new TaskItem { Title = "B", ScheduledDate = f.Today, Priority = Priority.High });
        var c = f.Planner.AddTask(new TaskItem { Title = "C", ScheduledDate = f.Today, Priority = Priority.Low });
        f.Planner.SetDone(a.Id, true);
        f.Planner.LogFocusTime(a.Id, 25);

        f.Clock.Now = new DateTime(2026, 10, 20, 9, 0, 0);
        f.Planner.RunDailyMaintenance(); // B and C roll to Tuesday
        f.Planner.SetDone(b.Id, true);

        f.Clock.Now = new DateTime(2026, 10, 22, 9, 0, 0);
        f.Planner.RunDailyMaintenance(); // C rolls again (Tue -> Thu)

        var byDay = StatsService.CompletionsByDay(f.Store.Tasks, new DateOnly(2026, 10, 1), new DateOnly(2026, 10, 31));
        Assert.Equal(1, byDay[new DateOnly(2026, 10, 19)]);
        Assert.Equal(1, byDay[new DateOnly(2026, 10, 20)]);

        var week = new DateOnly(2026, 10, 19);
        var rates = StatsService.RatesByPriority(f.Store.Tasks, f.Store.Events, week, week.AddDays(6), f.Planner.Today);
        var high = rates.Single(r => r.Label == "High");
        Assert.Equal(2, high.Done);
        Assert.Equal(3, high.Total); // A done, B done, B slipped once
        var low = rates.Single(r => r.Label == "Low");
        Assert.Equal(0, low.Done);
        Assert.Equal(2, low.Total); // C slipped twice
    }
}
