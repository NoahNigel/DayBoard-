using DayBoard.Core.Calendar;
using DayBoard.Core.Models;

namespace DayBoard.Core.Tests;

public class CalendarTests
{
    private static readonly TimeZoneInfo Amsterdam = TimeZoneInfo.FindSystemTimeZoneById("Europe/Amsterdam");

    private const string Feed = "BEGIN:VCALENDAR\r\n" +
        "VERSION:2.0\r\n" +
        "X-WR-CALNAME:Work\r\n" +
        "BEGIN:VTIMEZONE\r\nTZID:Europe/Amsterdam\r\nBEGIN:DAYLIGHT\r\nTZOFFSETFROM:+0100\r\nTZOFFSETTO:+0200\r\nDTSTART:19700329T020000\r\nRRULE:FREQ=YEARLY;BYMONTH=3;BYDAY=-1SU\r\nEND:DAYLIGHT\r\n" +
        "BEGIN:STANDARD\r\nTZOFFSETFROM:+0200\r\nTZOFFSETTO:+0100\r\nDTSTART:19701025T030000\r\nRRULE:FREQ=YEARLY;BYMONTH=10;BYDAY=-1SU\r\nEND:STANDARD\r\nEND:VTIMEZONE\r\n" +
        "BEGIN:VEVENT\r\nUID:a@x\r\nDTSTART;TZID=Europe/Amsterdam:20261022T090000\r\nDTEND;TZID=Europe/Amsterdam:20261022T100000\r\n" +
        "SUMMARY:Standup\\, daily\r\nLOCATION:Room 1\r\nRRULE:FREQ=WEEKLY;BYDAY=MO,TU,WE,TH,FR\r\nEXDATE;TZID=Europe/Amsterdam:20261023T090000\r\nEND:VEVENT\r\n" +
        "BEGIN:VEVENT\r\nUID:a@x\r\nRECURRENCE-ID;TZID=Europe/Amsterdam:20261026T090000\r\nDTSTART;TZID=Europe/Amsterdam:20261026T113000\r\n" +
        "DTEND;TZID=Europe/Amsterdam:20261026T120000\r\nSUMMARY:Standup (moved)\r\nEND:VEVENT\r\n" +
        "BEGIN:VEVENT\r\nUID:b@x\r\nDTSTART;VALUE=DATE:20261024\r\nDTEND;VALUE=DATE:20261026\r\nSUMMARY:Weekend trip\r\nEND:VEVENT\r\n" +
        "BEGIN:VEVENT\r\nUID:c@x\r\nDTSTART:20261022T130000Z\r\nDTEND:20261022T133000Z\r\nSUMMARY:Call with a very long title that is folded across\r\n  lines\r\nEND:VEVENT\r\n" +
        "BEGIN:VEVENT\r\nUID:d@x\r\nDTSTART:20261023T080000Z\r\nSUMMARY:Cancelled thing\r\nSTATUS:CANCELLED\r\nEND:VEVENT\r\n" +
        "END:VCALENDAR\r\n";

    [Test]
    public void ParsesAndExpandsFeed()
    {
        var cal = IcsCalendar.Parse(Feed);
        Assert.Equal("Work", cal.Name);
        var occ = CalendarExpander.Expand(cal, new DateTime(2026, 10, 22), new DateTime(2026, 10, 29), Amsterdam);
        var got = occ.Select(o => $"{o.Start:MM-dd HH:mm} {o.Title}").ToList();
        Assert.Sequence(new[]
        {
            "10-22 09:00 Standup, daily",
            "10-22 15:00 Call with a very long title that is folded across lines",
            "10-24 00:00 Weekend trip",
            "10-26 11:30 Standup (moved)",
            "10-27 09:00 Standup, daily",
            "10-28 09:00 Standup, daily",
        }, got);
        var trip = occ.Single(o => o.Title == "Weekend trip");
        Assert.True(trip.IsAllDay);
        Assert.True(trip.CoversDate(new DateOnly(2026, 10, 25)));
        Assert.False(trip.CoversDate(new DateOnly(2026, 10, 26)));
        Assert.Equal("Room 1", occ[0].Location);
        Assert.Equal(TimeSpan.FromHours(1), occ[0].End - occ[0].Start);
    }

    [Test]
    public void FallsBackToFeedTimeZoneDefinition()
    {
        var feed = Feed.Replace("Europe/Amsterdam", "My Custom Zone");
        var cal = IcsCalendar.Parse(feed);
        var occ = CalendarExpander.Expand(cal, new DateTime(2026, 10, 22), new DateTime(2026, 10, 28), TimeZoneInfo.Utc);
        var standups = occ.Where(o => o.Title.StartsWith("Standup, daily")).Select(o => o.Start.ToString("MM-dd HH:mm")).ToList();
        // 09:00 summer time (+2) => 07:00 UTC; after 25 Oct winter time (+1) => 08:00 UTC.
        Assert.Sequence(new[] { "10-22 07:00", "10-27 08:00" }, standups);
    }

    [Test]
    public void ResolvesWindowsAndPrefixedZoneIds()
    {
        var r = new TimeZoneResolver(new Dictionary<string, IcsTimeZone>(), TimeZoneInfo.Utc);
        Assert.NotNull(r.FindSystemZone("W. Europe Standard Time"));
        Assert.NotNull(r.FindSystemZone("/mozilla.org/20050126_1/Europe/Amsterdam"));
        Assert.Equal(new DateTime(2026, 7, 1, 7, 0, 0), r.WallToUtc(new DateTime(2026, 7, 1, 9, 0, 0), "W. Europe Standard Time"));
    }

    [Test]
    public void CountAndUntilOnTimedEvents()
    {
        var feed = "BEGIN:VCALENDAR\r\nBEGIN:VEVENT\r\nUID:z\r\nDTSTART:20261001T100000Z\r\nDURATION:PT30M\r\nRRULE:FREQ=DAILY;UNTIL=20261003T100000Z\r\nSUMMARY:U\r\nEND:VEVENT\r\n" +
                   "BEGIN:VEVENT\r\nUID:y\r\nDTSTART:20261001T120000Z\r\nDURATION:PT1H\r\nRRULE:FREQ=WEEKLY;COUNT=2\r\nSUMMARY:C\r\nEND:VEVENT\r\nEND:VCALENDAR";
        var occ = CalendarExpander.Expand(IcsCalendar.Parse(feed), new DateTime(2026, 9, 1), new DateTime(2026, 12, 1), TimeZoneInfo.Utc);
        Assert.Equal(3, occ.Count(o => o.Title == "U"));
        Assert.Equal(2, occ.Count(o => o.Title == "C"));
        Assert.Equal(TimeSpan.FromMinutes(30), occ.First(o => o.Title == "U").End - occ.First(o => o.Title == "U").Start);
    }

    [Test]
    public void ParsesDurations()
    {
        Assert.True(IcsCalendar.TryParseDuration("PT1H30M", out var a));
        Assert.Equal(TimeSpan.FromMinutes(90), a);
        Assert.True(IcsCalendar.TryParseDuration("P1D", out var b));
        Assert.Equal(TimeSpan.FromDays(1), b);
        Assert.True(IcsCalendar.TryParseDuration("-PT15M", out var c));
        Assert.Equal(TimeSpan.FromMinutes(-15), c);
        Assert.True(IcsCalendar.TryParseDuration("P2W", out var d));
        Assert.Equal(TimeSpan.FromDays(14), d);
        Assert.False(IcsCalendar.TryParseDuration("1H", out _));
    }

    [Test]
    public void QuotedParametersAndEscapes()
    {
        var p = IcsReader.ParseLine("ATTENDEE;CN=\"Doe, Jane\";ROLE=REQ-PARTICIPANT:mailto:jane@example.com");
        Assert.Equal("Doe, Jane", p!.Param("CN"));
        Assert.Equal("mailto:jane@example.com", p.Value);
        Assert.Equal("a,b;c\\d\ne", IcsReader.UnescapeText("a\\,b\\;c\\\\d\\ne"));
    }

    [Test]
    public void WritesTasksAsEvents()
    {
        var cat = new Category { Name = "Work" };
        var tasks = new[]
        {
            new TaskItem { Title = "Plan, review; ship", ScheduledDate = new DateOnly(2026, 10, 22), StartTime = new TimeOnly(10, 0), EstimateMinutes = 45, CategoryId = cat.Id, Priority = Priority.High },
            new TaskItem { Title = "All-day thing", ScheduledDate = new DateOnly(2026, 10, 23), Notes = new string('x', 200) + "\nsecond line" },
            new TaskItem { Title = "Inbox only" },
        };
        var ics = IcsWriter.WriteTasks(tasks, id => id == cat.Id ? cat : null, new DateTime(2026, 10, 22, 12, 0, 0, DateTimeKind.Utc), 30, Amsterdam);
        Assert.True(ics.Contains("DTSTART:20261022T080000Z\r\n"));
        Assert.True(ics.Contains("DTEND:20261022T084500Z\r\n"));
        Assert.True(ics.Contains("DTSTART;VALUE=DATE:20261023\r\n"));
        Assert.True(ics.Contains("SUMMARY:Plan\\, review\\; ship\r\n"));
        Assert.True(ics.Contains("PRIORITY:1\r\n"));
        Assert.False(ics.Contains("Inbox only"));
        foreach (var line in ics.Split("\r\n"))
            Assert.True(System.Text.Encoding.UTF8.GetByteCount(line) <= 75, $"line too long: {line.Length}");

        var back = IcsCalendar.Parse(ics);
        Assert.Equal(2, back.Events.Count);
        Assert.Equal("Plan, review; ship", back.Events[0].Summary);
        var occ = CalendarExpander.Expand(back, new DateTime(2026, 10, 22), new DateTime(2026, 10, 24), Amsterdam);
        Assert.Equal(new DateTime(2026, 10, 22, 10, 0, 0), occ[0].Start);
    }
}
