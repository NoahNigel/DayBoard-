using DayBoard.Core.Models;
using DayBoard.Core.Planning;
using DayBoard.Core.Recurrence;
using DayBoard.Core.Time;
using DayBoard.Data;

namespace DayBoard.Core.Tests;

public class DataTests
{
    private static string TempDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), "dayboard-tests-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        return dir;
    }

    [Test]
    public void SqliteRoundTripsEverything()
    {
        var dir = TempDir();
        var db = Path.Combine(dir, "t.db");
        var clock = new ManualClock(new DateTime(2026, 10, 22, 9, 0, 0));
        var settings = new AppSettings();
        Guid taskId;
        using (var repo = new SqliteRepository(db))
        {
            var p = new Planner(repo, clock, () => settings);
            var cat = new Category { Name = "Work", Color = "#123456", Icon = "Briefcase24" };
            p.SaveCategory(cat);
            var t = p.AddTask(new TaskItem
            {
                Title = "Write, \"quoted\"", Notes = "multi\nline", Priority = Priority.High, IsUrgent = true, CategoryId = cat.Id,
                ScheduledDate = clock.Today(), StartTime = new TimeOnly(9, 30), EstimateMinutes = 45, DueDate = new DateOnly(2026, 10, 30),
                Subtasks = { new Subtask { Title = "a", IsDone = true }, new Subtask { Title = "b" } },
            });
            taskId = t.Id;
            p.AddTask(new TaskItem { Title = "Gym", ScheduledDate = clock.Today() }, new RepeatPattern { Kind = RepeatKind.Weekly, Days = { DayOfWeek.Monday } });
            p.LogFocusTime(t.Id, 25);
            var gymMon = p.Store.Tasks.First(x => x.Title == "Gym");
            p.DeleteTask(gymMon.Id, EditScope.ThisOccurrence);
            p.SetDone(t.Id, true);
            new SettingsStore(repo).Save(new AppSettings { CapacityHours = 7.5, Theme = ThemeMode.Dark });
        }

        using (var repo = new SqliteRepository(db))
        {
            var p = new Planner(repo, clock, () => settings);
            var t = Assert.NotNull(p.Store.FindTask(taskId));
            Assert.Equal("Write, \"quoted\"", t.Title);
            Assert.Equal("multi\nline", t.Notes);
            Assert.Equal(new TimeOnly(9, 30), t.StartTime);
            Assert.Equal(25, t.ActualMinutes);
            Assert.True(t.IsDone);
            Assert.Equal(clock.Now, t.CompletedAt);
            Assert.Sequence(new[] { "a", "b" }, t.Subtasks.Select(s => s.Title));
            Assert.True(t.Subtasks[0].IsDone);
            Assert.Equal("#123456", p.Store.Categories.Single().Color);
            var series = p.Store.Series.Single();
            Assert.Equal(1, series.ExceptionDates.Count);
            Assert.Equal(1, p.Store.Events.Count(e => e.Kind == TaskEventKind.Focus));
            Assert.True(p.Store.Events.All(e => e.Id > 0));
            var s = new SettingsStore(repo).Load();
            Assert.Equal(7.5, s.CapacityHours);
            Assert.Equal(ThemeMode.Dark, s.Theme);
        }
    }

    [Test]
    public void DailyBackupKeepsFourteen()
    {
        var dir = TempDir();
        var backups = Path.Combine(dir, "backups");
        using var repo = new SqliteRepository(Path.Combine(dir, "t.db"));
        new SettingsStore(repo).Save(new AppSettings());
        var start = new DateOnly(2026, 10, 1);
        for (int i = 0; i < 20; i++) BackupService.RunDailyIfNeeded(repo, start.AddDays(i), backups);
        Assert.Equal(null, BackupService.RunDailyIfNeeded(repo, start.AddDays(19), backups));
        var files = BackupService.List(backups);
        Assert.Equal(14, files.Count);
        Assert.Equal("dayboard-2026-10-20.db", files[0].Name);
        Assert.Equal("dayboard-2026-10-07.db", files[^1].Name);
        using var check = new SqliteRepository(files[0].FullName);
        Assert.True(check.GetSetting("app") is not null);
    }
}
