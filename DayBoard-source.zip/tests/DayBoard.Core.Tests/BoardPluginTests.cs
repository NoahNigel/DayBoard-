using DayBoard.Core.Models;
using DayBoard.Core.Stats;
using DayBoard.Data.Plugins;
using DayBoard.PluginShared;
using DayBoard.Plugins;
using Kanban.Model;
using Matrix.Model;
using WeeklyReview.Model;

namespace DayBoard.Core.Tests;

/// <summary>The Kanban, matrix and weekly review plugins (views of DayBoard until 1.5) and the move to them.</summary>
public class BoardPluginTests
{
    private static readonly DateOnly Today = new(2026, 10, 22); // Thursday
    private static readonly DateTime Noon = Today.ToDateTime(new TimeOnly(12, 0));

    private static PluginTask T(string title, DateOnly? date, PluginTaskStatus status = PluginTaskStatus.ToDo, DateTime? completedAt = null,
        bool urgent = false, string priority = "None") =>
        new(Guid.NewGuid(), title, date, null, null, status == PluginTaskStatus.Done, priority, null)
        {
            Status = status,
            CompletedAt = completedAt,
            IsUrgent = urgent,
        };

    /// <summary>A task as the host hands it to plugins (see PluginHostContext).</summary>
    private static PluginTask Snap(TaskItem t) =>
        new(t.Id, t.Title, t.ScheduledDate, t.StartTime, t.EstimateMinutes, t.IsDone, t.Priority.ToString(), null)
        {
            ActualMinutes = t.ActualMinutes,
            Status = (PluginTaskStatus)(int)t.Status,
            IsUrgent = t.IsUrgent,
            DueDate = t.DueDate,
            CompletedAt = t.CompletedAt,
            RolloverCount = t.RolloverCount,
        };

    private static List<string> Titles(IEnumerable<PluginTask> tasks) => tasks.Select(t => t.Title).ToList();

    [Test]
    public void BoardScopesMatchDayBoard15()
    {
        var weekStart = Boards.StartOfWeek(Today, DayOfWeek.Monday);
        Assert.Equal(new DateOnly(2026, 10, 19), weekStart);
        Assert.Equal(new DateOnly(2026, 10, 18), Boards.StartOfWeek(Today, DayOfWeek.Sunday));
        Assert.Equal(BoardScope.Week, Boards.ParseScope(null)); // the default
        Assert.Equal(BoardScope.All, Boards.ParseScope("All"));
        Assert.Equal(BoardScope.Week, Boards.ParseScope("Someday"));
        Assert.Equal(BoardScope.Week, Boards.ParseScope("7"));

        var overdue = T("Overdue", Today.AddDays(-7));
        var inbox = T("Inbox", null);
        var friday = T("Friday", Today.AddDays(1));
        Assert.True(Boards.InScope(overdue, BoardScope.Today, Today, DayOfWeek.Monday)); // overdue work always shows
        Assert.False(Boards.InScope(inbox, BoardScope.Week, Today, DayOfWeek.Monday));
        Assert.True(Boards.InScope(inbox, BoardScope.All, Today, DayOfWeek.Monday));
        Assert.False(Boards.InScope(friday, BoardScope.Today, Today, DayOfWeek.Monday));
        Assert.True(Boards.InScope(friday, BoardScope.Week, Today, DayOfWeek.Monday));
    }

    [Test]
    public void KanbanColumnsFollowStatusAndScope()
    {
        var tasks = new List<PluginTask>
        {
            T("Today", Today),
            T("Doing Friday", Today.AddDays(1), PluginTaskStatus.Doing),
            T("Overdue", Today.AddDays(-7)),
            T("Inbox", null),
            T("Next week", Today.AddDays(7)),
            T("Done Monday", Today.AddDays(-3), PluginTaskStatus.Done, Noon.AddDays(-3)),
            T("Done today", Today, PluginTaskStatus.Done, Noon),
            T("Done long ago", Today.AddDays(-20), PluginTaskStatus.Done, Noon.AddDays(-20)),
        };

        var (toDo, doing, done) = KanbanColumns.Sort(tasks, BoardScope.Today, Today, DayOfWeek.Monday);
        Assert.Sequence(new[] { "Today", "Overdue" }, Titles(toDo));
        Assert.Sequence(Array.Empty<string>(), Titles(doing));
        Assert.Sequence(new[] { "Done today" }, Titles(done));

        (toDo, doing, done) = KanbanColumns.Sort(tasks, BoardScope.Week, Today, DayOfWeek.Monday);
        Assert.Sequence(new[] { "Today", "Overdue" }, Titles(toDo));
        Assert.Sequence(new[] { "Doing Friday" }, Titles(doing));
        Assert.Sequence(new[] { "Done today", "Done Monday" }, Titles(done)); // newest first

        (toDo, _, done) = KanbanColumns.Sort(tasks, BoardScope.All, Today, DayOfWeek.Monday);
        Assert.Sequence(new[] { "Today", "Overdue", "Inbox", "Next week" }, Titles(toDo)); // the host's order is kept
        Assert.Sequence(new[] { "Done today", "Done Monday" }, Titles(done)); // the last two weeks
    }

    [Test]
    public void MatrixQuadrantsUseUrgencyAndPriority()
    {
        var tasks = new List<PluginTask>
        {
            T("Fire", Today, urgent: true, priority: "High"),
            T("Plan", Today, priority: "Medium"),
            T("Calls", Today, urgent: true, priority: "Low"),
            T("Browse", Today),
            T("Done fire", Today, PluginTaskStatus.Done, Noon, urgent: true, priority: "High"),
            T("Someday", null, priority: "High"),
        };
        List<string> In(bool urgent, bool important, BoardScope scope = BoardScope.Week) =>
            Titles(Quadrants.In(tasks, urgent, important, scope, Today, DayOfWeek.Monday));

        Assert.Sequence(new[] { "Fire" }, In(true, true));
        Assert.Sequence(new[] { "Plan" }, In(false, true));
        Assert.Sequence(new[] { "Calls" }, In(true, false));
        Assert.Sequence(new[] { "Browse" }, In(false, false));
        Assert.Sequence(new[] { "Plan", "Someday" }, In(false, true, BoardScope.All));
        Assert.True(tasks[1].IsImportant && !tasks[2].IsImportant);
    }

    [Test]
    public void WeeklyReviewIsBuiltFromTasksAndHistory()
    {
        var f = new Fixture(new DateTime(2026, 10, 19, 9, 0, 0)); // Monday
        var a = f.Planner.AddTask(new TaskItem { Title = "A", ScheduledDate = f.Today, Priority = Priority.High, EstimateMinutes = 30 });
        var b = f.Planner.AddTask(new TaskItem { Title = "B", ScheduledDate = f.Today, Priority = Priority.High });
        var c = f.Planner.AddTask(new TaskItem { Title = "C", ScheduledDate = f.Today, Priority = Priority.Low });
        f.Planner.SetDone(a.Id, true);
        f.Planner.LogFocusTime(a.Id, 25);

        f.Clock.Now = new DateTime(2026, 10, 20, 9, 0, 0);
        f.Planner.RunDailyMaintenance(); // B and C roll to Tuesday
        f.Planner.SetDone(b.Id, true);

        f.Clock.Now = new DateTime(2026, 10, 22, 9, 0, 0);
        f.Planner.RunDailyMaintenance(); // C rolls again (Tue -> Thu)

        var week = new DateOnly(2026, 10, 19);
        var tasks = f.Store.Tasks.Where(t => !t.IsSkipped).Select(Snap).ToList();
        var history = f.Store.Events
            .Select(e => new PluginTaskHistory(e.TaskId, (PluginHistoryKind)(int)e.Kind, e.At, e.FromDate, e.ToDate, e.Minutes))
            .Append(new PluginTaskHistory(a.Id, PluginHistoryKind.Focus, new DateTime(2026, 10, 26, 9, 0, 0), null, null, 50)) // next week
            .ToList();
        var overall = StatsService.Overall(f.Store.Tasks, f.Store.Events, week, week.AddDays(6), f.Planner.Today);
        var review = WeekReview.Build(tasks, history, new PluginCompletion(overall.Done, overall.Total), week);

        Assert.Equal(week.AddDays(6), review.WeekEnd);
        Assert.Sequence(new[] { "A", "B" }, Titles(review.Completed));
        Assert.Equal(3, review.Slipped.Count);
        Assert.True(review.Slipped.All(s => s.Kind == PluginHistoryKind.RolledOver));
        Assert.Sequence(new[] { week, week, week.AddDays(1) }, review.Slipped.Select(s => s.FromDate));
        Assert.Equal("C", review.MostRolledOver[0].Title);
        Assert.Equal(2, review.MostRolledOver[0].RolloverCount);
        Assert.Equal(25, review.FocusMinutes); // next week's 50 minutes don't count
        Assert.Equal(3, review.PlannedCount);
        Assert.Equal(30, review.CompletedEstimateMinutes);
        Assert.Equal(25, review.CompletedLoggedMinutes);
        Assert.Equal(0.4, review.CompletionRate); // 2 done of 5: A, B, and three slips
        Assert.Equal("1h 30m", WeekReview.FormatMinutes(90));
        Assert.Equal("0m", WeekReview.FormatMinutes(0));
        Assert.Equal(new DateOnly(2026, 10, 18), WeekReview.StartOfWeek(new DateOnly(2026, 10, 24), DayOfWeek.Sunday));
    }

    [Test]
    public void TheMovedViewsArePluginsForDayBoard16()
    {
        var root = RepoRoot();
        var folders = new Dictionary<string, string> { ["Matrix"] = "Matrix", ["Kanban"] = "Kanban", ["Review"] = "WeeklyReview" };
        Assert.Sequence(new[] { "Matrix", "Kanban", "Review" }, LegacySettings.MovedViews.Select(v => v.View));
        foreach (var view in LegacySettings.MovedViews)
        {
            var folder = Path.Combine(root, "plugins-src", folders[view.View]);
            var json = File.ReadAllText(Path.Combine(folder, "plugin.json"));
            var m = PluginFormat.ParseManifest(json, new Version(1, 6, 0));
            Assert.Equal(view.PluginId, m.Id);
            Assert.Equal(view.PluginName, m.Name);
            Assert.Equal(PluginKind.Code, m.Kind);
            Assert.Equal(3, m.ApiVersion);
            Assert.Equal("1.6.0", m.MinAppVersion);
            Assert.Equal(folders[view.View] + ".dll", m.Entry);
            try
            {
                PluginFormat.ParseManifest(json, new Version(1, 5, 0));
                throw new AssertionException($"DayBoard 1.5 should refuse {m.Name}.");
            }
            catch (PluginException ex)
            {
                Assert.True(ex.Message.Contains("1.6.0"), ex.Message);
            }

            // The Release build packs it; a Debug-only build has no package yet.
            var packed = Directory.Exists(Path.Combine(folder, "bin", "Release"))
                ? Directory.GetFiles(Path.Combine(folder, "bin", "Release"), "*.dayboard-plugin", SearchOption.AllDirectories).FirstOrDefault()
                : null;
            if (packed is null) continue;
            var (manifest, files) = PluginFormat.ReadPackage(packed, new Version(1, 6, 0));
            Assert.Equal(view.PluginId, manifest.Id);
            Assert.Sequence(new[] { m.Entry, "plugin.json" }, files.Keys.OrderBy(k => k, StringComparer.Ordinal));
        }
    }

    [Test]
    public void TheNoteAboutTheMovedViewsIsShownOnceToExistingUsers()
    {
        // A new install never sees it.
        var fresh = new AppSettings();
        Assert.Equal(null, LegacySettings.TakeViewsMovedNote(fresh, usedBefore: false, Array.Empty<string>()));
        Assert.True(fresh.SeenNotes.Contains(LegacySettings.ViewsMovedNoteId));
        Assert.Equal(null, LegacySettings.TakeViewsMovedNote(fresh, usedBefore: true, Array.Empty<string>()));

        // Someone who used DayBoard 1.5 sees it once.
        var existing = new AppSettings();
        var note = LegacySettings.TakeViewsMovedNote(existing, usedBefore: true, new[] { LegacySettings.FocusPluginId });
        Assert.True(note is not null && note.Contains("Kanban") && note.Contains("Settings › Plugins"), note);
        Assert.Equal(null, LegacySettings.TakeViewsMovedNote(existing, usedBefore: true, Array.Empty<string>()));
        Assert.True(existing.Clone().SeenNotes.Contains(LegacySettings.ViewsMovedNoteId));

        // Not when all three are there already.
        var all = LegacySettings.MovedViews.Select(v => v.PluginId).ToList();
        Assert.Equal(null, LegacySettings.TakeViewsMovedNote(new AppSettings(), usedBefore: true, all));
    }

    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir is not null && !File.Exists(Path.Combine(dir.FullName, "DayBoard.sln"))) dir = dir.Parent;
        return dir?.FullName ?? throw new AssertionException("Repository root not found.");
    }
}
