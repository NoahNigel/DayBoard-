using System.Reflection;

namespace DayBoard.Core.Tests;

/// <summary>Marks a test. Under xUnit (tests/DayBoard.Tests.xUnit) it's an xUnit fact instead.</summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class TestAttribute : Attribute { }

/// <summary>
/// Runs every [Test] without a test framework, so the tests also run where NuGet can't be reached:
/// dotnet run --project tests/DayBoard.Core.Tests [name filter]
/// </summary>
public static class Runner
{
    public static int Main(string[] args)
    {
        var filter = args.FirstOrDefault();
        var tests = typeof(Runner).Assembly.GetTypes()
            .SelectMany(t => t.GetMethods(BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance)
                .Where(m => m.GetCustomAttribute<TestAttribute>() is not null)
                .Select(m => (Type: t, Method: m)))
            .Where(x => filter is null || $"{x.Type.Name}.{x.Method.Name}".Contains(filter, StringComparison.OrdinalIgnoreCase))
            .OrderBy(x => x.Type.Name).ThenBy(x => x.Method.Name)
            .ToList();

        int passed = 0, failed = 0;
        foreach (var (type, method) in tests)
        {
            var name = $"{type.Name}.{method.Name}";
            try
            {
                var instance = method.IsStatic ? null : Activator.CreateInstance(type);
                method.Invoke(instance, null);
                passed++;
            }
            catch (TargetInvocationException tie)
            {
                failed++;
                var ex = tie.InnerException ?? tie;
                Console.WriteLine($"FAIL {name}\n     {ex.GetType().Name}: {ex.Message}");
                if (ex is not AssertionException) Console.WriteLine(ex.StackTrace);
            }
        }
        Console.WriteLine($"\n{passed} passed, {failed} failed, {tests.Count} total");
        return failed == 0 ? 0 : 1;
    }
}
