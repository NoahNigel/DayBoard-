using System.IO.Compression;
using System.Text;
using System.Text.RegularExpressions;
using DayBoard.Core.Models;
using DayBoard.Data;
using DayBoard.Data.Plugins;

namespace DayBoard.Core.Tests;

public class PluginTests
{
    private static readonly Version App = new(1, 4, 0);

    private const string Manifest = """
        {
          "format": "dayboard-plugin",
          "formatVersion": 1,
          "id": "test.theme.mint",
          "name": "Mint",
          "version": "1.0.0",
          "author": "Tester",
          "kind": "theme",
          "minAppVersion": "1.1.0",
          "entry": "theme.json"
        }
        """;

    private const string Theme = """
        { "light": { "Accent": "#2E8B57", "cardbackground": "#FFFFFF", "SomeFutureSlot": "#123456" },
          "dark": { "Accent": "#80CFA0" } }
        """;

    private static string TempDir()
    {
        var dir = Path.Combine(Path.GetTempPath(), "dayboard-plugins-" + Guid.NewGuid().ToString("N"));
        Directory.CreateDirectory(dir);
        return dir;
    }

    private static string Package(string dir, Dictionary<string, string> files, string name = "test.dayboard-plugin")
    {
        var path = Path.Combine(dir, name);
        if (File.Exists(path)) File.Delete(path);
        using var zip = ZipFile.Open(path, ZipArchiveMode.Create);
        foreach (var (entry, text) in files)
        {
            using var w = new StreamWriter(zip.CreateEntry(entry).Open(), new UTF8Encoding(false));
            w.Write(text);
        }
        return path;
    }

    private static string Edit(string json, string from, string to)
    {
        Assert.True(json.Contains(from), $"test setup: '{from}' not found");
        return json.Replace(from, to);
    }

    private static string RejectMessage(Dictionary<string, string> files)
    {
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        try
        {
            store.Install(Package(dir, files));
        }
        catch (PluginException ex)
        {
            Assert.Equal(0, Directory.Exists(store.Root) ? Directory.GetDirectories(store.Root).Length : 0);
            return ex.Message;
        }
        throw new AssertionException("Expected the plugin to be rejected");
    }

    private static string RepoRoot()
    {
        var dir = new DirectoryInfo(AppContext.BaseDirectory);
        while (dir is not null && !File.Exists(Path.Combine(dir.FullName, "DayBoard.sln"))) dir = dir.Parent;
        return dir?.FullName ?? throw new AssertionException("DayBoard.sln not found above the test binaries");
    }

    [Test]
    public void ThemeSlotsMatchTheAppPalettes()
    {
        foreach (var mode in new[] { "Light", "Dark" })
        {
            var xaml = File.ReadAllText(Path.Combine(RepoRoot(), "src", "DayBoard", "Themes", $"Palette.{mode}.xaml"));
            var keys = Regex.Matches(xaml, "<SolidColorBrush x:Key=\"DB\\.([A-Za-z0-9]+)\"").Select(m => m.Groups[1].Value).OrderBy(x => x);
            Assert.Sequence(keys, PluginFormat.ThemeSlots.OrderBy(x => x));
        }
    }

    [Test]
    public void BundledThemesAreValidCompleteAndReadable()
    {
        var folders = Directory.GetDirectories(Path.Combine(RepoRoot(), "plugins")).OrderBy(x => x)
            .Where(f => File.ReadAllText(Path.Combine(f, "plugin.json")).Contains("\"kind\": \"theme\"")).ToList();
        Assert.Sequence(new[] { "Classic", "FadedCherry", "Honey", "Sage", "Terracotta" }, folders.Select(Path.GetFileName));
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        foreach (var src in folders)
        {
            var name = Path.GetFileName(src);
            var path = Package(dir, Directory.GetFiles(src).ToDictionary(f => Path.GetFileName(f), File.ReadAllText), name + ".dayboard-plugin");
            var p = store.Install(path);
            Assert.Equal(PluginKind.Theme, p.Manifest!.Kind);
            Assert.True(p.Manifest.Description.Length > 0, $"{name} has no description");
            var t = Assert.NotNull(p.Theme);
            Assert.Equal(PluginFormat.ThemeSlots.Count, t.Light.Count);
            Assert.Equal(PluginFormat.ThemeSlots.Count, t.Dark.Count);
            Assert.Equal(PluginFormat.StockSwatches.Count, t.Swatches!.Count);
            Assert.True(t.PriorityLow.HasValue && t.PriorityMedium.HasValue && t.PriorityHigh.HasValue, $"{name} lacks priority colours");
            foreach (var (mode, pal, accent) in new[] { ("light", t.Light, t.AccentLight), ("dark", t.Dark, t.AccentDark) })
            {
                Assert.Equal(pal["Accent"], accent!.Value);
                ExpectContrast(name, mode, "OnAccent on Accent", pal["OnAccent"], pal["Accent"], 4.5);
                ExpectContrast(name, mode, "AccentText on CardBackground", pal["AccentText"], pal["CardBackground"], 4.5);
                ExpectContrast(name, mode, "TextPrimary on CardBackground", pal["TextPrimary"], pal["CardBackground"], 7);
                ExpectContrast(name, mode, "TextSecondary on WindowBackground", pal["TextSecondary"], pal["WindowBackground"], 4.5);
                // High priority and the accent must look different, or every button would read as urgent.
                Assert.True(Distance(t.PriorityHigh!.Value, pal["Accent"]) > 60, $"{name} {mode}: high priority looks like the accent");
            }
        }
        var all = store.LoadAll();
        Assert.Equal(folders.Count, all.Count); // ids are unique
        Assert.Equal(0xFFAD4A50u, all.Single(p => p.Id == "dayboard.theme.faded-cherry").Theme!.AccentLight);
    }

    [Test]
    public void StockLookIsDustyPlumAndReadable()
    {
        // Since 1.5 DayBoard's own colours are the "Dusty Plum" look, to match the logo. Same checks as the bundled themes.
        var pals = new[] { "Light", "Dark" }.ToDictionary(m => m, m =>
        {
            var xaml = File.ReadAllText(Path.Combine(RepoRoot(), "src", "DayBoard", "Themes", $"Palette.{m}.xaml"));
            return Regex.Matches(xaml, "<Color x:Key=\"DB\\.([A-Za-z0-9]+)Color\">#([0-9A-Fa-f]{8})</Color>")
                .ToDictionary(x => x.Groups[1].Value, x => Convert.ToUInt32(x.Groups[2].Value, 16));
        });
        Assert.Equal(StockLook.AccentLight, pals["Light"]["Accent"]);
        Assert.Equal(StockLook.AccentDark, pals["Dark"]["Accent"]);
        Assert.Equal(0xFFF5F1EAu, pals["Light"]["WindowBackground"]); // oat paper
        Assert.Equal(0xFF1F1D1Au, pals["Dark"]["WindowBackground"]); // warm charcoal
        Assert.Equal(PluginFormat.StockSwatches.Count, StockLook.Swatches.Count);
        foreach (var (mode, pal) in pals)
        {
            Assert.Equal(PluginFormat.ThemeSlots.Count, pal.Count);
            ExpectContrast("Stock", mode, "OnAccent on Accent", pal["OnAccent"], pal["Accent"], 4.5);
            ExpectContrast("Stock", mode, "AccentText on CardBackground", pal["AccentText"], pal["CardBackground"], 4.5);
            ExpectContrast("Stock", mode, "TextPrimary on CardBackground", pal["TextPrimary"], pal["CardBackground"], 7);
            ExpectContrast("Stock", mode, "TextSecondary on WindowBackground", pal["TextSecondary"], pal["WindowBackground"], 4.5);
            Assert.True(Distance(StockLook.PriorityHigh, pal["Accent"]) > 60, $"Stock {mode}: high priority looks like the accent");
        }
    }

    private static double Luminance(uint argb)
    {
        static double Ch(uint c)
        {
            var v = c / 255.0;
            return v <= 0.03928 ? v / 12.92 : Math.Pow((v + 0.055) / 1.055, 2.4);
        }
        return 0.2126 * Ch((argb >> 16) & 0xFF) + 0.7152 * Ch((argb >> 8) & 0xFF) + 0.0722 * Ch(argb & 0xFF);
    }

    private static void ExpectContrast(string theme, string mode, string what, uint fg, uint bg, double min)
    {
        double a = Luminance(fg), b = Luminance(bg);
        double ratio = (Math.Max(a, b) + 0.05) / (Math.Min(a, b) + 0.05);
        Assert.True(ratio >= min, $"{theme} {mode}: {what} contrast {ratio:0.00} is below {min}");
    }

    private static double Distance(uint a, uint b)
    {
        double dr = (int)((a >> 16) & 0xFF) - (int)((b >> 16) & 0xFF);
        double dg = (int)((a >> 8) & 0xFF) - (int)((b >> 8) & 0xFF);
        double db = (int)(a & 0xFF) - (int)(b & 0xFF);
        return Math.Sqrt(dr * dr + dg * dg + db * db);
    }

    [Test]
    public void InstallsListsUpdatesAndRemoves()
    {
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        Assert.Equal(0, store.LoadAll().Count);

        var p = store.Install(Package(dir, new() { ["plugin.json"] = Manifest, ["theme.json"] = Theme, ["README.txt"] = "ignored" }));
        Assert.True(p.IsUsable);
        Assert.Equal(0xFF2E8B57u, p.Theme!.Light["Accent"]);
        Assert.Equal(0xFFFFFFFFu, p.Theme.Light["CardBackground"]); // slot names are matched case-insensitively
        Assert.False(p.Theme.Light.ContainsKey("SomeFutureSlot"));  // unknown slots are ignored
        Assert.Equal(1, store.LoadAll().Count);
        Assert.False(File.Exists(Path.Combine(p.Directory, "README.txt")));

        var updated = store.Install(Package(dir, new()
        {
            ["plugin.json"] = Edit(Manifest, "\"1.0.0\"", "\"1.1.0\""),
            ["theme.json"] = Edit(Theme, "#2E8B57", "#000000"),
        }));
        Assert.Equal("1.1.0", updated.Manifest!.Version);
        Assert.Equal(0xFF000000u, updated.Theme!.Light["Accent"]);
        Assert.Equal(1, store.LoadAll().Count);
        Assert.Equal(1, Directory.GetDirectories(store.Root).Length); // no leftovers from the swap

        store.Remove("test.theme.mint");
        Assert.Equal(0, store.LoadAll().Count);
    }

    [Test]
    public void AcceptsAZippedFolder()
    {
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        var p = store.Install(Package(dir, new() { ["Mint/plugin.json"] = Manifest, ["Mint/theme.json"] = Theme }));
        Assert.Equal("test.theme.mint", p.Id);
    }

    [Test]
    public void RejectsInvalidPluginsWithReadableMessages()
    {
        Assert.True(RejectMessage(new() { ["theme.json"] = Theme }).Contains("no plugin.json"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "\"dayboard-plugin\"", "\"other\""), ["theme.json"] = Theme }).Contains("isn't a DayBoard plugin"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "\"formatVersion\": 1", "\"formatVersion\": 2"), ["theme.json"] = Theme }).Contains("newer version of DayBoard"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "\"1.1.0\"", "\"2.0\""), ["theme.json"] = Theme }).Contains("needs DayBoard 2.0 or newer"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "\"theme\"", "\"script\""), ["theme.json"] = Theme }).Contains("doesn't support \"script\" plugins"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "test.theme.mint", "../evil"), ["theme.json"] = Theme }).Contains("id is missing or invalid"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Edit(Manifest, "\"theme.json\"", "\"../theme.json\""), ["theme.json"] = Theme }).Contains("entry must name a file"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Manifest }).Contains("missing its theme.json"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Manifest, ["theme.json"] = Edit(Theme, "#80CFA0", "teal") }).Contains("dark › Accent"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Manifest, ["theme.json"] = "{ \"swatches\": [\"#FFFFFF\"], \"light\": { \"Accent\": \"#000000\" } }" }).Contains("exactly 12 colours"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = Manifest, ["theme.json"] = "{ }" }).Contains("doesn't set any colours"));
        Assert.True(RejectMessage(new() { ["plugin.json"] = "{ not json", ["theme.json"] = Theme }).Contains("couldn't be read"));

        var dir = TempDir();
        var notZip = Path.Combine(dir, "fake.dayboard-plugin");
        File.WriteAllText(notZip, "hello");
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        Assert.Throws<PluginException>(() => store.Install(notZip));

        var big = Package(dir, new() { ["plugin.json"] = Manifest, ["theme.json"] = "{\"light\":{\"Accent\":\"#000000\"}," + new string(' ', PluginFormat.MaxFileBytes) + "}" }, "big.dayboard-plugin");
        Assert.Throws<PluginException>(() => store.Install(big));
    }

    [Test]
    public void NeverWritesOutsideItsOwnFolder()
    {
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        store.Install(Package(dir, new() { ["plugin.json"] = Manifest, ["theme.json"] = Theme, ["../escape.json"] = "{}", ["sub/x.json"] = "{}" }));
        Assert.False(File.Exists(Path.Combine(dir, "escape.json")));
        Assert.Sequence(new[] { "test.theme.mint" }, Directory.GetDirectories(store.Root).Select(Path.GetFileName));
        Assert.Throws<ArgumentException>(() => store.Remove(".."));
        Assert.Throws<ArgumentException>(() => store.Remove("a/../../b"));
    }

    [Test]
    public void BrokenPluginsAreListedNotFatal()
    {
        var dir = TempDir();
        var store = new PluginStore(Path.Combine(dir, "plugins"), App);
        store.Install(Package(dir, new() { ["plugin.json"] = Manifest, ["theme.json"] = Theme }));
        File.WriteAllText(Path.Combine(store.Root, "test.theme.mint", "theme.json"), "{ broken");
        Directory.CreateDirectory(Path.Combine(store.Root, "stray-folder"));
        Directory.CreateDirectory(Path.Combine(store.Root, ".incoming-123"));

        var all = store.LoadAll();
        Assert.Equal(2, all.Count);
        Assert.True(all.All(p => !p.IsUsable));
        Assert.True(all.Single(p => p.Id == "test.theme.mint").Error!.Contains("couldn't be read"));
        Assert.True(all.Single(p => p.Id == "stray-folder").Error!.Contains("plugin.json is missing"));

        store.CleanUp();
        Assert.False(Directory.Exists(Path.Combine(store.Root, ".incoming-123")));
        store.Remove("stray-folder");
        Assert.Equal(1, store.LoadAll().Count);
    }

    [Test]
    public void ParsesColours()
    {
        Assert.True(PluginFormat.TryParseColor("#abc", out var a));
        Assert.Equal(0xFFAABBCCu, a);
        Assert.True(PluginFormat.TryParseColor(" #AD4A50 ", out var b));
        Assert.Equal(0xFFAD4A50u, b);
        Assert.True(PluginFormat.TryParseColor("#80F2EDE4", out var c));
        Assert.Equal(0x80F2EDE4u, c);
        Assert.False(PluginFormat.TryParseColor("AD4A50", out _));
        Assert.False(PluginFormat.TryParseColor("#GG0000", out _));
        Assert.False(PluginFormat.TryParseColor("#12345", out _));
        Assert.Equal("#AD4A50", PluginFormat.ToHex(0xFFAD4A50));
        Assert.Equal("#80F2EDE4", PluginFormat.ToHex(0x80F2EDE4));
    }

    [Test]
    public void PluginSettingsRoundTripAndOldSettingsStillLoad()
    {
        var dir = TempDir();
        using var repo = new SqliteRepository(Path.Combine(dir, "t.db"));
        var store = new SettingsStore(repo);
        repo.SetSetting("app", "{\"Theme\":\"Dark\",\"CapacityHours\":5}"); // written by DayBoard 1.0
        var old = store.Load();
        Assert.Equal(null, old.ThemePluginId);
        Assert.Equal(ThemeMode.Dark, old.Theme);

        old.ThemePluginId = "dayboard.theme.faded-cherry";
        store.Save(old);
        var back = store.Load();
        Assert.Equal("dayboard.theme.faded-cherry", back.ThemePluginId);
        Assert.Equal("dayboard.theme.faded-cherry", back.Clone().ThemePluginId);
    }
}
