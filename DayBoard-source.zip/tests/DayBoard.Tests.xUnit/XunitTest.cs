namespace DayBoard.Core.Tests;

/// <summary>Under xUnit, every [Test] in the shared test files is an xUnit fact.</summary>
[AttributeUsage(AttributeTargets.Method)]
public sealed class TestAttribute : Xunit.FactAttribute { }
