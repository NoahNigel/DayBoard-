"""
Builds DayBoard's logo: the open "focus arc", a swelling brush stroke on a soft violet rounded square.

Writes, next to this script: dayboard-logo.svg, dayboard-logo-small.svg (for 16-32 px), 512 and 1024 px PNGs and a
preview sheet. Writes the app's icons into src/DayBoard/Assets: DayBoard.ico (16-256 px, with 16-32 px drawn from the
small variant) and DayBoard.png (64 px, small variant, for the title bar and quick add).

Needs: pip install cairosvg pillow
"""
import io
import math
import os

import cairosvg
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
ASSETS = os.path.join(HERE, "..", "src", "DayBoard", "Assets")

BG = "#7B63A8"
FG = "#FFFFFF"


def mark_svg(wmin, wmax, rx=36):
    """The arc runs clockwise for 270 degrees from the top, from wmin to wmax wide, on a 160 grid."""
    fn = lambda t: wmin + (wmax - wmin) * t ** 0.9
    r, cx, cy, n = 38, 80, 80, 200
    outer, inner = [], []
    for k in range(n + 1):
        t = k / n
        a = math.radians(-90 + 270 * t)
        w = fn(t)
        outer.append(f"{cx + (r + w / 2) * math.cos(a):.2f} {cy + (r + w / 2) * math.sin(a):.2f}")
        inner.append(f"{cx + (r - w / 2) * math.cos(a):.2f} {cy + (r - w / 2) * math.sin(a):.2f}")
    d = "M" + "L".join(outer) + "L" + "L".join(reversed(inner)) + "Z"
    return (
        '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 160 160">'
        f'<rect width="160" height="160" rx="{rx}" fill="{BG}"/>'
        f'<path d="{d}" fill="{FG}"/>'
        f'<circle cx="80" cy="42" r="{fn(0) / 2:.2f}" fill="{FG}"/>'
        f'<circle cx="42" cy="80" r="{fn(1) / 2:.2f}" fill="{FG}"/>'
        "</svg>"
    )


def png(svg, size):
    data = cairosvg.svg2png(bytestring=svg.encode(), output_width=size, output_height=size)
    return Image.open(io.BytesIO(data)).convert("RGBA")


main = mark_svg(3, 22)
small = mark_svg(8, 24, rx=32)  # thicker start, so the arc survives at 16-32 px

with open(os.path.join(HERE, "dayboard-logo.svg"), "w") as f:
    f.write(main)
with open(os.path.join(HERE, "dayboard-logo-small.svg"), "w") as f:
    f.write(small)
png(main, 1024).save(os.path.join(HERE, "dayboard-logo-1024.png"))
png(main, 512).save(os.path.join(HERE, "dayboard-logo-512.png"))

sizes = [16, 20, 24, 32, 40, 48, 64, 128, 256]
imgs = [png(small if s <= 32 else main, s) for s in sizes]
imgs[-1].save(os.path.join(ASSETS, "DayBoard.ico"), format="ICO", sizes=[(s, s) for s in sizes], append_images=imgs[:-1])
png(small, 64).save(os.path.join(ASSETS, "DayBoard.png"))

# Preview sheet: every icon size, on a light and a dark background.
row = 300
width = sum(sizes) + 20 * (len(sizes) + 1)
sheet = Image.new("RGBA", (width, 2 * row), (245, 241, 234, 255))
sheet.paste(Image.new("RGBA", (width, row), (31, 29, 26, 255)), (0, row))
for top in (0, row):
    x = 20
    for s, im in zip(sizes[::-1], imgs[::-1]):
        sheet.paste(im, (x, top + row // 2 - s // 2), im)
        x += s + 20
sheet.save(os.path.join(HERE, "preview.png"))
print("done")
